-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: characters
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GSI_Atributs`
--

DROP TABLE IF EXISTS `GSI_Atributs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GSI_Atributs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Descrip` varchar(255) DEFAULT NULL,
  `Defecte` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GSI_Atributs`
--

LOCK TABLES `GSI_Atributs` WRITE;
/*!40000 ALTER TABLE `GSI_Atributs` DISABLE KEYS */;
/*!40000 ALTER TABLE `GSI_Atributs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GSI_HabAttr`
--

DROP TABLE IF EXISTS `GSI_HabAttr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GSI_HabAttr` (
  `HAB_ID` int(11) NOT NULL,
  `ATT_ID` int(11) NOT NULL,
  `Mult` decimal(10,0) NOT NULL,
  KEY `REL_HAB` (`HAB_ID`),
  KEY `REL_ATT` (`ATT_ID`),
  CONSTRAINT `REL_ATT` FOREIGN KEY (`ATT_ID`) REFERENCES `GSI_Atributs` (`ID`),
  CONSTRAINT `REL_HAB` FOREIGN KEY (`HAB_ID`) REFERENCES `GSI_Habilitats` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GSI_HabAttr`
--

LOCK TABLES `GSI_HabAttr` WRITE;
/*!40000 ALTER TABLE `GSI_HabAttr` DISABLE KEYS */;
/*!40000 ALTER TABLE `GSI_HabAttr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GSI_Habilitats`
--

DROP TABLE IF EXISTS `GSI_Habilitats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GSI_Habilitats` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) DEFAULT NULL,
  `Descrip` varchar(255) DEFAULT NULL,
  `Defecte` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Icon` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GSI_Habilitats`
--

LOCK TABLES `GSI_Habilitats` WRITE;
/*!40000 ALTER TABLE `GSI_Habilitats` DISABLE KEYS */;
/*!40000 ALTER TABLE `GSI_Habilitats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_BasicHab`
--

DROP TABLE IF EXISTS `LD_BasicHab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_BasicHab` (
  `LD_PJ` varchar(50) NOT NULL DEFAULT ' ',
  `LD_Nombre` varchar(50) NOT NULL DEFAULT ' ',
  `LD_Level` int(11) NOT NULL DEFAULT '1',
  `LD_Increment` decimal(10,2) NOT NULL DEFAULT '0.00',
  UNIQUE KEY `LD_PJ` (`LD_PJ`,`LD_Nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_BasicHab`
--

LOCK TABLES `LD_BasicHab` WRITE;
/*!40000 ALTER TABLE `LD_BasicHab` DISABLE KEYS */;
INSERT INTO `LD_BasicHab` VALUES ('Alaina','Lanzar',1,0.02),('Emilia','Lanzar',1,0.01),('Emilia','Nadar',1,0.05),('Emilia','Saltar',1,0.01),('Irma','Correr',1,0.01);
/*!40000 ALTER TABLE `LD_BasicHab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_HabPJ`
--

DROP TABLE IF EXISTS `LD_HabPJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_HabPJ` (
  `ID` int(11) NOT NULL,
  `LD_PJ` varchar(50) NOT NULL,
  `Nivel` int(11) NOT NULL,
  UNIQUE KEY `ID` (`ID`,`LD_PJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_HabPJ`
--

LOCK TABLES `LD_HabPJ` WRITE;
/*!40000 ALTER TABLE `LD_HabPJ` DISABLE KEYS */;
INSERT INTO `LD_HabPJ` VALUES (5,'Aduin',1);
/*!40000 ALTER TABLE `LD_HabPJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_Habilidades`
--

DROP TABLE IF EXISTS `LD_Habilidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_Habilidades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Descrip` varchar(255) NOT NULL DEFAULT '0',
  `Ata_DESTRE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_PERCEP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_AGILID` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_SABIDU` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_FUERZA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_INTELE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_CONSTI` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_DESTRE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_PERCEP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_AGILID` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_SABIDU` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_FUERZA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_INTELE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_CONSTI` decimal(10,2) NOT NULL DEFAULT '0.00',
  `FunctionType` varchar(50) NOT NULL,
  `Dif_TIPI` int(11) NOT NULL DEFAULT '0',
  `Cos_MANA` int(11) NOT NULL DEFAULT '0',
  `Cos_ENER` int(11) NOT NULL DEFAULT '0',
  `Icono` varchar(255) NOT NULL,
  `OnlyAta` tinyint(1) NOT NULL DEFAULT '0',
  `OnlyDef` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_Habilidades`
--

LOCK TABLES `LD_Habilidades` WRITE;
/*!40000 ALTER TABLE `LD_Habilidades` DISABLE KEYS */;
INSERT INTO `LD_Habilidades` VALUES (1,'Combate sin armas','Define tu destreza en combatir cuerpo a cuerpo tan solo con tus manos y el resto de tu anatomia',0.30,0.10,0.20,0.00,0.30,0.00,0.00,0.30,0.20,0.30,0.00,0.20,0.00,0.00,'Basic',0,0,2,'ability_warrior_bloodfrenzy',0,0),(2,'Golpe de espada (entrenamiento)','Sirve para incrementar tu destreza en el manejo de la espada',0.50,0.10,0.20,0.00,0.20,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,'Basic',0,0,2,'ability_meleedamage',0,0),(3,'Practicas de tiro con arco','Sirve para incrementar tu destreza en el tiro con arco',0.50,0.30,0.00,0.00,0.20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'Dificultad',10,0,1,'inv_weapon_bow_02',0,0),(4,'Espada corta - Desviar','Desvías el ataque con un hábil movimiento de muñeca.',0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.40,0.00,0.30,0.00,0.30,0.00,0.00,'Basic',0,0,5,'ability_dualwield',0,0),(5,'Espada corta - Toque ligero','Un suave estoque para desorientar al contrario',0.30,0.10,0.40,0.00,0.20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'Basic',0,0,5,'inv_weapon_shortblade_24',0,0);
/*!40000 ALTER TABLE `LD_Habilidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_PlayerPJ`
--

DROP TABLE IF EXISTS `LD_PlayerPJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_PlayerPJ` (
  `LD_Player` varchar(50) NOT NULL,
  `LD_PJ` varchar(50) NOT NULL,
  UNIQUE KEY `IDX_PlayerPJ` (`LD_PJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_PlayerPJ`
--

LOCK TABLES `LD_PlayerPJ` WRITE;
/*!40000 ALTER TABLE `LD_PlayerPJ` DISABLE KEYS */;
INSERT INTO `LD_PlayerPJ` VALUES ('DUT92','Aduin'),('SUBIGEMMA','Alaina'),('NIVEKZUELO','Artus'),('NUVALIA','Boingboing'),('BLUES','Colette'),('KIRADEC','Devilman'),('ZOIDBERG','Drzoidberg'),('LAKITU','Eadrig'),('KIRA','Eldoren'),('DESCHAIN','Emilia'),('KARIO','Eothan'),('NUVALIA','Estalaborro'),('KOIZORA','Gerd'),('DUT92','Hacedor'),('NUVALIA','Irma'),('KIRA','Jaqen'),('ZOIDBERG','Joseph'),('SUBIGEMMA','Liadrin'),('NUVALIA','Margot'),('SUBIGEMMA','Morticia'),('SUBIGEMMA','Tantaria'),('LEROY','Tomasa'),('TST5','Tstcinco'),('TST4','Tstcuatro'),('TST2','Tstdos'),('TST3','Tsttres'),('TST1','Tstuno'),('IVANCETUS','Vanya');
/*!40000 ALTER TABLE `LD_PlayerPJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SessionVars`
--

DROP TABLE IF EXISTS `LD_SessionVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SessionVars` (
  `LD_PJ` varchar(50) NOT NULL,
  `LD_INDEX` varchar(50) NOT NULL,
  `LD_VALUE` varchar(255) NOT NULL,
  `LD_TYPE` varchar(10) NOT NULL,
  `LD_DATEUP` bigint(14) NOT NULL,
  PRIMARY KEY (`LD_PJ`,`LD_INDEX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SessionVars`
--

LOCK TABLES `LD_SessionVars` WRITE;
/*!40000 ALTER TABLE `LD_SessionVars` DISABLE KEYS */;
INSERT INTO `LD_SessionVars` VALUES ('Aduin','AGILID','6','ATRIBUTO',20180426062832),('Aduin','APELLIDO','Lothoren','ROL',20180513212728),('Aduin','APP','A','ROL',0),('Aduin','Combate sin armas','5.4','HABILIDAD',0),('Aduin','CONSTI','8','ATRIBUTO',20180501140618),('Aduin','DESTRE','7','ATRIBUTO',20180501140613),('Aduin','DICE1MAX','10','DICE',0),('Aduin','DICE1MIN','1','DICE',20180519232532),('Aduin','DICE2MAX','6','DICE',20180519232532),('Aduin','DICE2MIN','1','DICE',20180519232528),('Aduin','ENER','29.4','ATRIBUTO',0),('Aduin','FUERZA','8','ATRIBUTO',20180513214234),('Aduin','Golpe de espada (entrenamiento)','81','HABILIDAD',0),('Aduin','HIST1','Proyecto de Paladin','ROL',20180513212728),('Aduin','HIST2','Proyecto de Paladin','ROL',20180513212728),('Aduin','INTELE','7','ATRIBUTO',20180501140603),('Aduin','MAGILID','0','ATRIBUTO',20190302000627),('Aduin','MANA','42','ATRIBUTO',0),('Aduin','MCONSTI','0','ATRIBUTO',20190302000627),('Aduin','MDESTRE','0','ATRIBUTO',20190302000627),('Aduin','MFUERZA','0','ATRIBUTO',20190302000627),('Aduin','MINTELE','0','ATRIBUTO',20190302000627),('Aduin','MPERCEP','0','ATRIBUTO',20190302000627),('Aduin','MSABIDU','0','ATRIBUTO',20190302000627),('Aduin','NOMBRE','Aduin','ROL',20180513212728),('Aduin','PATTR','6','ROL',20180513214240),('Aduin','PERCEP','7','ATRIBUTO',20180428153410),('Aduin','Practicas de tiro con arco','18.8','HABILIDAD',0),('Aduin','SABIDU','7','ATRIBUTO',20180501140548),('Aduin','SAY1',' ','SAY',20180519232532),('Aduin','SAY2',' ','SAY',20180519232556),('Aduin','SAY3',' ','SAY',20180519232555),('Aduin','VIDA','45.4','ATRIBUTO',20180609195556),('Alaina','AGILID','8','ATRIBUTO',20180426062832),('Alaina','APELLIDO','Burnett','ROL',20180513212728),('Alaina','APP','A','ROL',0),('Alaina','CONSTI','7','ATRIBUTO',20180501140618),('Alaina','DESTRE','8','ATRIBUTO',20180501140613),('Alaina','DICE1MAX','10','DICE',0),('Alaina','DICE1MIN','1','DICE',0),('Alaina','DICE2MAX','6','DICE',0),('Alaina','DICE2MIN','1','DICE',0),('Alaina','ENER','34.2','ATRIBUTO',0),('Alaina','FUERZA','7','ATRIBUTO',20180513214234),('Alaina','Golpe de espada (entrenamiento)','32.099999999999994','HABILIDAD',0),('Alaina','INTELE','7','ATRIBUTO',20180501140603),('Alaina','MAGILID','0','ATRIBUTO',20180810184310),('Alaina','MANA','42','ATRIBUTO',0),('Alaina','MCONSTI','0','ATRIBUTO',20180810184310),('Alaina','MDESTRE','0','ATRIBUTO',20180810184310),('Alaina','MFUERZA','0','ATRIBUTO',20180810184310),('Alaina','MINTELE','0','ATRIBUTO',20180810184310),('Alaina','MPERCEP','0','ATRIBUTO',20180810184310),('Alaina','MSABIDU','0','ATRIBUTO',20180810184310),('Alaina','NOMBRE','Alaina','ROL',20180526155846),('Alaina','PERCEP','7','ATRIBUTO',20180428153410),('Alaina','ROL','6','PATTR',20180526163806),('Alaina','SABIDU','7','ATRIBUTO',20180501140548),('Alaina','SAY1',' ','SAY',20180526163500),('Alaina','SAY2',' ','SAY',20180526163500),('Alaina','SAY3',' ','SAY',20180526161020),('Alaina','VIDA','41.8','ATRIBUTO',20180602200856),('Artus','AGILID','6','ATRIBUTO',20180428215636),('Artus','APELLIDO','Broudig','ROL',20180427201015),('Artus','APP','A','ROL',0),('Artus','CONSTI','5','ATRIBUTO',20180428215448),('Artus','DESTRE','7','ATRIBUTO',20180428215656),('Artus','DICE1MAX','10','DICE',20180513220809),('Artus','DICE1MIN','1','DICE',20180513215910),('Artus','DICE2MAX','6','DICE',20180513220809),('Artus','DICE2MIN','1','DICE',0),('Artus','EDAD','24','ROL',20180427201015),('Artus','ENER','27.5','ATRIBUTO',20180608210632),('Artus','Espada corta - Toque ligero','5.3','HABILIDAD',0),('Artus','FUERZA','6','ATRIBUTO',20180428215639),('Artus','Golpe de espada (entrenamiento)','10','HABILIDAD',0),('Artus','HIST1','Hijo de un Luthier, desde pequeño le han apasionado todo tipo de instrumentos aunque siempre ha tenido cierta predilección por las guitarras.\n\nJamás ha tocado un arma, pero tal y como están las cosas... El deber llama...','ROL',20180427201015),('Artus','HIST2','De complexión esbelta, su tono de piel más bien tirando a blanquecino, tiene un largo cabello negro y unas cejas y bigote poblados.','ROL',20180427201015),('Artus','INTELE','6','ATRIBUTO',20180428215647),('Artus','MAGILID','0','ATRIBUTO',20190302232641),('Artus','MANA','32.6','ATRIBUTO',20180608210632),('Artus','MCONSTI','0','ATRIBUTO',20190302232641),('Artus','MDESTRE','0','ATRIBUTO',20190302232641),('Artus','MFUERZA','0','ATRIBUTO',20190302232641),('Artus','MINTELE','0','ATRIBUTO',20190302232641),('Artus','MPERCEP','0','ATRIBUTO',20190302232641),('Artus','MSABIDU','0','ATRIBUTO',20190302232641),('Artus','NOMBRE','Artus ','ROL',20180427201015),('Artus','PATTR','0','ROL',20180428215656),('Artus','PERCEP','6','ATRIBUTO',20180428215505),('Artus','ROL','6','PATTR',20180428215441),('Artus','SABIDU','5','ATRIBUTO',20180428215448),('Artus','SAY1',' ','SAY',20180513215737),('Artus','SAY2',' ','SAY',20180513221023),('Artus','SAY3',' ','SAY',20180513231700),('Artus','VIDA','30','ATRIBUTO',20180608210632),('Colette','AGILID','7','ATRIBUTO',20180520143737),('Colette','APELLIDO','Agnincourt','ROL',20180427140251),('Colette','APP','A','ROL',0),('Colette','CONSTI','5','ATRIBUTO',20180427141029),('Colette','DESTRE','7','ATRIBUTO',20180520143801),('Colette','DICE1MAX','10','DICE',0),('Colette','DICE1MIN','1','DICE',0),('Colette','DICE2MAX','6','DICE',0),('Colette','DICE2MIN','1','DICE',0),('Colette','EDAD','17','ROL',20180427140251),('Colette','FUERZA','5','ATRIBUTO',20180427141029),('Colette','HIST1','Colette es una chica grajera común y corriente que gusta de ir al bosque cuando pueda. Apenas sabe usar el arco y se separó de su familia en el apocalipsis, terminó en el monasterio con los demás refugiados dejandose arrastrar en el montón','ROL',20180427140251),('Colette','HIST2','Es peliroja de ojos castaños y mal alimentada, grajera pobre.','ROL',20180427140251),('Colette','INTELE','5','ATRIBUTO',20180427141029),('Colette','MAGILID','0','ATRIBUTO',20180520142040),('Colette','MCONSTI','0','ATRIBUTO',20180520142040),('Colette','MDESTRE','0','ATRIBUTO',20180520142040),('Colette','MFUERZA','0','ATRIBUTO',20180520142040),('Colette','MINTELE','0','ATRIBUTO',20180520142040),('Colette','MPERCEP','0','ATRIBUTO',20180520142040),('Colette','MSABIDU','0','ATRIBUTO',20180520142040),('Colette','NOMBRE','Collete','ROL',20180427140251),('Colette','PATTR','0','ROL',20180520143807),('Colette','PERCEP','7','ATRIBUTO',20180520143807),('Colette','ROL','6','PATTR',20180520142052),('Colette','SABIDU','5','ATRIBUTO',20180427141029),('Colette','SAY1',' Hola','SAY',20180504163345),('Colette','SAY2',' ','SAY',20180504163345),('Colette','SAY3',' ','SAY',20180504163345),('Eadrig','DICE1MAX','10','DICE',20180502180653),('Eadrig','DICE1MIN','1','DICE',0),('Eadrig','DICE2MAX','20','DICE',20180502180724),('Eadrig','DICE2MIN','1','DICE',20180416081412),('Eadrig','MAGILID','0','ATRIBUTO',20180503161433),('Eadrig','MCONSTI','0','ATRIBUTO',20180503161433),('Eadrig','MDESTRE','0','ATRIBUTO',20180503161433),('Eadrig','MFUERZA','0','ATRIBUTO',20180503161433),('Eadrig','MINTELE','0','ATRIBUTO',20180503161433),('Eadrig','MPERCEP','0','ATRIBUTO',20180503161433),('Eadrig','MSABIDU','0','ATRIBUTO',20180503161433),('Eadrig','ROL','6','PATTR',20180502180521),('Eadrig','SAY1',' mira a la mujer loca gritando a su lado','SAY',20180502180704),('Eadrig','SAY2',' ','SAY',20180502180724),('Eadrig','SAY3',' ','SAY',20180502180644),('Emilia','AGILID','7','ATRIBUTO',20180506000810),('Emilia','APELLIDO','Anderson','ROL',20180427210102),('Emilia','APP','A','ROL',0),('Emilia','CONSTI','5','ATRIBUTO',20180501140618),('Emilia','DESTRE','7','ATRIBUTO',20180506000838),('Emilia','DICE1MAX','10','DICE',20180506001309),('Emilia','DICE1MIN','1','DICE',20180506001223),('Emilia','DICE2MAX','6','DICE',20180506001312),('Emilia','DICE2MIN','1','DICE',20180505234733),('Emilia','EDAD','25','ROL',20180427210102),('Emilia','ENER','0.1','ATRIBUTO',20180830201219),('Emilia','FUERZA','5','ATRIBUTO',20180426062832),('Emilia','HIST1','Nacida en Stratholme, en una familia acomodada. La infección la pilló de vacaciones en la casa de campo. Fue bien educada, sabe coser y dio clases de canto. Soñaba con ser artista y llevar una vída bohemia.\nActualmente, se mueve sola entre campamentos.','ROL',20180427210102),('Emilia','HIST2','Estatura media, delgada y ágil. Tiene los ojos verdes y el pelo negro cortado a navaja, obedeciendo a la practicidad. De la nuca le nace una trenza que llega hasta su cintura. Piel clara y sin cicatrices importantes.','ROL',20180427210102),('Emilia','INTELE','5','ATRIBUTO',20180501140603),('Emilia','MAGILID','0','ATRIBUTO',20180830191212),('Emilia','MANA','33.4','ATRIBUTO',20180830201219),('Emilia','MCONSTI','0','ATRIBUTO',20180830191212),('Emilia','MDESTRE','0','ATRIBUTO',20180830191212),('Emilia','MFUERZA','0','ATRIBUTO',20180830191212),('Emilia','MINTELE','0','ATRIBUTO',20180830191212),('Emilia','MPERCEP','0','ATRIBUTO',20180830191212),('Emilia','MSABIDU','0','ATRIBUTO',20180830191212),('Emilia','NOMBRE','Emilia','ROL',20180427210102),('Emilia','PATTR','0','ROL',20180506001154),('Emilia','PERCEP','6','ATRIBUTO',20180506001108),('Emilia','SABIDU','6','ATRIBUTO',20180506001154),('Emilia','SAY1',' ','SAY',20180506002337),('Emilia','SAY2',' ','SAY',20180506002337),('Emilia','SAY3',' ','SAY',20180506001312),('Emilia','VIDA','27.5','ATRIBUTO',20180830201219),('Eothan','AGILID','6','ATRIBUTO',20180506012002),('Eothan','APP','A','ROL',0),('Eothan','CONSTI','5','ATRIBUTO',20180501140618),('Eothan','DESTRE','5','ATRIBUTO',20180501140613),('Eothan','DICE1MAX','10','DICE',20180506012719),('Eothan','DICE1MIN','1','DICE',20180506005309),('Eothan','DICE2MAX','6','DICE',20180506011127),('Eothan','DICE2MIN','1','DICE',20180506005257),('Eothan','EDAD','22','ROL',20180506010352),('Eothan','FUERZA','5','ATRIBUTO',20180426062832),('Eothan','HIST1','Nacido en Fiol, justo antes de entrar en la Santa Iglesia como monaguillo, realizó las pruebas mágicas del Kirin Tor y se descubrió su talento como mago. Fue trasladado a Lordaeron, allí encontró el amor y lo perdió por el apocalípsis zombie...','ROL',20180506010352),('Eothan','HIST2','Es un hombre alto (1,85m) de cabellos rubios y de unos ojos azules muy intensos. Suele ir sin barba y su físico normal en lo que respecta a la raza humana. Con todo lo último vivido quizá esta algo más demacrado.','ROL',20180506010352),('Eothan','INTELE','7','ATRIBUTO',20180506011850),('Eothan','MAGILID','0','ATRIBUTO',20180509221700),('Eothan','MCONSTI','0','ATRIBUTO',20180509221700),('Eothan','MDESTRE','0','ATRIBUTO',20180509221700),('Eothan','MFUERZA','0','ATRIBUTO',20180509221700),('Eothan','MINTELE','0','ATRIBUTO',20180509221700),('Eothan','MPERCEP','0','ATRIBUTO',20180509221700),('Eothan','MSABIDU','0','ATRIBUTO',20180509221700),('Eothan','NOMBRE','Eothan de Fiol','ROL',20180506010352),('Eothan','PATTR','0','ROL',20180506012002),('Eothan','PERCEP','7','ATRIBUTO',20180506011935),('Eothan','SABIDU','6','ATRIBUTO',20180506011835),('Eothan','SAY1',' ','SAY',20180506012719),('Eothan','SAY2',' ','SAY',20180506012719),('Eothan','SAY3',' ','SAY',20180506012719),('Gerd','AGILID','5','ATRIBUTO',20180426062832),('Gerd','APELLIDO','Larsson','ROL',20180809180619),('Gerd','APP','A','ROL',0),('Gerd','CONSTI','7','ATRIBUTO',20180809181913),('Gerd','DESTRE','5','ATRIBUTO',20180426062832),('Gerd','DICE1MAX','20','DICE1',20180809180915),('Gerd','DICE1MIN','1','DICE1',20180809180932),('Gerd','DICE2MAX','8','DICE2',20180809180907),('Gerd','DICE2MIN','1','DICE2',20180809180949),('Gerd','EDAD','25 años','ROL',20180809180619),('Gerd','ENER','30.5','ATRIBUTO',20180809180818),('Gerd','FUERZA','6','ATRIBUTO',20180809181934),('Gerd','HIST1','-Primogénito de un carpintero y una peluquera, huyó de la capital con su hermana pequeña (8 años) y su hermano (19 años).\n-Estudios básico, ligeros conocimientos de cartografía y pesca.\n-Trabaja con las barricadas en el monasterio.\n-Fiel a la luz sagrada.','ROL',20180809180619),('Gerd','HIST2','Altura: 1.96 metros, 104 kilos.\nComplexión: Musculada por el trabajo físico en la carpintería.\nPiel blanca, ojos verdes y cabello castaño claro medio largo, recogido.','ROL',20180809180619),('Gerd','INTELE','6','ATRIBUTO',20180809181919),('Gerd','MAGILID','0','ATRIBUTO',20180809224744),('Gerd','MANA','36','ATRIBUTO',20180809180818),('Gerd','MCONSTI','0','ATRIBUTO',20180809224744),('Gerd','MDESTRE','0','ATRIBUTO',20180809224744),('Gerd','MFUERZA','0','ATRIBUTO',20180809224744),('Gerd','MINTELE','0','ATRIBUTO',20180809224744),('Gerd','MPERCEP','0','ATRIBUTO',20180809224744),('Gerd','MSABIDU','0','ATRIBUTO',20180809224744),('Gerd','NOMBRE','Gerd','ROL',20180809180619),('Gerd','PATTR','0','ROL',20180809181934),('Gerd','PERCEP','5','ATRIBUTO',20180428153410),('Gerd','SABIDU','6','ATRIBUTO',20180809181925),('Gerd','SAY1','nil','SAY',20180809180945),('Gerd','SAY2','nil','SAY',20180809180907),('Gerd','SAY3','nil','SAY',20180809180907),('Gerd','VIDA','39.5','ATRIBUTO',20180809180818),('Hacedor','AGILID','5','ATRIBUTO',20180425203543),('Hacedor','APELLIDO','Lothoren','ROL',20180425203708),('Hacedor','APP','A','ROL',0),('Hacedor','CONSTI','7','ATRIBUTO',20180429230733),('Hacedor','DESTRE','7','ATRIBUTO',20180429230800),('Hacedor','DICE1MAX','6','DICE',20180506004704),('Hacedor','DICE1MIN','1','DICE',0),('Hacedor','DICE2MAX','6','DICE',20180506020505),('Hacedor','DICE2MIN','1','DICE',0),('Hacedor','EDAD','30','ROL',20180425203708),('Hacedor','ENER','29','ATRIBUTO',20190302234708),('Hacedor','FUERZA','6','ATRIBUTO',20180429230738),('Hacedor','HIST1','rsgreg\nsrg\nsrg\nsrg\ns\nr\n','ROL',20180425203708),('Hacedor','HIST2','shthst\nsht\nhs\nth\nst\nh\n\n\nshtsthsrthst','ROL',20180425203708),('Hacedor','INTELE','5','ATRIBUTO',20180425203543),('Hacedor','MAGILID','0','ATRIBUTO',20190322232513),('Hacedor','MANA','30','ATRIBUTO',20190302234708),('Hacedor','MCONSTI','0','ATRIBUTO',20190322232513),('Hacedor','MDESTRE','0','ATRIBUTO',20190322232513),('Hacedor','MFUERZA','0','ATRIBUTO',20190322232513),('Hacedor','MINTELE','0','ATRIBUTO',20190322232513),('Hacedor','MPERCEP','0','ATRIBUTO',20190322232513),('Hacedor','MSABIDU','0','ATRIBUTO',20190322232513),('Hacedor','NOMBRE','Aduin','ROL',20180425203708),('Hacedor','PATTR','0','ROL',20180429230800),('Hacedor','PERCEP','6','ATRIBUTO',20180429230753),('Hacedor','ROL','6','PATTR',20180429230717),('Hacedor','SABIDU','5','ATRIBUTO',20180425203543),('Hacedor','SAY1',' ','SAY',20180506020506),('Hacedor','SAY2',' ','SAY',20180506020505),('Hacedor','SAY3',' ','SAY',20180506020506),('Hacedor','VIDA','36.8','ATRIBUTO',20190302234708),('Irma','AGILID','5','ATRIBUTO',20180426062832),('Irma','APELLIDO','Noor','ROL',20180427143728),('Irma','APP','A','ROL',0),('Irma','CONSTI','6','ATRIBUTO',20180501140618),('Irma','DESTRE','6','ATRIBUTO',20180426062832),('Irma','DICE1MAX','10','DICE1',20180519174525),('Irma','DICE1MIN','1','DICE1',20180518161615),('Irma','DICE2MAX','3','DICE2',20180527081804),('Irma','DICE2MIN','1','DICE2',20180518161622),('Irma','EDAD','20','ROL',20180427143728),('Irma','ENER','28.8','ATRIBUTO',0),('Irma','Espada corta - Toque ligero','13.600000000000001','HABILIDAD',0),('Irma','FUERZA','5','ATRIBUTO',20180426062832),('Irma','Golpe de espada (entrenamiento)','93','HABILIDAD',0),('Irma','HIST1','Nacida en Lordaeron.\nEstudios primarios (leer/escribir)\nPadres vendedores de telas.\n\nSe ofrecio voluntaria como enfermera en el hospital de Ciudad Capital durante su asedio, donde perderia a su familia.\n\nSigue con su funcion en el monasterio','ROL',20180427143728),('Irma','HIST2','Estatura media, piel blanca.\nNi tatuajes ni marcas especiales.','ROL',20180427143728),('Irma','INTELE','7','ATRIBUTO',20180501140603),('Irma','MAGILID','0','ATRIBUTO',20190302231730),('Irma','MANA','42','ATRIBUTO',0),('Irma','MCONSTI','0','ATRIBUTO',20190302231730),('Irma','MDESTRE','0','ATRIBUTO',20190302231730),('Irma','MFUERZA','0','ATRIBUTO',20190302231730),('Irma','MINTELE','0','ATRIBUTO',20190302231730),('Irma','MPERCEP','0','ATRIBUTO',20190302231730),('Irma','MSABIDU','0','ATRIBUTO',20190302231730),('Irma','NOMBRE','Irma Lorelay','ROL',20180427143728),('Irma','PATTR','0','ROL',20180501140618),('Irma','PERCEP','5','ATRIBUTO',20180428153410),('Irma','Practicas de tiro con arco','24.5','HABILIDAD',0),('Irma','ROL','6','PATTR',20180501140530),('Irma','SABIDU','7','ATRIBUTO',20180501140548),('Irma','SAY1','sonrie con menos nerviosismo','SAY',20180527111054),('Irma','SAY2','aspira profundamente, carga una flecha en la ballesta y dispara','SAY',20180527111111),('Irma','SAY3','sonrie a su vez','SAY',20180527111056),('Irma','VIDA','38.6','ATRIBUTO',20180602200904),('Jaqen','AGILID','7','ATRIBUTO',20180524224528),('Jaqen','APELLIDO','Wulf','ROL',20180519235735),('Jaqen','APP','A','ROL',0),('Jaqen','CONSTI','6','ATRIBUTO',20180524225014),('Jaqen','DESTRE','7','ATRIBUTO',20180524224522),('Jaqen','DICE1MAX','10','DICE',0),('Jaqen','DICE1MIN','1','DICE',0),('Jaqen','DICE2MAX','6','DICE',0),('Jaqen','DICE2MIN','1','DICE',0),('Jaqen','EDAD','34','ROL',20180519235735),('Jaqen','ENER','28.8','ATRIBUTO',20180530232807),('Jaqen','FUERZA','5','ATRIBUTO',20180429170845),('Jaqen','HIST1','De familia acomodada sin llegar a noble, encargado de viajar, expandir y mantener el negocio de su padre. Cuando volvió de uno de sus viajes se encontró con la situación, sobreviviendo solo como pudo, hasta encontrar a un grupo de supervivientes.','ROL',20180519235735),('Jaqen','HIST2','Complexión fuerte sin ser excesiva, 1,85 de altura, cabello castaño oscuro y ojos marrones con trazas verdes. De ragos agraciados pero algo ocultos por pelo y barba crecidos, debido a la situación y a su actual dejadez.','ROL',20180519235735),('Jaqen','INTELE','5','ATRIBUTO',20180428143129),('Jaqen','MAGILID','0','ATRIBUTO',20180530223841),('Jaqen','MANA','30','ATRIBUTO',20180530232807),('Jaqen','MCONSTI','0','ATRIBUTO',20180530223841),('Jaqen','MDESTRE','0','ATRIBUTO',20180530223841),('Jaqen','MFUERZA','0','ATRIBUTO',20180530223841),('Jaqen','MINTELE','0','ATRIBUTO',20180530223841),('Jaqen','MPERCEP','0','ATRIBUTO',20180530223841),('Jaqen','MSABIDU','0','ATRIBUTO',20180530223841),('Jaqen','NOMBRE','Jaqen','ROL',20180519235735),('Jaqen','PATTR','0','ROL',20180524225014),('Jaqen','PERCEP','6','ATRIBUTO',20180524224956),('Jaqen','Practicas de tiro con arco','3.3','HABILIDAD',0),('Jaqen','SABIDU','5','ATRIBUTO',20180501140548),('Jaqen','SAY1',' ','SAY',20180524223633),('Jaqen','SAY2',' ','SAY',20180524223634),('Jaqen','SAY3',' ','SAY',20180524223635),('Joseph','AGILID','7','ATRIBUTO',20180610171328),('Joseph','APELLIDO','Sin Apellidos','ROL',20180610165711),('Joseph','APP','A','ROL',0),('Joseph','CONSTI','5','ATRIBUTO',20180501140618),('Joseph','DESTRE','7','ATRIBUTO',20180610171333),('Joseph','EDAD','24','ROL',20180610165711),('Joseph','ENER','25.5','ATRIBUTO',20180610165834),('Joseph','FUERZA','5','ATRIBUTO',20180426062832),('Joseph','HIST1','Antiguo contrabandista y criminal de Andorhal. Se unio a la milicia de Lordaeron cuando empezo la tercera guerra. Ha sobrevivido lo suficiente para acabar aqui.','ROL',20180610165711),('Joseph','HIST2','Enclenque de pelo moreno con coleta. Con una sonrisa burlona permanente en su cara.','ROL',20180610165711),('Joseph','INTELE','5','ATRIBUTO',20180501140603),('Joseph','MAGILID','0','ATRIBUTO',20180810000149),('Joseph','MANA','30','ATRIBUTO',20180610165834),('Joseph','MCONSTI','0','ATRIBUTO',20180810000149),('Joseph','MDESTRE','0','ATRIBUTO',20180810000149),('Joseph','MFUERZA','0','ATRIBUTO',20180810000149),('Joseph','MINTELE','0','ATRIBUTO',20180810000149),('Joseph','MPERCEP','0','ATRIBUTO',20180810000149),('Joseph','MSABIDU','0','ATRIBUTO',20180810000149),('Joseph','NOMBRE','Joseph','ROL',20180610165711),('Joseph','PATTR','0','ROL',20180610171333),('Joseph','PERCEP','7','ATRIBUTO',20180610171301),('Joseph','SABIDU','5','ATRIBUTO',20180501140548),('Joseph','VIDA','30','ATRIBUTO',20180610165834),('Liadrin','DICE1MAX','10','DICE',0),('Liadrin','DICE1MIN','1','DICE',0),('Liadrin','DICE2MAX','6','DICE',0),('Liadrin','DICE2MIN','1','DICE',0),('Liadrin','SAY1',' ','SAY',0),('Liadrin','SAY2',' ','SAY',0),('Liadrin','SAY3',' ','SAY',0),('Margot','DICE1MAX','10','DICE',0),('Margot','DICE1MIN','1','DICE',0),('Margot','DICE2MAX','6','DICE',0),('Margot','DICE2MIN','1','DICE',0),('Margot','MAGILID','0','ATRIBUTO',20180614175456),('Margot','MCONSTI','0','ATRIBUTO',20180614175456),('Margot','MDESTRE','0','ATRIBUTO',20180614175456),('Margot','MFUERZA','0','ATRIBUTO',20180614175456),('Margot','MINTELE','0','ATRIBUTO',20180614175456),('Margot','MPERCEP','0','ATRIBUTO',20180614175456),('Margot','MSABIDU','0','ATRIBUTO',20180614175456),('Margot','SAY1',' ','SAY',0),('Margot','SAY2',' ','SAY',0),('Margot','SAY3',' ','SAY',0),('Morticia','AGILID','5','ATRIBUTO',20180428104256),('Morticia','APELLIDO','Adams','ROL',20180429173103),('Morticia','APP','A','ROL',0),('Morticia','Combate sin armas','12','HABILIDAD',0),('Morticia','CONSTI','5','ATRIBUTO',20180428143159),('Morticia','DESTRE','5','ATRIBUTO',20180428104207),('Morticia','DICE1MAX','10','DICE',20180503073759),('Morticia','DICE1MIN','1','DICE',20180501105828),('Morticia','DICE2MAX','6','DICE',20180503070620),('Morticia','DICE2MIN','1','DICE',20180501112313),('Morticia','EDAD','148','ROL',20180429173103),('Morticia','ENER','0.9','ATRIBUTO',0),('Morticia','FUERZA','5','ATRIBUTO',20180429170845),('Morticia','Golpe de espada (entrenamiento)','96','HABILIDAD',0),('Morticia','HIST1','No se sabe donde nacio.\r\nSu cometido en esta vida es fastidiar todo lo posible al prójimo manteniendo una sonrisa sádica.\r\nNo se si cabe aqui todo lo que esta mujer arrastra consigo.\nUna vez afeito a su loro con un papel de lija. \n','ROL',20180429173103),('Morticia','HIST2','Lleva maquillaje pasado de moda\nSu palidez es muy evidente\nSus dientes terminan en punta','ROL',20180429173103),('Morticia','INTELE','5','ATRIBUTO',20180428143129),('Morticia','MAGILID','0','ATRIBUTO',20180807123127),('Morticia','MANA','36.8','ATRIBUTO',0),('Morticia','MCONSTI','0','ATRIBUTO',20180807123127),('Morticia','MDESTRE','0','ATRIBUTO',20180807123127),('Morticia','MFUERZA','0','ATRIBUTO',20180807123127),('Morticia','MINTELE','0','ATRIBUTO',20180807123127),('Morticia','MPERCEP','0','ATRIBUTO',20180807123127),('Morticia','MSABIDU','0','ATRIBUTO',20180807123127),('Morticia','NOMBRE','Morticia','ROL',20180429173103),('Morticia','PATTR','4','ROL',20180501120239),('Morticia','PERCEP','5','ATRIBUTO',20180417065251),('Morticia','Practicas de tiro con arco','159','HABILIDAD',0),('Morticia','SABIDU','7','ATRIBUTO',20180501120239),('Morticia','SAY1',' ','SAY',20180501190656),('Morticia','SAY2',' ','SAY',20180505213334),('Morticia','SAY3',' ','SAY',20180503070607),('Tantaria','APELLIDO','Necrofémur','ROL',20180501133609),('Tantaria','APP','A','ROL',0),('Tantaria','DICE1MAX','10','DICE',0),('Tantaria','DICE1MIN','1','DICE',0),('Tantaria','DICE2MAX','6','DICE',0),('Tantaria','DICE2MIN','1','DICE',0),('Tantaria','EDAD','95','ROL',20180501133609),('Tantaria','HIST1','.','ROL',20180501133609),('Tantaria','HIST2','.','ROL',20180501133609),('Tantaria','MAGILID','0','ATRIBUTO',20180529111129),('Tantaria','MCONSTI','0','ATRIBUTO',20180529111129),('Tantaria','MDESTRE','0','ATRIBUTO',20180529111129),('Tantaria','MFUERZA','0','ATRIBUTO',20180529111129),('Tantaria','MINTELE','0','ATRIBUTO',20180529111129),('Tantaria','MPERCEP','0','ATRIBUTO',20180529111129),('Tantaria','MSABIDU','0','ATRIBUTO',20180529111129),('Tantaria','NOMBRE','Tantaria','ROL',20180501133609),('Tantaria','ROL','6','PATTR',20180501133743),('Tantaria','SAY1',' ','SAY',0),('Tantaria','SAY2',' ','SAY',0),('Tantaria','SAY3',' ','SAY',0),('Tomasa','DICE1MAX','10','DICE',0),('Tomasa','DICE1MIN','1','DICE',0),('Tomasa','DICE2MAX','6','DICE',0),('Tomasa','DICE2MIN','1','DICE',0),('Tomasa','MAGILID','0','ATRIBUTO',20180830194005),('Tomasa','MCONSTI','0','ATRIBUTO',20180830194005),('Tomasa','MDESTRE','0','ATRIBUTO',20180830194005),('Tomasa','MFUERZA','0','ATRIBUTO',20180830194005),('Tomasa','MINTELE','0','ATRIBUTO',20180830194005),('Tomasa','MPERCEP','0','ATRIBUTO',20180830194005),('Tomasa','MSABIDU','0','ATRIBUTO',20180830194005),('Tomasa','ROL','6','PATTR',20180503213919),('Tomasa','SAY1',' ','SAY',0),('Tomasa','SAY2',' ','SAY',0),('Tomasa','SAY3',' ','SAY',0),('Tstcinco','DICE1MAX','10','DICE',0),('Tstcinco','DICE1MIN','1','DICE',0),('Tstcinco','DICE2MAX','6','DICE',0),('Tstcinco','DICE2MIN','1','DICE',0),('Tstcinco','MAGILID','0','ATRIBUTO',20180505120405),('Tstcinco','MCONSTI','0','ATRIBUTO',20180505120405),('Tstcinco','MDESTRE','0','ATRIBUTO',20180505120405),('Tstcinco','MFUERZA','0','ATRIBUTO',20180505120405),('Tstcinco','MINTELE','0','ATRIBUTO',20180505120405),('Tstcinco','MPERCEP','0','ATRIBUTO',20180505120405),('Tstcinco','MSABIDU','0','ATRIBUTO',20180505120405),('Tstcinco','SAY1',' ','SAY',0),('Tstcinco','SAY2',' ','SAY',0),('Tstcinco','SAY3',' ','SAY',0),('Tstcuatro','DICE1MAX','10','DICE',0),('Tstcuatro','DICE1MIN','1','DICE',0),('Tstcuatro','DICE2MAX','6','DICE',0),('Tstcuatro','DICE2MIN','1','DICE',0),('Tstcuatro','MAGILID','0','ATRIBUTO',20180505120130),('Tstcuatro','MCONSTI','0','ATRIBUTO',20180505120130),('Tstcuatro','MDESTRE','0','ATRIBUTO',20180505120130),('Tstcuatro','MFUERZA','0','ATRIBUTO',20180505120130),('Tstcuatro','MINTELE','0','ATRIBUTO',20180505120130),('Tstcuatro','MPERCEP','0','ATRIBUTO',20180505120130),('Tstcuatro','MSABIDU','0','ATRIBUTO',20180505120130),('Tstcuatro','SAY1',' ','SAY',0),('Tstcuatro','SAY2',' ','SAY',0),('Tstcuatro','SAY3',' ','SAY',0),('Tstdos','DICE1MAX','10','DICE',0),('Tstdos','DICE1MIN','1','DICE',0),('Tstdos','DICE2MAX','6','DICE',0),('Tstdos','DICE2MIN','1','DICE',0),('Tstdos','MAGILID','0','ATRIBUTO',20180505120049),('Tstdos','MCONSTI','0','ATRIBUTO',20180505120049),('Tstdos','MDESTRE','0','ATRIBUTO',20180505120049),('Tstdos','MFUERZA','0','ATRIBUTO',20180505120049),('Tstdos','MINTELE','0','ATRIBUTO',20180505120049),('Tstdos','MPERCEP','0','ATRIBUTO',20180505120049),('Tstdos','MSABIDU','0','ATRIBUTO',20180505120049),('Tstdos','SAY1',' ','SAY',0),('Tstdos','SAY2',' ','SAY',0),('Tstdos','SAY3',' ','SAY',0),('Tsttres','DICE1MAX','10','DICE',0),('Tsttres','DICE1MIN','1','DICE',0),('Tsttres','DICE2MAX','6','DICE',0),('Tsttres','DICE2MIN','1','DICE',0),('Tsttres','MAGILID','0','ATRIBUTO',20180505120631),('Tsttres','MCONSTI','0','ATRIBUTO',20180505120631),('Tsttres','MDESTRE','0','ATRIBUTO',20180505120631),('Tsttres','MFUERZA','0','ATRIBUTO',20180505120631),('Tsttres','MINTELE','0','ATRIBUTO',20180505120631),('Tsttres','MPERCEP','0','ATRIBUTO',20180505120631),('Tsttres','MSABIDU','0','ATRIBUTO',20180505120631),('Tsttres','SAY1',' ','SAY',0),('Tsttres','SAY2',' ','SAY',0),('Tsttres','SAY3',' ','SAY',0),('Tstuno','DICE1MAX','10','DICE',0),('Tstuno','DICE1MIN','1','DICE',0),('Tstuno','DICE2MAX','6','DICE',0),('Tstuno','DICE2MIN','1','DICE',0),('Tstuno','MAGILID','0','ATRIBUTO',20180601144233),('Tstuno','MCONSTI','0','ATRIBUTO',20180601144233),('Tstuno','MDESTRE','0','ATRIBUTO',20180601144233),('Tstuno','MFUERZA','0','ATRIBUTO',20180601144233),('Tstuno','MINTELE','0','ATRIBUTO',20180601144233),('Tstuno','MPERCEP','0','ATRIBUTO',20180601144233),('Tstuno','MSABIDU','0','ATRIBUTO',20180601144233),('Tstuno','ROL','6','PATTR',20180505120016),('Tstuno','SAY1',' ','SAY',0),('Tstuno','SAY2',' ','SAY',0),('Tstuno','SAY3',' ','SAY',0),('Vanya','AGILID','6','ATRIBUTO',20180428233839),('Vanya','APELLIDO','Kostresky','ROL',20180428232807),('Vanya','APP','A','ROL',0),('Vanya','CONSTI','5','ATRIBUTO',20180428233139),('Vanya','DESTRE','7','ATRIBUTO',20180428233908),('Vanya','DICE1MAX','10','DICE',20180506004958),('Vanya','DICE1MIN','1','DICE',20180506004958),('Vanya','DICE2MAX','6','DICE',20180506004736),('Vanya','DICE2MIN','1','DICE',20180506004408),('Vanya','EDAD','25 años','ROL',20180428232807),('Vanya','FUERZA','5','ATRIBUTO',20180428233139),('Vanya','HIST1','De padre desconocido y de madre postituta,fue criada en un burdel de la capital de Lordaeron, de clase media, conforme fue creciendo,opto por cuando fue mayor de edad, ser de la misma profesion que su madre. Actualmente,todos sus conocidos estan muertos.','ROL',20180428232807),('Vanya','HIST2','Chica de piel palida,peliroja,con algunas pecas, ojos miel casi amarillentos,labios carnosos,cuerpo esbelto y mirada penetrante.','ROL',20180428232807),('Vanya','INTELE','6','ATRIBUTO',20180428233902),('Vanya','MAGILID','0','ATRIBUTO',20180527190740),('Vanya','MCONSTI','0','ATRIBUTO',20180527190740),('Vanya','MDESTRE','0','ATRIBUTO',20180527190740),('Vanya','MFUERZA','0','ATRIBUTO',20180527190740),('Vanya','MINTELE','0','ATRIBUTO',20180527190740),('Vanya','MPERCEP','0','ATRIBUTO',20180527190740),('Vanya','MSABIDU','0','ATRIBUTO',20180527190740),('Vanya','NOMBRE','Vanya','ROL',20180428232807),('Vanya','PATTR','0','ROL',20180428233923),('Vanya','PERCEP','7','ATRIBUTO',20180428233923),('Vanya','ROL','6','PATTR',20180428233130),('Vanya','SABIDU','5','ATRIBUTO',20180428233139),('Vanya','SAY1',' ','SAY',20180506024024),('Vanya','SAY2',' ','SAY',20180506024024),('Vanya','SAY3',' ','SAY',20180506024024);
/*!40000 ALTER TABLE `LD_SessionVars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SysMessages`
--

DROP TABLE IF EXISTS `LD_SysMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SysMessages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LD_Message` varchar(255) NOT NULL,
  `LD_Sender` varchar(50) NOT NULL,
  `LD_Recv` varchar(50) NOT NULL,
  `LD_TimeStamp` bigint(14) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SysMessages`
--

LOCK TABLES `LD_SysMessages` WRITE;
/*!40000 ALTER TABLE `LD_SysMessages` DISABLE KEYS */;
INSERT INTO `LD_SysMessages` VALUES (38,'TEATACAN#Espada corta - Toque ligero#9.3#Irma','Irma','Aduin',20180706231000),(39,'TEATACAN#Espada corta - Toque ligero#12.8#Aduin','Aduin','Irma',20180706231113),(40,'TEATACAN#Golpe de espada (entrenamiento)#12#Aduin','Aduin','Irma',20180706231217),(41,'TEATACAN#Espada corta - Toque ligero#13.8#Aduin','Aduin','Irma',20180706231228),(42,'TEATACAN#Espada corta - Toque ligero#10.3#Irma','Irma','Alaina',20180807174512),(43,'TEATACAN#Golpe de espada (entrenamiento)#9.5#Irma','Irma','Alaina',20180807174558),(44,'TEATACAN#Espada corta - Toque ligero#12.8#Aduin','Aduin','Alaina',20180811005526);
/*!40000 ALTER TABLE `LD_SysMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SystemVars`
--

DROP TABLE IF EXISTS `LD_SystemVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SystemVars` (
  `LD_NAME` varchar(50) NOT NULL,
  `LD_TYPE` varchar(50) NOT NULL,
  `LD_SUBTYPE` varchar(100) NOT NULL,
  `LD_VALUE` varchar(100) NOT NULL,
  PRIMARY KEY (`LD_NAME`,`LD_TYPE`,`LD_SUBTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SystemVars`
--

LOCK TABLES `LD_SystemVars` WRITE;
/*!40000 ALTER TABLE `LD_SystemVars` DISABLE KEYS */;
INSERT INTO `LD_SystemVars` VALUES ('AGILID_MAX','ATTRSETS','BloodElf','7'),('AGILID_MAX','ATTRSETS','Human','7'),('AGILID_MIN','ATTRSETS','BloodElf','5'),('AGILID_MIN','ATTRSETS','Human','5'),('CONSTI_MAX','ATTRSETS','BloodElf','7'),('CONSTI_MAX','ATTRSETS','Human','7'),('CONSTI_MIN','ATTRSETS','BloodElf','5'),('CONSTI_MIN','ATTRSETS','Human','5'),('DESTRE_MAX','ATTRSETS','BloodElf','7'),('DESTRE_MAX','ATTRSETS','Human','7'),('DESTRE_MIN','ATTRSETS','BloodElf','5'),('DESTRE_MIN','ATTRSETS','Human','5'),('FUERZA_MAX','ATTRSETS','BloodElf','7'),('FUERZA_MAX','ATTRSETS','Human','7'),('FUERZA_MIN','ATTRSETS','BloodElf','5'),('FUERZA_MIN','ATTRSETS','Human','5'),('INTELE_MAX','ATTRSETS','BloodElf','7'),('INTELE_MAX','ATTRSETS','Human','7'),('INTELE_MIN','ATTRSETS','BloodElf','5'),('INTELE_MIN','ATTRSETS','Human','5'),('MVEP','SYS','SYS','1'),('MVHP','SYS','SYS','2'),('MVMP','SYS','SYS','2'),('PERCEP_MAX','ATTRSETS','BloodElf','7'),('PERCEP_MAX','ATTRSETS','Human','7'),('PERCEP_MIN','ATTRSETS','BloodElf','5'),('PERCEP_MIN','ATTRSETS','Human','5'),('SABIDU_MAX','ATTRSETS','BloodElf','7'),('SABIDU_MAX','ATTRSETS','Human','7'),('SABIDU_MIN','ATTRSETS','BloodElf','5'),('SABIDU_MIN','ATTRSETS','Human','5');
/*!40000 ALTER TABLE `LD_SystemVars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_data`
--

DROP TABLE IF EXISTS `account_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_data` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`accountId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_data`
--

LOCK TABLES `account_data` WRITE;
/*!40000 ALTER TABLE `account_data` DISABLE KEYS */;
INSERT INTO `account_data` VALUES (1,0,1551564461,'SET scriptErrors \"1\"\nSET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##M##%##&##$##E##8##(##*##+##7##Z##[##;##)##\\##.##/##^##K##-##1##,##:##6##<##A##B##Q##5##O##P##Y##F##]##X##U##4##C##_##N##?##9##I##D##@##0##3##J##V##L##=##G\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\n'),(1,2,1551564462,'BINDINGMODE 0\r\nbind W TOGGLERUN\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind < TOGGLEAUTORUN\r\n'),(1,4,1551564463,'MACRO 1 \"m\" Spell_Nature_Polymorph_Cow\r\n/myaura 23228\r\nEND\r\n'),(2,0,1533826870,'SET scriptErrors \"1\"\nSET flaggedTutorials \"v##P##C##X##U##E\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraView \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\n'),(2,2,1533826871,'BINDINGMODE 0\r\nbind W TOGGLERUN\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind < TOGGLEAUTORUN\r\n'),(2,4,1533826872,'MACRO 14 \"A54844\" Spell_Holy_PrayerofShadowProtection\r\n.aura 54844\r\nEND\r\nMACRO 6 \"C1\" Ability_PoisonArrow\r\n.gob add 185475\r\nEND\r\nMACRO 7 \"C2\" Ability_PoisonArrow\r\n.gob add 178226  \r\nEND\r\nMACRO 3 \"del\" Ability_Creature_Cursed_02\r\n.npc del\r\nEND\r\nMACRO 5 \"DTFRAME\" Ability_Druid_EclipseOrange\r\n/dtframe stack on\r\nEND\r\nMACRO 13 \"fly\" Ability_Hunter_Pet_Wasp\r\n.gm fly on\r\nEND\r\nMACRO 8 \"H1\" Ability_Creature_Disease_05\r\n.npc add 16865\r\nEND\r\nMACRO 9 \"H2\" Ability_Creature_Disease_05\r\n.npc add 23783\r\nEND\r\nMACRO 11 \"H3\" Ability_Creature_Disease_05\r\n.npc add 27517\r\nEND\r\nMACRO 12 \"H4\" Ability_Creature_Disease_05\r\n.npc add 27517\r\nEND\r\nMACRO 4 \"MOV\" Ability_Druid_Eclipse\r\n.npc move\r\nEND\r\nMACRO 2 \"S1\" Ability_Creature_Cursed_04\r\n.mod speed 1\r\nEND\r\nMACRO 1 \"s5\" Ability_Creature_Cursed_04\r\n.mod speed 5\r\nEND\r\nMACRO 10 \"TAR\" Ability_Creature_Cursed_01\r\n.gob target\r\nEND\r\nMACRO 15 \"UNA\" Spell_Holy_PrayerOfHealing\r\n.unaura all\r\nEND\r\n'),(3,0,1533662426,'SET flaggedTutorials \"v##M##%##&##$##5##:##<##(##6##Z##1##9##I##D##0##J##V##[##A##B##)##\\##C##*##Q##7##?##@##Y##+##4##K##X##;##3##,##O##^##]##U##.##/##E##8\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\n'),(3,4,1551903264,'MACRO 1 \"apariencia\" Ability_Creature_Cursed_01\r\n.mod speed 5\r\n.gm fly on\r\nEND\r\nMACRO 6 \"ataque 2 manos\" Ability_ThunderClap\r\n.npc playemote 38\r\nEND\r\nMACRO 7 \"Ataque Arco\" Ability_Hunter_BeastTaming\r\n.npc playemote 384\r\nEND\r\nMACRO 5 \"ataque una mano\" Ability_SteelMelee\r\n.npc playemote 36\r\nEND\r\nMACRO 2 \"Borrar NPC\" INV_Misc_QuestionMark\r\n.npc del\r\nEND\r\nMACRO 3 \"NPC Posses\" Ability_Hunter_GoForTheThroat\r\n.posses\r\nEND\r\nMACRO 4 \"npc unposses\" Ability_Hunter_BeastSoothe\r\n.unpossess\r\nEND\r\n'),(4,0,1522178528,'SET flaggedTutorials \"v##M##:##%##&##$##[##Q##)\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\n'),(5,0,1525555302,'SET autoLootDefault \"1\"\nSET flaggedTutorials \"v##_##R##M##%##&##$##[##:##(##6##+##;##-##5##)##7##Q##\\##K##A##B##,##^##X##9##4\"\nSET profanityFilter \"0\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showItemLevel \"1\"\nSET talentFrameShown \"1\"\nSET threatShowNumeric \"1\"\n'),(6,0,1524855939,'SET rotateMinimap \"1\"\nSET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##M##%##&##$##:##+##-##9##5##[##7##;##)##K##\\##Q##6##(##A##B##,##F##X##?##@##<##E##Y##]##4\"\nSET profanityFilter \"0\"\nSET spamFilter \"0\"\nSET UnitNamePlayerGuild \"0\"\nSET UnitNamePlayerPVPTitle \"0\"\nSET UnitNameEnemyPlayerName \"0\"\nSET UnitNameEnemyPetName \"0\"\nSET UnitNameFriendlyPlayerName \"0\"\nSET UnitNameFriendlyPetName \"0\"\nSET playerStatusText \"1\"\nSET petStatusText \"1\"\nSET partyStatusText \"1\"\nSET targetStatusText \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET timeMgrUseLocalTime \"1\"\n'),(6,4,1523033124,'MACRO 1 \"Graficos\" Ability_CheapShot\r\n/console groundEffectDensity 256\r\n/console groundEffectDist 140 \r\n/console detailDoodadAlpha 100\r\n/console farclip 777\r\n/console characterAmbient\r\n/console spellEffectLevel 150\r\nEND\r\n'),(7,0,1525294942,'SET showTargetOfTarget \"1\"\nSET flaggedTutorials \"v##]##M##%##&##$##K##+##,##7##:##E##(##*##Z##[##;##)##\\##O##-##8##.##/##1##?##9##I##@##C##A##B##6##D##0##J##V##X##Y##^\"\nSET profanityFilter \"0\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET secureAbilityToggle \"0\"\nSET UnitNameOwn \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\nSET timeMgrUseLocalTime \"1\"\nSET ShowAllSpellRanks \"0\"\n'),(7,2,1525294943,'BINDINGMODE 0\r\nbind = NONE\r\nbind TAB ACTIONBUTTON12\r\nbind � NONE\r\n'),(7,4,1525294944,'MACRO 3 \"1 D10\" INV_Misc_QuestionMark\r\n/Dados 10\r\nEND\r\nMACRO 2 \"1 D6\" INV_Misc_QuestionMark\r\n/Dados 6\r\nEND\r\nMACRO 4 \"asd\" Ability_Creature_Cursed_03\r\n/Flex\r\nEND\r\nMACRO 1 \"Catedral\" Ability_Druid_LunarGuidance\r\n/s *Loranys se inclina haciendo un respetuoso gesto al entrar*\r\n/Kneel\r\nEND\r\nMACRO 5 \"TRP2 Macro\" Ability_Creature_Cursed_04\r\n/run TRP2RERolIfc()\r\nEND\r\n'),(8,0,1525375308,'SET flaggedTutorials \"v##:##M##%##&##$##4##Z##1##9##I##D##0##J##V##K##X##[##A##B##=##7##)##+##;##-##,##\\##6##5##F##(##3##*##Y##Q##]##W##C##?##^##E##@##U##.##/##L\"\nSET profanityFilter \"0\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraYawSmoothSpeed \"230\"\nSET cameraView \"5\"\nSET cameraDistanceMaxFactor \"1.5\"\nSET talentFrameShown \"1\"\nSET ShowAllSpellRanks \"0\"\n'),(8,2,1525375310,'BINDINGMODE 0\r\nbind NUMPADPLUS CAMERAZOOMIN\r\nbind NUMPADMINUS CAMERAZOOMOUT\r\nbind MOUSEWHEELUP CAMERAZOOMIN\r\nbind MOUSEWHEELDOWN CAMERAZOOMOUT\r\n'),(9,0,1525468430,'SET flaggedTutorials \"v##M##%##&##$##[##E##3##Q##:##)##6##5##4##(##\\##Y##7##K##+##,##X##A##B##;##O##?\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),(9,2,1525468431,'BINDINGMODE 0\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind HOME TOGGLEAUTORUN\r\nbind < TOGGLERUN\r\n'),(10,0,1527184150,'SET autoLootDefault \"1\"\nSET showTargetOfTarget \"1\"\nSET scriptErrors \"1\"\nSET flaggedTutorials \"v##M##%##&##$##:##4##(##6##A##B##Z##1##9##I##D##0##J##V##[##K##+##,##;##-##X##3##7##)##\\##=##5##]##F##Y##*##.##/##Q##?##^##>##C##N##@##E##W##O##<##P\"\nSET profanityFilter \"0\"\nSET chatBubbles \"0\"\nSET chatBubblesParty \"0\"\nSET showTimestamps \"%I:%M:%S\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNamePlayerGuild \"0\"\nSET UnitNamePlayerPVPTitle \"0\"\nSET UnitNameEnemyPlayerName \"0\"\nSET UnitNameEnemyPetName \"0\"\nSET UnitNameFriendlyPlayerName \"0\"\nSET UnitNameFriendlyPetName \"0\"\nSET mouseInvertPitch \"1\"\nSET cameraView \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\n'),(11,0,1525560461,'SET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##M##%##&##$##E##+##7##8##Z##[##(##)##*##1##;##.##/##\\##6##:##5##K##,##X##-##Q##4\"\nSET profanityFilter \"0\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\nSET threatShowNumeric \"1\"\n'),(12,0,1523731074,'SET flaggedTutorials \"v##M##%##&##$##:##7##(##K##+##6##Q##[##)##5##\\##4##A##B##,##U##?##>\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),(12,4,1523785371,'MACRO 1 \"Faction\" Ability_Creature_Disease_05\r\n.mod faction 2053\r\nEND\r\nMACRO 3 \"Npc delete\" Ability_Creature_Cursed_04\r\n.npc delete\r\nEND\r\nMACRO 2 \"Npc move\" Ability_BackStab\r\n.npc move\r\nEND\r\n'),(13,0,1525808477,'SET flaggedTutorials \"v##M##%##&##$##6##:##7##+##A##B##,##W##(##Z##[##C##)##?##1##\\##4##;##5##Q##Y\"\nSET profanityFilter \"0\"\nSET lockActionBars \"0\"\nSET mouseInvertPitch \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\n'),(13,4,1525808479,'MACRO 1 \"DELETE\" Ability_Creature_Cursed_02\r\n.npc delete\r\nEND\r\nMACRO 2 \"MOVE\" Ability_Creature_Cursed_04\r\n.npc move\r\nEND\r\nMACRO 3 \"WP ADD\" Ability_Hunter_BeastCall\r\n.wp add\r\nEND\r\n'),(14,0,1533852112,'SET flaggedTutorials \"v##M##%##&##$##Q##:##[##6##5##(##)##\\##+##A##B##K##4\"\nSET profanityFilter \"0\"\nSET cameraDistanceMaxFactor \"1\"\n'),(17,0,1525965131,'SET flaggedTutorials \"v##M##%##&##$##:##[##)##5##6##\\##A##B##7##(##+##;##-##,##K##W\"\nSET profanityFilter \"0\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),(18,0,1527878550,'SET flaggedTutorials \"v##M##%##&##$##:##[##Q##)##\\##+##;##A##B##K\"\nSET UnitNameFriendlyPlayerName \"0\"\nSET cameraDistanceMaxFactor \"1\"\n'),(19,0,1525534867,'SET flaggedTutorials \"v##M##%##&##$##:##[##Q##)\"\nSET cameraDistanceMaxFactor \"1\"\n'),(20,0,1525536388,'SET flaggedTutorials \"v\"\nSET cameraDistanceMaxFactor \"1\"\n'),(21,0,1525536088,'SET flaggedTutorials \"v##M##:##%##&##$##Q##[##)##\\\"\nSET cameraDistanceMaxFactor \"1\"\n'),(22,0,1525536242,'SET flaggedTutorials \"v##M##:\"\nSET cameraDistanceMaxFactor \"1\"\n'),(23,0,1533847659,'SET autoLootDefault \"1\"\nSET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##R##_##P##M##%##&##$##(##A##B##7##6##[##Q##:##+##;##-##)##\\##K##,##X##Y##4##5\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameEnemyGuardianName \"1\"\nSET UnitNameEnemyTotemName \"1\"\nSET UnitNameFriendlyGuardianName \"1\"\nSET UnitNameFriendlyTotemName \"1\"\nSET fctRepChanges \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\nSET threatShowNumeric \"1\"\nSET ShowAllSpellRanks \"0\"\n'),(23,2,1533828664,'BINDINGMODE 0\r\nbind 1 ACTIONBUTTON1\r\nbind CTRL-1 MULTIACTIONBAR1BUTTON1\r\nbind CTRL-2 MULTIACTIONBAR1BUTTON2\r\nbind CTRL-3 MULTIACTIONBAR1BUTTON3\r\nbind CTRL-4 MULTIACTIONBAR1BUTTON4\r\nbind CTRL-5 MULTIACTIONBAR1BUTTON5\r\nbind CTRL-6 MULTIACTIONBAR1BUTTON6\r\n'),(23,4,1533828665,'MACRO 12 \" Adds\" INV_Misc_QuestionMark\r\n/y ADDS!\r\nEND\r\nMACRO 20 \"100\" Ability_Creature_Cursed_04\r\n/DADOS 100\r\nEND\r\nMACRO 3 \"Adds\" Ability_Creature_Disease_04\r\n/ab adds\r\nEND\r\nMACRO 15 \"Botas1\" Ability_Rogue_Sprint\r\n/use Sandalias de Consagración \r\n/d ¡Adelante Gadgeto botas!\r\nEND\r\nMACRO 13 \"Cambio\" Ability_CheapShot\r\n/y ¡CAMBIO!\r\nEND\r\nMACRO 5 \"Centro /Y\" Ability_Creature_Cursed_04\r\n/y TODOS AL CENTRO\r\nEND\r\nMACRO 22 \"colera\" Ability_Creature_Disease_05\r\n/use Cólera Vengativa\r\n/y ¡Redbull te da alas!\r\nEND\r\nMACRO 11 \"Controlado\" INV_Misc_QuestionMark\r\n/y CONTROLADO!!\r\nEND\r\nMACRO 16 \"coña moto 2\" Ability_Mount_Dreadsteed\r\nEND\r\nMACRO 14 \"coñas moto 1\" Ability_Mount_Charger\r\n/d Pero qué... ¿¡Depósito de reserva?! ¡Tenía que haberlo llenado  en Orgrimmar, mierda!\r\nEND\r\nMACRO 1 \"Kiss\" Ability_Creature_Poison_05\r\n/kiss\r\nEND\r\nMACRO 6 \"Orbes\" Ability_Creature_Cursed_01\r\n/y RANGOS ORBES\r\nEND\r\nMACRO 19 \"Pestes\" Ability_Creature_Disease_03\r\n/castsequence reset=5 <Toque vampírico>,<Peste devoradora>,<Palabra de las Sombras: dolor>\r\nEND\r\nMACRO 18 \"pollo\" Ability_Creature_Poison_03\r\n/gallina\r\nEND\r\nMACRO 21 \"pompaso\" Ability_Ambush\r\n/cast Mano de protección\r\n/use Piedra de Hogar\r\nEND\r\nMACRO 4 \"todos centro\" Ability_Creature_Cursed_04\r\n/ab Todos al centro\r\nEND\r\nMACRO 2 \"Volcanes\" INV_Misc_QuestionMark\r\n/y Volcanes\r\nEND\r\nMACRO 17 \"¡Varita!\" Spell_Nature_Brilliance\r\n/use Disparar\r\n/run \r\nEND\r\n');
/*!40000 ALTER TABLE `account_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_instance_times`
--

DROP TABLE IF EXISTS `account_instance_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_instance_times` (
  `accountId` int(10) unsigned NOT NULL,
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0',
  `releaseTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`,`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_instance_times`
--

LOCK TABLES `account_instance_times` WRITE;
/*!40000 ALTER TABLE `account_instance_times` DISABLE KEYS */;
INSERT INTO `account_instance_times` VALUES (1,1,1551568835),(2,1,1533944663),(3,1,1551567955),(5,3,1527444461),(6,1,1551569473),(7,1,1525299009),(8,1,1527715040),(9,1,1526849018),(10,1,1527539659),(11,1,1525902064),(12,2,1523823514),(13,1,1526491615),(14,1,1533855764),(17,4,1525981897),(18,1,1525538346),(19,1,1525538516),(20,1,1525538702),(21,1,1525539696),(22,1,1525539913),(23,1,1533851383);
/*!40000 ALTER TABLE `account_instance_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_tutorial`
--

DROP TABLE IF EXISTS `account_tutorial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_tutorial` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `tut0` int(10) unsigned NOT NULL DEFAULT '0',
  `tut1` int(10) unsigned NOT NULL DEFAULT '0',
  `tut2` int(10) unsigned NOT NULL DEFAULT '0',
  `tut3` int(10) unsigned NOT NULL DEFAULT '0',
  `tut4` int(10) unsigned NOT NULL DEFAULT '0',
  `tut5` int(10) unsigned NOT NULL DEFAULT '0',
  `tut6` int(10) unsigned NOT NULL DEFAULT '0',
  `tut7` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_tutorial`
--

LOCK TABLES `account_tutorial` WRITE;
/*!40000 ALTER TABLE `account_tutorial` DISABLE KEYS */;
INSERT INTO `account_tutorial` VALUES (1,3789500407,267532934,0,0,0,0,0,0),(2,4026515447,133479143,0,0,0,0,0,0),(3,4185898487,91630307,0,0,0,0,0,0),(4,4194343,8397312,0,0,0,0,0,0),(5,1626276791,84943488,0,0,0,0,0,0),(6,2045707191,128983686,0,0,0,0,0,0),(7,3989770231,254818946,0,0,0,0,0,0),(8,3924791287,129514438,0,0,0,0,0,0),(9,1758429623,28322434,0,0,0,0,0,0),(10,1643054007,128989824,0,0,0,0,0,0),(11,13566903,17834624,0,0,0,0,0,0),(12,1615790519,16917120,0,0,0,0,0,0),(13,1624178871,27271680,0,0,0,0,0,0),(14,1615265943,16786048,0,0,0,0,0,0),(17,1624114071,25690752,0,0,0,0,0,0),(18,1623195815,8397440,0,0,0,0,0,0),(19,4194311,8397312,0,0,0,0,0,0),(20,4194311,8397312,0,0,0,0,0,0),(21,4194311,25174528,0,0,0,0,0,0),(22,4194304,512,0,0,0,0,0,0),(23,13566903,28320384,0,0,0,0,0,0);
/*!40000 ALTER TABLE `account_tutorial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addons`
--

DROP TABLE IF EXISTS `addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addons` (
  `name` varchar(120) NOT NULL DEFAULT '',
  `crc` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Addons';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addons`
--

LOCK TABLES `addons` WRITE;
/*!40000 ALTER TABLE `addons` DISABLE KEYS */;
INSERT INTO `addons` VALUES ('Blizzard_AchievementUI',1276933997),('Blizzard_ArenaUI',1276933997),('Blizzard_AuctionUI',1276933997),('Blizzard_BarbershopUI',1276933997),('Blizzard_BattlefieldMinimap',1276933997),('Blizzard_BindingUI',1276933997),('Blizzard_Calendar',1276933997),('Blizzard_CombatLog',1276933997),('Blizzard_CombatText',1276933997),('Blizzard_DebugTools',1276933997),('Blizzard_GlyphUI',1276933997),('Blizzard_GMChatUI',1276933997),('Blizzard_GMSurveyUI',1276933997),('Blizzard_GuildBankUI',1276933997),('Blizzard_InspectUI',1276933997),('Blizzard_ItemSocketingUI',1276933997),('Blizzard_MacroUI',1276933997),('Blizzard_RaidUI',1276933997),('Blizzard_TalentUI',1276933997),('Blizzard_TimeManager',1276933997),('Blizzard_TokenUI',1276933997),('Blizzard_TradeSkillUI',1276933997),('Blizzard_TrainerUI',1276933997);
/*!40000 ALTER TABLE `addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team`
--

DROP TABLE IF EXISTS `arena_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `captainGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `backgroundColor` int(10) unsigned NOT NULL DEFAULT '0',
  `emblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `emblemColor` int(10) unsigned NOT NULL DEFAULT '0',
  `borderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borderColor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team`
--

LOCK TABLES `arena_team` WRITE;
/*!40000 ALTER TABLE `arena_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team_member`
--

DROP TABLE IF EXISTS `arena_team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team_member` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `personalRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`,`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team_member`
--

LOCK TABLES `arena_team_member` WRITE;
/*!40000 ALTER TABLE `arena_team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auctionbidders`
--

DROP TABLE IF EXISTS `auctionbidders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auctionbidders` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `bidderguid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`bidderguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auctionbidders`
--

LOCK TABLES `auctionbidders` WRITE;
/*!40000 ALTER TABLE `auctionbidders` DISABLE KEYS */;
/*!40000 ALTER TABLE `auctionbidders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auctionhouse`
--

DROP TABLE IF EXISTS `auctionhouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auctionhouse` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `houseid` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `itemguid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemowner` int(10) unsigned NOT NULL DEFAULT '0',
  `buyoutprice` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `buyguid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastbid` int(10) unsigned NOT NULL DEFAULT '0',
  `startbid` int(10) unsigned NOT NULL DEFAULT '0',
  `deposit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auctionhouse`
--

LOCK TABLES `auctionhouse` WRITE;
/*!40000 ALTER TABLE `auctionhouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `auctionhouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_addons`
--

DROP TABLE IF EXISTS `banned_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banned_addons` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Version` varchar(255) NOT NULL DEFAULT '',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `idx_name_ver` (`Name`,`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned_addons`
--

LOCK TABLES `banned_addons` WRITE;
/*!40000 ALTER TABLE `banned_addons` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `battleground_deserters`
--

DROP TABLE IF EXISTS `battleground_deserters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `battleground_deserters` (
  `guid` int(10) unsigned NOT NULL COMMENT 'characters.guid',
  `type` tinyint(3) unsigned NOT NULL COMMENT 'type of the desertion',
  `datetime` datetime NOT NULL COMMENT 'datetime of the desertion'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `battleground_deserters`
--

LOCK TABLES `battleground_deserters` WRITE;
/*!40000 ALTER TABLE `battleground_deserters` DISABLE KEYS */;
/*!40000 ALTER TABLE `battleground_deserters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bugreport`
--

DROP TABLE IF EXISTS `bugreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bugreport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Debug System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bugreport`
--

LOCK TABLES `bugreport` WRITE;
/*!40000 ALTER TABLE `bugreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_events` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creator` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '4',
  `dungeon` int(10) NOT NULL DEFAULT '-1',
  `eventtime` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_invites`
--

DROP TABLE IF EXISTS `calendar_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_invites` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `event` bigint(20) unsigned NOT NULL DEFAULT '0',
  `invitee` int(10) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `statustime` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_invites`
--

LOCK TABLES `calendar_invites` WRITE;
/*!40000 ALTER TABLE `calendar_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels` (
  `name` varchar(128) NOT NULL,
  `team` int(10) unsigned NOT NULL,
  `announce` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ownership` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `password` varchar(32) DEFAULT NULL,
  `bannedList` text,
  `lastUsed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`,`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Channel System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_account_data`
--

DROP TABLE IF EXISTS `character_account_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_account_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`guid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_account_data`
--

LOCK TABLES `character_account_data` WRITE;
/*!40000 ALTER TABLE `character_account_data` DISABLE KEYS */;
INSERT INTO `character_account_data` VALUES (2,1,1524916507,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"8.548800\"\nSET cameraSavedPitch \"10.800001\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(2,7,1522140832,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(3,1,1553293513,'SET minimapZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"3.998400\"\nSET cameraSavedPitch \"9.149996\"\nSET showKeyring \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(3,5,1551903265,'MACRO 16777225 \"Arquero\" Ability_PierceDamage\r\n.npc add 901006\r\nEND\r\nMACRO 16777221 \"Borrar NPC\" Spell_Totem_WardOfDraining\r\n.npc del\r\nEND\r\nMACRO 16777218 \"Fusilero\" Ability_Vehicle_DemolisherFlameCatapult\r\n.npc add 901002\r\nEND\r\nMACRO 16777217 \"Hacedor\" Ability_Creature_Cursed_01\r\n.morph 18135\r\n.mod scale .20\r\nEND\r\nMACRO 16777220 \"MiliciaLordaeron\" Ability_MeleeDamage\r\n.npc add 901005\r\nEND\r\nMACRO 16777226 \"NPC ALIADO\" Ability_TownWatch\r\n.npc set factionid 1\r\nEND\r\nMACRO 16777219 \"Ranger Alto Elfo\" Ability_TrueShot\r\n.npc add 901003\r\nEND\r\nMACRO 16777224 \"SoldadoLordaeron\" Ability_DualWield\r\n.npc add 901001\r\nEND\r\nMACRO 16777222 \"zombie 1 \" Ability_Creature_Disease_02\r\n.npc add 10382\r\nEND\r\nMACRO 16777223 \"Zombie 2\" Ability_Creature_Disease_02\r\n.npc add 10381d\r\nEND\r\nMACRO 16777227 \"Zombie3\" Ability_Creature_Disease_02\r\n.npc add 4474\r\nEND\r\n'),(3,7,1525554693,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.029576 0.163378\nDIMENSIONS 430.000061 119.999985\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nNAME Todo\nSIZE 0\nCOLOR 0 0 0 63\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 1\nPOSITION BOTTOMRIGHT -0.324261 0.141259\nDIMENSIONS 429.999939 120.000008\n\nMESSAGES\nSYSTEM\nERRORS\nIGNORED\nCHANNEL\nTARGETICONS\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(4,1,1533659485,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.997600\"\nSET cameraSavedPitch \"2.850011\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_SPELL_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(4,7,1525352871,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.038862 0.193128\nDIMENSIONS 392.999908 274.000000\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.046445 0.059242\nDIMENSIONS 430.000000 120.000000\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(5,1,1526230054,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"6.549601\"\nSET cameraSavedPitch \"8.099994\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrame \"1\"\nSET showTokenFrameHonor \"1\"\n'),(5,7,1526230055,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.033175 0.194313\nDIMENSIONS 413.999969 365.000031\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.039810 0.235782\nDIMENSIONS 430.000000 120.000015\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(13,1,1522178327,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_RANGED_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(13,7,1522178328,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(14,1,1522178529,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(14,7,1522178530,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(15,1,1527440861,'SET equipmentManager \"1\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"1.416098\"\nSET cameraSavedPitch \"62.975957\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(15,7,1522935418,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(16,1,1551565600,'SET equipmentManager \"1\"\nSET minimapZoom \"0\"\nSET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"12.419533\"\nSET nameplateAllowOverlap \"0\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\nSET miniWorldMap \"1\"\n'),(16,7,1523187450,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 91 131 255 N\nTEXT_EMOTE 91 131 255 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME Onrol\nSIZE 0\nCOLOR 0 0 0 183\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.028280 0.205103\nDIMENSIONS 352.098846 399.999969\n\nMESSAGES\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nAFK\nDND\nBN_WHISPER_INFORM\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 16777218\n\nEND\n\nWINDOW 2\nNAME .\nSIZE 12\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.023071 0.213281\nDIMENSIONS 429.999969 119.999969\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nNAME Offrol\nSIZE 0\nCOLOR 0 0 0 186\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 1\nPOSITION BOTTOMRIGHT -0.054419 0.202153\nDIMENSIONS 386.543213 400.000000\n\nMESSAGES\nSYSTEM\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nERRORS\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 2097153\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(21,1,1525897016,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"16.712761\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(21,7,1525561970,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 Y\nPARTY 170 170 255 Y\nRAID 255 127 0 Y\nGUILD 64 255 64 Y\nOFFICER 64 192 64 Y\nYELL 255 64 64 Y\nWHISPER 255 128 255 Y\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 Y\nEMOTE 255 128 64 Y\nTEXT_EMOTE 255 128 64 Y\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 Y\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 Y\nDND 255 128 255 Y\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 Y\nRAID_WARNING 255 72 0 Y\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 Y\nBATTLEGROUND_LEADER 255 219 183 Y\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 Y\nGUILD_ACHIEVEMENT 64 255 64 Y\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 Y\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 Y\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 Y\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 255\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.025155 0.255468\nDIMENSIONS 469.506134 163.631561\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 0\nUNINTERACTABLE 1\nDOCKED 0\nSHOWN 1\nPOSITION TOPLEFT 0.157967 -0.030469\nDIMENSIONS 429.999969 119.999969\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(22,1,1525374866,'SET equipmentManager \"1\"\nSET minimapZoom \"0\"\nSET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"8.221711\"\nSET cameraSavedPitch \"22.350000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\nSET miniWorldMap \"1\"\n'),(22,7,1523042870,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(24,1,1551564974,'SET equipmentManager \"1\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"12.001200\"\nSET cameraSavedPitch \"16.749938\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(24,5,1526331786,'MACRO 16777219 \"LUZ\" Spell_Holy_DevineAegis\r\n/myspell  38589\r\nEND\r\nMACRO 16777218 \"REV\" Ability_Druid_LunarGuidance\r\n/reverenciar\r\nEND\r\nMACRO 16777217 \"SALUT\" Ability_Druid_LunarGuidance\r\n/say la luz guarde a los de bien\r\nEND\r\n'),(24,7,1551564975,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 12\nCOLOR 0 0 0 40\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.029477 0.151619\nDIMENSIONS 404.305847 131.482361\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.041706 0.327014\nDIMENSIONS 430.000000 120.000015\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(25,1,1523818595,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"3.998401\"\nSET cameraSavedPitch \"3.633574\"\nSET showKeyring \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(25,7,1523383220,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(26,1,1525536523,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"7.549201\"\nSET cameraSavedPitch \"27.007058\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(26,7,1525533807,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(27,1,1535652729,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.003999\"\nSET cameraSavedPitch \"15.796341\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(27,7,1527445317,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 0\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nPOSITION BOTTOMLEFT 0.042158 0.113092\nDIMENSIONS 608.000061 142.588364\n\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.029974 0.065104\nDIMENSIONS 555.690063 120.000015\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(28,1,1523571285,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"9.548402\"\nSET cameraSavedPitch \"16.649997\"\nSET nameplateShowEnemies \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(28,7,1523571286,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 52428803\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(29,1,1526844038,'SET minimapZoom \"1\"\nSET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v##*\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"19.350006\"\nSET nameplateShowEnemies \"1\"\nSET showBattlefieldMinimap \"2\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\nSET minimapTrackedInfo \"MINIMAP_TRACKING_TRAINER_CLASS\"\n'),(29,7,1523821004,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(30,1,1535654403,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.004004\"\nSET cameraSavedPitch \"5.750023\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(30,7,1524866255,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(31,1,1551481588,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.997599\"\nSET cameraSavedPitch \"22.950013\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(31,7,1526396629,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(32,1,1527712410,'SET equipmentManager \"1\"\nSET minimapInsideZoom \"0\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v$Q)\"\nSET trackedAchievements \"v\"\nSET advancedWorldMap \"1\"\nSET cameraSavedDistance \"5.883197\"\nSET cameraSavedPitch \"13.049996\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(32,7,1525214114,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(33,1,1525970204,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"8.002797\"\nSET cameraSavedPitch \"14.100010\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(33,7,1525861591,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(35,1,1525534868,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(35,7,1525536047,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(36,1,1525535033,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(36,7,1525536089,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(37,1,1525536389,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(37,7,1525536390,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(38,1,1525536243,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"10.000000\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(38,7,1525536244,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(39,1,1533940988,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"8.996398\"\nSET cameraSavedPitch \"15.000014\"\nSET nameplateShowEnemies \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(39,5,1527439807,'MACRO 16777217 \"Morp\" Ability_Ambush\r\n.morph 3000010054\r\nEND\r\n'),(39,7,1527363823,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(40,1,1527878551,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"7.549202\"\nSET cameraSavedPitch \"-8.616095\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(40,7,1527878552,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(41,1,1533852113,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"4.998000\"\nSET cameraSavedPitch \"30.868463\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(41,7,1528642782,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(42,1,1533847660,'SET minimapInsideZoom \"2\"\nSET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"4.995667\"\nSET cameraSavedPitch \"16.349967\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\nSET showTokenFrameHonor \"1\"\n'),(42,7,1533829202,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n');
/*!40000 ALTER TABLE `character_account_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_achievement`
--

DROP TABLE IF EXISTS `character_achievement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_achievement` (
  `guid` int(10) unsigned NOT NULL,
  `achievement` smallint(5) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`achievement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_achievement`
--

LOCK TABLES `character_achievement` WRITE;
/*!40000 ALTER TABLE `character_achievement` DISABLE KEYS */;
INSERT INTO `character_achievement` VALUES (2,6,1522079401),(2,7,1522079401),(2,8,1522079401),(2,9,1522079401),(2,10,1522079401),(2,11,1522079401),(2,12,1522079401),(2,13,1522079401),(2,457,1522079401),(2,465,1522079401),(2,891,1522080552),(2,1405,1522079401),(2,2716,1522081603),(3,6,1522094130),(3,7,1522094130),(3,8,1522094130),(3,9,1522094130),(3,10,1522094130),(3,11,1522094130),(3,12,1522094130),(3,13,1522094130),(3,16,1523818593),(3,705,1523818593),(3,891,1524869576),(4,6,1522085450),(4,7,1522085450),(4,8,1522085450),(4,9,1522085450),(4,10,1522085450),(4,11,1522085450),(4,12,1522085450),(4,13,1522085450),(4,16,1525374679),(4,464,1522085450),(4,705,1525374679),(4,889,1522965128),(4,891,1522965128),(4,1408,1522085450),(5,6,1522087205),(5,7,1522087206),(5,8,1522087206),(5,9,1522087206),(5,10,1522087206),(5,11,1522087314),(5,12,1522087314),(5,13,1522087314),(5,131,1522087206),(5,132,1522087206),(5,133,1522087206),(5,461,1522087314),(7,6,1522144298),(7,7,1522144298),(7,8,1522144298),(7,9,1522144298),(7,10,1522144298),(7,11,1522144298),(7,12,1522144298),(7,13,1522144298),(7,1409,1522144298),(11,459,1522160028),(12,462,1522178041),(13,6,1522178326),(13,7,1522178326),(13,8,1522178326),(13,9,1522178326),(13,10,1522178326),(13,11,1522178326),(13,12,1522178326),(13,13,1522178326),(13,1410,1522178326),(14,6,1522178528),(14,7,1522178528),(14,8,1522178528),(14,9,1522178528),(14,10,1522178528),(14,11,1522178528),(14,12,1522178528),(14,13,1522178528),(15,6,1522935293),(15,7,1522935293),(15,8,1522935293),(15,9,1522935293),(15,10,1522935293),(15,11,1522935293),(15,12,1522935293),(15,13,1522935293),(15,16,1523133373),(15,545,1522940692),(15,705,1523133373),(15,879,1523133454),(15,889,1523133437),(15,891,1523133373),(15,2076,1523133440),(15,2078,1523133443),(16,6,1522936079),(16,7,1522936079),(16,8,1522936079),(16,9,1522936079),(16,10,1522936079),(16,11,1522936079),(16,12,1522936079),(16,13,1522936079),(16,16,1522950365),(16,545,1522940637),(16,705,1522950365),(16,879,1522951844),(16,889,1522940889),(16,890,1522940946),(16,891,1522940889),(16,892,1522941057),(21,6,1522968708),(21,7,1522968708),(21,8,1522968708),(21,9,1522968708),(21,10,1522968708),(21,11,1522968708),(21,12,1522968708),(21,13,1522968708),(21,16,1522968708),(21,705,1522968708),(21,879,1522968988),(21,889,1522968950),(21,891,1522968950),(22,6,1523030624),(22,7,1523030624),(22,8,1523030624),(22,9,1523030624),(22,10,1523030624),(22,11,1523030624),(22,12,1523030624),(22,13,1523030624),(22,16,1523030624),(22,545,1523123972),(22,621,1523043331),(22,705,1523030624),(22,727,1523043597),(22,879,1523035160),(22,889,1523041053),(22,891,1523041053),(24,6,1523041495),(24,7,1523041495),(24,8,1523041495),(24,9,1523041495),(24,10,1523041495),(24,11,1523041495),(24,12,1523041495),(24,13,1523041495),(24,16,1523041495),(24,545,1526248184),(24,705,1523041495),(24,879,1523041968),(24,889,1523041956),(24,891,1523041956),(24,2076,1523133314),(24,2078,1523133310),(25,6,1523187349),(25,7,1523187349),(25,8,1523187349),(25,9,1523187349),(25,10,1523187349),(25,11,1523187349),(25,12,1523187349),(25,13,1523187349),(25,16,1523187349),(25,705,1523187349),(26,6,1523213247),(26,7,1523213247),(26,8,1523213247),(26,9,1523213247),(26,10,1523213247),(26,11,1523213247),(26,12,1523213247),(26,13,1523213247),(26,16,1523213247),(26,705,1523213247),(27,6,1523300809),(27,7,1523300809),(27,8,1523300809),(27,9,1523300809),(27,10,1523300809),(27,11,1523300809),(27,12,1523300809),(27,13,1523300809),(27,16,1523300809),(27,545,1524867556),(27,705,1523300809),(27,889,1525200632),(27,891,1525200632),(28,6,1523571285),(28,7,1523571285),(28,8,1523571285),(28,9,1523571285),(28,10,1523571285),(28,11,1523571285),(28,12,1523571285),(28,13,1523571285),(28,16,1523571285),(28,705,1523571285),(28,1407,1523571285),(29,6,1523817844),(29,7,1523817844),(29,8,1523817844),(29,9,1523817844),(29,10,1523817844),(29,11,1523817844),(29,12,1523817844),(29,13,1523817844),(29,16,1523817844),(29,545,1523857140),(29,705,1523817844),(29,889,1523819719),(29,891,1523819719),(30,6,1523911110),(30,7,1523911110),(30,8,1523911110),(30,9,1523911110),(30,10,1523911110),(30,11,1523911110),(30,12,1523911110),(30,13,1523911110),(30,16,1523911110),(30,458,1523911110),(30,964,1525458396),(31,6,1524871087),(31,7,1524871087),(31,8,1524871087),(31,9,1524871087),(31,10,1524871087),(31,11,1524871087),(31,12,1524871087),(31,13,1524871087),(31,16,1524871087),(31,705,1524871087),(32,6,1525214113),(32,7,1525214113),(32,8,1525214113),(32,9,1525214113),(32,10,1525214113),(32,11,1525214113),(32,12,1525214113),(32,13,1525214113),(32,16,1525214113),(32,648,1525277235),(32,666,1525371601),(32,705,1525214113),(32,889,1525214437),(32,890,1525215643),(32,891,1525214437),(32,892,1525215647),(32,1017,1525264958),(32,2084,1525216231),(32,2141,1525215670),(32,2716,1525214453),(33,6,1525445533),(33,7,1525445533),(33,8,1525445533),(33,9,1525445533),(33,10,1525445533),(33,11,1525445533),(33,12,1525445533),(33,13,1525445533),(33,16,1525445533),(33,705,1525445533),(35,6,1525534867),(35,7,1525534867),(35,8,1525534867),(35,9,1525534867),(35,10,1525534867),(35,11,1525534867),(35,12,1525534867),(35,13,1525534867),(35,16,1525534867),(35,460,1524936776),(35,705,1525534867),(36,6,1525535032),(36,7,1525535032),(36,8,1525535032),(36,9,1525535032),(36,10,1525535032),(36,11,1525535032),(36,12,1525535032),(36,13,1525535032),(36,16,1525535032),(36,463,1524937112),(36,705,1525535032),(37,6,1525535051),(37,7,1525535051),(37,8,1525535051),(37,9,1525535051),(37,10,1525535051),(37,11,1525535051),(37,12,1525535051),(37,13,1525535051),(37,16,1525535051),(37,705,1525535051),(38,6,1525536242),(38,7,1525536242),(38,8,1525536242),(38,9,1525536242),(38,10,1525536242),(38,11,1525536242),(38,12,1525536242),(38,13,1525536242),(38,16,1525536242),(38,705,1525536242),(39,6,1527362141),(39,7,1527362141),(39,8,1527362141),(39,9,1527362141),(39,10,1527362141),(39,11,1527362141),(39,12,1527362141),(39,13,1527362141),(39,16,1527362141),(39,545,1527363508),(39,705,1527362141),(40,6,1527878548),(40,7,1527878548),(40,8,1527878548),(40,9,1527878548),(40,10,1527878548),(40,11,1527878548),(40,12,1527878548),(40,13,1527878548),(40,16,1527878548),(40,705,1527878548),(41,6,1528641766),(41,7,1528641766),(41,8,1528641766),(41,9,1528641766),(41,10,1528641766),(41,11,1528641766),(41,12,1528641766),(41,13,1528641766),(41,16,1528641766),(41,705,1528641766),(42,6,1533828819),(42,7,1533828819),(42,8,1533828819),(42,9,1533828819),(42,10,1533828819),(42,11,1533828819),(42,12,1533828819),(42,13,1533828819),(42,16,1533828819),(42,705,1533828819),(42,889,1533832796),(42,891,1533832796);
/*!40000 ALTER TABLE `character_achievement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_achievement_progress`
--

DROP TABLE IF EXISTS `character_achievement_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_achievement_progress` (
  `guid` int(10) unsigned NOT NULL,
  `criteria` smallint(5) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_achievement_progress`
--

LOCK TABLES `character_achievement_progress` WRITE;
/*!40000 ALTER TABLE `character_achievement_progress` DISABLE KEYS */;
INSERT INTO `character_achievement_progress` VALUES (2,34,81,1522079401),(2,35,81,1522079401),(2,36,81,1522079401),(2,37,81,1522079401),(2,38,81,1522079401),(2,39,81,1522079401),(2,40,81,1522079401),(2,41,81,1522079401),(2,111,1,1522785812),(2,148,1,1522785812),(2,162,3186,1522935427),(2,167,1,1522079283),(2,655,1,1522079283),(2,753,1,1522079283),(2,755,26,1522935381),(2,756,1,1522079283),(2,950,1,1522785559),(2,952,1,1522785531),(2,954,1,1522785551),(2,955,1,1522785570),(2,966,1,1522786629),(2,992,500,1522079283),(2,993,500,1522079283),(2,994,3100,1522079283),(2,995,500,1522079283),(2,996,4000,1522079283),(2,1045,1,1522785489),(2,1050,1,1522935326),(2,1107,1,1522786619),(2,1108,1,1522786622),(2,1109,1,1522785610),(2,1110,1,1522786573),(2,1111,1,1522785603),(2,1112,1,1522785605),(2,1147,1,1522140954),(2,1149,1,1522140878),(2,1196,1,1522140987),(2,1206,1,1522141039),(2,1209,1,1522141031),(2,1508,1,1522079325),(2,1521,1,1522079713),(2,1870,75,1522080552),(2,1871,75,1522080552),(2,1872,75,1522080552),(2,1873,75,1522080552),(2,1884,3500,1522079283),(2,2020,200,1522079283),(2,2342,1,1522081368),(2,2344,1,1522081303),(2,2345,1,1522081284),(2,2346,1,1522081240),(2,2347,1,1522081381),(2,2348,1,1522081217),(2,2349,1,1522081260),(2,2350,1,1522081356),(2,3354,351,1522935434),(2,3506,351,1522935434),(2,3507,351,1522935434),(2,3510,351,1522935434),(2,3511,351,1522935434),(2,3512,351,1522935434),(2,3723,1,1522081368),(2,3725,1,1522081303),(2,3726,1,1522081284),(2,3727,1,1522081240),(2,3728,1,1522081381),(2,3729,1,1522081217),(2,3730,1,1522081260),(2,3731,1,1522081356),(2,4093,351,1522935434),(2,4224,30103951,1522080577),(2,4763,3500,1522079283),(2,4787,1,1522080552),(2,4943,164,1522787717),(2,4944,5,1522935427),(2,4946,1,1522079368),(2,4948,2,1522079410),(2,4953,3,1522935427),(2,5212,81,1522079401),(2,5215,81,1522079401),(2,5230,81,1522079401),(2,5301,7,1522140831),(2,5313,500,1522079283),(2,5314,500,1522079283),(2,5315,500,1522079283),(2,5316,3100,1522079283),(2,5317,4000,1522079283),(2,5371,3433,1522785809),(2,5372,16068,1522785811),(2,5373,897,1522935409),(2,5374,6046,1522787717),(2,5375,164,1522787717),(2,5376,6046,1522787717),(2,5512,5,1522935427),(2,5529,9,1522935427),(2,5531,2,1522079410),(2,5532,1,1522080251),(2,5576,1,1522079283),(2,5577,26,1522935381),(2,5580,1,1522079283),(2,5589,1,1522079283),(2,5593,1,1522785812),(2,6142,10,1522081525),(2,7550,1,1522080552),(2,7551,1,1522080552),(2,7552,1,1522080552),(2,8819,500,1522079283),(2,8820,500,1522079283),(2,8821,500,1522079283),(2,8822,500,1522079283),(2,9224,1,1522080552),(2,9598,81,1522079401),(2,9619,1,1522081603),(2,9683,500,1522079283),(2,9684,500,1522079283),(2,9685,4000,1522079283),(2,9686,500,1522079283),(2,9687,3100,1522079283),(2,12698,100,1522081603),(2,13409,3500,1522079283),(3,34,100,1522094130),(3,35,100,1522094130),(3,36,100,1522094130),(3,37,100,1522094130),(3,38,100,1522094130),(3,39,100,1522094130),(3,40,100,1522094130),(3,41,100,1522094130),(3,111,2,1522085273),(3,162,816,1525548722),(3,167,500,1523818593),(3,655,500,1523818593),(3,753,500,1523818593),(3,755,500,1523818593),(3,756,500,1523818593),(3,834,500,1523818593),(3,1045,1,1522094130),(3,1050,1,1523818593),(3,1051,1,1523818593),(3,1052,1,1523818593),(3,1071,1,1523818593),(3,1072,1,1523818593),(3,1074,1,1523818593),(3,1076,1,1523818593),(3,1077,1,1522181286),(3,1079,1,1522181286),(3,1080,1,1522181286),(3,1081,1,1522181286),(3,1090,1,1522094130),(3,1146,1,1522085048),(3,1149,1,1522094130),(3,1428,1,1522174772),(3,1539,1,1522094130),(3,1733,1,1522094130),(3,1870,75,1524869576),(3,1871,75,1524869576),(3,1872,75,1524869576),(3,1873,75,1524869576),(3,2020,200,1522085000),(3,2030,4000,1522085000),(3,2031,3100,1522085000),(3,2032,3100,1522085000),(3,2033,3100,1522085000),(3,2034,3000,1522085000),(3,2072,1537,1523818595),(3,4224,15190252,1527362597),(3,4943,58,1522705068),(3,4944,2,1522705180),(3,4955,2,1522705180),(3,5212,100,1522094130),(3,5215,100,1522094130),(3,5233,100,1522094130),(3,5301,7,1522181286),(3,5328,3100,1522085000),(3,5329,3100,1522085000),(3,5330,3100,1522085000),(3,5331,4000,1522085000),(3,5332,3000,1522085000),(3,5371,2511,1522085253),(3,5372,4375,1523818595),(3,5373,438,1525548720),(3,5374,58,1522705068),(3,5375,58,1522705068),(3,5376,58,1522705068),(3,5529,2,1523213568),(3,5576,500,1523818593),(3,5577,500,1523818593),(3,5580,500,1523818593),(3,5581,500,1523818593),(3,5589,500,1523818593),(3,5593,2,1522085273),(3,8749,1,1522094130),(3,8819,500,1522085000),(3,8820,500,1522085000),(3,8821,500,1522085000),(3,8822,500,1522085000),(3,9598,100,1522094130),(3,9678,3100,1522085000),(3,9679,3000,1522085000),(3,9680,3100,1522085000),(3,9681,3100,1522085000),(3,9682,4000,1522085000),(3,12698,125,1524869576),(4,34,80,1522085450),(4,35,80,1522085450),(4,36,80,1522085450),(4,37,80,1522085450),(4,38,80,1522085450),(4,39,80,1522085450),(4,40,80,1522085450),(4,41,80,1522085450),(4,111,1,1522087749),(4,162,76195,1522790663),(4,167,500,1525374679),(4,514,1,1525374679),(4,653,500,1525374679),(4,655,500,1525374679),(4,657,500,1525374679),(4,756,500,1525374679),(4,757,500,1525374679),(4,965,1,1522790349),(4,1045,1,1522086039),(4,1050,1,1522790600),(4,1088,1,1522086894),(4,1090,1,1522086079),(4,1091,1,1522086919),(4,1146,1,1522085304),(4,1147,1,1522522705),(4,1149,1,1522522705),(4,1150,1,1522941850),(4,1428,1,1522522705),(4,1586,1,1525374679),(4,1733,1,1522085679),(4,1870,150,1522965128),(4,1871,150,1522965128),(4,1872,150,1522965128),(4,1873,150,1522965128),(4,2020,200,1522085292),(4,2030,4000,1522085292),(4,2031,3100,1522085292),(4,2032,3100,1522085292),(4,2033,3100,1522085292),(4,2034,3000,1522085292),(4,2072,5087,1522790305),(4,3354,2593,1522790665),(4,3506,2593,1522790665),(4,3507,2593,1522790665),(4,3510,2593,1522790665),(4,3511,2593,1522790665),(4,3512,2593,1522790665),(4,4093,2593,1522790665),(4,4224,304001643,1522940928),(4,4944,46,1522790663),(4,4949,1,1522790483),(4,4953,43,1522790663),(4,4955,1,1522704950),(4,4958,1,1522790436),(4,5212,100,1522085486),(4,5216,100,1522085486),(4,5233,100,1522085486),(4,5301,8,1522790381),(4,5328,3100,1522085292),(4,5329,3100,1522085292),(4,5330,3100,1522085292),(4,5331,4000,1522085292),(4,5332,3000,1522085292),(4,5371,5176,1522790305),(4,5372,13196,1522790305),(4,5373,873,1522087912),(4,5374,1788,1522087969),(4,5376,1788,1522087969),(4,5512,16,1522790663),(4,5529,50,1522790663),(4,5580,500,1525374679),(4,5585,500,1525374679),(4,5586,500,1525374679),(4,5589,500,1525374679),(4,5591,500,1525374679),(4,5593,1,1522087749),(4,6142,8,1522939329),(4,6388,1,1525374679),(4,7226,1,1525374679),(4,8749,1,1522086105),(4,8819,500,1522085292),(4,8820,500,1522085292),(4,8821,500,1522085292),(4,8822,500,1522085292),(4,8824,50,1522790523),(4,9368,1,1522790436),(4,9598,80,1522085450),(4,9678,3100,1522085292),(4,9679,3000,1522085292),(4,9680,3100,1522085292),(4,9681,3100,1522085292),(4,9682,4000,1522085292),(4,12698,135,1525374679),(5,34,55,1522087205),(5,35,55,1522087206),(5,36,55,1522087206),(5,37,55,1522087206),(5,38,55,1522087206),(5,39,155,1522087314),(5,40,155,1522087314),(5,41,155,1522087314),(5,167,270,1522087206),(5,641,270,1522087206),(5,656,270,1522087206),(5,753,270,1522087206),(5,754,270,1522087206),(5,755,270,1522087206),(5,756,270,1522087206),(5,840,300,1522087206),(5,841,300,1522087206),(5,842,300,1522087206),(5,843,300,1522087206),(5,844,300,1522087206),(5,2020,200,1522087206),(5,2030,4000,1522087206),(5,2031,3100,1522087206),(5,2032,3100,1522087206),(5,2033,3100,1522087206),(5,2034,3000,1522087206),(5,2342,1,1526230054),(5,2343,1,1523602577),(5,2344,1,1523602577),(5,2345,1,1523602577),(5,2346,1,1523602577),(5,2347,1,1523602577),(5,2350,1,1523602577),(5,2351,1,1523602577),(5,2355,1,1523602577),(5,2417,3200,1522087206),(5,3723,1,1526230054),(5,3724,1,1523602577),(5,3725,1,1523602577),(5,3726,1,1523602577),(5,3727,1,1523602577),(5,3728,1,1523602577),(5,3731,1,1523602577),(5,3732,1,1523602577),(5,3733,1,1523602577),(5,3736,1,1523602577),(5,4224,1002985,1527606687),(5,4743,3200,1522087206),(5,5212,155,1522087314),(5,5219,155,1522087314),(5,5233,155,1522087314),(5,5249,270,1522087206),(5,5301,6,1522087206),(5,5328,3100,1522087206),(5,5329,3100,1522087206),(5,5330,3100,1522087206),(5,5331,4000,1522087206),(5,5332,3000,1522087206),(5,5371,236,1522087314),(5,5372,717,1522087314),(5,5529,4,1522087376),(5,5562,270,1522087206),(5,5576,270,1522087206),(5,5577,270,1522087206),(5,5578,270,1522087206),(5,5579,270,1522087206),(5,5589,270,1522087206),(5,5590,270,1522087206),(5,5592,270,1522087206),(5,5816,1,1523602577),(5,6394,15,1522087200),(5,7222,15,1522087200),(5,8819,500,1522087206),(5,8820,500,1522087206),(5,8821,500,1522087206),(5,8822,500,1522087206),(5,9598,55,1522087206),(5,9678,3100,1522087206),(5,9679,3000,1522087206),(5,9680,3100,1522087206),(5,9681,3100,1522087206),(5,9682,4000,1522087206),(5,12698,110,1522087314),(7,34,101,1522144298),(7,35,101,1522144298),(7,36,101,1522144298),(7,37,101,1522144298),(7,38,101,1522144298),(7,39,101,1522144298),(7,40,101,1522144298),(7,41,101,1522144298),(7,167,1,1522143767),(7,655,1,1522143767),(7,657,1,1522143767),(7,756,1,1522143767),(7,757,1,1522143767),(7,2020,200,1522143767),(7,2030,3100,1522143767),(7,2031,3100,1522143767),(7,2032,4000,1522143767),(7,2033,3100,1522143767),(7,2034,3000,1522143767),(7,4224,1000000,1522143767),(7,5212,100,1522144307),(7,5216,100,1522144307),(7,5234,100,1522144307),(7,5301,6,1522143768),(7,5328,4000,1522143767),(7,5329,3100,1522143767),(7,5330,3100,1522143767),(7,5331,3100,1522143767),(7,5332,3000,1522143767),(7,5529,1,1522144396),(7,5580,1,1522143767),(7,5586,1,1522143767),(7,5589,1,1522143767),(7,5591,1,1522143767),(7,8819,500,1522143767),(7,8820,500,1522143767),(7,8821,500,1522143767),(7,8822,500,1522143767),(7,9598,101,1522144298),(7,9678,4000,1522143767),(7,9679,3000,1522143767),(7,9680,3100,1522143767),(7,9681,3100,1522143767),(7,9682,3100,1522143767),(7,12698,80,1522144298),(13,34,80,1522178326),(13,35,80,1522178326),(13,36,80,1522178326),(13,37,80,1522178326),(13,38,80,1522178326),(13,39,80,1522178326),(13,40,80,1522178326),(13,41,80,1522178326),(13,167,1,1522178326),(13,641,1,1522178326),(13,651,1,1522178326),(13,653,1,1522178326),(13,753,1,1522178326),(13,754,1,1522178326),(13,756,1,1522178326),(13,992,4000,1522178326),(13,993,3100,1522178326),(13,994,500,1522178326),(13,995,3100,1522178326),(13,996,400,1522178326),(13,2020,200,1522178326),(13,4224,1000000,1522178326),(13,5212,80,1522178326),(13,5218,80,1522178326),(13,5235,80,1522178326),(13,5301,6,1522178326),(13,5313,3100,1522178326),(13,5314,4000,1522178326),(13,5315,3100,1522178326),(13,5316,500,1522178326),(13,5317,400,1522178326),(13,5576,1,1522178326),(13,5578,1,1522178326),(13,5579,1,1522178326),(13,5584,1,1522178326),(13,5585,1,1522178326),(13,5589,1,1522178326),(13,8819,500,1522178326),(13,8820,500,1522178326),(13,8821,500,1522178326),(13,8822,500,1522178326),(13,9598,80,1522178326),(13,9683,4000,1522178326),(13,9684,3100,1522178326),(13,9685,400,1522178326),(13,9686,3100,1522178326),(13,9687,500,1522178326),(13,12698,80,1522178326),(14,34,80,1522178528),(14,35,80,1522178528),(14,36,80,1522178528),(14,37,80,1522178528),(14,38,80,1522178528),(14,39,80,1522178528),(14,40,80,1522178528),(14,41,80,1522178528),(14,167,1,1522178528),(14,641,1,1522178528),(14,653,1,1522178528),(14,655,1,1522178528),(14,753,1,1522178528),(14,754,1,1522178528),(14,755,1,1522178528),(14,756,1,1522178528),(14,2020,200,1522178528),(14,2030,3100,1522178528),(14,2031,3100,1522178528),(14,2032,4000,1522178528),(14,2033,3100,1522178528),(14,2034,3000,1522178528),(14,4224,1000000,1522178528),(14,5212,80,1522178528),(14,5220,80,1522178528),(14,5234,80,1522178528),(14,5301,6,1522178528),(14,5328,4000,1522178528),(14,5329,3100,1522178528),(14,5330,3100,1522178528),(14,5331,3100,1522178528),(14,5332,3000,1522178528),(14,5576,1,1522178528),(14,5577,1,1522178528),(14,5578,1,1522178528),(14,5579,1,1522178528),(14,5580,1,1522178528),(14,5585,1,1522178528),(14,5589,1,1522178528),(14,8819,500,1522178528),(14,8820,500,1522178528),(14,8821,500,1522178528),(14,8822,500,1522178528),(14,9598,80,1522178528),(14,9678,4000,1522178528),(14,9679,3000,1522178528),(14,9680,3100,1522178528),(14,9681,3100,1522178528),(14,9682,3100,1522178528),(14,12698,80,1522178528),(15,34,80,1522935293),(15,35,80,1522935293),(15,36,80,1522935293),(15,37,80,1522935293),(15,38,80,1522935293),(15,39,80,1522935293),(15,40,80,1522935293),(15,41,80,1522935293),(15,167,400,1523133373),(15,641,400,1523133373),(15,652,400,1523133373),(15,653,400,1523133373),(15,655,400,1523133373),(15,656,400,1523133373),(15,657,400,1523133373),(15,753,400,1523133373),(15,754,400,1523133373),(15,755,400,1523133373),(15,756,400,1523133373),(15,834,400,1523133373),(15,1050,1,1522935480),(15,1147,1,1522941454),(15,1150,1,1522941705),(15,1850,1,1523133454),(15,1870,150,1523133437),(15,1871,150,1523133437),(15,1872,75,1523133373),(15,1873,150,1523133437),(15,2020,200,1522935293),(15,2030,4000,1522935293),(15,2031,3100,1522935293),(15,2032,3100,1522935293),(15,2033,3100,1522935293),(15,2034,3000,1522935293),(15,2072,1662,1522940425),(15,2341,1,1522940692),(15,3357,111173,1522940692),(15,4224,100877427,1522941155),(15,4787,9,1523133468),(15,5212,80,1522935293),(15,5220,80,1522935293),(15,5233,80,1522935293),(15,5301,7,1523133373),(15,5328,3100,1522935293),(15,5329,3100,1522935293),(15,5330,3100,1522935293),(15,5331,4000,1522935293),(15,5332,3000,1522935293),(15,5371,544,1522940425),(15,5372,761,1522940425),(15,5576,400,1523133373),(15,5577,400,1523133373),(15,5578,400,1523133373),(15,5579,400,1523133373),(15,5580,400,1523133373),(15,5581,400,1523133373),(15,5585,400,1523133373),(15,5588,400,1523133373),(15,5589,400,1523133373),(15,5590,400,1523133373),(15,5591,400,1523133373),(15,5802,2,1525559292),(15,6142,9,1523133454),(15,6195,1,1523133458),(15,7369,1,1523133440),(15,7380,1,1523133443),(15,7550,9,1523133468),(15,7551,9,1523133468),(15,7552,9,1523133468),(15,8819,500,1522935293),(15,8820,500,1522935293),(15,8821,500,1522935293),(15,8822,500,1522935293),(15,9223,9,1523133468),(15,9598,80,1522935293),(15,9678,3100,1522935293),(15,9679,3000,1522935293),(15,9680,3100,1522935293),(15,9681,3100,1522935293),(15,9682,4000,1522935293),(15,12698,165,1523133443),(16,34,80,1522936079),(16,35,80,1522936079),(16,36,80,1522936079),(16,37,80,1522936079),(16,38,80,1522936079),(16,39,80,1522936079),(16,40,80,1522936079),(16,41,80,1522936079),(16,111,18,1551482175),(16,149,1,1522949660),(16,151,1,1522949391),(16,162,622,1522966145),(16,167,400,1522950365),(16,169,4,1523813103),(16,171,2,1529102534),(16,641,400,1522950365),(16,652,400,1522950365),(16,653,400,1522950365),(16,655,400,1522950365),(16,656,400,1522950365),(16,657,400,1522950365),(16,753,400,1522950365),(16,754,400,1522950365),(16,755,400,1522950365),(16,756,400,1522950365),(16,834,400,1522950365),(16,944,1,1522945286),(16,964,1,1522945586),(16,965,1,1522945704),(16,968,1,1522945935),(16,1017,1,1522948230),(16,1018,1,1522948328),(16,1021,1,1522948225),(16,1022,1,1522948184),(16,1023,1,1522948149),(16,1025,1,1522948121),(16,1026,1,1522948032),(16,1049,1,1522944697),(16,1050,1,1522944619),(16,1051,1,1523040632),(16,1052,1,1522945012),(16,1071,1,1522945089),(16,1072,1,1522945031),(16,1073,1,1522945069),(16,1104,1,1522945428),(16,1105,1,1522945491),(16,1130,1,1522948849),(16,1132,1,1522948824),(16,1134,1,1522948808),(16,1135,1,1522948956),(16,1139,1,1522949766),(16,1145,1,1522949406),(16,1147,1,1522941459),(16,1149,1,1522950697),(16,1150,1,1522941862),(16,1176,1,1522947467),(16,1178,1,1522946739),(16,1181,1,1522947239),(16,1182,1,1522946846),(16,1183,1,1522947208),(16,1184,1,1522946914),(16,1185,1,1522949927),(16,1186,1,1522949998),(16,1188,1,1522949941),(16,1190,1,1522949850),(16,1269,1,1522945981),(16,1271,1,1522946415),(16,1272,1,1522946056),(16,1273,1,1522946162),(16,1746,1,1526844848),(16,1850,1,1522951844),(16,1870,150,1522940889),(16,1871,225,1522940946),(16,1872,150,1522940889),(16,1873,300,1522941057),(16,2020,200,1522936079),(16,2030,4000,1522936079),(16,2031,3100,1522936079),(16,2032,3100,1522936079),(16,2033,3100,1522936079),(16,2034,3000,1522936079),(16,2072,1947,1523040583),(16,2341,1,1522940637),(16,2355,1,1522943632),(16,3233,1,1551482492),(16,3236,1,1525469364),(16,3238,4,1523040268),(16,3357,111173,1522940637),(16,3736,1,1522943632),(16,4224,100837427,1522941030),(16,4787,5,1522951912),(16,4944,1,1522966145),(16,4958,1,1522966145),(16,5008,6,1523813795),(16,5212,80,1522936079),(16,5220,80,1522936079),(16,5233,80,1522936079),(16,5301,8,1522950365),(16,5328,3100,1522936079),(16,5329,3100,1522936079),(16,5330,3100,1522936079),(16,5331,4000,1522936079),(16,5332,3000,1522936079),(16,5371,8613,1522949660),(16,5372,51522,1523816745),(16,5373,186,1522966145),(16,5512,2,1522949660),(16,5529,3,1522966145),(16,5576,400,1522950365),(16,5577,400,1522950365),(16,5578,400,1522950365),(16,5579,400,1522950365),(16,5580,400,1522950365),(16,5581,400,1522950365),(16,5585,400,1522950365),(16,5588,400,1522950365),(16,5589,400,1522950365),(16,5590,400,1522950365),(16,5591,400,1522950365),(16,5593,18,1551482175),(16,5594,14,1551482175),(16,6142,13,1522951859),(16,6846,2,1529102534),(16,6847,4,1523813103),(16,7550,5,1522951912),(16,7551,5,1522951912),(16,7552,5,1522951912),(16,8819,500,1522936079),(16,8820,500,1522936079),(16,8821,500,1522936079),(16,8822,500,1522936079),(16,9223,5,1522951912),(16,9598,80,1522936079),(16,9678,3100,1522936079),(16,9679,3000,1522936079),(16,9680,3100,1522936079),(16,9681,3100,1522936079),(16,9682,4000,1522936079),(16,12698,165,1522950365),(21,34,80,1522968708),(21,35,80,1522968708),(21,36,80,1522968708),(21,37,80,1522968708),(21,38,80,1522968708),(21,39,80,1522968708),(21,40,80,1522968708),(21,41,80,1522968708),(21,111,1,1522968901),(21,167,400,1522968708),(21,641,400,1522968708),(21,652,400,1523132262),(21,653,400,1522968708),(21,655,400,1522968708),(21,656,400,1523132262),(21,657,400,1523132262),(21,753,400,1522968708),(21,754,400,1522968708),(21,755,400,1522968708),(21,756,400,1522968708),(21,834,400,1522968708),(21,1050,1,1522970038),(21,1850,1,1522968988),(21,1870,150,1522968950),(21,1871,150,1522968950),(21,1872,150,1522968950),(21,1873,150,1522968950),(21,2020,200,1522968708),(21,2030,4000,1522968708),(21,2031,3100,1522968708),(21,2032,3100,1522968708),(21,2033,3100,1522968708),(21,2034,3000,1522968708),(21,2072,1602,1523132324),(21,4224,1000000,1522968708),(21,4787,1,1522968990),(21,5212,80,1522968708),(21,5220,80,1522968708),(21,5233,80,1522968708),(21,5301,6,1522968708),(21,5328,3100,1522968708),(21,5329,3100,1522968708),(21,5330,3100,1522968708),(21,5331,4000,1522968708),(21,5332,3000,1522968708),(21,5371,441,1523132324),(21,5372,441,1523132324),(21,5576,400,1522968708),(21,5577,400,1522968708),(21,5578,400,1522968708),(21,5579,400,1522968708),(21,5580,400,1522968708),(21,5581,400,1522968708),(21,5585,400,1522968708),(21,5588,400,1523132262),(21,5589,400,1522968708),(21,5590,400,1523132262),(21,5591,400,1523132262),(21,5593,1,1522968901),(21,5594,1,1522968901),(21,6142,6,1522969281),(21,6195,1,1522968990),(21,7550,1,1522968990),(21,7551,1,1522968990),(21,7552,1,1522968990),(21,8819,500,1522968708),(21,8820,500,1522968708),(21,8821,500,1522968708),(21,8822,500,1522968708),(21,9223,1,1522968990),(21,9598,80,1522968708),(21,9678,3100,1522968708),(21,9679,3000,1522968708),(21,9680,3100,1522968708),(21,9681,3100,1522968708),(21,9682,4000,1522968708),(21,12698,135,1522968950),(22,34,80,1523030624),(22,35,80,1523030624),(22,36,80,1523030624),(22,37,80,1523030624),(22,38,80,1523030624),(22,39,80,1523030624),(22,40,80,1523030624),(22,41,80,1523030624),(22,73,1,1523044321),(22,111,3,1523213672),(22,162,4656,1523214211),(22,167,400,1523030624),(22,169,1,1523213672),(22,230,1,1523044321),(22,231,1,1523044321),(22,232,1,1523044321),(22,233,1,1523044321),(22,234,1,1523044321),(22,236,1,1523044321),(22,641,400,1523030624),(22,653,400,1523030624),(22,655,400,1523030624),(22,753,400,1523030624),(22,754,400,1523030624),(22,755,400,1523030624),(22,756,400,1523030624),(22,834,400,1523030624),(22,1045,1,1523038526),(22,1049,1,1523041316),(22,1050,1,1523034521),(22,1090,1,1523037666),(22,1147,1,1523037754),(22,1149,1,1523037563),(22,1152,1,1523125824),(22,1154,1,1523125853),(22,1157,1,1523126122),(22,1746,1,1523039776),(22,1850,1,1523035160),(22,1870,150,1523041053),(22,1871,150,1523041053),(22,1872,150,1523041053),(22,1873,150,1523041053),(22,2020,200,1523030624),(22,2030,4000,1523030624),(22,2031,3100,1523030624),(22,2032,3100,1523030624),(22,2033,3100,1523030624),(22,2034,3000,1523030624),(22,2072,2056,1523038541),(22,2239,1,1523044321),(22,2341,1,1523123971),(22,2342,1,1523214125),(22,2345,1,1523214124),(22,2350,1,1523214126),(22,2355,1,1523214068),(22,2903,1,1523043331),(22,3231,1,1523121548),(22,3233,5,1524085308),(22,3238,2,1523727707),(22,3355,540,1523044321),(22,3357,444692,1523840601),(22,3361,894,1523840550),(22,3513,540,1523044321),(22,3631,1,1523044321),(22,3723,1,1523214125),(22,3726,1,1523214124),(22,3731,1,1523214126),(22,3736,1,1523214068),(22,4091,894,1523840550),(22,4092,540,1523044321),(22,4224,300006240,1523121519),(22,4787,8,1523655092),(22,4944,9,1523126123),(22,4948,8,1523126123),(22,4958,1,1523126051),(22,5008,4,1523121351),(22,5212,80,1523030624),(22,5220,80,1523030624),(22,5233,80,1523030624),(22,5301,7,1524084823),(22,5328,3100,1523030624),(22,5329,3100,1523030624),(22,5330,3100,1523030624),(22,5331,4000,1523030624),(22,5332,3000,1523030624),(22,5371,1227,1523038541),(22,5372,1327,1523038541),(22,5373,1584,1523126060),(22,5512,9,1523126123),(22,5529,9,1523126123),(22,5576,400,1523030624),(22,5577,400,1523030624),(22,5578,400,1523030624),(22,5579,400,1523030624),(22,5580,400,1523030624),(22,5581,400,1523030624),(22,5585,400,1523030624),(22,5589,400,1523030624),(22,5593,3,1523213672),(22,5594,3,1523213672),(22,5802,2,1523123743),(22,5909,1,1523044321),(22,6142,21,1523214099),(22,6195,1,1523041059),(22,6219,1,1523043597),(22,6847,1,1523213672),(22,6883,1,1523123860),(22,7550,8,1523655092),(22,7551,8,1523655092),(22,7552,8,1523655092),(22,8819,500,1523030624),(22,8820,500,1523030624),(22,8821,500,1523030624),(22,8822,500,1523030624),(22,9223,8,1523655092),(22,9598,80,1523030624),(22,9678,3100,1523030624),(22,9679,3000,1523030624),(22,9680,3100,1523030624),(22,9681,3100,1523030624),(22,9682,4000,1523030624),(22,12698,165,1523123972),(24,34,80,1523041495),(24,35,80,1523041495),(24,36,80,1523041495),(24,37,80,1523041495),(24,38,80,1523041495),(24,39,80,1523041495),(24,40,80,1523041495),(24,41,80,1523041495),(24,111,2,1526682232),(24,162,349846,1533712871),(24,167,400,1523041495),(24,171,1,1526682232),(24,641,400,1523041495),(24,651,400,1527441184),(24,652,400,1523045670),(24,653,400,1523041495),(24,655,400,1523041495),(24,753,400,1523041495),(24,754,400,1523041495),(24,755,400,1523041495),(24,756,400,1523041495),(24,834,400,1523041495),(24,840,75,1523134327),(24,841,75,1523134327),(24,842,75,1523134327),(24,843,75,1523134327),(24,844,75,1523134327),(24,1049,1,1525536750),(24,1050,1,1523818953),(24,1052,1,1551568320),(24,1147,1,1523041822),(24,1149,1,1523133034),(24,1308,1,1527439489),(24,1521,1,1530741581),(24,1733,1,1523133541),(24,1850,1,1523041968),(24,1870,150,1523041956),(24,1871,150,1523041956),(24,1872,150,1523041956),(24,1873,150,1523041956),(24,2020,200,1523041495),(24,2030,4000,1523041495),(24,2031,3100,1523041495),(24,2032,3100,1523041495),(24,2033,3100,1523041495),(24,2034,3000,1523041495),(24,2072,2801,1523133575),(24,2341,1,1526248184),(24,2345,1,1523041838),(24,2349,1,1525199759),(24,2355,1,1525199906),(24,3238,4,1526677250),(24,3357,333519,1551565990),(24,3361,750,1523961143),(24,3726,1,1523041838),(24,3730,1,1525199759),(24,3736,1,1525199906),(24,4091,750,1523961143),(24,4224,123322800,1523041850),(24,4323,1,1529095340),(24,4697,10,1527697337),(24,4705,43,1551568742),(24,4787,5,1523133314),(24,4943,95230,1533712870),(24,4944,47,1533712871),(24,4946,4,1533712871),(24,4953,46,1533712871),(24,4958,1,1526329999),(24,5008,2,1523961196),(24,5183,5,1527698141),(24,5184,3,1533851280),(24,5212,80,1523041495),(24,5220,80,1523041495),(24,5233,80,1523041495),(24,5249,1,1523134327),(24,5301,6,1523041495),(24,5328,3100,1523041495),(24,5329,3100,1523041495),(24,5330,3100,1523041495),(24,5331,4000,1523041495),(24,5332,3000,1523041495),(24,5371,4146,1533712435),(24,5372,92798,1551569105),(24,5373,3240,1533712817),(24,5374,28432,1526682712),(24,5375,95230,1533712870),(24,5376,28432,1526682712),(24,5529,47,1533712871),(24,5562,1,1523134327),(24,5576,400,1523041495),(24,5577,400,1523041495),(24,5578,400,1523041495),(24,5579,400,1523041495),(24,5580,400,1523041495),(24,5581,400,1523041495),(24,5584,400,1527441184),(24,5585,400,1523041495),(24,5588,400,1523045670),(24,5589,400,1523041495),(24,5592,1,1523134327),(24,5593,2,1526682232),(24,5594,2,1526682232),(24,6142,17,1525555549),(24,6195,1,1523042015),(24,6394,2,1523134327),(24,6846,1,1526682232),(24,7114,2,1527705104),(24,7222,2,1523134327),(24,7314,5,1527697349),(24,7369,1,1523133314),(24,7380,1,1523133310),(24,7550,5,1523133314),(24,7551,5,1523133314),(24,7552,5,1523133314),(24,8819,500,1523041495),(24,8820,500,1523041495),(24,8821,500,1523041495),(24,8822,500,1523041495),(24,9223,5,1523133314),(24,9598,80,1523041495),(24,9678,3100,1523041495),(24,9679,3000,1523041495),(24,9680,3100,1523041495),(24,9681,3100,1523041495),(24,9682,4000,1523041495),(24,12698,165,1526248184),(25,34,90,1523187349),(25,35,90,1523187349),(25,36,90,1523187349),(25,37,90,1523187349),(25,38,90,1523187349),(25,39,90,1523187349),(25,40,90,1523187349),(25,41,90,1523187349),(25,167,450,1523187349),(25,641,450,1523187349),(25,653,450,1523187349),(25,655,450,1523187349),(25,753,450,1523187349),(25,754,450,1523187349),(25,755,450,1523187349),(25,756,450,1523187349),(25,834,450,1523187349),(25,2020,200,1523187349),(25,2030,4000,1523187349),(25,2031,3100,1523187349),(25,2032,3100,1523187349),(25,2033,3100,1523187349),(25,2034,3000,1523187349),(25,4224,993742890,1523212838),(25,5212,90,1523187349),(25,5220,90,1523187349),(25,5233,90,1523187349),(25,5301,6,1523187349),(25,5328,3100,1523187349),(25,5329,3100,1523187349),(25,5330,3100,1523187349),(25,5331,4000,1523187349),(25,5332,3000,1523187349),(25,5576,450,1523187349),(25,5577,450,1523187349),(25,5578,450,1523187349),(25,5579,450,1523187349),(25,5580,450,1523187349),(25,5581,450,1523187349),(25,5585,450,1523187349),(25,5589,450,1523187349),(25,8819,500,1523187349),(25,8820,500,1523187349),(25,8821,500,1523187349),(25,8822,500,1523187349),(25,9598,90,1523187349),(25,9678,3100,1523187349),(25,9679,3000,1523187349),(25,9680,3100,1523187349),(25,9681,3100,1523187349),(25,9682,4000,1523187349),(25,12698,115,1523187349),(26,34,80,1523213247),(26,35,80,1523213247),(26,36,80,1523213247),(26,37,80,1523213247),(26,38,80,1523213247),(26,39,80,1523213247),(26,40,80,1523213247),(26,41,80,1523213247),(26,167,400,1523213247),(26,641,400,1523213247),(26,653,400,1523213247),(26,655,400,1523213247),(26,753,400,1523213247),(26,754,400,1523213247),(26,755,400,1523213247),(26,756,400,1523213247),(26,834,400,1523213247),(26,2020,200,1523213247),(26,2030,4000,1523213247),(26,2031,3100,1523213247),(26,2032,3100,1523213247),(26,2033,3100,1523213247),(26,2034,3000,1523213247),(26,4224,1000000,1523213247),(26,5212,80,1523213247),(26,5220,80,1523213247),(26,5233,80,1523213247),(26,5301,6,1523213247),(26,5328,3100,1523213247),(26,5329,3100,1523213247),(26,5330,3100,1523213247),(26,5331,4000,1523213247),(26,5332,3000,1523213247),(26,5576,400,1523213247),(26,5577,400,1523213247),(26,5578,400,1523213247),(26,5579,400,1523213247),(26,5580,400,1523213247),(26,5581,400,1523213247),(26,5585,400,1523213247),(26,5589,400,1523213247),(26,8819,500,1523213247),(26,8820,500,1523213247),(26,8821,500,1523213247),(26,8822,500,1523213247),(26,9598,80,1523213247),(26,9678,3100,1523213247),(26,9679,3000,1523213247),(26,9680,3100,1523213247),(26,9681,3100,1523213247),(26,9682,4000,1523213247),(26,12698,115,1523213247),(27,34,80,1523300809),(27,35,80,1523300809),(27,36,80,1523300809),(27,37,80,1523300809),(27,38,80,1523300809),(27,39,80,1523300809),(27,40,80,1523300809),(27,41,80,1523300809),(27,111,4,1525979913),(27,162,111,1525203879),(27,167,400,1523300809),(27,641,400,1523300809),(27,651,400,1527536059),(27,652,400,1524857889),(27,653,400,1523300809),(27,655,400,1523300809),(27,656,400,1524857889),(27,657,400,1524857889),(27,753,400,1523300809),(27,754,400,1523300809),(27,755,400,1523300809),(27,756,400,1523300809),(27,834,400,1523300809),(27,1049,1,1525979877),(27,1050,1,1523818955),(27,1051,1,1525203843),(27,1308,1,1527445893),(27,1870,150,1525200632),(27,1871,150,1525200632),(27,1872,150,1525200632),(27,1873,150,1525200632),(27,2020,200,1523300809),(27,2030,4000,1523300809),(27,2031,3100,1523300809),(27,2032,3100,1523300809),(27,2033,3100,1523300809),(27,2034,3000,1523300809),(27,2072,1488,1525203844),(27,2341,1,1524867556),(27,2355,1,1524870044),(27,3232,1,1526337897),(27,3357,222346,1525266182),(27,3359,1,1525204648),(27,3360,10000,1525204648),(27,3736,1,1524870044),(27,4224,1987536,1523820669),(27,4787,2,1525200654),(27,5212,80,1523300809),(27,5220,80,1523300809),(27,5233,80,1523300809),(27,5301,6,1523300809),(27,5328,3100,1523300809),(27,5329,3100,1523300809),(27,5330,3100,1523300809),(27,5331,4000,1523300809),(27,5332,3000,1523300809),(27,5371,1905,1525202144),(27,5372,15262,1525203844),(27,5373,111,1525203879),(27,5374,213,1525203879),(27,5576,400,1523300809),(27,5577,400,1523300809),(27,5578,400,1523300809),(27,5579,400,1523300809),(27,5580,400,1523300809),(27,5581,400,1523300809),(27,5582,400,1527536059),(27,5584,400,1527536059),(27,5585,400,1523300809),(27,5587,400,1527536059),(27,5588,400,1524857889),(27,5589,400,1523300809),(27,5590,400,1524857889),(27,5591,400,1524857889),(27,5593,4,1525979913),(27,5594,2,1525979913),(27,6142,6,1525200646),(27,7550,2,1525200654),(27,7551,2,1525200654),(27,7552,2,1525200654),(27,8819,500,1523300809),(27,8820,500,1523300809),(27,8821,500,1523300809),(27,8822,500,1523300809),(27,9223,2,1525200654),(27,9378,400,1527536059),(27,9598,80,1523300809),(27,9678,3100,1523300809),(27,9679,3000,1523300809),(27,9680,3100,1523300809),(27,9681,3100,1523300809),(27,9682,4000,1523300809),(27,12698,145,1525200632),(28,34,80,1523571285),(28,35,80,1523571285),(28,36,80,1523571285),(28,37,80,1523571285),(28,38,80,1523571285),(28,39,80,1523571285),(28,40,80,1523571285),(28,41,80,1523571285),(28,167,400,1523571285),(28,514,1,1523571291),(28,641,400,1523571285),(28,653,400,1523571285),(28,655,400,1523571285),(28,753,400,1523571285),(28,754,400,1523571285),(28,755,400,1523571285),(28,756,400,1523571285),(28,834,400,1523571285),(28,1149,1,1523571892),(28,2020,200,1523571285),(28,2030,3100,1523571285),(28,2031,4000,1523571285),(28,2032,3100,1523571285),(28,2033,3100,1523571285),(28,2034,3000,1523571285),(28,3361,962,1523571636),(28,4091,962,1523571636),(28,4224,1000000,1523571285),(28,5212,80,1523571285),(28,5220,80,1523571285),(28,5232,80,1523571285),(28,5301,6,1523571285),(28,5328,3100,1523571285),(28,5329,3100,1523571285),(28,5330,4000,1523571285),(28,5331,3100,1523571285),(28,5332,3000,1523571285),(28,5576,400,1523571285),(28,5577,400,1523571285),(28,5578,400,1523571285),(28,5579,400,1523571285),(28,5580,400,1523571285),(28,5581,400,1523571285),(28,5585,400,1523571285),(28,5589,400,1523571285),(28,8819,500,1523571285),(28,8820,500,1523571285),(28,8821,500,1523571285),(28,8822,500,1523571285),(28,9598,80,1523571285),(28,9678,3100,1523571285),(28,9679,3000,1523571285),(28,9680,3100,1523571285),(28,9681,4000,1523571285),(28,9682,3100,1523571285),(28,12698,115,1523571285),(29,34,80,1523817844),(29,35,80,1523817844),(29,36,80,1523817844),(29,37,80,1523817844),(29,38,80,1523817844),(29,39,80,1523817844),(29,40,80,1523817844),(29,41,80,1523817844),(29,73,1,1523817900),(29,111,2,1524855812),(29,167,400,1523817844),(29,230,1,1523817900),(29,231,1,1523817900),(29,232,1,1523817900),(29,233,1,1523817900),(29,234,1,1523817900),(29,236,1,1523817900),(29,641,400,1523817844),(29,651,400,1523838026),(29,652,400,1523821001),(29,653,400,1523817844),(29,654,400,1523838026),(29,655,400,1523817844),(29,656,400,1523821001),(29,657,400,1523821001),(29,753,400,1523817844),(29,754,400,1523817844),(29,755,400,1523817844),(29,756,400,1523817844),(29,834,400,1523817844),(29,1050,1,1523818957),(29,1146,1,1523817873),(29,1149,1,1523856784),(29,1308,1,1523821073),(29,1870,150,1523819719),(29,1871,150,1523819719),(29,1872,150,1523819719),(29,1873,150,1523819719),(29,2020,200,1523817844),(29,2030,4082,1523817900),(29,2031,3120,1523817900),(29,2032,3120,1523817900),(29,2033,3120,1523817900),(29,2034,3020,1523817900),(29,2239,1,1523817900),(29,2341,1,1523857140),(29,3355,30,1523817900),(29,3357,333519,1524853356),(29,3361,52576,1523856703),(29,3513,30,1523817900),(29,3631,1,1523817900),(29,4091,52576,1523856703),(29,4092,30,1523817900),(29,4224,11475630,1523820694),(29,4787,2,1523821028),(29,5212,80,1523817844),(29,5220,80,1523817844),(29,5233,80,1523817844),(29,5301,6,1523817844),(29,5328,3120,1523817900),(29,5329,3120,1523817900),(29,5330,3120,1523817900),(29,5331,4082,1523817900),(29,5332,3020,1523817900),(29,5371,92,1523819096),(29,5372,197,1524857374),(29,5576,400,1523817844),(29,5577,400,1523817844),(29,5578,400,1523817844),(29,5579,400,1523817844),(29,5580,400,1523817844),(29,5581,400,1523817844),(29,5582,400,1523838026),(29,5583,400,1523838026),(29,5584,400,1523838026),(29,5585,400,1523817844),(29,5587,400,1523838026),(29,5588,400,1523821001),(29,5589,400,1523817844),(29,5590,400,1523821001),(29,5591,400,1523821001),(29,5593,2,1524855812),(29,5594,2,1524855812),(29,6142,3,1523820976),(29,7550,2,1523821028),(29,7551,2,1523821028),(29,7552,2,1523821028),(29,7884,1,1523817900),(29,8819,500,1523817844),(29,8820,500,1523817844),(29,8821,500,1523817844),(29,8822,500,1523817844),(29,9223,2,1523821028),(29,9378,400,1523838026),(29,9598,80,1523817844),(29,9678,3120,1523817900),(29,9679,3020,1523817900),(29,9680,3120,1523817900),(29,9681,3120,1523817900),(29,9682,4082,1523817900),(29,12698,145,1523857140),(30,34,90,1523911110),(30,35,90,1523911110),(30,36,90,1523911110),(30,37,90,1523911110),(30,38,90,1523911110),(30,39,90,1523911110),(30,40,90,1523911110),(30,41,90,1523911110),(30,111,1,1525446305),(30,167,450,1523911110),(30,169,1,1525446305),(30,653,450,1523911110),(30,756,450,1523911110),(30,1043,1,1525444098),(30,1046,1,1525444107),(30,1049,1,1525451032),(30,1050,1,1525444179),(30,1051,1,1525444189),(30,1147,1,1523973063),(30,1149,1,1523974442),(30,1156,1,1523973062),(30,1168,1,1525376910),(30,1171,1,1525376922),(30,1173,1,1525376902),(30,1361,1,1525277345),(30,2020,200,1523911110),(30,2030,4000,1523911110),(30,2031,3100,1523911110),(30,2032,3100,1523911110),(30,2033,3100,1523911110),(30,2034,3000,1523911110),(30,2072,6671,1525458396),(30,2345,1,1525209047),(30,3726,1,1525209047),(30,3768,1,1525462180),(30,4224,3010000,1525214468),(30,4944,1,1525376124),(30,4958,1,1525376124),(30,5212,90,1523911110),(30,5221,90,1523911110),(30,5233,90,1523911110),(30,5301,6,1523911110),(30,5328,3100,1523911110),(30,5329,3100,1523911110),(30,5330,3100,1523911110),(30,5331,4000,1523911110),(30,5332,3000,1523911110),(30,5371,8388,1525458396),(30,5372,23144,1525461831),(30,5512,1,1525380772),(30,5529,1,1525380772),(30,5585,450,1523911110),(30,5587,450,1523911110),(30,5589,450,1523911110),(30,5593,1,1525446305),(30,5594,1,1525446305),(30,6142,1,1525209045),(30,6847,1,1525446305),(30,8819,500,1523911110),(30,8820,500,1523911110),(30,8821,500,1523911110),(30,8822,500,1523911110),(30,9378,450,1523911110),(30,9598,90,1523911110),(30,9678,3100,1523911110),(30,9679,3000,1523911110),(30,9680,3100,1523911110),(30,9681,3100,1523911110),(30,9682,4000,1523911110),(30,12698,100,1525458396),(31,34,90,1524871087),(31,35,90,1524871087),(31,36,90,1524871087),(31,37,90,1524871087),(31,38,90,1524871087),(31,39,90,1524871087),(31,40,90,1524871087),(31,41,90,1524871087),(31,162,2495,1526397642),(31,167,450,1524871087),(31,519,1,1527449267),(31,641,450,1524871087),(31,651,450,1527541214),(31,652,450,1527541214),(31,653,450,1524871087),(31,655,450,1524871087),(31,657,450,1527541214),(31,753,450,1524871087),(31,754,450,1524871087),(31,755,450,1524871087),(31,756,450,1524871087),(31,834,450,1524871087),(31,949,1,1526396850),(31,1050,1,1526396628),(31,1062,1,1526396628),(31,1064,1,1526396628),(31,1149,1,1526498256),(31,1308,1,1527449488),(31,1428,1,1526396628),(31,2020,200,1524871087),(31,2030,4000,1524871087),(31,2031,3100,1524871087),(31,2032,3100,1524871087),(31,2033,3100,1524871087),(31,2034,3000,1524871087),(31,2072,3639,1527449269),(31,4224,1000000,1524871087),(31,4293,1,1527706739),(31,4672,1,1527706798),(31,4705,7,1527706869),(31,4944,1,1526397642),(31,4955,1,1526397642),(31,5212,90,1524871087),(31,5220,90,1524871087),(31,5233,90,1524871087),(31,5301,6,1524871087),(31,5328,3100,1524871087),(31,5329,3100,1524871087),(31,5330,3100,1524871087),(31,5331,4000,1524871087),(31,5332,3000,1524871087),(31,5371,4163,1527449269),(31,5372,6869,1527449269),(31,5373,690,1526397634),(31,5374,21571,1526765974),(31,5376,505,1527706739),(31,5512,2,1526413616),(31,5529,2,1526413616),(31,5576,450,1524871087),(31,5577,450,1524871087),(31,5578,450,1524871087),(31,5579,450,1524871087),(31,5580,450,1524871087),(31,5581,450,1524871087),(31,5582,450,1527541214),(31,5584,450,1527541214),(31,5585,450,1524871087),(31,5587,450,1527541214),(31,5588,450,1527541214),(31,5589,450,1524871087),(31,5591,450,1527541214),(31,8819,500,1524871087),(31,8820,500,1524871087),(31,8821,500,1524871087),(31,8822,500,1524871087),(31,9378,450,1527541214),(31,9598,90,1524871087),(31,9678,3100,1524871087),(31,9679,3000,1524871087),(31,9680,3100,1524871087),(31,9681,3100,1524871087),(31,9682,4000,1524871087),(31,12698,115,1524871087),(32,34,80,1525214113),(32,35,80,1525214113),(32,36,80,1525214113),(32,37,80,1525214113),(32,38,80,1525214113),(32,39,80,1525214113),(32,40,80,1525214113),(32,41,80,1525214113),(32,73,1,1525373595),(32,77,1,1525373595),(32,111,8,1525380772),(32,162,3056563,1525376124),(32,167,400,1525214113),(32,169,2,1525371185),(32,230,1,1525373595),(32,231,1,1525373595),(32,232,1,1525373595),(32,233,1,1525373595),(32,234,1,1525373595),(32,236,1,1525373595),(32,508,1,1525371825),(32,555,1,1525277235),(32,573,1,1525371601),(32,641,400,1525214113),(32,651,400,1527711440),(32,652,400,1525264854),(32,653,400,1525214113),(32,655,400,1525214113),(32,656,400,1525264854),(32,657,400,1525264854),(32,753,400,1525214113),(32,754,400,1525214113),(32,755,400,1525214113),(32,756,400,1525214113),(32,834,400,1525214113),(32,915,1,1525372579),(32,952,1,1525371771),(32,1009,432,1525368508),(32,1011,675,1525371653),(32,1016,1,1525371715),(32,1023,1,1525372320),(32,1035,1,1525372890),(32,1039,1,1525371707),(32,1043,1,1525270283),(32,1044,1,1525269871),(32,1046,1,1525269863),(32,1047,1,1525268804),(32,1048,1,1525268798),(32,1049,1,1525269832),(32,1050,1,1525268644),(32,1051,1,1525268768),(32,1052,1,1525268814),(32,1111,1,1525370256),(32,1115,1,1525371691),(32,1121,1,1525371718),(32,1149,1,1525215875),(32,1160,1,1525270320),(32,1162,1,1525371684),(32,1170,1,1525372597),(32,1178,1,1525371744),(32,1191,1,1525371782),(32,1214,1,1525370025),(32,1249,1,1525370259),(32,1257,1,1525371740),(32,1259,1,1525370263),(32,1265,1,1525370291),(32,1270,1,1525372309),(32,1272,1,1525370288),(32,1307,1,1525370196),(32,1308,1,1527447434),(32,1348,1,1525370342),(32,1353,1,1525370192),(32,1415,1,1525370149),(32,1416,1,1525370388),(32,1426,1,1525369604),(32,1504,1,1525372291),(32,1505,1,1525371798),(32,1519,1,1525373068),(32,1537,1,1525372366),(32,1540,1,1525372303),(32,1542,1,1525372362),(32,1543,1,1525371806),(32,1552,1,1525371847),(32,1553,1,1525371850),(32,1573,1,1525371837),(32,1597,1,1525370049),(32,1598,1,1525369623),(32,1603,1,1525369960),(32,1608,1,1525367716),(32,1609,1,1525369099),(32,1633,1,1525367856),(32,1672,1,1525370092),(32,1674,1,1525371756),(32,1706,1,1525369955),(32,1707,1,1525369854),(32,1708,1,1525370067),(32,1719,1,1525370111),(32,1729,1,1525369829),(32,1732,1,1525369799),(32,1733,1,1525371733),(32,1745,1,1525369968),(32,1747,1,1525369874),(32,1870,150,1525214437),(32,1871,225,1525215643),(32,1872,150,1525214437),(32,1873,300,1525215647),(32,2020,200,1525214113),(32,2030,4000,1525214113),(32,2031,3100,1525214113),(32,2032,3100,1525214113),(32,2033,3100,1525214113),(32,2034,3000,1525214113),(32,2044,1,1525369537),(32,2238,1,1525369992),(32,2239,1,1525373595),(32,2342,1,1525215788),(32,2343,1,1525267790),(32,2344,1,1525215789),(32,2345,1,1525215789),(32,2346,1,1525267791),(32,2347,1,1525215790),(32,2348,1,1525267267),(32,2349,1,1525267792),(32,2350,1,1525215789),(32,2351,1,1525216287),(32,2353,1,1525267794),(32,2355,1,1525267793),(32,3238,8,1525380740),(32,3239,1,1525277235),(32,3244,1,1525371601),(32,3354,129302,1525373772),(32,3355,387600,1525373595),(32,3506,129302,1525373772),(32,3507,129302,1525373772),(32,3510,129302,1525373772),(32,3511,129302,1525373772),(32,3512,129302,1525373772),(32,3513,387600,1525373595),(32,3631,1,1525373595),(32,3686,1,1525264958),(32,3689,1,1525264958),(32,3690,1,1525264958),(32,3692,1,1525264958),(32,3723,1,1525215788),(32,3724,1,1525267790),(32,3725,1,1525215789),(32,3726,1,1525215789),(32,3727,1,1525267791),(32,3728,1,1525215790),(32,3729,1,1525267267),(32,3730,1,1525267792),(32,3731,1,1525215789),(32,3732,1,1525216287),(32,3733,1,1525216287),(32,3734,1,1525267794),(32,3735,1,1525267795),(32,3736,1,1525267793),(32,3965,1,1525277235),(32,3980,1,1525371601),(32,4092,387600,1525373595),(32,4093,129302,1525373772),(32,4132,1,1525215607),(32,4194,1,1525373186),(32,4196,1,1525373702),(32,4224,100200765,1525214374),(32,4752,432,1525368508),(32,4759,675,1525371653),(32,4787,13,1525215681),(32,4788,1,1525264958),(32,4940,1,1525371752),(32,4943,337596,1525374233),(32,4944,265,1525376124),(32,4946,8,1525374231),(32,4948,18,1525373584),(32,4949,30,1525370100),(32,4951,3,1525374231),(32,4953,162,1525373770),(32,4955,48,1525371653),(32,4956,3,1525372883),(32,4958,1,1525376124),(32,5212,80,1525214113),(32,5220,80,1525214113),(32,5233,80,1525214113),(32,5289,1,1525373474),(32,5301,10,1525374894),(32,5328,3100,1525214113),(32,5329,3100,1525214113),(32,5330,3100,1525214113),(32,5331,4000,1525214113),(32,5332,3000,1525214113),(32,5336,432,1525368508),(32,5371,7424,1525367893),(32,5372,610534,1525374228),(32,5373,5162,1525276784),(32,5374,949,1525268287),(32,5375,337596,1525374233),(32,5376,949,1525268287),(32,5512,13,1525372883),(32,5529,265,1525376124),(32,5530,8,1525372585),(32,5531,13,1525371839),(32,5532,8,1525374231),(32,5576,400,1525214113),(32,5577,400,1525214113),(32,5578,400,1525214113),(32,5579,400,1525214113),(32,5580,400,1525214113),(32,5581,400,1525214113),(32,5582,400,1527711440),(32,5584,400,1527711440),(32,5585,400,1525214113),(32,5587,400,1527711440),(32,5588,400,1525264854),(32,5589,400,1525214113),(32,5590,400,1525264854),(32,5591,400,1525264854),(32,5593,8,1525380772),(32,5594,3,1525380772),(32,5803,12,1525370968),(32,5816,1,1525216287),(32,5817,1,1525267795),(32,5874,1,1525369653),(32,6142,65,1525267786),(32,6476,9,1525373607),(32,6847,2,1525371185),(32,7550,10,1525215670),(32,7551,13,1525215681),(32,7552,13,1525215681),(32,8819,500,1525214113),(32,8820,500,1525214113),(32,8821,500,1525214113),(32,8822,500,1525214113),(32,9218,1,1525264958),(32,9223,13,1525215681),(32,9378,400,1527711440),(32,9419,1,1525216231),(32,9598,80,1525214113),(32,9619,1,1525214453),(32,9678,3100,1525214113),(32,9679,3000,1525214113),(32,9680,3100,1525214113),(32,9681,3100,1525214113),(32,9682,4000,1525214113),(32,12698,215,1525371601),(33,34,90,1525445533),(33,35,90,1525445533),(33,36,90,1525445533),(33,37,90,1525445533),(33,38,90,1525445533),(33,39,90,1525445533),(33,40,90,1525445533),(33,41,90,1525445533),(33,167,450,1525445533),(33,641,450,1525445533),(33,653,450,1525445533),(33,655,450,1525445533),(33,753,450,1525445533),(33,754,450,1525445533),(33,755,450,1525445533),(33,756,450,1525445533),(33,834,450,1525445533),(33,2020,200,1525445533),(33,2030,4000,1525445533),(33,2031,3100,1525445533),(33,2032,3100,1525445533),(33,2033,3100,1525445533),(33,2034,3000,1525445533),(33,2346,1,1525965154),(33,3727,1,1525965154),(33,4224,1000000,1525445533),(33,5212,90,1525445533),(33,5220,90,1525445533),(33,5233,90,1525445533),(33,5301,6,1525445533),(33,5328,3100,1525445533),(33,5329,3100,1525445533),(33,5330,3100,1525445533),(33,5331,4000,1525445533),(33,5332,3000,1525445533),(33,5576,450,1525445533),(33,5577,450,1525445533),(33,5578,450,1525445533),(33,5579,450,1525445533),(33,5580,450,1525445533),(33,5581,450,1525445533),(33,5585,450,1525445533),(33,5589,450,1525445533),(33,8819,500,1525445533),(33,8820,500,1525445533),(33,8821,500,1525445533),(33,8822,500,1525445533),(33,9598,90,1525445533),(33,9678,3100,1525445533),(33,9679,3000,1525445533),(33,9680,3100,1525445533),(33,9681,3100,1525445533),(33,9682,4000,1525445533),(33,12698,115,1525445533),(35,34,80,1525534867),(35,35,80,1525534867),(35,36,80,1525534867),(35,37,80,1525534867),(35,38,80,1525534867),(35,39,80,1525534867),(35,40,80,1525534867),(35,41,80,1525534867),(35,167,400,1525534867),(35,641,400,1525534867),(35,653,400,1525534867),(35,655,400,1525534867),(35,753,400,1525534867),(35,754,400,1525534867),(35,755,400,1525534867),(35,756,400,1525534867),(35,834,400,1525534867),(35,2020,200,1525534867),(35,2030,4000,1525534867),(35,2031,3100,1525534867),(35,2032,3100,1525534867),(35,2033,3100,1525534867),(35,2034,3000,1525534867),(35,4224,1000000,1525534867),(35,5212,80,1525534867),(35,5220,80,1525534867),(35,5233,80,1525534867),(35,5301,6,1525534867),(35,5328,3100,1525534867),(35,5329,3100,1525534867),(35,5330,3100,1525534867),(35,5331,4000,1525534867),(35,5332,3000,1525534867),(35,5576,400,1525534867),(35,5577,400,1525534867),(35,5578,400,1525534867),(35,5579,400,1525534867),(35,5580,400,1525534867),(35,5581,400,1525534867),(35,5585,400,1525534867),(35,5589,400,1525534867),(35,8819,500,1525534867),(35,8820,500,1525534867),(35,8821,500,1525534867),(35,8822,500,1525534867),(35,9598,80,1525534867),(35,9678,3100,1525534867),(35,9679,3000,1525534867),(35,9680,3100,1525534867),(35,9681,3100,1525534867),(35,9682,4000,1525534867),(35,12698,115,1525534867),(36,34,80,1525535032),(36,35,80,1525535032),(36,36,80,1525535032),(36,37,80,1525535032),(36,38,80,1525535032),(36,39,80,1525535032),(36,40,80,1525535032),(36,41,80,1525535032),(36,167,400,1525535032),(36,641,400,1525535032),(36,653,400,1525535032),(36,655,400,1525535032),(36,753,400,1525535032),(36,754,400,1525535032),(36,755,400,1525535032),(36,756,400,1525535032),(36,834,400,1525535032),(36,2020,200,1525535032),(36,2030,3100,1525535032),(36,2031,4000,1525535032),(36,2032,3100,1525535032),(36,2033,3100,1525535032),(36,2034,3000,1525535032),(36,4224,1000000,1525535032),(36,5212,80,1525535032),(36,5220,80,1525535032),(36,5232,80,1525535032),(36,5301,6,1525535032),(36,5328,3100,1525535032),(36,5329,3100,1525535032),(36,5330,4000,1525535032),(36,5331,3100,1525535032),(36,5332,3000,1525535032),(36,5576,400,1525535032),(36,5577,400,1525535032),(36,5578,400,1525535032),(36,5579,400,1525535032),(36,5580,400,1525535032),(36,5581,400,1525535032),(36,5585,400,1525535032),(36,5589,400,1525535032),(36,8819,500,1525535032),(36,8820,500,1525535032),(36,8821,500,1525535032),(36,8822,500,1525535032),(36,9598,80,1525535032),(36,9678,3100,1525535032),(36,9679,3000,1525535032),(36,9680,3100,1525535032),(36,9681,4000,1525535032),(36,9682,3100,1525535032),(36,12698,115,1525535032),(37,34,80,1525535051),(37,35,80,1525535051),(37,36,80,1525535051),(37,37,80,1525535051),(37,38,80,1525535051),(37,39,80,1525535051),(37,40,80,1525535051),(37,41,80,1525535051),(37,167,400,1525535051),(37,641,400,1525535051),(37,653,400,1525535051),(37,655,400,1525535051),(37,753,400,1525535051),(37,754,400,1525535051),(37,755,400,1525535051),(37,756,400,1525535051),(37,834,400,1525535051),(37,1146,1,1525535056),(37,2020,200,1525535051),(37,2030,4000,1525535051),(37,2031,3100,1525535051),(37,2032,3100,1525535051),(37,2033,3100,1525535051),(37,2034,3000,1525535051),(37,4224,1000000,1525535051),(37,5212,80,1525535051),(37,5220,80,1525535051),(37,5233,80,1525535051),(37,5301,6,1525535051),(37,5328,3100,1525535051),(37,5329,3100,1525535051),(37,5330,3100,1525535051),(37,5331,4000,1525535051),(37,5332,3000,1525535051),(37,5576,400,1525535051),(37,5577,400,1525535051),(37,5578,400,1525535051),(37,5579,400,1525535051),(37,5580,400,1525535051),(37,5581,400,1525535051),(37,5585,400,1525535051),(37,5589,400,1525535051),(37,8819,500,1525535051),(37,8820,500,1525535051),(37,8821,500,1525535051),(37,8822,500,1525535051),(37,9598,80,1525535051),(37,9678,3100,1525535051),(37,9679,3000,1525535051),(37,9680,3100,1525535051),(37,9681,3100,1525535051),(37,9682,4000,1525535051),(37,12698,115,1525535051),(38,34,80,1525536242),(38,35,80,1525536242),(38,36,80,1525536242),(38,37,80,1525536242),(38,38,80,1525536242),(38,39,80,1525536242),(38,40,80,1525536242),(38,41,80,1525536242),(38,167,400,1525536242),(38,641,400,1525536242),(38,653,400,1525536242),(38,655,400,1525536242),(38,753,400,1525536242),(38,754,400,1525536242),(38,755,400,1525536242),(38,756,400,1525536242),(38,834,400,1525536242),(38,2020,200,1525536242),(38,2030,4000,1525536242),(38,2031,3100,1525536242),(38,2032,3100,1525536242),(38,2033,3100,1525536242),(38,2034,3000,1525536242),(38,4224,1000000,1525536242),(38,5212,80,1525536242),(38,5220,80,1525536242),(38,5233,80,1525536242),(38,5301,6,1525536242),(38,5328,3100,1525536242),(38,5329,3100,1525536242),(38,5330,3100,1525536242),(38,5331,4000,1525536242),(38,5332,3000,1525536242),(38,5576,400,1525536242),(38,5577,400,1525536242),(38,5578,400,1525536242),(38,5579,400,1525536242),(38,5580,400,1525536242),(38,5581,400,1525536242),(38,5585,400,1525536242),(38,5589,400,1525536242),(38,8819,500,1525536242),(38,8820,500,1525536242),(38,8821,500,1525536242),(38,8822,500,1525536242),(38,9598,80,1525536242),(38,9678,3100,1525536242),(38,9679,3000,1525536242),(38,9680,3100,1525536242),(38,9681,3100,1525536242),(38,9682,4000,1525536242),(38,12698,115,1525536242),(39,34,90,1527362141),(39,35,90,1527362141),(39,36,90,1527362141),(39,37,90,1527362141),(39,38,90,1527362141),(39,39,90,1527362141),(39,40,90,1527362141),(39,41,90,1527362141),(39,73,1,1533747766),(39,76,1,1533747766),(39,111,3,1527362850),(39,167,450,1527362141),(39,230,1,1533747766),(39,231,1,1533747766),(39,232,1,1533747766),(39,233,1,1533747766),(39,234,1,1533747766),(39,236,1,1533747766),(39,641,450,1527362141),(39,651,450,1527363822),(39,652,450,1527363822),(39,653,450,1527362141),(39,655,450,1527362141),(39,753,450,1527362141),(39,754,450,1527362141),(39,755,450,1527362141),(39,756,450,1527362141),(39,832,1,1533747766),(39,834,450,1527362141),(39,1045,1,1533747766),(39,1050,1,1527888238),(39,1054,1,1533747766),(39,1058,1,1533747766),(39,1064,1,1533747766),(39,1065,1,1533747766),(39,1147,1,1533747766),(39,1149,1,1527362367),(39,1308,1,1527363117),(39,2020,200,1527362141),(39,2030,4550,1533747766),(39,2031,3237,1533747766),(39,2032,3237,1533747766),(39,2033,3237,1533747766),(39,2034,3137,1533747766),(39,2239,1,1533747766),(39,2341,1,1527363508),(39,2345,1,1527363800),(39,2347,1,1527363875),(39,2425,275,1533747766),(39,3357,160845,1527363508),(39,3631,1,1533747766),(39,3726,1,1527363800),(39,3728,1,1527363875),(39,4162,1,1533747766),(39,4170,1,1533747766),(39,4224,100224165,1527362690),(39,4705,1,1527706813),(39,4747,550,1533747766),(39,4748,275,1533747766),(39,4749,275,1533747766),(39,5212,90,1527362141),(39,5220,90,1527362141),(39,5233,90,1527362141),(39,5289,2,1533747782),(39,5301,11,1533747766),(39,5328,3237,1533747766),(39,5329,3237,1533747766),(39,5330,3237,1533747766),(39,5331,4550,1533747766),(39,5332,3137,1533747766),(39,5339,550,1533747766),(39,5340,275,1533747766),(39,5341,275,1533747766),(39,5371,13316,1527362850),(39,5372,34313,1533662471),(39,5512,1,1533662472),(39,5529,10,1533662472),(39,5576,450,1527362141),(39,5577,450,1527362141),(39,5578,450,1527362141),(39,5579,450,1527362141),(39,5580,450,1527362141),(39,5581,450,1527362141),(39,5584,450,1527363822),(39,5585,450,1527362141),(39,5588,450,1527363822),(39,5589,450,1527362141),(39,5593,3,1527362850),(39,6142,2,1527363872),(39,8819,500,1527362141),(39,8820,500,1527362141),(39,8821,500,1527362141),(39,8822,500,1527362141),(39,9598,90,1527362141),(39,9678,3237,1533747766),(39,9679,3137,1533747766),(39,9680,3237,1533747766),(39,9681,3237,1533747766),(39,9682,4550,1533747766),(39,11278,275,1533747766),(39,12698,125,1527363508),(40,34,80,1527878548),(40,35,80,1527878548),(40,36,80,1527878548),(40,37,80,1527878548),(40,38,80,1527878548),(40,39,80,1527878548),(40,40,80,1527878548),(40,41,80,1527878548),(40,167,400,1527878548),(40,641,400,1527878548),(40,653,400,1527878548),(40,655,400,1527878548),(40,753,400,1527878548),(40,754,400,1527878548),(40,755,400,1527878548),(40,756,400,1527878548),(40,834,400,1527878548),(40,1308,1,1527878740),(40,2020,200,1527878548),(40,2030,4000,1527878548),(40,2031,3100,1527878548),(40,2032,3100,1527878548),(40,2033,3100,1527878548),(40,2034,3000,1527878548),(40,4224,101000000,1527878685),(40,5212,80,1527878548),(40,5220,80,1527878548),(40,5233,80,1527878548),(40,5301,6,1527878548),(40,5328,3100,1527878548),(40,5329,3100,1527878548),(40,5330,3100,1527878548),(40,5331,4000,1527878548),(40,5332,3000,1527878548),(40,5576,400,1527878548),(40,5577,400,1527878548),(40,5578,400,1527878548),(40,5579,400,1527878548),(40,5580,400,1527878548),(40,5581,400,1527878548),(40,5585,400,1527878548),(40,5589,400,1527878548),(40,8819,500,1527878548),(40,8820,500,1527878548),(40,8821,500,1527878548),(40,8822,500,1527878548),(40,9598,80,1527878548),(40,9678,3100,1527878548),(40,9679,3000,1527878548),(40,9680,3100,1527878548),(40,9681,3100,1527878548),(40,9682,4000,1527878548),(40,12698,115,1527878548),(41,34,80,1528641766),(41,35,80,1528641766),(41,36,80,1528641766),(41,37,80,1528641766),(41,38,80,1528641766),(41,39,80,1528641766),(41,40,80,1528641766),(41,41,80,1528641766),(41,167,400,1528641766),(41,641,400,1528641766),(41,651,400,1533852112),(41,653,400,1528641766),(41,655,400,1528641766),(41,657,400,1533852112),(41,753,400,1528641766),(41,754,400,1528641766),(41,755,400,1528641766),(41,756,400,1528641766),(41,834,400,1528641766),(41,1308,1,1528643642),(41,2020,200,1528641766),(41,2030,4000,1528641766),(41,2031,3100,1528641766),(41,2032,3100,1528641766),(41,2033,3100,1528641766),(41,2034,3000,1528641766),(41,4224,1000000,1528641766),(41,5212,80,1528641766),(41,5220,80,1528641766),(41,5233,80,1528641766),(41,5301,6,1528641766),(41,5328,3100,1528641766),(41,5329,3100,1528641766),(41,5330,3100,1528641766),(41,5331,4000,1528641766),(41,5332,3000,1528641766),(41,5576,400,1528641766),(41,5577,400,1528641766),(41,5578,400,1528641766),(41,5579,400,1528641766),(41,5580,400,1528641766),(41,5581,400,1528641766),(41,5582,400,1533852112),(41,5584,400,1533852112),(41,5585,400,1528641766),(41,5587,400,1533852112),(41,5589,400,1528641766),(41,5591,400,1533852112),(41,8819,500,1528641766),(41,8820,500,1528641766),(41,8821,500,1528641766),(41,8822,500,1528641766),(41,9378,400,1533852112),(41,9598,80,1528641766),(41,9678,3100,1528641766),(41,9679,3000,1528641766),(41,9680,3100,1528641766),(41,9681,3100,1528641766),(41,9682,4000,1528641766),(41,12698,115,1528641766),(42,34,80,1533828819),(42,35,80,1533828819),(42,36,80,1533828819),(42,37,80,1533828819),(42,38,80,1533828819),(42,39,80,1533828819),(42,40,80,1533828819),(42,41,80,1533828819),(42,167,400,1533828819),(42,641,400,1533828819),(42,652,400,1533847659),(42,653,400,1533828819),(42,655,400,1533828819),(42,656,400,1533847659),(42,657,400,1533847659),(42,753,400,1533828819),(42,754,400,1533828819),(42,755,400,1533828819),(42,756,400,1533828819),(42,834,400,1533828819),(42,1870,150,1533832796),(42,1871,150,1533832796),(42,1872,150,1533832796),(42,1873,150,1533832796),(42,2020,200,1533828819),(42,2030,4000,1533828819),(42,2031,3100,1533828819),(42,2032,3100,1533828819),(42,2033,3100,1533828819),(42,2034,3000,1533828819),(42,4224,100249590,1533833204),(42,4787,6,1533832945),(42,5212,80,1533828819),(42,5220,80,1533828819),(42,5233,80,1533828819),(42,5301,6,1533828819),(42,5328,3100,1533828819),(42,5329,3100,1533828819),(42,5330,3100,1533828819),(42,5331,4000,1533828819),(42,5332,3000,1533828819),(42,5371,2409,1533833117),(42,5372,6808,1533833119),(42,5576,400,1533828819),(42,5577,400,1533828819),(42,5578,400,1533828819),(42,5579,400,1533828819),(42,5580,400,1533828819),(42,5581,400,1533828819),(42,5585,400,1533828819),(42,5588,400,1533847659),(42,5589,400,1533828819),(42,5590,400,1533847659),(42,5591,400,1533847659),(42,6142,4,1533832927),(42,7550,6,1533832945),(42,7551,6,1533832945),(42,7552,6,1533832945),(42,8819,500,1533828819),(42,8820,500,1533828819),(42,8821,500,1533828819),(42,8822,500,1533828819),(42,9223,6,1533832945),(42,9598,80,1533828819),(42,9678,3100,1533828819),(42,9679,3000,1533828819),(42,9680,3100,1533828819),(42,9681,3100,1533828819),(42,9682,4000,1533828819),(42,12698,135,1533832796);
/*!40000 ALTER TABLE `character_achievement_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_action`
--

DROP TABLE IF EXISTS `character_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_action` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `button` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `action` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spec`,`button`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_action`
--

LOCK TABLES `character_action` WRITE;
/*!40000 ALTER TABLE `character_action` DISABLE KEYS */;
INSERT INTO `character_action` VALUES (2,0,1,20271,0),(2,0,2,48806,0),(2,0,3,28730,0),(2,0,5,48782,0),(2,0,6,48825,0),(2,0,7,48801,0),(2,0,8,1,64),(2,0,9,2,64),(2,0,10,642,0),(2,0,60,21084,0),(2,0,61,6603,0),(2,0,62,10308,0),(2,1,1,10308,0),(2,1,3,28730,0),(2,1,4,48817,0),(2,1,5,48782,0),(2,1,7,62124,0),(2,1,8,1,64),(2,1,9,2,64),(2,1,60,21084,0),(2,1,61,6603,0),(3,0,0,5,64),(3,0,1,11,65),(3,0,4,5,65),(3,0,9,1,65),(3,0,10,1,64),(3,0,11,59752,0),(3,0,25,11,65),(3,0,26,6,65),(3,0,27,7,65),(3,0,28,9,65),(3,0,29,3,65),(3,0,30,2,65),(3,0,31,4,65),(3,0,32,8,65),(3,0,34,6,64),(3,0,35,5,64),(3,0,47,7,64),(3,0,49,3,64),(3,0,50,4,64),(3,0,54,10,65),(3,0,70,5,65),(4,0,0,3,64),(4,0,1,4,64),(4,0,2,48078,0),(4,0,3,10,64),(4,0,4,14,64),(4,0,5,15,64),(4,0,7,2053,0),(4,0,8,1,64),(4,0,9,2,64),(4,0,10,48123,0),(4,0,11,59752,0),(4,0,24,5,64),(4,0,25,6,64),(4,0,26,7,64),(4,0,27,8,64),(4,0,28,9,64),(4,0,29,11,64),(4,0,30,12,64),(5,0,0,49576,0),(5,0,1,49941,0),(5,0,2,49909,0),(5,0,3,49921,0),(5,0,4,49930,0),(5,0,5,49895,0),(5,0,6,50842,0),(5,0,7,55233,0),(5,0,8,1,64),(5,0,9,2,64),(5,0,10,585,0),(5,0,11,59752,0),(5,0,60,2061,0),(7,0,0,585,0),(7,0,1,2050,0),(7,0,2,58984,0),(7,0,11,1,64),(13,0,0,6603,0),(13,0,1,2973,0),(13,0,2,75,0),(13,0,11,20572,0),(14,0,72,6603,0),(14,0,73,78,0),(14,0,82,58984,0),(14,0,85,6603,0),(14,0,97,6603,0),(14,0,109,6603,0),(15,0,0,6603,0),(15,0,72,6603,0),(15,0,73,47450,0),(15,0,82,59752,0),(15,0,84,6603,0),(15,0,96,6603,0),(15,0,108,6603,0),(16,0,0,6603,0),(16,0,81,23228,0),(16,0,82,32240,0),(16,0,83,61229,0),(16,0,84,6603,0),(16,0,96,6603,0),(16,0,108,6603,0),(21,0,0,6603,0),(21,0,72,6603,0),(21,0,73,284,0),(21,0,76,16083,0),(21,0,82,59752,0),(21,0,84,6603,0),(21,0,96,6603,0),(21,0,108,6603,0),(22,0,0,6603,0),(22,0,25,0,32),(22,0,26,1,32),(22,0,34,22723,0),(22,0,35,23228,0),(22,0,72,7384,0),(22,0,73,47450,0),(22,0,74,47465,0),(22,0,75,47502,0),(22,0,76,1715,0),(22,0,82,59752,0),(22,0,83,11578,0),(22,0,84,6603,0),(22,0,96,6603,0),(22,0,108,6603,0),(24,0,0,1,65),(24,0,1,2,65),(24,0,2,3,65),(24,0,3,47502,0),(24,0,4,47520,0),(24,0,5,11578,0),(24,0,6,16083,0),(24,0,7,1,64),(24,0,33,6603,0),(24,0,34,422,128),(24,0,72,6603,0),(24,0,73,47450,0),(24,0,74,3018,0),(24,0,82,59752,0),(24,0,83,2457,0),(24,0,84,6603,0),(24,0,96,6603,0),(24,0,108,6603,0),(25,0,0,6603,0),(25,0,1,1,64),(25,0,2,2,64),(25,0,3,3,64),(25,0,72,6603,0),(25,0,73,47450,0),(25,0,82,59752,0),(25,0,84,6603,0),(25,0,96,6603,0),(25,0,108,6603,0),(26,0,0,6603,0),(26,0,72,6603,0),(26,0,73,78,0),(26,0,82,59752,0),(26,0,84,6603,0),(26,0,96,6603,0),(26,0,108,6603,0),(27,0,0,6603,0),(27,0,1,3018,0),(27,0,9,23228,0),(27,0,11,458,0),(27,0,72,6603,0),(27,0,73,78,0),(27,0,82,59752,0),(27,0,84,6603,0),(27,0,96,6603,0),(27,0,108,6603,0),(28,0,0,6603,0),(28,0,1,78,0),(28,0,72,6603,0),(28,0,73,78,0),(28,0,74,20594,0),(28,0,75,2481,0),(28,0,84,6603,0),(28,0,96,6603,0),(28,0,108,6603,0),(29,0,0,6603,0),(29,0,72,23229,0),(29,0,73,6648,0),(29,0,82,59752,0),(29,0,84,6603,0),(29,0,96,6603,0),(29,0,108,6603,0),(30,0,0,6603,0),(30,0,1,1752,0),(30,0,2,2098,0),(30,0,3,2764,0),(30,0,9,3,64),(30,0,10,2,64),(30,0,11,1,64),(31,0,0,6603,0),(31,0,16,2,64),(31,0,34,5,64),(31,0,35,6,64),(31,0,50,3,64),(31,0,51,4,64),(31,0,72,6603,0),(31,0,73,47450,0),(31,0,76,2,64),(31,0,82,59752,0),(31,0,84,6603,0),(31,0,96,6603,0),(31,0,108,6603,0),(32,0,0,6603,0),(32,0,72,6603,0),(32,0,73,47450,0),(32,0,82,59752,0),(32,0,84,6603,0),(32,0,96,6603,0),(32,0,108,6603,0),(32,1,0,6603,0),(32,1,34,32242,0),(32,1,35,23227,0),(32,1,55,0,32),(32,1,56,1,32),(32,1,60,7384,0),(32,1,61,5246,0),(32,1,62,1680,0),(32,1,63,20230,0),(32,1,64,34428,0),(32,1,65,47475,0),(32,1,66,47436,0),(32,1,67,2687,0),(32,1,68,12292,0),(32,1,69,55694,0),(32,1,70,47437,0),(32,1,71,47440,0),(32,1,72,47450,0),(32,1,73,47465,0),(32,1,74,47502,0),(32,1,75,47520,0),(32,1,76,23881,0),(32,1,77,11578,0),(32,1,78,1715,0),(32,1,79,47471,0),(32,1,80,64382,0),(32,1,81,57755,0),(32,1,82,59752,0),(32,1,83,3018,0),(32,1,84,6603,0),(32,1,96,6603,0),(32,1,108,6603,0),(33,0,0,6603,0),(33,0,72,6603,0),(33,0,73,78,0),(33,0,82,59752,0),(33,0,84,6603,0),(33,0,96,6603,0),(33,0,108,6603,0),(35,0,0,6603,0),(35,0,72,6603,0),(35,0,73,78,0),(35,0,82,59752,0),(35,0,84,6603,0),(35,0,96,6603,0),(35,0,108,6603,0),(36,0,0,6603,0),(36,0,1,78,0),(36,0,72,6603,0),(36,0,73,78,0),(36,0,74,20594,0),(36,0,75,2481,0),(36,0,84,6603,0),(36,0,96,6603,0),(36,0,108,6603,0),(37,0,0,6603,0),(37,0,72,6603,0),(37,0,73,78,0),(37,0,82,59752,0),(37,0,84,6603,0),(37,0,96,6603,0),(37,0,108,6603,0),(38,0,0,6603,0),(38,0,72,6603,0),(38,0,73,78,0),(38,0,82,59752,0),(38,0,84,6603,0),(38,0,96,6603,0),(38,0,108,6603,0),(39,0,0,6603,0),(39,0,60,6603,0),(39,0,72,3,64),(39,0,73,47450,0),(39,0,74,3018,0),(39,0,75,1,65),(39,0,79,3,64),(39,0,80,1,64),(39,0,81,2,64),(39,0,82,59752,0),(39,0,84,6603,0),(39,0,96,6603,0),(39,0,108,6603,0),(40,0,0,6603,0),(40,0,72,6603,0),(40,0,73,47450,0),(40,0,82,59752,0),(40,0,84,6603,0),(40,0,96,6603,0),(40,0,108,6603,0),(41,0,0,6603,0),(41,0,72,6603,0),(41,0,73,78,0),(41,0,82,59752,0),(41,0,84,6603,0),(41,0,96,6603,0),(41,0,108,6603,0),(42,0,0,6603,0),(42,0,72,6603,0),(42,0,73,472,0),(42,0,74,23228,0),(42,0,82,59752,0),(42,0,84,6603,0),(42,0,96,6603,0),(42,0,108,6603,0);
/*!40000 ALTER TABLE `character_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_arena_stats`
--

DROP TABLE IF EXISTS `character_arena_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_arena_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `matchMakerRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_arena_stats`
--

LOCK TABLES `character_arena_stats` WRITE;
/*!40000 ALTER TABLE `character_arena_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_arena_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_aura`
--

DROP TABLE IF EXISTS `character_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` int(11) NOT NULL DEFAULT '0',
  `amount1` int(11) NOT NULL DEFAULT '0',
  `amount2` int(11) NOT NULL DEFAULT '0',
  `base_amount0` int(11) NOT NULL DEFAULT '0',
  `base_amount1` int(11) NOT NULL DEFAULT '0',
  `base_amount2` int(11) NOT NULL DEFAULT '0',
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `critChance` float NOT NULL DEFAULT '0',
  `applyResilience` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_aura`
--

LOCK TABLES `character_aura` WRITE;
/*!40000 ALTER TABLE `character_aura` DISABLE KEYS */;
INSERT INTO `character_aura` VALUES (3,3,37800,1,1,1,0,0,0,0,0,0,-1,-1,0,0,1),(28,28,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(28,28,51915,1,1,1,0,0,0,-1,0,0,-1,-1,0,0,1),(29,29,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(31,31,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(32,32,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(33,33,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(35,35,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(36,36,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(37,37,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(38,38,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(39,39,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(40,40,468,3,3,1,0,60,0,0,59,0,-1,-1,0,0,1),(40,40,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(41,41,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(42,42,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1);
/*!40000 ALTER TABLE `character_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_banned`
--

DROP TABLE IF EXISTS `character_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_banned` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_banned`
--

LOCK TABLES `character_banned` WRITE;
/*!40000 ALTER TABLE `character_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_battleground_data`
--

DROP TABLE IF EXISTS `character_battleground_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_battleground_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `instanceId` int(10) unsigned NOT NULL COMMENT 'Instance Identifier',
  `team` smallint(5) unsigned NOT NULL,
  `joinX` float NOT NULL DEFAULT '0',
  `joinY` float NOT NULL DEFAULT '0',
  `joinZ` float NOT NULL DEFAULT '0',
  `joinO` float NOT NULL DEFAULT '0',
  `joinMapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `taxiStart` int(10) unsigned NOT NULL DEFAULT '0',
  `taxiEnd` int(10) unsigned NOT NULL DEFAULT '0',
  `mountSpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_battleground_data`
--

LOCK TABLES `character_battleground_data` WRITE;
/*!40000 ALTER TABLE `character_battleground_data` DISABLE KEYS */;
INSERT INTO `character_battleground_data` VALUES (2,0,0,0,0,0,0,65535,0,0,0),(3,0,0,0,0,0,0,65535,0,0,0),(4,0,0,0,0,0,0,65535,0,0,0),(5,0,0,0,0,0,0,65535,0,0,0),(7,0,0,0,0,0,0,65535,0,0,0),(13,0,0,0,0,0,0,65535,0,0,0),(14,0,0,0,0,0,0,65535,0,0,0),(15,0,0,0,0,0,0,65535,0,0,0),(16,0,0,0,0,0,0,65535,0,0,0),(21,0,0,0,0,0,0,65535,0,0,0),(22,0,0,0,0,0,0,65535,0,0,0),(24,0,0,0,0,0,0,65535,0,0,0),(25,0,0,0,0,0,0,65535,0,0,0),(26,0,0,0,0,0,0,65535,0,0,0),(27,0,0,0,0,0,0,65535,0,0,0),(28,0,0,0,0,0,0,65535,0,0,0),(29,0,0,0,0,0,0,65535,0,0,0),(30,0,0,0,0,0,0,65535,0,0,0),(31,0,0,0,0,0,0,65535,0,0,0),(32,0,0,0,0,0,0,65535,0,0,0),(33,0,0,0,0,0,0,65535,0,0,0),(35,0,0,0,0,0,0,65535,0,0,0),(36,0,0,0,0,0,0,65535,0,0,0),(37,0,0,0,0,0,0,65535,0,0,0),(38,0,0,0,0,0,0,65535,0,0,0),(39,0,0,0,0,0,0,65535,0,0,0),(40,0,0,0,0,0,0,65535,0,0,0),(41,0,0,0,0,0,0,65535,0,0,0),(42,0,0,0,0,0,0,65535,0,0,0);
/*!40000 ALTER TABLE `character_battleground_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_battleground_random`
--

DROP TABLE IF EXISTS `character_battleground_random`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_battleground_random` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_battleground_random`
--

LOCK TABLES `character_battleground_random` WRITE;
/*!40000 ALTER TABLE `character_battleground_random` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_battleground_random` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_declinedname`
--

DROP TABLE IF EXISTS `character_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_declinedname` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL DEFAULT '',
  `dative` varchar(15) NOT NULL DEFAULT '',
  `accusative` varchar(15) NOT NULL DEFAULT '',
  `instrumental` varchar(15) NOT NULL DEFAULT '',
  `prepositional` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_declinedname`
--

LOCK TABLES `character_declinedname` WRITE;
/*!40000 ALTER TABLE `character_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_equipmentsets`
--

DROP TABLE IF EXISTS `character_equipmentsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_equipmentsets` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `setguid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setindex` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(31) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `ignore_mask` int(11) unsigned NOT NULL DEFAULT '0',
  `item0` int(11) unsigned NOT NULL DEFAULT '0',
  `item1` int(11) unsigned NOT NULL DEFAULT '0',
  `item2` int(11) unsigned NOT NULL DEFAULT '0',
  `item3` int(11) unsigned NOT NULL DEFAULT '0',
  `item4` int(11) unsigned NOT NULL DEFAULT '0',
  `item5` int(11) unsigned NOT NULL DEFAULT '0',
  `item6` int(11) unsigned NOT NULL DEFAULT '0',
  `item7` int(11) unsigned NOT NULL DEFAULT '0',
  `item8` int(11) unsigned NOT NULL DEFAULT '0',
  `item9` int(11) unsigned NOT NULL DEFAULT '0',
  `item10` int(11) unsigned NOT NULL DEFAULT '0',
  `item11` int(11) unsigned NOT NULL DEFAULT '0',
  `item12` int(11) unsigned NOT NULL DEFAULT '0',
  `item13` int(11) unsigned NOT NULL DEFAULT '0',
  `item14` int(11) unsigned NOT NULL DEFAULT '0',
  `item15` int(11) unsigned NOT NULL DEFAULT '0',
  `item16` int(11) unsigned NOT NULL DEFAULT '0',
  `item17` int(11) unsigned NOT NULL DEFAULT '0',
  `item18` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_equipmentsets`
--

LOCK TABLES `character_equipmentsets` WRITE;
/*!40000 ALTER TABLE `character_equipmentsets` DISABLE KEYS */;
INSERT INTO `character_equipmentsets` VALUES (16,1,0,'Normal','INV_Shirt_14',0,0,0,0,1450,0,0,1448,1449,0,0,0,0,0,0,0,0,0,0,0),(16,2,1,'OP','INV_Chest_Plate03',0,0,0,431,584,433,579,436,434,0,435,0,0,0,0,437,428,0,0,0),(16,3,2,'Desnudo','Ability_CheapShot',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(22,4,0,'Atuendo Base','INV_Shirt_Red_01',0,0,0,0,752,0,753,754,755,0,0,0,0,0,0,0,756,0,0,0),(22,5,1,'Caballero','INV_Chest_Plate03',0,0,0,771,752,773,753,776,774,0,775,0,0,0,0,0,778,777,0,770),(32,6,0,'Set pvp','INV_HELMET_98',0,1185,1238,1187,1131,1184,1210,1186,1209,1219,1188,1195,1192,1241,1240,1239,1201,1202,1203,0),(32,7,1,'Set rol','INV_Chest_Leather_03',0,1150,1238,0,1131,1151,1210,1142,1209,1219,1143,1195,1192,1241,1240,1141,1183,1182,1203,0),(16,8,3,'Milicia','INV_Chest_Chain',0,0,0,1452,1450,1453,1454,1455,1456,1457,1458,0,0,0,0,0,0,0,0,1460),(24,9,0,'Enfermera','INV_Chest_Cloth_12',0,1016,1031,0,408,813,0,0,260,1034,0,1030,1032,0,0,1394,0,0,327,0),(24,12,1,'Milicia','INV_Chest_Chain',0,1016,1031,1395,0,1396,1397,1398,1609,1401,1467,1030,1032,0,0,1394,0,0,327,1468),(24,13,2,'Calle','INV_Chest_Cloth_38',0,1016,1031,0,408,269,0,0,260,1034,0,1030,1032,0,0,1394,0,0,327,0);
/*!40000 ALTER TABLE `character_equipmentsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_fishingsteps`
--

DROP TABLE IF EXISTS `character_fishingsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_fishingsteps` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `fishingSteps` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_fishingsteps`
--

LOCK TABLES `character_fishingsteps` WRITE;
/*!40000 ALTER TABLE `character_fishingsteps` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_fishingsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_gifts`
--

DROP TABLE IF EXISTS `character_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_gifts` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_gifts`
--

LOCK TABLES `character_gifts` WRITE;
/*!40000 ALTER TABLE `character_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_glyphs`
--

DROP TABLE IF EXISTS `character_glyphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_glyphs` (
  `guid` int(10) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `glyph1` smallint(5) unsigned DEFAULT '0',
  `glyph2` smallint(5) unsigned DEFAULT '0',
  `glyph3` smallint(5) unsigned DEFAULT '0',
  `glyph4` smallint(5) unsigned DEFAULT '0',
  `glyph5` smallint(5) unsigned DEFAULT '0',
  `glyph6` smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (`guid`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_glyphs`
--

LOCK TABLES `character_glyphs` WRITE;
/*!40000 ALTER TABLE `character_glyphs` DISABLE KEYS */;
INSERT INTO `character_glyphs` VALUES (2,0,0,0,0,0,0,0),(2,1,0,0,0,0,0,0),(3,0,0,0,0,0,0,0),(4,0,0,0,0,0,0,0),(5,0,0,0,0,0,0,0),(7,0,0,0,0,0,0,0),(13,0,0,0,0,0,0,0),(14,0,0,0,0,0,0,0),(15,0,0,0,0,0,0,0),(16,0,0,0,0,0,0,0),(21,0,0,0,0,0,0,0),(22,0,0,0,0,0,0,0),(24,0,0,0,0,0,0,0),(25,0,0,0,0,0,0,0),(26,0,0,0,0,0,0,0),(27,0,0,0,0,0,0,0),(28,0,0,0,0,0,0,0),(29,0,0,0,0,0,0,0),(30,0,0,0,0,0,0,0),(31,0,0,0,0,0,0,0),(32,0,0,0,0,0,0,0),(32,1,0,0,0,0,0,0),(33,0,0,0,0,0,0,0),(35,0,0,0,0,0,0,0),(36,0,0,0,0,0,0,0),(37,0,0,0,0,0,0,0),(38,0,0,0,0,0,0,0),(39,0,0,0,0,0,0,0),(40,0,0,0,0,0,0,0),(41,0,0,0,0,0,0,0),(42,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `character_glyphs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_homebind`
--

DROP TABLE IF EXISTS `character_homebind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_homebind` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `zoneId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Zone Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_homebind`
--

LOCK TABLES `character_homebind` WRITE;
/*!40000 ALTER TABLE `character_homebind` DISABLE KEYS */;
INSERT INTO `character_homebind` VALUES (2,530,3431,10349.6,-6357.29,33.4026),(3,0,12,-8949.95,-132.493,83.5312),(4,0,12,-8949.95,-132.493,83.5312),(5,609,4298,2355.84,-5664.77,426.028),(7,609,4298,1705.94,-5826.3,116.123),(13,609,4298,1705.94,-5826.3,116.123),(14,609,4298,1705.94,-5826.3,116.123),(15,0,796,2880.09,-742.353,160.333),(16,0,796,2875.62,-745.204,160.333),(21,0,796,2840.92,-689.2,139.33),(22,0,796,2860.41,-770.853,160.332),(24,0,796,2840.92,-689.2,139.33),(25,0,796,2840.92,-689.2,139.33),(26,0,796,2840.92,-689.2,139.33),(27,0,796,2840.92,-689.2,139.33),(28,0,1,-6240.32,331.033,382.758),(29,0,796,2860.74,-776.9,160.333),(30,0,12,-8949.95,-132.493,83.5312),(31,0,12,-8949.95,-132.493,83.5312),(32,0,12,-8949.95,-132.493,83.5312),(33,0,12,-8949.95,-132.493,83.5312),(35,0,12,-8949.95,-132.493,83.5312),(36,0,1,-6240.32,331.033,382.758),(37,0,12,-8949.95,-132.493,83.5312),(38,0,12,-8949.95,-132.493,83.5312),(39,0,796,2872.36,-763.15,160.33),(40,0,796,2872.36,-763.15,160.33),(41,0,796,2872.36,-763.15,160.33),(42,0,796,2872.36,-763.15,160.33);
/*!40000 ALTER TABLE `character_homebind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_instance`
--

DROP TABLE IF EXISTS `character_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `extendState` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_instance`
--

LOCK TABLES `character_instance` WRITE;
/*!40000 ALTER TABLE `character_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_inventory`
--

DROP TABLE IF EXISTS `character_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_inventory` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bag` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Global Unique Identifier',
  PRIMARY KEY (`item`),
  UNIQUE KEY `guid` (`guid`,`bag`,`slot`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_inventory`
--

LOCK TABLES `character_inventory` WRITE;
/*!40000 ALTER TABLE `character_inventory` DISABLE KEYS */;
INSERT INTO `character_inventory` VALUES (2,0,2,32),(2,0,3,12),(2,0,4,31),(2,0,5,29),(2,0,6,36),(2,0,7,28),(2,0,8,30),(2,0,9,34),(2,0,15,18),(2,0,23,20),(2,0,24,912),(3,0,3,108),(3,0,6,112),(3,0,7,110),(3,0,15,594),(3,0,23,114),(3,0,24,592),(3,0,25,116),(3,0,26,593),(3,0,27,858),(3,0,28,886),(3,0,29,995),(3,0,86,1441),(4,0,1,391),(4,0,3,781),(4,0,4,393),(4,0,6,392),(4,0,7,395),(4,0,10,389),(4,0,14,390),(4,0,15,131),(4,0,19,589),(4,0,20,586),(4,0,21,587),(4,0,22,588),(4,0,23,133),(4,0,24,591),(4,0,25,127),(4,0,26,782),(4,0,27,330),(4,0,28,583),(4,0,29,123),(4,0,31,340),(4,0,33,394),(4,0,34,125),(4,0,35,387),(4,0,36,270),(4,0,37,575),(4,0,38,129),(4,0,118,964),(4,0,119,965),(4,0,120,966),(4,0,121,967),(4,0,122,963),(4,0,123,968),(4,589,0,970),(4,589,1,410),(4,589,2,978),(4,589,3,983),(4,589,4,986),(4,589,5,999),(4,589,6,1157),(5,0,0,867),(5,0,1,861),(5,0,2,865),(5,0,4,884),(5,0,5,862),(5,0,6,866),(5,0,7,152),(5,0,8,144),(5,0,9,1038),(5,0,10,882),(5,0,11,883),(5,0,14,879),(5,0,15,789),(5,0,19,158),(5,0,20,160),(5,0,21,162),(5,0,22,164),(5,0,23,168),(5,0,24,750),(5,0,25,148),(5,0,26,146),(5,0,27,138),(5,0,28,150),(5,0,29,154),(5,0,30,136),(5,0,31,1039),(5,0,32,140),(5,0,33,156),(5,0,34,166),(5,0,35,142),(5,0,36,885),(5,0,37,863),(5,0,38,1442),(5,0,118,860),(5,0,119,864),(5,0,120,881),(7,0,3,215),(7,0,4,209),(7,0,6,211),(7,0,7,213),(7,0,15,207),(7,0,23,217),(13,0,3,289),(13,0,6,291),(13,0,7,293),(13,0,15,295),(13,0,17,301),(13,0,19,299),(13,0,23,297),(13,299,0,303),(14,0,3,308),(14,0,6,310),(14,0,7,312),(14,0,15,306),(14,0,23,314),(15,0,4,374),(15,0,5,381),(15,0,6,427),(15,0,7,377),(15,0,8,383),(15,0,9,379),(15,0,19,364),(15,0,20,365),(15,0,21,366),(15,0,22,367),(15,0,23,350),(15,0,24,342),(15,0,25,344),(15,0,26,346),(15,0,27,348),(15,0,28,414),(15,0,29,403),(15,0,30,404),(15,0,31,405),(15,0,32,406),(15,0,33,1412),(15,0,34,1413),(15,0,35,375),(15,0,36,426),(15,367,0,1403),(15,367,1,1404),(15,367,2,1408),(15,367,3,1409),(15,367,4,1405),(15,367,5,1406),(15,367,6,1407),(16,0,2,1452),(16,0,4,1453),(16,0,5,1454),(16,0,6,1455),(16,0,7,1456),(16,0,8,1457),(16,0,9,1458),(16,0,15,424),(16,0,16,421),(16,0,18,1460),(16,0,19,371),(16,0,20,370),(16,0,21,368),(16,0,22,369),(16,0,23,362),(16,0,24,1469),(16,0,25,431),(16,0,26,472),(16,0,28,419),(16,0,29,432),(16,0,30,420),(16,0,31,463),(16,0,32,464),(16,0,33,465),(16,0,34,466),(16,0,35,576),(16,0,36,437),(16,0,37,581),(16,0,38,578),(16,368,9,590),(16,369,0,428),(16,369,1,471),(16,369,2,415),(16,369,3,422),(16,369,4,417),(16,369,5,418),(16,369,6,416),(16,369,10,354),(16,369,13,436),(16,369,17,434),(16,370,0,360),(16,370,15,585),(16,371,0,580),(16,371,2,577),(16,371,3,430),(16,371,4,584),(16,371,5,433),(16,371,6,435),(16,371,7,429),(16,371,8,1447),(16,371,9,356),(16,371,10,358),(16,371,11,783),(16,371,12,1451),(16,371,13,579),(16,371,14,1450),(16,371,17,1448),(16,371,18,1449),(21,0,0,1393),(21,0,3,596),(21,0,4,1389),(21,0,5,1391),(21,0,6,1390),(21,0,7,1387),(21,0,9,1388),(21,0,14,1392),(21,0,19,611),(21,0,20,609),(21,0,21,610),(21,0,23,604),(21,0,24,608),(21,0,25,602),(21,0,26,1385),(21,0,27,1386),(21,0,28,600),(21,0,29,598),(22,0,3,752),(22,0,5,753),(22,0,6,754),(22,0,7,755),(22,0,15,756),(22,0,19,730),(22,0,20,733),(22,0,21,731),(22,0,22,732),(22,0,23,699),(22,0,24,749),(22,0,25,854),(22,0,26,856),(22,0,27,855),(22,0,28,774),(22,0,29,853),(22,0,30,776),(22,0,31,777),(22,0,32,778),(22,0,33,772),(22,0,35,804),(22,0,36,841),(22,730,0,773),(22,730,1,775),(22,730,2,771),(22,733,0,770),(24,0,0,1016),(24,0,1,1031),(24,0,2,1395),(24,0,4,1396),(24,0,5,1397),(24,0,6,1398),(24,0,7,1609),(24,0,8,1401),(24,0,9,1467),(24,0,10,1030),(24,0,11,1032),(24,0,14,1394),(24,0,15,326),(24,0,17,327),(24,0,18,1468),(24,0,19,764),(24,0,20,766),(24,0,21,767),(24,0,22,768),(24,0,23,745),(24,0,24,408),(24,0,25,1033),(24,0,26,1604),(24,0,27,1529),(24,0,28,1530),(24,0,29,1541),(24,0,30,1565),(24,0,31,1610),(24,0,32,1612),(24,0,33,759),(24,0,34,760),(24,0,35,1470),(24,0,37,1543),(24,764,0,1022),(24,764,1,1028),(24,764,3,260),(24,764,20,815),(24,766,0,269),(24,766,3,1606),(24,766,4,741),(24,767,20,1034),(24,767,22,407),(24,767,23,813),(24,768,1,737),(24,768,16,266),(24,768,23,757),(25,0,0,840),(25,0,3,828),(25,0,4,839),(25,0,5,838),(25,0,6,830),(25,0,7,832),(25,0,23,836),(25,0,24,834),(26,0,3,843),(26,0,6,845),(26,0,7,847),(26,0,15,849),(26,0,23,851),(27,0,0,993),(27,0,3,981),(27,0,4,975),(27,0,5,932),(27,0,6,987),(27,0,7,982),(27,0,9,1071),(27,0,14,992),(27,0,15,1073),(27,0,16,936),(27,0,17,935),(27,0,19,1002),(27,0,20,1001),(27,0,21,1003),(27,0,22,1004),(27,0,23,878),(27,0,24,1474),(27,0,25,949),(27,0,26,990),(27,0,27,1037),(27,0,28,934),(27,0,29,1046),(27,0,30,984),(27,0,31,1000),(27,0,32,1045),(27,0,33,1049),(27,0,34,1471),(27,0,36,1526),(27,0,37,1527),(27,0,38,1528),(28,0,0,911),(28,0,3,888),(28,0,4,905),(28,0,5,906),(28,0,6,908),(28,0,7,907),(28,0,8,909),(28,0,9,910),(28,0,15,904),(28,0,16,903),(28,0,23,896),(28,0,25,890),(28,0,26,894),(28,0,28,892),(28,0,29,899),(28,0,31,898),(29,0,2,1491),(29,0,3,938),(29,0,4,1492),(29,0,5,1493),(29,0,6,1494),(29,0,7,1495),(29,0,8,1496),(29,0,9,1497),(29,0,17,941),(29,0,19,947),(29,0,23,922),(29,0,25,939),(29,0,27,940),(29,0,28,918),(29,947,0,943),(30,0,3,1476),(30,0,4,1477),(30,0,5,1478),(30,0,7,1481),(30,0,17,955),(30,0,23,961),(31,0,0,1445),(31,0,2,1017),(31,0,3,1006),(31,0,4,1019),(31,0,5,1020),(31,0,6,1024),(31,0,7,1023),(31,0,8,1021),(31,0,9,1018),(31,0,15,1446),(31,0,17,1536),(31,0,18,1443),(31,0,23,1014),(31,0,24,1473),(31,0,25,1475),(31,0,26,1560),(31,0,27,1483),(31,0,28,1015),(31,0,29,1484),(31,0,30,1485),(31,0,31,1486),(31,0,32,1487),(31,0,33,1488),(31,0,34,1489),(32,0,1,1238),(32,0,3,1131),(32,0,4,1151),(32,0,5,1210),(32,0,6,1142),(32,0,7,1209),(32,0,8,1219),(32,0,9,1143),(32,0,10,1195),(32,0,11,1192),(32,0,12,1241),(32,0,13,1240),(32,0,14,1141),(32,0,15,1183),(32,0,16,1182),(32,0,17,1531),(32,0,19,1179),(32,0,20,1181),(32,0,21,1180),(32,0,22,1178),(32,0,23,1139),(32,0,24,1146),(32,0,25,1133),(32,0,26,1135),(32,0,27,1275),(32,0,28,1253),(32,0,29,1148),(32,0,30,1147),(32,0,31,1185),(32,0,32,1152),(32,0,33,1242),(32,0,34,1149),(32,0,35,1186),(32,0,36,1184),(32,0,37,1188),(32,0,38,1498),(32,1178,0,1175),(32,1178,1,1150),(32,1178,2,1174),(32,1178,3,1177),(32,1178,4,1176),(32,1179,0,1196),(32,1179,1,1199),(32,1179,2,1201),(32,1179,3,1261),(32,1179,4,1243),(32,1179,5,1502),(32,1179,6,1247),(32,1179,7,1214),(32,1179,8,1259),(32,1179,9,1239),(32,1179,10,1264),(32,1179,11,1293),(32,1180,0,743),(32,1180,1,1505),(32,1180,2,1499),(32,1180,3,1500),(32,1180,4,1137),(32,1180,5,1501),(32,1180,6,1145),(32,1180,7,1503),(32,1180,8,1144),(32,1180,9,1472),(32,1180,11,1533),(32,1181,0,1267),(32,1181,1,1273),(32,1181,2,1504),(32,1181,3,1277),(32,1181,4,1281),(32,1181,5,1285),(32,1181,6,1287),(32,1181,7,1203),(32,1181,8,1187),(32,1181,9,1202),(32,1181,10,1308),(32,1181,11,1309),(33,0,0,1418),(33,0,2,1433),(33,0,3,1435),(33,0,4,1434),(33,0,5,1437),(33,0,6,1438),(33,0,7,1440),(33,0,8,1326),(33,0,9,1436),(33,0,15,1432),(33,0,19,1414),(33,0,20,1415),(33,0,21,1417),(33,0,22,1416),(33,0,23,1319),(33,0,24,1327),(33,0,25,1328),(33,0,26,1313),(33,0,27,1315),(33,0,28,1329),(33,0,30,1419),(33,0,31,1429),(33,0,32,1424),(33,0,33,1423),(35,0,3,1342),(35,0,6,1344),(35,0,7,1346),(35,0,15,1348),(35,0,23,1350),(36,0,3,1353),(36,0,6,1355),(36,0,7,1357),(36,0,15,1359),(36,0,23,1361),(37,0,3,1364),(37,0,6,1366),(37,0,7,1368),(37,0,15,1370),(37,0,23,1372),(38,0,3,1375),(38,0,6,1377),(38,0,7,1379),(38,0,15,1381),(38,0,23,1383),(39,0,3,1519),(39,0,4,1520),(39,0,6,1521),(39,0,7,1522),(39,0,9,1523),(39,0,14,1524),(39,0,15,1517),(39,0,17,1518),(39,0,23,1515),(39,0,24,1513),(39,0,25,1507),(39,0,26,1509),(39,0,27,1511),(39,0,28,1556),(39,0,29,1564),(40,0,2,1580),(40,0,3,1567),(40,0,4,1579),(40,0,5,1578),(40,0,6,1577),(40,0,7,1571),(40,0,15,1573),(40,0,18,1581),(40,0,23,1575),(40,0,24,1569),(41,0,2,1593),(41,0,3,1583),(41,0,4,1594),(41,0,5,1595),(41,0,6,1596),(41,0,7,1598),(41,0,8,1599),(41,0,9,1600),(41,0,15,1602),(41,0,18,1601),(41,0,23,1591),(41,0,24,1589),(41,0,25,1603),(41,0,27,1585),(41,0,29,1587),(42,0,4,1630),(42,0,5,1635),(42,0,6,1628),(42,0,7,1629),(42,0,19,1627),(42,0,20,1626),(42,0,21,1625),(42,0,22,1624),(42,0,23,1622),(42,0,24,1616),(42,0,25,1618),(42,0,26,1614),(42,0,27,1636),(42,0,35,1620),(42,1627,20,1631),(42,1627,21,1632),(42,1627,22,1633),(42,1627,23,1634);
/*!40000 ALTER TABLE `character_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet`
--

DROP TABLE IF EXISTS `character_pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` int(10) unsigned DEFAULT '0',
  `CreatedBySpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `PetType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` smallint(5) unsigned NOT NULL DEFAULT '1',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `Reactstate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(21) NOT NULL DEFAULT 'Pet',
  `renamed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `curhealth` int(10) unsigned NOT NULL DEFAULT '1',
  `curmana` int(10) unsigned NOT NULL DEFAULT '0',
  `curhappiness` int(10) unsigned NOT NULL DEFAULT '0',
  `savetime` int(10) unsigned NOT NULL DEFAULT '0',
  `abdata` text,
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`),
  KEY `idx_slot` (`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet`
--

LOCK TABLES `character_pet` WRITE;
/*!40000 ALTER TABLE `character_pet` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet_declinedname`
--

DROP TABLE IF EXISTS `character_pet_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_declinedname` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `genitive` varchar(12) NOT NULL DEFAULT '',
  `dative` varchar(12) NOT NULL DEFAULT '',
  `accusative` varchar(12) NOT NULL DEFAULT '',
  `instrumental` varchar(12) NOT NULL DEFAULT '',
  `prepositional` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet_declinedname`
--

LOCK TABLES `character_pet_declinedname` WRITE;
/*!40000 ALTER TABLE `character_pet_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_pet_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus`
--

DROP TABLE IF EXISTS `character_queststatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `explored` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timer` int(10) unsigned NOT NULL DEFAULT '0',
  `mobcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playercount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus`
--

LOCK TABLES `character_queststatus` WRITE;
/*!40000 ALTER TABLE `character_queststatus` DISABLE KEYS */;
INSERT INTO `character_queststatus` VALUES (29,7,3,0,1523817990,0,0,0,0,0,0,0,0,0),(32,12933,3,0,1525373685,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `character_queststatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_daily`
--

DROP TABLE IF EXISTS `character_queststatus_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_daily`
--

LOCK TABLES `character_queststatus_daily` WRITE;
/*!40000 ALTER TABLE `character_queststatus_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_monthly`
--

DROP TABLE IF EXISTS `character_queststatus_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_monthly`
--

LOCK TABLES `character_queststatus_monthly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_rewarded`
--

DROP TABLE IF EXISTS `character_queststatus_rewarded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_rewarded` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `active` tinyint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_rewarded`
--

LOCK TABLES `character_queststatus_rewarded` WRITE;
/*!40000 ALTER TABLE `character_queststatus_rewarded` DISABLE KEYS */;
INSERT INTO `character_queststatus_rewarded` VALUES (22,6661,1),(29,783,1),(31,13347,1),(32,12932,1),(39,13347,1);
/*!40000 ALTER TABLE `character_queststatus_rewarded` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_seasonal`
--

DROP TABLE IF EXISTS `character_queststatus_seasonal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_seasonal` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `event` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_seasonal`
--

LOCK TABLES `character_queststatus_seasonal` WRITE;
/*!40000 ALTER TABLE `character_queststatus_seasonal` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_seasonal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_weekly`
--

DROP TABLE IF EXISTS `character_queststatus_weekly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_weekly`
--

LOCK TABLES `character_queststatus_weekly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_weekly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_reputation`
--

DROP TABLE IF EXISTS `character_reputation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_reputation` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `faction` smallint(5) unsigned NOT NULL DEFAULT '0',
  `standing` int(11) NOT NULL DEFAULT '0',
  `flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_reputation`
--

LOCK TABLES `character_reputation` WRITE;
/*!40000 ALTER TABLE `character_reputation` DISABLE KEYS */;
INSERT INTO `character_reputation` VALUES (2,21,0,64),(2,46,0,4),(2,47,0,6),(2,54,0,6),(2,59,0,16),(2,67,0,25),(2,68,0,17),(2,69,0,6),(2,70,0,2),(2,72,0,6),(2,76,0,17),(2,81,0,17),(2,83,0,4),(2,86,0,4),(2,87,0,2),(2,92,0,2),(2,93,0,2),(2,169,0,12),(2,270,0,16),(2,289,0,4),(2,349,0,0),(2,369,0,64),(2,469,0,14),(2,470,0,64),(2,471,0,22),(2,509,0,2),(2,510,0,16),(2,529,0,0),(2,530,0,17),(2,549,0,4),(2,550,0,4),(2,551,0,4),(2,569,0,4),(2,570,0,4),(2,571,0,4),(2,574,0,4),(2,576,0,2),(2,577,0,64),(2,589,0,6),(2,609,0,0),(2,729,0,16),(2,730,0,2),(2,749,0,0),(2,809,0,16),(2,889,0,16),(2,890,0,6),(2,891,0,0),(2,892,0,24),(2,909,0,16),(2,910,0,2),(2,911,0,17),(2,922,0,16),(2,930,0,6),(2,932,0,82),(2,933,0,16),(2,934,0,80),(2,935,0,16),(2,936,0,28),(2,941,0,16),(2,942,0,16),(2,946,0,2),(2,947,0,16),(2,948,0,8),(2,949,0,24),(2,952,0,0),(2,967,0,16),(2,970,0,0),(2,978,0,2),(2,980,0,0),(2,989,0,16),(2,990,0,16),(2,1005,0,4),(2,1011,0,16),(2,1012,0,16),(2,1015,0,2),(2,1031,0,16),(2,1037,0,6),(2,1038,0,16),(2,1050,0,6),(2,1052,0,152),(2,1064,0,16),(2,1067,0,16),(2,1068,0,6),(2,1073,0,16),(2,1077,0,16),(2,1082,0,2),(2,1085,0,16),(2,1090,0,16),(2,1091,0,16),(2,1094,0,6),(2,1097,0,0),(2,1098,0,16),(2,1104,0,16),(2,1105,0,16),(2,1106,0,16),(2,1117,0,12),(2,1118,0,12),(2,1119,0,2),(2,1124,0,17),(2,1126,0,2),(2,1136,0,4),(2,1137,0,4),(2,1154,0,4),(2,1155,0,4),(2,1156,0,16),(3,21,0,64),(3,46,0,4),(3,47,0,17),(3,54,0,17),(3,59,0,16),(3,67,0,14),(3,68,0,6),(3,69,0,17),(3,70,0,2),(3,72,0,17),(3,76,0,6),(3,81,0,6),(3,83,0,4),(3,86,0,4),(3,87,0,2),(3,92,0,2),(3,93,0,2),(3,169,0,12),(3,270,0,16),(3,289,0,4),(3,349,0,0),(3,369,0,64),(3,469,0,25),(3,470,0,64),(3,471,0,20),(3,509,0,16),(3,510,0,2),(3,529,0,0),(3,530,0,6),(3,549,0,4),(3,550,0,4),(3,551,0,4),(3,569,0,4),(3,570,0,4),(3,571,0,4),(3,574,0,4),(3,576,0,2),(3,577,0,64),(3,589,0,0),(3,609,0,0),(3,729,0,2),(3,730,0,16),(3,749,0,0),(3,809,0,16),(3,889,0,6),(3,890,0,16),(3,891,0,24),(3,892,0,14),(3,909,0,16),(3,910,0,2),(3,911,0,6),(3,922,0,6),(3,930,0,17),(3,932,0,80),(3,933,0,16),(3,934,0,80),(3,935,0,16),(3,936,0,28),(3,941,0,6),(3,942,0,16),(3,946,0,16),(3,947,0,2),(3,948,0,8),(3,949,0,24),(3,952,0,0),(3,967,0,16),(3,970,0,0),(3,978,0,16),(3,980,0,0),(3,989,0,17),(3,990,0,16),(3,1005,0,4),(3,1011,0,16),(3,1012,0,16),(3,1015,0,2),(3,1031,0,16),(3,1037,0,136),(3,1038,0,16),(3,1050,0,16),(3,1052,0,2),(3,1064,0,6),(3,1067,0,2),(3,1068,0,16),(3,1073,0,16),(3,1077,0,16),(3,1082,0,4),(3,1085,0,6),(3,1090,0,16),(3,1091,0,16),(3,1094,0,16),(3,1097,0,0),(3,1098,0,16),(3,1104,0,16),(3,1105,0,16),(3,1106,0,16),(3,1117,0,12),(3,1118,0,12),(3,1119,0,2),(3,1124,0,6),(3,1126,0,16),(3,1136,0,4),(3,1137,0,4),(3,1154,0,4),(3,1155,0,4),(3,1156,0,16),(4,21,0,64),(4,46,0,4),(4,47,0,17),(4,54,0,17),(4,59,0,16),(4,67,0,14),(4,68,0,6),(4,69,0,17),(4,70,-220,3),(4,72,0,17),(4,76,0,6),(4,81,0,6),(4,83,0,4),(4,86,0,4),(4,87,0,2),(4,92,0,2),(4,93,0,2),(4,169,0,12),(4,270,0,16),(4,289,0,4),(4,349,50,1),(4,369,0,64),(4,469,0,25),(4,470,0,64),(4,471,0,20),(4,509,0,16),(4,510,0,2),(4,529,0,0),(4,530,0,6),(4,549,0,4),(4,550,0,4),(4,551,0,4),(4,569,0,4),(4,570,0,4),(4,571,0,4),(4,574,0,4),(4,576,0,2),(4,577,0,64),(4,589,0,0),(4,609,0,0),(4,729,0,2),(4,730,0,16),(4,749,0,0),(4,809,0,16),(4,889,0,6),(4,890,0,16),(4,891,0,24),(4,892,0,14),(4,909,0,16),(4,910,0,2),(4,911,0,6),(4,922,0,6),(4,930,0,17),(4,932,0,80),(4,933,0,16),(4,934,0,80),(4,935,0,16),(4,936,0,28),(4,941,0,6),(4,942,0,16),(4,946,0,16),(4,947,0,2),(4,948,0,8),(4,949,0,24),(4,952,0,0),(4,967,0,16),(4,970,0,0),(4,978,0,16),(4,980,0,0),(4,989,0,16),(4,990,0,16),(4,1005,0,4),(4,1011,0,16),(4,1012,0,16),(4,1015,0,2),(4,1031,0,16),(4,1037,0,136),(4,1038,0,16),(4,1050,0,16),(4,1052,0,2),(4,1064,0,6),(4,1067,0,2),(4,1068,0,16),(4,1073,0,16),(4,1077,0,16),(4,1082,0,4),(4,1085,0,6),(4,1090,0,16),(4,1091,0,16),(4,1094,0,16),(4,1097,0,0),(4,1098,0,16),(4,1104,0,16),(4,1105,0,16),(4,1106,0,16),(4,1117,0,12),(4,1118,0,12),(4,1119,0,2),(4,1124,0,6),(4,1126,0,16),(4,1136,0,4),(4,1137,0,4),(4,1154,0,4),(4,1155,0,4),(4,1156,0,16),(5,21,0,64),(5,46,0,4),(5,47,0,17),(5,54,0,17),(5,59,0,16),(5,67,0,14),(5,68,0,6),(5,69,0,17),(5,70,0,2),(5,72,0,17),(5,76,0,6),(5,81,0,6),(5,83,0,4),(5,86,0,4),(5,87,0,2),(5,92,0,2),(5,93,0,2),(5,169,0,12),(5,270,0,16),(5,289,0,4),(5,349,0,0),(5,369,0,64),(5,469,0,25),(5,470,0,64),(5,471,0,20),(5,509,0,16),(5,510,0,2),(5,529,0,0),(5,530,0,6),(5,549,0,4),(5,550,0,4),(5,551,0,4),(5,569,0,4),(5,570,0,4),(5,571,0,4),(5,574,0,4),(5,576,0,2),(5,577,0,64),(5,589,0,0),(5,609,0,0),(5,729,0,2),(5,730,0,16),(5,749,0,0),(5,809,0,16),(5,889,0,6),(5,890,0,16),(5,891,0,24),(5,892,0,14),(5,909,0,16),(5,910,0,2),(5,911,0,6),(5,922,0,6),(5,930,0,17),(5,932,0,80),(5,933,0,16),(5,934,0,80),(5,935,0,16),(5,936,0,28),(5,941,0,6),(5,942,0,16),(5,946,0,16),(5,947,0,2),(5,948,0,8),(5,949,0,24),(5,952,0,0),(5,967,0,16),(5,970,0,0),(5,978,0,16),(5,980,0,0),(5,989,0,16),(5,990,0,16),(5,1005,0,0),(5,1011,0,16),(5,1012,0,16),(5,1015,0,2),(5,1031,0,16),(5,1037,0,136),(5,1038,0,16),(5,1050,0,16),(5,1052,0,2),(5,1064,0,6),(5,1067,0,2),(5,1068,0,16),(5,1073,0,16),(5,1077,0,16),(5,1082,0,4),(5,1085,0,6),(5,1090,0,16),(5,1091,0,16),(5,1094,0,16),(5,1097,0,0),(5,1098,0,16),(5,1104,0,16),(5,1105,0,16),(5,1106,0,16),(5,1117,0,12),(5,1118,0,12),(5,1119,0,2),(5,1124,0,6),(5,1126,0,16),(5,1136,0,4),(5,1137,0,4),(5,1154,0,4),(5,1155,0,4),(5,1156,0,16),(7,21,0,64),(7,46,0,4),(7,47,0,17),(7,54,0,17),(7,59,0,16),(7,67,0,14),(7,68,0,6),(7,69,0,17),(7,70,0,2),(7,72,0,17),(7,76,0,6),(7,81,0,6),(7,83,0,4),(7,86,0,4),(7,87,0,2),(7,92,0,2),(7,93,0,2),(7,169,0,12),(7,270,0,16),(7,289,0,4),(7,349,0,0),(7,369,0,64),(7,469,0,25),(7,470,0,64),(7,471,0,20),(7,509,0,16),(7,510,0,2),(7,529,0,0),(7,530,0,6),(7,549,0,4),(7,550,0,4),(7,551,0,4),(7,569,0,4),(7,570,0,4),(7,571,0,4),(7,574,0,4),(7,576,0,2),(7,577,0,64),(7,589,0,0),(7,609,0,0),(7,729,0,2),(7,730,0,16),(7,749,0,0),(7,809,0,16),(7,889,0,6),(7,890,0,16),(7,891,0,24),(7,892,0,14),(7,909,0,16),(7,910,0,0),(7,911,0,6),(7,922,0,6),(7,930,0,17),(7,932,0,80),(7,933,0,16),(7,934,0,80),(7,935,0,16),(7,936,0,28),(7,941,0,6),(7,942,0,16),(7,946,0,16),(7,947,0,0),(7,948,0,8),(7,949,0,24),(7,952,0,0),(7,967,0,16),(7,970,0,0),(7,978,0,16),(7,980,0,0),(7,989,0,16),(7,990,0,16),(7,1005,0,4),(7,1011,0,16),(7,1012,0,16),(7,1015,0,2),(7,1031,0,16),(7,1037,0,136),(7,1038,0,16),(7,1050,0,16),(7,1052,0,0),(7,1064,0,6),(7,1067,0,0),(7,1068,0,16),(7,1073,0,16),(7,1077,0,16),(7,1082,0,4),(7,1085,0,6),(7,1090,0,16),(7,1091,0,16),(7,1094,0,16),(7,1097,0,0),(7,1098,0,16),(7,1104,0,16),(7,1105,0,16),(7,1106,0,16),(7,1117,0,12),(7,1118,0,12),(7,1119,0,0),(7,1124,0,6),(7,1126,0,16),(7,1136,0,4),(7,1137,0,4),(7,1154,0,4),(7,1155,0,4),(7,1156,0,16),(13,21,0,64),(13,46,0,4),(13,47,0,6),(13,54,0,6),(13,59,0,16),(13,67,0,25),(13,68,0,17),(13,69,0,6),(13,70,0,2),(13,72,0,6),(13,76,0,17),(13,81,0,17),(13,83,0,4),(13,86,0,4),(13,87,0,2),(13,92,0,2),(13,93,0,2),(13,169,0,12),(13,270,0,16),(13,289,0,4),(13,349,0,0),(13,369,0,64),(13,469,0,14),(13,470,0,64),(13,471,0,22),(13,509,0,2),(13,510,0,16),(13,529,0,0),(13,530,0,17),(13,549,0,4),(13,550,0,4),(13,551,0,4),(13,569,0,4),(13,570,0,4),(13,571,0,4),(13,574,0,4),(13,576,0,2),(13,577,0,64),(13,589,0,6),(13,609,0,0),(13,729,0,16),(13,730,0,2),(13,749,0,0),(13,809,0,16),(13,889,0,16),(13,890,0,6),(13,891,0,14),(13,892,0,24),(13,909,0,16),(13,910,0,0),(13,911,0,17),(13,922,0,16),(13,930,0,6),(13,932,0,80),(13,933,0,16),(13,934,0,80),(13,935,0,16),(13,936,0,28),(13,941,0,16),(13,942,0,16),(13,946,0,0),(13,947,0,16),(13,948,0,8),(13,949,0,24),(13,952,0,0),(13,967,0,16),(13,970,0,0),(13,978,0,0),(13,980,0,0),(13,989,0,16),(13,990,0,16),(13,1005,0,4),(13,1011,0,16),(13,1012,0,16),(13,1015,0,2),(13,1031,0,16),(13,1037,0,6),(13,1038,0,16),(13,1050,0,6),(13,1052,0,152),(13,1064,0,16),(13,1067,0,16),(13,1068,0,6),(13,1073,0,16),(13,1077,0,16),(13,1082,0,2),(13,1085,0,16),(13,1090,0,16),(13,1091,0,16),(13,1094,0,6),(13,1097,0,0),(13,1098,0,16),(13,1104,0,16),(13,1105,0,16),(13,1106,0,16),(13,1117,0,12),(13,1118,0,12),(13,1119,0,0),(13,1124,0,16),(13,1126,0,0),(13,1136,0,4),(13,1137,0,4),(13,1154,0,4),(13,1155,0,4),(13,1156,0,16),(14,21,0,64),(14,46,0,4),(14,47,0,17),(14,54,0,17),(14,59,0,16),(14,67,0,14),(14,68,0,6),(14,69,0,17),(14,70,0,2),(14,72,0,17),(14,76,0,6),(14,81,0,6),(14,83,0,4),(14,86,0,4),(14,87,0,2),(14,92,0,2),(14,93,0,2),(14,169,0,12),(14,270,0,16),(14,289,0,4),(14,349,0,0),(14,369,0,64),(14,469,0,25),(14,470,0,64),(14,471,0,20),(14,509,0,16),(14,510,0,2),(14,529,0,0),(14,530,0,6),(14,549,0,4),(14,550,0,4),(14,551,0,4),(14,569,0,4),(14,570,0,4),(14,571,0,4),(14,574,0,4),(14,576,0,2),(14,577,0,64),(14,589,0,0),(14,609,0,0),(14,729,0,2),(14,730,0,16),(14,749,0,0),(14,809,0,16),(14,889,0,6),(14,890,0,16),(14,891,0,24),(14,892,0,14),(14,909,0,16),(14,910,0,0),(14,911,0,6),(14,922,0,6),(14,930,0,17),(14,932,0,80),(14,933,0,16),(14,934,0,80),(14,935,0,16),(14,936,0,28),(14,941,0,6),(14,942,0,16),(14,946,0,16),(14,947,0,0),(14,948,0,8),(14,949,0,24),(14,952,0,0),(14,967,0,16),(14,970,0,0),(14,978,0,16),(14,980,0,0),(14,989,0,16),(14,990,0,16),(14,1005,0,4),(14,1011,0,16),(14,1012,0,16),(14,1015,0,2),(14,1031,0,16),(14,1037,0,136),(14,1038,0,16),(14,1050,0,16),(14,1052,0,0),(14,1064,0,6),(14,1067,0,0),(14,1068,0,16),(14,1073,0,16),(14,1077,0,16),(14,1082,0,4),(14,1085,0,6),(14,1090,0,16),(14,1091,0,16),(14,1094,0,16),(14,1097,0,0),(14,1098,0,16),(14,1104,0,16),(14,1105,0,16),(14,1106,0,16),(14,1117,0,12),(14,1118,0,12),(14,1119,0,0),(14,1124,0,6),(14,1126,0,16),(14,1136,0,4),(14,1137,0,4),(14,1154,0,4),(14,1155,0,4),(14,1156,0,16),(15,21,0,64),(15,46,0,4),(15,47,0,17),(15,54,0,17),(15,59,0,16),(15,67,0,14),(15,68,0,6),(15,69,0,17),(15,70,0,2),(15,72,0,17),(15,76,0,6),(15,81,0,6),(15,83,0,4),(15,86,0,4),(15,87,0,2),(15,92,0,2),(15,93,0,2),(15,169,0,12),(15,270,0,16),(15,289,0,4),(15,349,0,0),(15,369,0,64),(15,469,0,25),(15,470,0,64),(15,471,0,20),(15,509,0,16),(15,510,0,2),(15,529,0,0),(15,530,0,6),(15,549,0,4),(15,550,0,4),(15,551,0,4),(15,569,0,4),(15,570,0,4),(15,571,0,4),(15,574,0,4),(15,576,0,2),(15,577,0,64),(15,589,0,0),(15,609,0,0),(15,729,0,2),(15,730,0,16),(15,749,0,0),(15,809,0,16),(15,889,0,6),(15,890,0,16),(15,891,0,24),(15,892,0,14),(15,909,0,16),(15,910,0,2),(15,911,0,6),(15,922,0,6),(15,930,0,17),(15,932,0,80),(15,933,0,16),(15,934,0,80),(15,935,0,16),(15,936,0,28),(15,941,0,6),(15,942,0,16),(15,946,0,16),(15,947,0,2),(15,948,0,8),(15,949,0,24),(15,952,0,0),(15,967,0,16),(15,970,0,0),(15,978,0,16),(15,980,0,0),(15,989,0,16),(15,990,0,16),(15,1005,0,4),(15,1011,0,16),(15,1012,0,16),(15,1015,0,2),(15,1031,0,16),(15,1037,0,136),(15,1038,0,16),(15,1050,0,16),(15,1052,0,2),(15,1064,0,6),(15,1067,0,2),(15,1068,0,16),(15,1073,0,16),(15,1077,0,16),(15,1082,0,4),(15,1085,0,6),(15,1090,0,17),(15,1091,0,16),(15,1094,0,16),(15,1097,0,0),(15,1098,0,16),(15,1104,0,16),(15,1105,0,16),(15,1106,0,16),(15,1117,0,12),(15,1118,0,12),(15,1119,0,2),(15,1124,0,6),(15,1126,0,16),(15,1136,0,4),(15,1137,0,4),(15,1154,0,4),(15,1155,0,4),(15,1156,0,16),(16,21,0,64),(16,46,0,4),(16,47,0,17),(16,54,0,17),(16,59,0,16),(16,67,0,14),(16,68,0,6),(16,69,0,17),(16,70,0,2),(16,72,0,17),(16,76,0,6),(16,81,0,6),(16,83,0,4),(16,86,0,4),(16,87,0,2),(16,92,0,2),(16,93,0,2),(16,169,0,12),(16,270,0,16),(16,289,0,4),(16,349,0,0),(16,369,0,64),(16,469,0,25),(16,470,0,64),(16,471,0,20),(16,509,0,16),(16,510,0,2),(16,529,0,0),(16,530,0,6),(16,549,0,4),(16,550,0,4),(16,551,0,4),(16,569,0,4),(16,570,0,4),(16,571,0,4),(16,574,0,4),(16,576,0,2),(16,577,0,64),(16,589,0,0),(16,609,0,0),(16,729,0,2),(16,730,0,16),(16,749,0,0),(16,809,0,16),(16,889,0,6),(16,890,0,16),(16,891,0,24),(16,892,0,14),(16,909,0,16),(16,910,0,2),(16,911,0,6),(16,922,0,6),(16,930,0,17),(16,932,0,80),(16,933,0,16),(16,934,0,80),(16,935,0,16),(16,936,0,28),(16,941,0,6),(16,942,0,16),(16,946,0,16),(16,947,0,2),(16,948,0,8),(16,949,0,24),(16,952,0,0),(16,967,0,16),(16,970,0,0),(16,978,0,16),(16,980,0,0),(16,989,0,16),(16,990,0,16),(16,1005,0,4),(16,1011,0,16),(16,1012,0,16),(16,1015,0,2),(16,1031,0,16),(16,1037,0,136),(16,1038,0,16),(16,1050,0,16),(16,1052,0,2),(16,1064,0,6),(16,1067,0,2),(16,1068,0,16),(16,1073,0,16),(16,1077,0,16),(16,1082,0,4),(16,1085,0,6),(16,1090,0,17),(16,1091,0,16),(16,1094,0,16),(16,1097,0,0),(16,1098,0,16),(16,1104,0,16),(16,1105,0,16),(16,1106,0,17),(16,1117,0,12),(16,1118,0,12),(16,1119,0,2),(16,1124,0,6),(16,1126,0,16),(16,1136,0,4),(16,1137,0,4),(16,1154,0,4),(16,1155,0,4),(16,1156,0,16),(21,21,0,64),(21,46,0,4),(21,47,0,17),(21,54,0,17),(21,59,0,16),(21,67,0,14),(21,68,0,6),(21,69,0,17),(21,70,0,2),(21,72,0,17),(21,76,0,6),(21,81,0,6),(21,83,0,4),(21,86,0,4),(21,87,0,2),(21,92,0,2),(21,93,0,2),(21,169,0,12),(21,270,0,16),(21,289,0,4),(21,349,0,0),(21,369,0,64),(21,469,0,25),(21,470,0,64),(21,471,0,20),(21,509,0,16),(21,510,0,2),(21,529,0,0),(21,530,0,6),(21,549,0,4),(21,550,0,4),(21,551,0,4),(21,569,0,4),(21,570,0,4),(21,571,0,4),(21,574,0,4),(21,576,0,2),(21,577,0,64),(21,589,0,0),(21,609,0,0),(21,729,0,2),(21,730,0,16),(21,749,0,0),(21,809,0,16),(21,889,0,6),(21,890,0,16),(21,891,0,24),(21,892,0,14),(21,909,0,16),(21,910,0,2),(21,911,0,6),(21,922,0,6),(21,930,0,17),(21,932,0,80),(21,933,0,16),(21,934,0,80),(21,935,0,16),(21,936,0,28),(21,941,0,6),(21,942,0,16),(21,946,0,16),(21,947,0,2),(21,948,0,8),(21,949,0,24),(21,952,0,0),(21,967,0,16),(21,970,0,0),(21,978,0,16),(21,980,0,0),(21,989,0,16),(21,990,0,16),(21,1005,0,4),(21,1011,0,16),(21,1012,0,16),(21,1015,0,2),(21,1031,0,16),(21,1037,0,136),(21,1038,0,16),(21,1050,0,16),(21,1052,0,2),(21,1064,0,6),(21,1067,0,2),(21,1068,0,16),(21,1073,0,16),(21,1077,0,16),(21,1082,0,4),(21,1085,0,6),(21,1090,0,16),(21,1091,0,16),(21,1094,0,16),(21,1097,0,0),(21,1098,0,16),(21,1104,0,16),(21,1105,0,16),(21,1106,0,16),(21,1117,0,12),(21,1118,0,12),(21,1119,0,2),(21,1124,0,6),(21,1126,0,16),(21,1136,0,4),(21,1137,0,4),(21,1154,0,4),(21,1155,0,4),(21,1156,0,16),(22,21,0,64),(22,46,0,4),(22,47,0,17),(22,54,0,17),(22,59,0,16),(22,67,0,14),(22,68,0,6),(22,69,0,17),(22,70,0,2),(22,72,0,17),(22,76,0,6),(22,81,0,6),(22,83,0,4),(22,86,0,4),(22,87,0,2),(22,92,0,2),(22,93,0,2),(22,169,0,12),(22,270,0,16),(22,289,0,4),(22,349,0,0),(22,369,0,64),(22,469,0,25),(22,470,0,64),(22,471,0,20),(22,509,0,16),(22,510,0,2),(22,529,0,1),(22,530,0,6),(22,549,0,4),(22,550,0,4),(22,551,0,4),(22,569,0,4),(22,570,0,4),(22,571,0,4),(22,574,0,4),(22,576,0,2),(22,577,0,64),(22,589,0,0),(22,609,0,0),(22,729,0,2),(22,730,0,16),(22,749,0,0),(22,809,0,16),(22,889,0,6),(22,890,0,16),(22,891,0,24),(22,892,0,14),(22,909,0,16),(22,910,0,2),(22,911,0,6),(22,922,0,6),(22,930,0,17),(22,932,0,80),(22,933,0,16),(22,934,0,80),(22,935,0,16),(22,936,0,28),(22,941,0,6),(22,942,0,16),(22,946,0,16),(22,947,0,2),(22,948,0,8),(22,949,0,24),(22,952,0,0),(22,967,0,16),(22,970,0,0),(22,978,0,16),(22,980,0,0),(22,989,0,16),(22,990,0,16),(22,1005,0,4),(22,1011,0,16),(22,1012,0,16),(22,1015,0,2),(22,1031,0,16),(22,1037,0,136),(22,1038,0,16),(22,1050,0,16),(22,1052,0,2),(22,1064,0,6),(22,1067,0,2),(22,1068,0,16),(22,1073,0,16),(22,1077,0,16),(22,1082,0,4),(22,1085,0,6),(22,1090,0,16),(22,1091,0,16),(22,1094,0,16),(22,1097,0,0),(22,1098,0,16),(22,1104,0,16),(22,1105,0,16),(22,1106,0,16),(22,1117,0,12),(22,1118,0,12),(22,1119,0,2),(22,1124,0,6),(22,1126,0,16),(22,1136,0,4),(22,1137,0,4),(22,1154,0,4),(22,1155,0,4),(22,1156,0,16),(24,21,0,64),(24,46,0,4),(24,47,0,17),(24,54,0,17),(24,59,0,16),(24,67,0,14),(24,68,0,6),(24,69,0,17),(24,70,0,2),(24,72,0,17),(24,76,0,6),(24,81,0,6),(24,83,0,4),(24,86,0,4),(24,87,0,2),(24,92,0,2),(24,93,0,2),(24,169,0,12),(24,270,0,16),(24,289,0,4),(24,349,0,0),(24,369,0,64),(24,469,0,25),(24,470,0,64),(24,471,0,20),(24,509,0,16),(24,510,0,2),(24,529,0,0),(24,530,0,6),(24,549,0,4),(24,550,0,4),(24,551,0,4),(24,569,0,4),(24,570,0,4),(24,571,0,4),(24,574,0,4),(24,576,0,2),(24,577,0,64),(24,589,0,0),(24,609,0,0),(24,729,0,2),(24,730,0,16),(24,749,0,0),(24,809,0,16),(24,889,0,6),(24,890,0,16),(24,891,0,24),(24,892,0,14),(24,909,0,16),(24,910,0,2),(24,911,0,6),(24,922,0,6),(24,930,0,17),(24,932,0,80),(24,933,0,16),(24,934,0,80),(24,935,0,16),(24,936,0,28),(24,941,0,6),(24,942,0,16),(24,946,0,16),(24,947,0,2),(24,948,0,8),(24,949,0,24),(24,952,0,0),(24,967,0,16),(24,970,0,0),(24,978,0,16),(24,980,0,0),(24,989,0,16),(24,990,0,16),(24,1005,0,4),(24,1011,0,16),(24,1012,0,16),(24,1015,0,2),(24,1031,0,16),(24,1037,0,136),(24,1038,0,16),(24,1050,0,16),(24,1052,0,2),(24,1064,0,6),(24,1067,0,2),(24,1068,0,16),(24,1073,0,16),(24,1077,0,16),(24,1082,0,4),(24,1085,0,6),(24,1090,0,16),(24,1091,0,16),(24,1094,0,16),(24,1097,0,0),(24,1098,0,16),(24,1104,0,16),(24,1105,0,16),(24,1106,0,16),(24,1117,0,12),(24,1118,0,12),(24,1119,0,2),(24,1124,0,6),(24,1126,0,16),(24,1136,0,4),(24,1137,0,4),(24,1154,0,4),(24,1155,0,4),(24,1156,0,16),(25,21,0,64),(25,46,0,4),(25,47,0,17),(25,54,0,17),(25,59,0,16),(25,67,0,14),(25,68,0,6),(25,69,0,17),(25,70,0,2),(25,72,0,17),(25,76,0,6),(25,81,0,6),(25,83,0,4),(25,86,0,4),(25,87,0,2),(25,92,0,2),(25,93,0,2),(25,169,0,12),(25,270,0,16),(25,289,0,4),(25,349,0,0),(25,369,0,64),(25,469,0,25),(25,470,0,64),(25,471,0,20),(25,509,0,16),(25,510,0,2),(25,529,0,0),(25,530,0,6),(25,549,0,4),(25,550,0,4),(25,551,0,4),(25,569,0,4),(25,570,0,4),(25,571,0,4),(25,574,0,4),(25,576,0,2),(25,577,0,64),(25,589,0,0),(25,609,0,0),(25,729,0,2),(25,730,0,16),(25,749,0,0),(25,809,0,16),(25,889,0,6),(25,890,0,16),(25,891,0,24),(25,892,0,14),(25,909,0,16),(25,910,0,2),(25,911,0,6),(25,922,0,6),(25,930,0,17),(25,932,0,80),(25,933,0,16),(25,934,0,80),(25,935,0,16),(25,936,0,28),(25,941,0,6),(25,942,0,16),(25,946,0,16),(25,947,0,2),(25,948,0,8),(25,949,0,24),(25,952,0,0),(25,967,0,16),(25,970,0,0),(25,978,0,16),(25,980,0,0),(25,989,0,16),(25,990,0,16),(25,1005,0,4),(25,1011,0,16),(25,1012,0,16),(25,1015,0,2),(25,1031,0,16),(25,1037,0,136),(25,1038,0,16),(25,1050,0,16),(25,1052,0,2),(25,1064,0,6),(25,1067,0,2),(25,1068,0,16),(25,1073,0,16),(25,1077,0,16),(25,1082,0,4),(25,1085,0,6),(25,1090,0,16),(25,1091,0,16),(25,1094,0,16),(25,1097,0,0),(25,1098,0,16),(25,1104,0,16),(25,1105,0,16),(25,1106,0,16),(25,1117,0,12),(25,1118,0,12),(25,1119,0,2),(25,1124,0,6),(25,1126,0,16),(25,1136,0,4),(25,1137,0,4),(25,1154,0,4),(25,1155,0,4),(25,1156,0,16),(26,21,0,64),(26,46,0,4),(26,47,0,17),(26,54,0,17),(26,59,0,16),(26,67,0,14),(26,68,0,6),(26,69,0,17),(26,70,0,2),(26,72,0,17),(26,76,0,6),(26,81,0,6),(26,83,0,4),(26,86,0,4),(26,87,0,2),(26,92,0,2),(26,93,0,2),(26,169,0,12),(26,270,0,16),(26,289,0,4),(26,349,0,0),(26,369,0,64),(26,469,0,25),(26,470,0,64),(26,471,0,20),(26,509,0,16),(26,510,0,2),(26,529,0,0),(26,530,0,6),(26,549,0,4),(26,550,0,4),(26,551,0,4),(26,569,0,4),(26,570,0,4),(26,571,0,4),(26,574,0,4),(26,576,0,2),(26,577,0,64),(26,589,0,0),(26,609,0,0),(26,729,0,2),(26,730,0,16),(26,749,0,0),(26,809,0,16),(26,889,0,6),(26,890,0,16),(26,891,0,24),(26,892,0,14),(26,909,0,16),(26,910,0,2),(26,911,0,6),(26,922,0,6),(26,930,0,17),(26,932,0,80),(26,933,0,16),(26,934,0,80),(26,935,0,16),(26,936,0,28),(26,941,0,6),(26,942,0,16),(26,946,0,16),(26,947,0,2),(26,948,0,8),(26,949,0,24),(26,952,0,0),(26,967,0,16),(26,970,0,0),(26,978,0,16),(26,980,0,0),(26,989,0,16),(26,990,0,16),(26,1005,0,4),(26,1011,0,16),(26,1012,0,16),(26,1015,0,2),(26,1031,0,16),(26,1037,0,136),(26,1038,0,16),(26,1050,0,16),(26,1052,0,2),(26,1064,0,6),(26,1067,0,2),(26,1068,0,16),(26,1073,0,16),(26,1077,0,16),(26,1082,0,4),(26,1085,0,6),(26,1090,0,16),(26,1091,0,16),(26,1094,0,16),(26,1097,0,0),(26,1098,0,16),(26,1104,0,16),(26,1105,0,16),(26,1106,0,16),(26,1117,0,12),(26,1118,0,12),(26,1119,0,2),(26,1124,0,6),(26,1126,0,16),(26,1136,0,4),(26,1137,0,4),(26,1154,0,4),(26,1155,0,4),(26,1156,0,16),(27,21,0,64),(27,46,0,4),(27,47,0,17),(27,54,0,17),(27,59,0,16),(27,67,0,14),(27,68,0,6),(27,69,0,17),(27,70,0,2),(27,72,0,17),(27,76,0,6),(27,81,0,6),(27,83,0,4),(27,86,0,4),(27,87,0,2),(27,92,0,2),(27,93,0,2),(27,169,0,12),(27,270,0,16),(27,289,0,4),(27,349,0,0),(27,369,0,64),(27,469,0,25),(27,470,0,64),(27,471,0,20),(27,509,0,16),(27,510,0,2),(27,529,0,0),(27,530,0,6),(27,549,0,4),(27,550,0,4),(27,551,0,4),(27,569,0,4),(27,570,0,4),(27,571,0,4),(27,574,0,4),(27,576,0,2),(27,577,0,64),(27,589,0,0),(27,609,0,0),(27,729,0,2),(27,730,0,16),(27,749,0,0),(27,809,0,16),(27,889,0,6),(27,890,0,16),(27,891,0,24),(27,892,0,14),(27,909,0,16),(27,910,0,2),(27,911,0,6),(27,922,0,6),(27,930,0,17),(27,932,0,80),(27,933,0,16),(27,934,0,80),(27,935,0,16),(27,936,0,28),(27,941,0,6),(27,942,0,16),(27,946,0,16),(27,947,0,2),(27,948,0,8),(27,949,0,24),(27,952,0,0),(27,967,0,16),(27,970,0,0),(27,978,0,16),(27,980,0,0),(27,989,0,16),(27,990,0,16),(27,1005,0,4),(27,1011,0,16),(27,1012,0,16),(27,1015,0,2),(27,1031,0,16),(27,1037,0,136),(27,1038,0,16),(27,1050,0,16),(27,1052,0,2),(27,1064,0,6),(27,1067,0,2),(27,1068,0,16),(27,1073,0,16),(27,1077,0,16),(27,1082,0,4),(27,1085,0,6),(27,1090,0,16),(27,1091,0,16),(27,1094,0,16),(27,1097,0,0),(27,1098,0,16),(27,1104,0,16),(27,1105,0,16),(27,1106,0,16),(27,1117,0,12),(27,1118,0,12),(27,1119,0,2),(27,1124,0,6),(27,1126,0,16),(27,1136,0,4),(27,1137,0,4),(27,1154,0,4),(27,1155,0,4),(27,1156,0,16),(28,21,0,64),(28,46,0,4),(28,47,0,17),(28,54,0,17),(28,59,0,16),(28,67,0,14),(28,68,0,6),(28,69,0,17),(28,70,0,2),(28,72,0,17),(28,76,0,6),(28,81,0,6),(28,83,0,4),(28,86,0,4),(28,87,0,2),(28,92,0,2),(28,93,0,2),(28,169,0,12),(28,270,0,16),(28,289,0,4),(28,349,0,0),(28,369,0,64),(28,469,0,25),(28,470,0,64),(28,471,0,4),(28,509,0,16),(28,510,0,2),(28,529,0,0),(28,530,0,6),(28,549,0,4),(28,550,0,4),(28,551,0,4),(28,569,0,4),(28,570,0,4),(28,571,0,4),(28,574,0,4),(28,576,0,2),(28,577,0,64),(28,589,0,0),(28,609,0,0),(28,729,0,2),(28,730,0,16),(28,749,0,0),(28,809,0,16),(28,889,0,6),(28,890,0,16),(28,891,0,24),(28,892,0,14),(28,909,0,16),(28,910,0,0),(28,911,0,6),(28,922,0,6),(28,930,0,17),(28,932,0,80),(28,933,0,16),(28,934,0,80),(28,935,0,16),(28,936,0,28),(28,941,0,6),(28,942,0,16),(28,946,0,16),(28,947,0,0),(28,948,0,8),(28,949,0,24),(28,952,0,0),(28,967,0,16),(28,970,0,0),(28,978,0,16),(28,980,0,0),(28,989,0,16),(28,990,0,16),(28,1005,0,4),(28,1011,0,16),(28,1012,0,16),(28,1015,0,2),(28,1031,0,16),(28,1037,0,136),(28,1038,0,16),(28,1050,0,16),(28,1052,0,0),(28,1064,0,6),(28,1067,0,0),(28,1068,0,16),(28,1073,0,16),(28,1077,0,16),(28,1082,0,4),(28,1085,0,6),(28,1090,0,16),(28,1091,0,16),(28,1094,0,16),(28,1097,0,0),(28,1098,0,16),(28,1104,0,16),(28,1105,0,16),(28,1106,0,16),(28,1117,0,12),(28,1118,0,12),(28,1119,0,0),(28,1124,0,6),(28,1126,0,16),(28,1136,0,4),(28,1137,0,4),(28,1154,0,4),(28,1155,0,4),(28,1156,0,16),(29,21,0,64),(29,46,0,4),(29,47,20,17),(29,54,20,17),(29,59,0,16),(29,67,0,14),(29,68,0,6),(29,69,20,17),(29,70,0,2),(29,72,82,17),(29,76,0,6),(29,81,0,6),(29,83,0,4),(29,86,0,4),(29,87,0,2),(29,92,0,2),(29,93,0,2),(29,169,0,12),(29,270,0,16),(29,289,0,4),(29,349,0,0),(29,369,0,64),(29,469,0,25),(29,470,0,64),(29,471,0,20),(29,509,0,16),(29,510,0,2),(29,529,0,0),(29,530,0,6),(29,549,0,4),(29,550,0,4),(29,551,0,4),(29,569,0,4),(29,570,0,4),(29,571,0,4),(29,574,0,4),(29,576,0,2),(29,577,0,64),(29,589,0,0),(29,609,0,0),(29,729,0,2),(29,730,0,16),(29,749,0,0),(29,809,0,16),(29,889,0,6),(29,890,0,16),(29,891,0,24),(29,892,0,14),(29,909,0,16),(29,910,0,2),(29,911,0,6),(29,922,0,6),(29,930,20,17),(29,932,0,80),(29,933,0,16),(29,934,0,80),(29,935,0,16),(29,936,0,28),(29,941,0,6),(29,942,0,16),(29,946,0,16),(29,947,0,2),(29,948,0,8),(29,949,0,24),(29,952,0,0),(29,967,0,16),(29,970,0,0),(29,978,0,16),(29,980,0,0),(29,989,0,16),(29,990,0,16),(29,1005,0,4),(29,1011,0,16),(29,1012,0,16),(29,1015,0,2),(29,1031,0,16),(29,1037,0,136),(29,1038,0,16),(29,1050,0,16),(29,1052,0,2),(29,1064,0,6),(29,1067,0,2),(29,1068,0,16),(29,1073,0,16),(29,1077,0,16),(29,1082,0,4),(29,1085,0,6),(29,1090,0,16),(29,1091,0,16),(29,1094,0,16),(29,1097,0,0),(29,1098,0,16),(29,1104,0,16),(29,1105,0,16),(29,1106,0,16),(29,1117,0,12),(29,1118,0,12),(29,1119,0,2),(29,1124,0,6),(29,1126,0,16),(29,1136,0,4),(29,1137,0,4),(29,1154,0,4),(29,1155,0,4),(29,1156,0,16),(30,21,0,64),(30,46,0,4),(30,47,0,17),(30,54,0,17),(30,59,0,16),(30,67,0,14),(30,68,0,6),(30,69,0,17),(30,70,0,2),(30,72,0,17),(30,76,0,6),(30,81,0,6),(30,83,0,4),(30,86,0,4),(30,87,0,2),(30,92,0,2),(30,93,0,2),(30,169,0,12),(30,270,0,16),(30,289,0,4),(30,349,0,0),(30,369,0,64),(30,469,0,25),(30,470,0,64),(30,471,0,20),(30,509,0,16),(30,510,0,2),(30,529,0,0),(30,530,0,6),(30,549,0,4),(30,550,0,4),(30,551,0,4),(30,569,0,4),(30,570,0,4),(30,571,0,4),(30,574,0,4),(30,576,0,2),(30,577,0,64),(30,589,0,0),(30,609,0,0),(30,729,0,2),(30,730,0,16),(30,749,0,0),(30,809,0,16),(30,889,0,6),(30,890,0,16),(30,891,0,24),(30,892,0,14),(30,909,0,16),(30,910,0,2),(30,911,0,6),(30,922,0,6),(30,930,0,17),(30,932,0,80),(30,933,0,16),(30,934,0,80),(30,935,0,16),(30,936,0,28),(30,941,0,6),(30,942,0,16),(30,946,0,16),(30,947,0,2),(30,948,0,8),(30,949,0,24),(30,952,0,0),(30,967,0,16),(30,970,0,0),(30,978,0,16),(30,980,0,0),(30,989,0,16),(30,990,0,16),(30,1005,0,4),(30,1011,0,16),(30,1012,0,16),(30,1015,0,2),(30,1031,0,16),(30,1037,0,136),(30,1038,0,16),(30,1050,0,16),(30,1052,0,2),(30,1064,0,6),(30,1067,0,2),(30,1068,0,16),(30,1073,0,16),(30,1077,0,16),(30,1082,0,4),(30,1085,0,6),(30,1090,0,16),(30,1091,0,16),(30,1094,0,16),(30,1097,0,0),(30,1098,0,16),(30,1104,0,16),(30,1105,0,16),(30,1106,0,16),(30,1117,0,12),(30,1118,0,12),(30,1119,0,2),(30,1124,0,6),(30,1126,0,16),(30,1136,0,4),(30,1137,0,4),(30,1154,0,4),(30,1155,0,4),(30,1156,0,16),(31,21,0,64),(31,46,0,4),(31,47,137,17),(31,54,137,17),(31,59,0,16),(31,67,0,14),(31,68,0,6),(31,69,137,17),(31,70,0,2),(31,72,550,17),(31,76,0,6),(31,81,0,6),(31,83,0,4),(31,86,0,4),(31,87,0,2),(31,92,0,2),(31,93,0,2),(31,169,0,12),(31,270,0,16),(31,289,0,4),(31,349,0,0),(31,369,0,64),(31,469,0,25),(31,470,0,64),(31,471,0,20),(31,509,0,16),(31,510,0,2),(31,529,0,0),(31,530,0,6),(31,549,0,4),(31,550,0,4),(31,551,0,4),(31,569,0,4),(31,570,0,4),(31,571,0,4),(31,574,0,4),(31,576,0,2),(31,577,0,64),(31,589,0,0),(31,609,0,0),(31,729,0,2),(31,730,0,16),(31,749,0,0),(31,809,0,16),(31,889,0,6),(31,890,0,16),(31,891,0,24),(31,892,0,14),(31,909,0,16),(31,910,0,2),(31,911,0,6),(31,922,0,6),(31,930,137,17),(31,932,0,80),(31,933,0,16),(31,934,0,80),(31,935,0,16),(31,936,0,28),(31,941,0,6),(31,942,0,16),(31,946,0,16),(31,947,0,2),(31,948,0,8),(31,949,0,24),(31,952,0,0),(31,967,0,16),(31,970,0,0),(31,978,0,16),(31,980,0,0),(31,989,0,16),(31,990,0,16),(31,1005,0,4),(31,1011,0,16),(31,1012,0,16),(31,1015,0,2),(31,1031,0,16),(31,1037,275,137),(31,1038,0,16),(31,1050,550,17),(31,1052,0,2),(31,1064,0,6),(31,1067,0,2),(31,1068,275,17),(31,1073,0,16),(31,1077,0,16),(31,1082,0,4),(31,1085,0,6),(31,1090,0,16),(31,1091,0,16),(31,1094,275,17),(31,1097,0,0),(31,1098,0,16),(31,1104,0,16),(31,1105,0,16),(31,1106,0,16),(31,1117,0,12),(31,1118,0,12),(31,1119,0,2),(31,1124,0,6),(31,1126,275,17),(31,1136,0,4),(31,1137,0,4),(31,1154,0,4),(31,1155,0,4),(31,1156,0,16),(32,21,0,64),(32,46,0,4),(32,47,0,17),(32,54,0,17),(32,59,0,16),(32,67,0,14),(32,68,0,6),(32,69,0,17),(32,70,0,2),(32,72,0,17),(32,76,0,6),(32,81,0,6),(32,83,0,4),(32,86,0,4),(32,87,0,2),(32,92,0,2),(32,93,0,2),(32,169,0,12),(32,270,0,16),(32,289,0,4),(32,349,0,0),(32,369,0,64),(32,469,0,25),(32,470,0,64),(32,471,0,20),(32,509,0,16),(32,510,0,2),(32,529,0,0),(32,530,0,6),(32,549,0,4),(32,550,0,4),(32,551,0,4),(32,569,0,4),(32,570,0,4),(32,571,0,4),(32,574,0,4),(32,576,0,2),(32,577,0,64),(32,589,0,0),(32,609,0,0),(32,729,0,2),(32,730,0,16),(32,749,0,0),(32,809,0,16),(32,889,0,6),(32,890,0,16),(32,891,0,24),(32,892,0,14),(32,909,0,16),(32,910,0,2),(32,911,0,6),(32,922,0,6),(32,930,0,17),(32,932,0,80),(32,933,0,16),(32,934,0,80),(32,935,0,16),(32,936,0,28),(32,941,0,6),(32,942,0,16),(32,946,432,17),(32,947,0,2),(32,948,0,8),(32,949,0,24),(32,952,0,0),(32,967,0,16),(32,970,0,0),(32,978,0,16),(32,980,0,0),(32,989,0,16),(32,990,0,16),(32,1005,0,4),(32,1011,675,17),(32,1012,0,16),(32,1015,0,2),(32,1031,0,17),(32,1037,0,136),(32,1038,0,16),(32,1050,0,16),(32,1052,0,2),(32,1064,0,6),(32,1067,0,2),(32,1068,0,16),(32,1073,0,16),(32,1077,0,16),(32,1082,0,4),(32,1085,0,6),(32,1090,0,17),(32,1091,0,16),(32,1094,0,16),(32,1097,0,0),(32,1098,0,16),(32,1104,0,16),(32,1105,0,16),(32,1106,0,16),(32,1117,0,12),(32,1118,0,12),(32,1119,0,2),(32,1124,0,6),(32,1126,0,16),(32,1136,0,4),(32,1137,0,4),(32,1154,0,4),(32,1155,0,4),(32,1156,0,16),(33,21,0,64),(33,46,0,4),(33,47,0,17),(33,54,0,17),(33,59,0,16),(33,67,0,14),(33,68,0,6),(33,69,0,17),(33,70,0,2),(33,72,0,17),(33,76,0,6),(33,81,0,6),(33,83,0,4),(33,86,0,4),(33,87,0,2),(33,92,0,2),(33,93,0,2),(33,169,0,12),(33,270,0,16),(33,289,0,4),(33,349,0,0),(33,369,0,64),(33,469,0,25),(33,470,0,64),(33,471,0,20),(33,509,0,16),(33,510,0,2),(33,529,0,0),(33,530,0,6),(33,549,0,4),(33,550,0,4),(33,551,0,4),(33,569,0,4),(33,570,0,4),(33,571,0,4),(33,574,0,4),(33,576,0,2),(33,577,0,64),(33,589,0,0),(33,609,0,0),(33,729,0,2),(33,730,0,16),(33,749,0,0),(33,809,0,16),(33,889,0,6),(33,890,0,16),(33,891,0,24),(33,892,0,14),(33,909,0,16),(33,910,0,2),(33,911,0,6),(33,922,0,6),(33,930,0,17),(33,932,0,80),(33,933,0,16),(33,934,0,80),(33,935,0,16),(33,936,0,28),(33,941,0,6),(33,942,0,16),(33,946,0,16),(33,947,0,2),(33,948,0,8),(33,949,0,24),(33,952,0,0),(33,967,0,16),(33,970,0,0),(33,978,0,16),(33,980,0,0),(33,989,0,16),(33,990,0,16),(33,1005,0,4),(33,1011,0,16),(33,1012,0,16),(33,1015,0,2),(33,1031,0,16),(33,1037,0,136),(33,1038,0,16),(33,1050,0,16),(33,1052,0,2),(33,1064,0,6),(33,1067,0,2),(33,1068,0,16),(33,1073,0,16),(33,1077,0,16),(33,1082,0,4),(33,1085,0,6),(33,1090,0,16),(33,1091,0,16),(33,1094,0,16),(33,1097,0,0),(33,1098,0,16),(33,1104,0,16),(33,1105,0,16),(33,1106,0,16),(33,1117,0,12),(33,1118,0,12),(33,1119,0,2),(33,1124,0,6),(33,1126,0,16),(33,1136,0,4),(33,1137,0,4),(33,1154,0,4),(33,1155,0,4),(33,1156,0,16),(35,21,0,64),(35,46,0,4),(35,47,0,17),(35,54,0,17),(35,59,0,16),(35,67,0,14),(35,68,0,6),(35,69,0,17),(35,70,0,2),(35,72,0,17),(35,76,0,6),(35,81,0,6),(35,83,0,4),(35,86,0,4),(35,87,0,2),(35,92,0,2),(35,93,0,2),(35,169,0,12),(35,270,0,16),(35,289,0,4),(35,349,0,0),(35,369,0,64),(35,469,0,25),(35,470,0,64),(35,471,0,20),(35,509,0,16),(35,510,0,2),(35,529,0,0),(35,530,0,6),(35,549,0,4),(35,550,0,4),(35,551,0,4),(35,569,0,4),(35,570,0,4),(35,571,0,4),(35,574,0,4),(35,576,0,2),(35,577,0,64),(35,589,0,0),(35,609,0,0),(35,729,0,2),(35,730,0,16),(35,749,0,0),(35,809,0,16),(35,889,0,6),(35,890,0,16),(35,891,0,24),(35,892,0,14),(35,909,0,16),(35,910,0,2),(35,911,0,6),(35,922,0,6),(35,930,0,17),(35,932,0,80),(35,933,0,16),(35,934,0,80),(35,935,0,16),(35,936,0,28),(35,941,0,6),(35,942,0,16),(35,946,0,16),(35,947,0,2),(35,948,0,8),(35,949,0,24),(35,952,0,0),(35,967,0,16),(35,970,0,0),(35,978,0,16),(35,980,0,0),(35,989,0,16),(35,990,0,16),(35,1005,0,4),(35,1011,0,16),(35,1012,0,16),(35,1015,0,2),(35,1031,0,16),(35,1037,0,136),(35,1038,0,16),(35,1050,0,16),(35,1052,0,2),(35,1064,0,6),(35,1067,0,2),(35,1068,0,16),(35,1073,0,16),(35,1077,0,16),(35,1082,0,4),(35,1085,0,6),(35,1090,0,16),(35,1091,0,16),(35,1094,0,16),(35,1097,0,0),(35,1098,0,16),(35,1104,0,16),(35,1105,0,16),(35,1106,0,16),(35,1117,0,12),(35,1118,0,12),(35,1119,0,2),(35,1124,0,6),(35,1126,0,16),(35,1136,0,4),(35,1137,0,4),(35,1154,0,4),(35,1155,0,4),(35,1156,0,16),(36,21,0,64),(36,46,0,4),(36,47,0,17),(36,54,0,17),(36,59,0,16),(36,67,0,14),(36,68,0,6),(36,69,0,17),(36,70,0,2),(36,72,0,17),(36,76,0,6),(36,81,0,6),(36,83,0,4),(36,86,0,4),(36,87,0,2),(36,92,0,2),(36,93,0,2),(36,169,0,12),(36,270,0,16),(36,289,0,4),(36,349,0,0),(36,369,0,64),(36,469,0,25),(36,470,0,64),(36,471,0,4),(36,509,0,16),(36,510,0,2),(36,529,0,0),(36,530,0,6),(36,549,0,4),(36,550,0,4),(36,551,0,4),(36,569,0,4),(36,570,0,4),(36,571,0,4),(36,574,0,4),(36,576,0,2),(36,577,0,64),(36,589,0,0),(36,609,0,0),(36,729,0,2),(36,730,0,16),(36,749,0,0),(36,809,0,16),(36,889,0,6),(36,890,0,16),(36,891,0,24),(36,892,0,14),(36,909,0,16),(36,910,0,2),(36,911,0,6),(36,922,0,6),(36,930,0,17),(36,932,0,80),(36,933,0,16),(36,934,0,80),(36,935,0,16),(36,936,0,28),(36,941,0,6),(36,942,0,16),(36,946,0,16),(36,947,0,2),(36,948,0,8),(36,949,0,24),(36,952,0,0),(36,967,0,16),(36,970,0,0),(36,978,0,16),(36,980,0,0),(36,989,0,16),(36,990,0,16),(36,1005,0,4),(36,1011,0,16),(36,1012,0,16),(36,1015,0,2),(36,1031,0,16),(36,1037,0,136),(36,1038,0,16),(36,1050,0,16),(36,1052,0,2),(36,1064,0,6),(36,1067,0,2),(36,1068,0,16),(36,1073,0,16),(36,1077,0,16),(36,1082,0,4),(36,1085,0,6),(36,1090,0,16),(36,1091,0,16),(36,1094,0,16),(36,1097,0,0),(36,1098,0,16),(36,1104,0,16),(36,1105,0,16),(36,1106,0,16),(36,1117,0,12),(36,1118,0,12),(36,1119,0,2),(36,1124,0,6),(36,1126,0,16),(36,1136,0,4),(36,1137,0,4),(36,1154,0,4),(36,1155,0,4),(36,1156,0,16),(37,21,0,64),(37,46,0,4),(37,47,0,17),(37,54,0,17),(37,59,0,16),(37,67,0,14),(37,68,0,6),(37,69,0,17),(37,70,0,2),(37,72,0,17),(37,76,0,6),(37,81,0,6),(37,83,0,4),(37,86,0,4),(37,87,0,2),(37,92,0,2),(37,93,0,2),(37,169,0,12),(37,270,0,16),(37,289,0,4),(37,349,0,0),(37,369,0,64),(37,469,0,25),(37,470,0,64),(37,471,0,20),(37,509,0,16),(37,510,0,2),(37,529,0,0),(37,530,0,6),(37,549,0,4),(37,550,0,4),(37,551,0,4),(37,569,0,4),(37,570,0,4),(37,571,0,4),(37,574,0,4),(37,576,0,2),(37,577,0,64),(37,589,0,0),(37,609,0,0),(37,729,0,2),(37,730,0,16),(37,749,0,0),(37,809,0,16),(37,889,0,6),(37,890,0,16),(37,891,0,24),(37,892,0,14),(37,909,0,16),(37,910,0,2),(37,911,0,6),(37,922,0,6),(37,930,0,17),(37,932,0,80),(37,933,0,16),(37,934,0,80),(37,935,0,16),(37,936,0,28),(37,941,0,6),(37,942,0,16),(37,946,0,16),(37,947,0,2),(37,948,0,8),(37,949,0,24),(37,952,0,0),(37,967,0,16),(37,970,0,0),(37,978,0,16),(37,980,0,0),(37,989,0,16),(37,990,0,16),(37,1005,0,4),(37,1011,0,16),(37,1012,0,16),(37,1015,0,2),(37,1031,0,16),(37,1037,0,136),(37,1038,0,16),(37,1050,0,16),(37,1052,0,2),(37,1064,0,6),(37,1067,0,2),(37,1068,0,16),(37,1073,0,16),(37,1077,0,16),(37,1082,0,4),(37,1085,0,6),(37,1090,0,16),(37,1091,0,16),(37,1094,0,16),(37,1097,0,0),(37,1098,0,16),(37,1104,0,16),(37,1105,0,16),(37,1106,0,16),(37,1117,0,12),(37,1118,0,12),(37,1119,0,2),(37,1124,0,6),(37,1126,0,16),(37,1136,0,4),(37,1137,0,4),(37,1154,0,4),(37,1155,0,4),(37,1156,0,16),(38,21,0,64),(38,46,0,4),(38,47,0,17),(38,54,0,17),(38,59,0,16),(38,67,0,14),(38,68,0,6),(38,69,0,17),(38,70,0,2),(38,72,0,17),(38,76,0,6),(38,81,0,6),(38,83,0,4),(38,86,0,4),(38,87,0,2),(38,92,0,2),(38,93,0,2),(38,169,0,12),(38,270,0,16),(38,289,0,4),(38,349,0,0),(38,369,0,64),(38,469,0,25),(38,470,0,64),(38,471,0,20),(38,509,0,16),(38,510,0,2),(38,529,0,0),(38,530,0,6),(38,549,0,4),(38,550,0,4),(38,551,0,4),(38,569,0,4),(38,570,0,4),(38,571,0,4),(38,574,0,4),(38,576,0,2),(38,577,0,64),(38,589,0,0),(38,609,0,0),(38,729,0,2),(38,730,0,16),(38,749,0,0),(38,809,0,16),(38,889,0,6),(38,890,0,16),(38,891,0,24),(38,892,0,14),(38,909,0,16),(38,910,0,0),(38,911,0,6),(38,922,0,6),(38,930,0,17),(38,932,0,80),(38,933,0,16),(38,934,0,80),(38,935,0,16),(38,936,0,28),(38,941,0,6),(38,942,0,16),(38,946,0,16),(38,947,0,0),(38,948,0,8),(38,949,0,24),(38,952,0,0),(38,967,0,16),(38,970,0,0),(38,978,0,16),(38,980,0,0),(38,989,0,16),(38,990,0,16),(38,1005,0,4),(38,1011,0,16),(38,1012,0,16),(38,1015,0,2),(38,1031,0,16),(38,1037,0,136),(38,1038,0,16),(38,1050,0,16),(38,1052,0,0),(38,1064,0,6),(38,1067,0,0),(38,1068,0,16),(38,1073,0,16),(38,1077,0,16),(38,1082,0,4),(38,1085,0,6),(38,1090,0,16),(38,1091,0,16),(38,1094,0,16),(38,1097,0,0),(38,1098,0,16),(38,1104,0,16),(38,1105,0,16),(38,1106,0,16),(38,1117,0,12),(38,1118,0,12),(38,1119,0,0),(38,1124,0,6),(38,1126,0,16),(38,1136,0,4),(38,1137,0,4),(38,1154,0,4),(38,1155,0,4),(38,1156,0,16),(39,21,0,64),(39,46,0,4),(39,47,137,17),(39,54,137,17),(39,59,0,16),(39,67,0,14),(39,68,0,6),(39,69,137,17),(39,70,0,2),(39,72,550,17),(39,76,0,6),(39,81,0,6),(39,83,0,4),(39,86,0,4),(39,87,0,2),(39,92,0,2),(39,93,0,2),(39,169,0,12),(39,270,0,16),(39,289,0,4),(39,349,0,0),(39,369,0,64),(39,469,0,25),(39,470,0,64),(39,471,0,20),(39,509,0,16),(39,510,0,2),(39,529,0,0),(39,530,0,6),(39,549,0,4),(39,550,0,4),(39,551,0,4),(39,569,0,4),(39,570,0,4),(39,571,0,4),(39,574,0,4),(39,576,0,2),(39,577,0,64),(39,589,0,0),(39,609,0,0),(39,729,0,2),(39,730,0,16),(39,749,0,0),(39,809,0,16),(39,889,0,6),(39,890,0,16),(39,891,0,24),(39,892,0,14),(39,909,0,16),(39,910,0,2),(39,911,0,6),(39,922,0,6),(39,930,137,17),(39,932,0,80),(39,933,0,16),(39,934,0,80),(39,935,0,16),(39,936,0,28),(39,941,0,6),(39,942,0,16),(39,946,0,16),(39,947,0,2),(39,948,0,8),(39,949,0,24),(39,952,0,0),(39,967,0,16),(39,970,0,0),(39,978,0,16),(39,980,0,0),(39,989,0,16),(39,990,0,16),(39,1005,0,4),(39,1011,0,16),(39,1012,0,16),(39,1015,0,2),(39,1031,0,16),(39,1037,275,137),(39,1038,0,16),(39,1050,550,17),(39,1052,0,2),(39,1064,0,6),(39,1067,0,2),(39,1068,275,17),(39,1073,0,16),(39,1077,0,16),(39,1082,0,4),(39,1085,0,6),(39,1090,0,16),(39,1091,0,16),(39,1094,275,17),(39,1097,0,0),(39,1098,0,16),(39,1104,0,16),(39,1105,0,16),(39,1106,0,16),(39,1117,0,12),(39,1118,0,12),(39,1119,0,2),(39,1124,0,6),(39,1126,275,17),(39,1136,0,4),(39,1137,0,4),(39,1154,0,4),(39,1155,0,4),(39,1156,0,16),(40,21,0,64),(40,46,0,4),(40,47,0,17),(40,54,0,17),(40,59,0,16),(40,67,0,14),(40,68,0,6),(40,69,0,17),(40,70,0,2),(40,72,0,17),(40,76,0,6),(40,81,0,6),(40,83,0,4),(40,86,0,4),(40,87,0,2),(40,92,0,2),(40,93,0,2),(40,169,0,12),(40,270,0,16),(40,289,0,4),(40,349,0,0),(40,369,0,64),(40,469,0,25),(40,470,0,64),(40,471,0,20),(40,509,0,16),(40,510,0,2),(40,529,0,0),(40,530,0,6),(40,549,0,4),(40,550,0,4),(40,551,0,4),(40,569,0,4),(40,570,0,4),(40,571,0,4),(40,574,0,4),(40,576,0,2),(40,577,0,64),(40,589,0,0),(40,609,0,0),(40,729,0,2),(40,730,0,16),(40,749,0,0),(40,809,0,16),(40,889,0,6),(40,890,0,16),(40,891,0,24),(40,892,0,14),(40,909,0,16),(40,910,0,0),(40,911,0,6),(40,922,0,6),(40,930,0,17),(40,932,0,80),(40,933,0,16),(40,934,0,80),(40,935,0,16),(40,936,0,28),(40,941,0,6),(40,942,0,16),(40,946,0,16),(40,947,0,0),(40,948,0,8),(40,949,0,24),(40,952,0,0),(40,967,0,16),(40,970,0,0),(40,978,0,16),(40,980,0,0),(40,989,0,16),(40,990,0,16),(40,1005,0,4),(40,1011,0,16),(40,1012,0,16),(40,1015,0,2),(40,1031,0,16),(40,1037,0,136),(40,1038,0,16),(40,1050,0,16),(40,1052,0,0),(40,1064,0,6),(40,1067,0,0),(40,1068,0,16),(40,1073,0,16),(40,1077,0,16),(40,1082,0,4),(40,1085,0,6),(40,1090,0,16),(40,1091,0,16),(40,1094,0,16),(40,1097,0,0),(40,1098,0,16),(40,1104,0,16),(40,1105,0,16),(40,1106,0,16),(40,1117,0,12),(40,1118,0,12),(40,1119,0,0),(40,1124,0,6),(40,1126,0,16),(40,1136,0,4),(40,1137,0,4),(40,1154,0,4),(40,1155,0,4),(40,1156,0,16),(41,21,0,64),(41,46,0,4),(41,47,0,17),(41,54,0,17),(41,59,0,16),(41,67,0,14),(41,68,0,6),(41,69,0,17),(41,70,0,2),(41,72,0,17),(41,76,0,6),(41,81,0,6),(41,83,0,4),(41,86,0,4),(41,87,0,2),(41,92,0,2),(41,93,0,2),(41,169,0,12),(41,270,0,16),(41,289,0,4),(41,349,0,0),(41,369,0,64),(41,469,0,25),(41,470,0,64),(41,471,0,20),(41,509,0,16),(41,510,0,2),(41,529,0,0),(41,530,0,6),(41,549,0,4),(41,550,0,4),(41,551,0,4),(41,569,0,4),(41,570,0,4),(41,571,0,4),(41,574,0,4),(41,576,0,2),(41,577,0,64),(41,589,0,0),(41,609,0,0),(41,729,0,2),(41,730,0,16),(41,749,0,0),(41,809,0,16),(41,889,0,6),(41,890,0,16),(41,891,0,24),(41,892,0,14),(41,909,0,16),(41,910,0,2),(41,911,0,6),(41,922,0,6),(41,930,0,17),(41,932,0,80),(41,933,0,16),(41,934,0,80),(41,935,0,16),(41,936,0,28),(41,941,0,6),(41,942,0,16),(41,946,0,16),(41,947,0,2),(41,948,0,8),(41,949,0,24),(41,952,0,0),(41,967,0,16),(41,970,0,0),(41,978,0,16),(41,980,0,0),(41,989,0,16),(41,990,0,16),(41,1005,0,4),(41,1011,0,16),(41,1012,0,16),(41,1015,0,2),(41,1031,0,16),(41,1037,0,136),(41,1038,0,16),(41,1050,0,16),(41,1052,0,2),(41,1064,0,6),(41,1067,0,2),(41,1068,0,16),(41,1073,0,16),(41,1077,0,16),(41,1082,0,4),(41,1085,0,6),(41,1090,0,16),(41,1091,0,16),(41,1094,0,16),(41,1097,0,0),(41,1098,0,16),(41,1104,0,16),(41,1105,0,16),(41,1106,0,16),(41,1117,0,12),(41,1118,0,12),(41,1119,0,2),(41,1124,0,6),(41,1126,0,16),(41,1136,0,4),(41,1137,0,4),(41,1154,0,4),(41,1155,0,4),(41,1156,0,16),(42,21,0,64),(42,46,0,4),(42,47,0,17),(42,54,0,17),(42,59,0,16),(42,67,0,14),(42,68,0,6),(42,69,0,17),(42,70,0,2),(42,72,0,17),(42,76,0,6),(42,81,0,6),(42,83,0,4),(42,86,0,4),(42,87,0,2),(42,92,0,2),(42,93,0,2),(42,169,0,12),(42,270,0,16),(42,289,0,4),(42,349,0,0),(42,369,0,64),(42,469,0,25),(42,470,0,64),(42,471,0,20),(42,509,0,16),(42,510,0,2),(42,529,0,0),(42,530,0,6),(42,549,0,4),(42,550,0,4),(42,551,0,4),(42,569,0,4),(42,570,0,4),(42,571,0,4),(42,574,0,4),(42,576,0,2),(42,577,0,64),(42,589,0,0),(42,609,0,0),(42,729,0,2),(42,730,0,16),(42,749,0,0),(42,809,0,16),(42,889,0,6),(42,890,0,16),(42,891,0,24),(42,892,0,14),(42,909,0,16),(42,910,0,2),(42,911,0,6),(42,922,0,6),(42,930,0,17),(42,932,0,80),(42,933,0,16),(42,934,0,80),(42,935,0,16),(42,936,0,28),(42,941,0,6),(42,942,0,16),(42,946,0,16),(42,947,0,2),(42,948,0,8),(42,949,0,24),(42,952,0,0),(42,967,0,16),(42,970,0,0),(42,978,0,16),(42,980,0,0),(42,989,0,16),(42,990,0,16),(42,1005,0,4),(42,1011,0,16),(42,1012,0,16),(42,1015,0,2),(42,1031,0,16),(42,1037,0,136),(42,1038,0,16),(42,1050,0,16),(42,1052,0,2),(42,1064,0,6),(42,1067,0,2),(42,1068,0,16),(42,1073,0,16),(42,1077,0,16),(42,1082,0,4),(42,1085,0,6),(42,1090,0,16),(42,1091,0,16),(42,1094,0,16),(42,1097,0,0),(42,1098,0,16),(42,1104,0,16),(42,1105,0,16),(42,1106,0,16),(42,1117,0,12),(42,1118,0,12),(42,1119,0,2),(42,1124,0,6),(42,1126,0,16),(42,1136,0,4),(42,1137,0,4),(42,1154,0,4),(42,1155,0,4),(42,1156,0,16);
/*!40000 ALTER TABLE `character_reputation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_skills`
--

DROP TABLE IF EXISTS `character_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_skills` (
  `guid` int(10) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` smallint(5) unsigned NOT NULL,
  `value` smallint(5) unsigned NOT NULL,
  `max` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_skills`
--

LOCK TABLES `character_skills` WRITE;
/*!40000 ALTER TABLE `character_skills` DISABLE KEYS */;
INSERT INTO `character_skills` VALUES (2,43,405,405),(2,54,405,405),(2,55,405,405),(2,95,405,405),(2,109,300,300),(2,137,300,300),(2,162,405,405),(2,183,405,405),(2,184,405,405),(2,229,405,405),(2,267,405,405),(2,293,1,1),(2,413,1,1),(2,414,1,1),(2,415,1,1),(2,433,1,1),(2,594,405,405),(2,756,405,405),(2,762,75,75),(2,777,405,405),(2,778,405,405),(3,43,500,500),(3,54,500,500),(3,55,500,500),(3,95,500,500),(3,98,300,300),(3,160,500,500),(3,162,500,500),(3,183,500,500),(3,184,500,500),(3,267,500,500),(3,293,1,1),(3,413,1,1),(3,414,1,1),(3,415,1,1),(3,433,1,1),(3,594,500,500),(3,754,500,500),(3,762,75,75),(3,777,500,500),(3,778,500,500),(4,54,500,500),(4,56,500,500),(4,78,500,500),(4,95,500,500),(4,98,300,300),(4,136,500,500),(4,162,500,500),(4,173,500,500),(4,183,500,500),(4,228,500,500),(4,415,1,1),(4,613,500,500),(4,754,500,500),(4,762,150,150),(4,777,500,500),(4,778,500,500),(5,43,775,775),(5,44,775,775),(5,55,775,775),(5,95,775,775),(5,98,300,300),(5,118,775,775),(5,129,270,300),(5,162,775,775),(5,172,775,775),(5,183,775,775),(5,229,775,775),(5,293,1,1),(5,413,1,1),(5,414,1,1),(5,415,1,1),(5,754,775,775),(5,770,775,775),(5,771,775,775),(5,772,775,775),(5,777,775,775),(5,778,775,775),(7,54,1,500),(7,56,5,500),(7,78,5,500),(7,95,1,500),(7,98,300,300),(7,113,300,300),(7,126,5,500),(7,136,1,500),(7,162,1,500),(7,183,5,500),(7,228,1,500),(7,415,1,1),(7,613,5,500),(7,777,1,500),(7,778,1,500),(13,43,1,400),(13,44,1,400),(13,45,1,400),(13,50,400,400),(13,51,400,400),(13,95,1,400),(13,109,300,300),(13,125,400,400),(13,162,1,400),(13,163,400,400),(13,172,1,400),(13,173,1,400),(13,183,400,400),(13,414,1,1),(13,415,1,1),(13,777,1,400),(13,778,1,400),(14,26,400,400),(14,43,1,400),(14,44,1,400),(14,54,1,400),(14,55,1,400),(14,95,1,400),(14,98,300,300),(14,113,300,300),(14,126,400,400),(14,162,1,400),(14,172,1,400),(14,173,1,400),(14,183,400,400),(14,256,400,400),(14,257,400,400),(14,413,1,1),(14,414,1,1),(14,415,1,1),(14,433,1,1),(14,777,1,400),(14,778,1,400),(15,26,400,400),(15,43,400,400),(15,44,400,400),(15,54,400,400),(15,55,400,400),(15,95,400,400),(15,98,300,300),(15,118,400,400),(15,136,400,400),(15,160,400,400),(15,162,400,400),(15,172,400,400),(15,173,400,400),(15,183,400,400),(15,226,400,400),(15,229,400,400),(15,256,400,400),(15,257,400,400),(15,293,1,1),(15,413,1,1),(15,414,1,1),(15,415,1,1),(15,433,1,1),(15,754,400,400),(15,762,150,150),(15,777,400,400),(15,778,400,400),(16,26,400,400),(16,43,400,400),(16,44,400,400),(16,54,400,400),(16,55,400,400),(16,95,400,400),(16,98,300,300),(16,118,400,400),(16,136,400,400),(16,160,400,400),(16,162,400,400),(16,172,400,400),(16,173,400,400),(16,183,400,400),(16,226,400,400),(16,229,400,400),(16,256,400,400),(16,257,400,400),(16,293,1,1),(16,413,1,1),(16,414,1,1),(16,415,1,1),(16,433,1,1),(16,754,400,400),(16,762,300,300),(16,777,400,400),(16,778,400,400),(21,26,400,400),(21,43,400,400),(21,44,400,400),(21,54,400,400),(21,55,400,400),(21,95,400,400),(21,98,300,300),(21,136,400,400),(21,160,400,400),(21,162,400,400),(21,172,400,400),(21,173,400,400),(21,183,400,400),(21,226,400,400),(21,229,400,400),(21,256,400,400),(21,257,400,400),(21,413,1,1),(21,414,1,1),(21,415,1,1),(21,433,1,1),(21,754,400,400),(21,762,150,150),(21,777,400,400),(21,778,400,400),(22,26,400,400),(22,43,400,400),(22,44,400,400),(22,54,400,400),(22,55,400,400),(22,95,400,400),(22,98,300,300),(22,118,400,400),(22,160,400,400),(22,162,400,400),(22,172,400,400),(22,173,400,400),(22,183,400,400),(22,256,400,400),(22,257,400,400),(22,293,1,1),(22,413,1,1),(22,414,1,1),(22,415,1,1),(22,433,1,1),(22,754,400,400),(22,762,150,150),(22,777,400,400),(22,778,400,400),(24,26,400,400),(24,43,400,400),(24,44,400,400),(24,45,400,400),(24,54,400,400),(24,55,400,400),(24,95,400,400),(24,98,300,300),(24,118,400,400),(24,129,1,75),(24,160,400,400),(24,162,400,400),(24,172,400,400),(24,173,400,400),(24,183,400,400),(24,226,400,400),(24,256,400,400),(24,257,400,400),(24,293,1,1),(24,413,1,1),(24,414,1,1),(24,415,1,1),(24,433,1,1),(24,754,400,400),(24,762,150,150),(24,777,400,400),(24,778,400,400),(25,26,450,450),(25,43,450,450),(25,44,450,450),(25,54,450,450),(25,55,450,450),(25,95,450,450),(25,98,300,300),(25,118,450,450),(25,136,450,450),(25,160,450,450),(25,162,450,450),(25,172,450,450),(25,173,450,450),(25,183,450,450),(25,226,450,450),(25,229,450,450),(25,256,450,450),(25,257,450,450),(25,293,1,1),(25,413,1,1),(25,414,1,1),(25,415,1,1),(25,433,1,1),(25,754,450,450),(25,777,450,450),(25,778,450,450),(26,26,400,400),(26,43,400,400),(26,44,400,400),(26,54,400,400),(26,55,400,400),(26,95,400,400),(26,98,300,300),(26,160,400,400),(26,162,400,400),(26,172,400,400),(26,173,400,400),(26,183,400,400),(26,256,400,400),(26,257,400,400),(26,413,1,1),(26,414,1,1),(26,415,1,1),(26,433,1,1),(26,754,400,400),(26,777,400,400),(26,778,400,400),(27,26,400,400),(27,43,400,400),(27,44,400,400),(27,45,400,400),(27,54,400,400),(27,55,400,400),(27,95,400,400),(27,98,300,300),(27,118,400,400),(27,136,400,400),(27,160,400,400),(27,162,400,400),(27,172,400,400),(27,173,400,400),(27,176,400,400),(27,183,400,400),(27,226,400,400),(27,229,400,400),(27,256,400,400),(27,257,400,400),(27,293,1,1),(27,413,1,1),(27,414,1,1),(27,415,1,1),(27,433,1,1),(27,473,400,400),(27,754,400,400),(27,762,150,150),(27,777,400,400),(27,778,400,400),(28,26,400,400),(28,43,400,400),(28,44,400,400),(28,54,400,400),(28,55,400,400),(28,95,400,400),(28,98,300,300),(28,101,400,400),(28,111,300,300),(28,136,1,400),(28,160,400,400),(28,162,400,400),(28,172,400,400),(28,173,400,400),(28,183,400,400),(28,226,1,400),(28,229,1,400),(28,256,400,400),(28,257,400,400),(28,413,1,1),(28,414,1,1),(28,415,1,1),(28,433,1,1),(28,777,400,400),(28,778,400,400),(29,26,400,400),(29,43,400,400),(29,44,400,400),(29,45,400,400),(29,46,400,400),(29,54,400,400),(29,55,400,400),(29,95,400,400),(29,98,300,300),(29,118,400,400),(29,136,400,400),(29,160,400,400),(29,162,400,400),(29,172,400,400),(29,173,400,400),(29,176,400,400),(29,183,400,400),(29,226,400,400),(29,229,400,400),(29,256,400,400),(29,257,400,400),(29,293,1,1),(29,413,1,1),(29,414,1,1),(29,415,1,1),(29,433,1,1),(29,473,400,400),(29,754,400,400),(29,762,150,150),(29,777,400,400),(29,778,400,400),(30,38,450,450),(30,39,450,450),(30,95,450,450),(30,98,300,300),(30,118,450,450),(30,162,450,450),(30,173,450,450),(30,176,450,450),(30,183,450,450),(30,253,450,450),(30,414,1,1),(30,415,1,1),(30,754,450,450),(30,777,450,450),(30,778,450,450),(31,26,450,450),(31,43,450,450),(31,44,450,450),(31,45,450,450),(31,54,450,450),(31,55,450,450),(31,95,450,450),(31,98,300,300),(31,118,450,450),(31,136,450,450),(31,160,450,450),(31,162,450,450),(31,172,450,450),(31,173,450,450),(31,176,450,450),(31,183,450,450),(31,226,450,450),(31,256,450,450),(31,257,450,450),(31,293,1,1),(31,413,1,1),(31,414,1,1),(31,415,1,1),(31,433,1,1),(31,473,450,450),(31,754,450,450),(31,769,450,450),(31,777,450,450),(31,778,450,450),(32,26,400,400),(32,43,400,400),(32,44,400,400),(32,45,400,400),(32,54,400,400),(32,55,400,400),(32,95,400,400),(32,98,300,300),(32,118,400,400),(32,136,400,400),(32,160,400,400),(32,162,400,400),(32,172,400,400),(32,173,400,400),(32,176,400,400),(32,183,400,400),(32,226,400,400),(32,229,400,400),(32,256,400,400),(32,257,400,400),(32,293,1,1),(32,413,1,1),(32,414,1,1),(32,415,1,1),(32,433,1,1),(32,473,400,400),(32,754,400,400),(32,762,300,300),(32,777,400,400),(32,778,400,400),(33,26,450,450),(33,43,450,450),(33,44,450,450),(33,54,450,450),(33,55,450,450),(33,95,450,450),(33,98,300,300),(33,160,450,450),(33,162,450,450),(33,172,450,450),(33,173,450,450),(33,183,450,450),(33,256,450,450),(33,257,450,450),(33,293,1,1),(33,413,1,1),(33,414,1,1),(33,415,1,1),(33,433,1,1),(33,754,450,450),(33,777,450,450),(33,778,450,450),(35,26,400,400),(35,43,400,400),(35,44,400,400),(35,54,400,400),(35,55,400,400),(35,95,400,400),(35,98,300,300),(35,160,400,400),(35,162,400,400),(35,172,400,400),(35,173,400,400),(35,183,400,400),(35,256,400,400),(35,257,400,400),(35,413,1,1),(35,414,1,1),(35,415,1,1),(35,433,1,1),(35,754,400,400),(35,777,400,400),(35,778,400,400),(36,26,400,400),(36,43,400,400),(36,44,400,400),(36,54,400,400),(36,55,400,400),(36,95,400,400),(36,98,300,300),(36,101,400,400),(36,111,300,300),(36,160,400,400),(36,162,400,400),(36,172,400,400),(36,173,400,400),(36,183,400,400),(36,256,400,400),(36,257,400,400),(36,413,1,1),(36,414,1,1),(36,415,1,1),(36,433,1,1),(36,777,400,400),(36,778,400,400),(37,26,400,400),(37,43,400,400),(37,44,400,400),(37,54,400,400),(37,55,400,400),(37,95,400,400),(37,98,300,300),(37,160,400,400),(37,162,400,400),(37,172,400,400),(37,173,400,400),(37,183,400,400),(37,256,400,400),(37,257,400,400),(37,413,1,1),(37,414,1,1),(37,415,1,1),(37,433,1,1),(37,754,400,400),(37,777,400,400),(37,778,400,400),(38,26,400,400),(38,43,400,400),(38,44,400,400),(38,54,400,400),(38,55,400,400),(38,95,400,400),(38,98,300,300),(38,160,400,400),(38,162,400,400),(38,172,400,400),(38,173,400,400),(38,183,400,400),(38,256,400,400),(38,257,400,400),(38,413,1,1),(38,414,1,1),(38,415,1,1),(38,433,1,1),(38,754,400,400),(38,777,400,400),(38,778,400,400),(39,26,450,450),(39,43,450,450),(39,44,450,450),(39,45,450,450),(39,54,450,450),(39,55,450,450),(39,95,450,450),(39,98,300,300),(39,118,450,450),(39,160,450,450),(39,162,450,450),(39,172,450,450),(39,173,450,450),(39,183,450,450),(39,226,450,450),(39,256,450,450),(39,257,450,450),(39,293,1,1),(39,413,1,1),(39,414,1,1),(39,415,1,1),(39,433,1,1),(39,754,450,450),(39,777,450,450),(39,778,450,450),(40,26,400,400),(40,43,400,400),(40,44,400,400),(40,54,400,400),(40,55,400,400),(40,95,400,400),(40,98,300,300),(40,118,1,1),(40,160,400,400),(40,162,400,400),(40,172,400,400),(40,173,400,400),(40,183,400,400),(40,256,400,400),(40,257,400,400),(40,293,1,1),(40,413,1,1),(40,414,1,1),(40,415,1,1),(40,433,1,1),(40,754,400,400),(40,777,400,400),(40,778,400,400),(41,26,400,400),(41,43,400,400),(41,44,400,400),(41,45,400,400),(41,54,400,400),(41,55,400,400),(41,95,400,400),(41,98,300,300),(41,136,400,400),(41,160,400,400),(41,162,400,400),(41,172,400,400),(41,173,400,400),(41,176,400,400),(41,183,400,400),(41,256,400,400),(41,257,400,400),(41,413,1,1),(41,414,1,1),(41,415,1,1),(41,433,1,1),(41,473,400,400),(41,754,400,400),(41,777,400,400),(41,778,400,400),(42,26,400,400),(42,43,400,400),(42,44,400,400),(42,54,400,400),(42,55,400,400),(42,95,400,400),(42,98,300,300),(42,118,400,400),(42,136,400,400),(42,160,400,400),(42,162,400,400),(42,172,400,400),(42,173,400,400),(42,183,400,400),(42,226,400,400),(42,229,400,400),(42,256,400,400),(42,257,400,400),(42,293,1,1),(42,413,1,1),(42,414,1,1),(42,415,1,1),(42,433,1,1),(42,754,400,400),(42,762,150,150),(42,777,400,400),(42,778,400,400);
/*!40000 ALTER TABLE `character_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_social`
--

DROP TABLE IF EXISTS `character_social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_social` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL DEFAULT '' COMMENT 'Friend Note',
  PRIMARY KEY (`guid`,`friend`,`flags`),
  KEY `friend` (`friend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_social`
--

LOCK TABLES `character_social` WRITE;
/*!40000 ALTER TABLE `character_social` DISABLE KEYS */;
INSERT INTO `character_social` VALUES (3,16,1,''),(3,24,1,''),(15,16,1,''),(15,21,1,''),(15,22,1,''),(15,24,1,''),(16,15,1,''),(16,24,1,''),(16,29,1,''),(27,15,1,''),(27,16,1,''),(27,21,1,''),(27,24,1,''),(27,29,1,''),(27,32,1,''),(31,16,1,''),(31,24,1,''),(31,27,1,''),(31,29,1,''),(32,22,1,''),(32,24,1,''),(32,27,1,'');
/*!40000 ALTER TABLE `character_social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell`
--

DROP TABLE IF EXISTS `character_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell`
--

LOCK TABLES `character_spell` WRITE;
/*!40000 ALTER TABLE `character_spell` DISABLE KEYS */;
INSERT INTO `character_spell` VALUES (2,498,1,0),(2,642,1,0),(2,1038,1,0),(2,1044,1,0),(2,1152,1,0),(2,3127,1,0),(2,4987,1,0),(2,5502,1,0),(2,5924,1,0),(2,6940,1,0),(2,10278,1,0),(2,10308,1,0),(2,10326,1,0),(2,19746,1,0),(2,19752,1,0),(2,20045,1,1),(2,20057,1,1),(2,20064,1,1),(2,20066,1,1),(2,20100,1,1),(2,20105,1,1),(2,20113,1,1),(2,20121,1,1),(2,20135,1,1),(2,20140,1,1),(2,20147,1,1),(2,20154,1,0),(2,20164,1,0),(2,20165,1,0),(2,20166,1,0),(2,20175,1,1),(2,20182,1,1),(2,20184,1,0),(2,20185,1,0),(2,20186,1,0),(2,20187,1,0),(2,20198,1,1),(2,20206,1,0),(2,20215,1,0),(2,20216,1,0),(2,20217,1,0),(2,20235,1,0),(2,20239,1,0),(2,20245,1,0),(2,20256,1,1),(2,20258,1,0),(2,20266,1,1),(2,20271,1,0),(2,20330,1,0),(2,20337,1,1),(2,20360,1,0),(2,20375,1,1),(2,20425,1,0),(2,20467,1,0),(2,20470,1,1),(2,20488,1,1),(2,20911,1,1),(2,25780,1,0),(2,25781,1,0),(2,25836,1,1),(2,25898,1,0),(2,25899,1,1),(2,25957,1,1),(2,25988,1,1),(2,25997,1,0),(2,26016,1,1),(2,26017,1,0),(2,26023,1,1),(2,31789,1,0),(2,31821,1,1),(2,31823,1,0),(2,31826,1,0),(2,31830,1,0),(2,31836,1,0),(2,31841,1,0),(2,31842,1,0),(2,31849,1,1),(2,31852,1,1),(2,31860,1,1),(2,31868,1,1),(2,31869,1,1),(2,31872,1,1),(2,31878,1,1),(2,31881,1,1),(2,31884,1,0),(2,31898,1,0),(2,32223,1,0),(2,33388,1,0),(2,33776,1,1),(2,34767,1,0),(2,34769,1,0),(2,35395,1,1),(2,35397,1,1),(2,48782,1,0),(2,48785,1,0),(2,48788,1,0),(2,48801,1,0),(2,48806,1,0),(2,48817,1,0),(2,48819,1,0),(2,48821,1,0),(2,48823,1,0),(2,48825,1,0),(2,48827,1,1),(2,48932,1,0),(2,48934,1,0),(2,48936,1,0),(2,48938,1,0),(2,48942,1,0),(2,48943,1,0),(2,48945,1,0),(2,48947,1,0),(2,48952,1,1),(2,53376,1,1),(2,53382,1,1),(2,53385,1,1),(2,53407,1,0),(2,53408,1,0),(2,53488,1,1),(2,53503,1,1),(2,53519,1,1),(2,53530,1,1),(2,53553,1,0),(2,53557,1,0),(2,53563,1,0),(2,53576,1,0),(2,53585,1,1),(2,53592,1,1),(2,53595,1,1),(2,53601,1,0),(2,53648,1,1),(2,53651,1,0),(2,53652,1,0),(2,53653,1,0),(2,53654,1,0),(2,53661,1,0),(2,53696,1,1),(2,53711,1,1),(2,53733,1,0),(2,53736,1,0),(2,53742,1,0),(2,54043,1,0),(2,54154,1,0),(2,54428,1,0),(2,61411,1,0),(2,62124,1,0),(2,63650,1,1),(2,64205,1,1),(2,64891,1,0),(2,66906,1,0),(2,66907,1,0),(3,498,1,0),(3,642,1,0),(3,1038,1,0),(3,1044,1,0),(3,1152,1,0),(3,2800,1,0),(3,3127,1,0),(3,3472,1,0),(3,5502,1,0),(3,5615,1,0),(3,6940,1,0),(3,10278,1,0),(3,10308,1,0),(3,10326,1,0),(3,13819,1,0),(3,19746,1,0),(3,19752,1,0),(3,19852,1,0),(3,19940,1,0),(3,20116,1,0),(3,20164,1,0),(3,20165,1,0),(3,20166,1,0),(3,20217,1,0),(3,20271,1,0),(3,25780,1,0),(3,25898,1,0),(3,31789,1,0),(3,31801,1,0),(3,31884,1,0),(3,32223,1,0),(3,33388,1,0),(3,48806,1,0),(3,48932,1,0),(3,48934,1,0),(3,48942,1,0),(3,48943,1,0),(3,48945,1,0),(3,48947,1,0),(3,53407,1,0),(3,53408,1,0),(3,54043,1,0),(3,61411,1,0),(3,62124,1,0),(4,453,1,0),(4,528,1,0),(4,552,1,0),(4,586,1,0),(4,605,1,0),(4,988,1,0),(4,1706,1,0),(4,2053,1,0),(4,6064,1,0),(4,6346,1,0),(4,8129,1,0),(4,10060,1,0),(4,10890,1,0),(4,10909,1,0),(4,10955,1,0),(4,14751,1,0),(4,14767,1,0),(4,14769,1,0),(4,14771,1,0),(4,14772,1,0),(4,14774,1,0),(4,14777,1,0),(4,14781,1,0),(4,14785,1,0),(4,14791,1,0),(4,15011,1,0),(4,15012,1,0),(4,15014,1,0),(4,15017,1,0),(4,15018,1,0),(4,15031,1,0),(4,15286,1,0),(4,15310,1,0),(4,15311,1,0),(4,15316,1,0),(4,15317,1,0),(4,15320,1,0),(4,15328,1,0),(4,15332,1,0),(4,15336,1,0),(4,15338,1,0),(4,15356,1,0),(4,15363,1,0),(4,15448,1,0),(4,15473,1,0),(4,15487,1,0),(4,17191,1,0),(4,17323,1,0),(4,18535,1,0),(4,18555,1,0),(4,20711,1,0),(4,27790,1,0),(4,27816,1,0),(4,27840,1,0),(4,27904,1,0),(4,32375,1,0),(4,32841,1,0),(4,33110,1,0),(4,33146,1,0),(4,33154,1,0),(4,33162,1,0),(4,33172,1,0),(4,33190,1,0),(4,33193,1,0),(4,33202,1,0),(4,33206,1,0),(4,33215,1,0),(4,33225,1,0),(4,33371,1,0),(4,33391,1,0),(4,33619,1,0),(4,34433,1,0),(4,34754,1,0),(4,34860,1,0),(4,34910,1,0),(4,45244,1,0),(4,47508,1,0),(4,47515,1,0),(4,47517,1,0),(4,47537,1,0),(4,47560,1,0),(4,47567,1,0),(4,47570,1,0),(4,47582,1,0),(4,47585,1,0),(4,47788,1,0),(4,48063,1,0),(4,48066,1,0),(4,48068,1,0),(4,48071,1,0),(4,48072,1,0),(4,48073,1,0),(4,48074,1,0),(4,48076,1,0),(4,48078,1,0),(4,48085,1,0),(4,48087,1,0),(4,48089,1,0),(4,48113,1,0),(4,48120,1,0),(4,48123,1,0),(4,48125,1,0),(4,48127,1,0),(4,48135,1,0),(4,48153,1,0),(4,48156,1,0),(4,48158,1,0),(4,48160,1,0),(4,48161,1,0),(4,48162,1,0),(4,48168,1,0),(4,48169,1,0),(4,48170,1,0),(4,48171,1,0),(4,48173,1,0),(4,48300,1,0),(4,51167,1,0),(4,52800,1,0),(4,52803,1,0),(4,52985,1,0),(4,52988,1,0),(4,53000,1,0),(4,53003,1,0),(4,53007,1,0),(4,53022,1,0),(4,53023,1,0),(4,54844,1,0),(4,56131,1,0),(4,56160,1,0),(4,56161,1,0),(4,56473,1,0),(4,57472,1,0),(4,63506,1,0),(4,63543,1,0),(4,63574,1,0),(4,63627,1,0),(4,63737,1,0),(4,64044,1,0),(4,64129,1,0),(4,64843,1,0),(4,64844,1,0),(4,64901,1,0),(4,64904,1,0),(5,585,1,0),(5,2061,1,0),(5,42650,1,0),(5,45469,1,0),(5,45470,1,0),(5,45524,1,0),(5,45529,1,0),(5,46584,1,0),(5,47476,1,0),(5,47528,1,0),(5,47568,1,0),(5,47632,1,0),(5,47633,1,0),(5,48263,1,0),(5,48265,1,0),(5,48707,1,0),(5,48743,1,0),(5,48778,1,0),(5,48792,1,0),(5,48982,1,0),(5,49005,1,0),(5,49016,1,0),(5,49028,1,0),(5,49039,1,0),(5,49142,1,0),(5,49194,1,0),(5,49203,1,0),(5,49206,1,0),(5,49222,1,0),(5,49393,1,0),(5,49395,1,0),(5,49480,1,0),(5,49483,1,0),(5,49489,1,0),(5,49491,1,0),(5,49497,1,0),(5,49504,1,0),(5,49509,1,0),(5,49530,1,0),(5,49534,1,0),(5,49538,1,0),(5,49543,1,0),(5,49562,1,0),(5,49565,1,0),(5,49568,1,0),(5,49572,1,0),(5,49589,1,0),(5,49599,1,0),(5,49611,1,0),(5,49628,1,0),(5,49632,1,0),(5,49638,1,0),(5,49655,1,0),(5,49657,1,0),(5,49664,1,0),(5,49789,1,0),(5,49791,1,0),(5,49796,1,0),(5,49895,1,0),(5,49909,1,0),(5,49921,1,0),(5,49924,1,0),(5,49930,1,0),(5,49938,1,0),(5,49941,1,0),(5,50029,1,0),(5,50034,1,0),(5,50043,1,0),(5,50111,1,0),(5,50115,1,0),(5,50121,1,0),(5,50130,1,0),(5,50138,1,0),(5,50147,1,0),(5,50150,1,0),(5,50152,1,0),(5,50191,1,0),(5,50371,1,0),(5,50385,1,0),(5,50392,1,0),(5,50536,1,0),(5,50842,1,0),(5,50887,1,0),(5,51052,1,0),(5,51109,1,0),(5,51130,1,0),(5,51161,1,0),(5,51267,1,0),(5,51271,1,0),(5,51328,1,0),(5,51411,1,0),(5,51425,1,0),(5,51456,1,0),(5,51465,1,0),(5,51473,1,0),(5,51746,1,0),(5,51970,1,0),(5,51986,1,0),(5,52143,1,0),(5,52286,1,0),(5,52372,1,0),(5,52373,1,0),(5,52374,1,0),(5,52375,1,0),(5,53138,1,0),(5,54637,1,0),(5,55062,1,0),(5,55108,1,0),(5,55133,1,0),(5,55136,1,0),(5,55226,1,0),(5,55233,1,0),(5,55237,1,0),(5,55262,1,0),(5,55268,1,0),(5,55271,1,0),(5,55610,1,0),(5,55623,1,0),(5,55667,1,0),(5,56222,1,0),(5,56815,1,0),(5,56835,1,0),(5,57532,1,0),(5,57623,1,0),(5,59057,1,0),(5,61158,1,0),(5,61278,1,0),(5,61999,1,0),(5,62904,1,0),(5,62908,1,0),(5,63560,1,0),(5,66192,1,0),(5,66817,1,0),(15,72,1,0),(15,458,1,0),(15,472,1,0),(15,676,1,0),(15,694,1,0),(15,871,1,0),(15,1161,1,0),(15,1680,1,0),(15,1715,1,0),(15,1719,1,0),(15,2565,1,0),(15,2687,1,0),(15,3127,1,0),(15,3411,1,0),(15,5246,1,0),(15,6552,1,0),(15,6648,1,0),(15,7384,1,0),(15,11578,1,0),(15,12678,1,0),(15,16083,1,0),(15,18499,1,0),(15,20230,1,0),(15,20252,1,0),(15,23227,1,0),(15,23228,1,0),(15,23229,1,0),(15,23920,1,0),(15,33391,1,0),(15,34428,1,0),(15,47436,1,0),(15,47437,1,0),(15,47440,1,0),(15,47450,1,0),(15,47465,1,0),(15,47471,1,0),(15,47475,1,0),(15,47488,1,0),(15,47502,1,0),(15,47520,1,0),(15,55694,1,0),(15,57755,1,0),(15,57823,1,0),(15,60114,1,0),(15,61425,1,0),(15,64382,1,0),(16,72,1,0),(16,676,1,0),(16,694,1,0),(16,871,1,0),(16,1161,1,0),(16,1680,1,0),(16,1715,1,0),(16,1719,1,0),(16,2565,1,0),(16,2687,1,0),(16,3127,1,0),(16,3411,1,0),(16,5246,1,0),(16,6552,1,0),(16,7384,1,0),(16,11578,1,0),(16,12678,1,0),(16,18499,1,0),(16,20230,1,0),(16,20252,1,0),(16,23228,1,0),(16,23920,1,0),(16,32235,1,0),(16,32239,1,0),(16,32240,1,0),(16,34091,1,0),(16,34428,1,0),(16,47436,1,0),(16,47437,1,0),(16,47440,1,0),(16,47450,1,0),(16,47465,1,0),(16,47471,1,0),(16,47475,1,0),(16,47488,1,0),(16,47502,1,0),(16,47520,1,0),(16,54197,1,0),(16,55694,1,0),(16,57755,1,0),(16,57823,1,0),(16,61229,1,0),(16,64382,1,0),(21,100,1,0),(21,284,1,0),(21,772,1,0),(21,6343,1,0),(21,16083,1,0),(21,33391,1,0),(22,72,1,0),(22,458,1,0),(22,472,1,0),(22,676,1,0),(22,694,1,0),(22,871,1,0),(22,1161,1,0),(22,1680,1,0),(22,1715,1,0),(22,1719,1,0),(22,2565,1,0),(22,2687,1,0),(22,3127,1,0),(22,3411,1,0),(22,5246,1,0),(22,6552,1,0),(22,6648,1,0),(22,7384,1,0),(22,11578,1,0),(22,12678,1,0),(22,16083,1,0),(22,18499,1,0),(22,20230,1,0),(22,20252,1,0),(22,22723,1,0),(22,23227,1,0),(22,23228,1,0),(22,23229,1,0),(22,23920,1,0),(22,33391,1,0),(22,34428,1,0),(22,47436,1,0),(22,47437,1,0),(22,47440,1,0),(22,47450,1,0),(22,47465,1,0),(22,47471,1,0),(22,47475,1,0),(22,47488,1,0),(22,47502,1,0),(22,47520,1,0),(22,55694,1,0),(22,57755,1,0),(22,57823,1,0),(22,64382,1,0),(24,72,1,0),(24,676,1,0),(24,694,1,0),(24,871,1,0),(24,1161,1,0),(24,1680,1,0),(24,1715,1,0),(24,1719,1,0),(24,2565,1,0),(24,2687,1,0),(24,3127,1,0),(24,3273,1,0),(24,3411,1,0),(24,5246,1,0),(24,6552,1,0),(24,7384,1,0),(24,11578,1,0),(24,12678,1,0),(24,16083,1,0),(24,18499,1,0),(24,20230,1,0),(24,20252,1,0),(24,23227,1,0),(24,23228,1,0),(24,23920,1,0),(24,33391,1,0),(24,34428,1,0),(24,47436,1,0),(24,47437,1,0),(24,47440,1,0),(24,47450,1,0),(24,47465,1,0),(24,47471,1,0),(24,47475,1,0),(24,47488,1,0),(24,47502,1,0),(24,47520,1,0),(24,55694,1,0),(24,57755,1,0),(24,57823,1,0),(24,60114,1,0),(24,61425,1,0),(24,64382,1,0),(25,72,1,0),(25,676,1,0),(25,694,1,0),(25,871,1,0),(25,1161,1,0),(25,1680,1,0),(25,1715,1,0),(25,1719,1,0),(25,2565,1,0),(25,2687,1,0),(25,3127,1,0),(25,3411,1,0),(25,5246,1,0),(25,6552,1,0),(25,7384,1,0),(25,11578,1,0),(25,12678,1,0),(25,18499,1,0),(25,20230,1,0),(25,20252,1,0),(25,23920,1,0),(25,34428,1,0),(25,47436,1,0),(25,47437,1,0),(25,47440,1,0),(25,47450,1,0),(25,47465,1,0),(25,47471,1,0),(25,47475,1,0),(25,47488,1,0),(25,47502,1,0),(25,47520,1,0),(25,55694,1,0),(25,57755,1,0),(25,57823,1,0),(25,64382,1,0),(27,458,1,0),(27,12292,1,0),(27,12658,1,1),(27,12664,1,1),(27,12697,1,1),(27,12856,1,0),(27,12860,1,0),(27,12960,1,1),(27,12974,1,0),(27,13002,1,0),(27,20501,1,0),(27,20503,1,0),(27,23228,1,0),(27,23588,1,0),(27,23881,1,0),(27,29763,1,0),(27,29801,1,0),(27,33391,1,0),(27,46911,1,0),(27,46917,1,0),(27,56924,1,0),(27,56932,1,0),(27,60970,1,0),(27,61222,1,0),(28,12292,1,0),(28,12318,1,0),(28,12323,1,0),(28,12835,1,0),(28,12856,1,0),(28,12879,1,0),(28,12974,1,0),(28,20496,1,0),(28,20501,1,0),(28,20503,1,0),(28,23588,1,0),(28,23881,1,0),(28,29761,1,0),(28,29801,1,0),(28,46911,1,0),(28,46915,1,0),(28,46917,1,0),(28,56924,1,0),(28,56932,1,0),(29,3127,1,0),(29,6648,1,0),(29,23229,1,0),(29,33391,1,0),(31,5,1,0),(31,45,1,0),(31,71,1,0),(31,72,1,0),(31,265,1,0),(31,355,1,0),(31,676,1,0),(31,694,1,0),(31,871,1,0),(31,1161,1,0),(31,1680,1,0),(31,1715,1,0),(31,1719,1,0),(31,1908,1,0),(31,2458,1,0),(31,2565,1,0),(31,2687,1,0),(31,3127,1,0),(31,3411,1,0),(31,5246,1,0),(31,6552,1,0),(31,6560,1,0),(31,7381,1,0),(31,7384,1,0),(31,7386,1,0),(31,7482,1,0),(31,8295,1,0),(31,10073,1,0),(31,11578,1,0),(31,11821,1,0),(31,12292,1,0),(31,12296,1,0),(31,12323,1,0),(31,12328,1,0),(31,12330,1,0),(31,12658,1,0),(31,12664,1,0),(31,12666,1,0),(31,12677,1,0),(31,12678,1,0),(31,12697,1,0),(31,12704,1,0),(31,12712,1,0),(31,12727,1,0),(31,12753,1,0),(31,12764,1,0),(31,12785,1,0),(31,12799,1,0),(31,12803,1,0),(31,12804,1,0),(31,12809,1,0),(31,12811,1,0),(31,12815,1,0),(31,12818,1,0),(31,12835,1,0),(31,12856,1,0),(31,12861,1,0),(31,12867,1,0),(31,12879,1,0),(31,12886,1,0),(31,12958,1,0),(31,12960,1,0),(31,12963,1,0),(31,12970,1,0),(31,12974,1,0),(31,12975,1,0),(31,13002,1,0),(31,13048,1,0),(31,16466,1,0),(31,16492,1,0),(31,16494,1,0),(31,16542,1,0),(31,18209,1,0),(31,18210,1,0),(31,18389,1,0),(31,18499,1,0),(31,19901,1,0),(31,20230,1,0),(31,20252,1,0),(31,20496,1,0),(31,20501,1,0),(31,20503,1,0),(31,20505,1,0),(31,20647,1,0),(31,23588,1,0),(31,23695,1,0),(31,23789,1,0),(31,23880,1,0),(31,23881,1,0),(31,23885,1,0),(31,23920,1,0),(31,25565,1,0),(31,26368,1,0),(31,27254,1,0),(31,27255,1,0),(31,27258,1,0),(31,27261,1,0),(31,29144,1,0),(31,29592,1,0),(31,29594,1,0),(31,29599,1,0),(31,29623,1,0),(31,29724,1,0),(31,29763,1,0),(31,29776,1,0),(31,29792,1,0),(31,29801,1,0),(31,29838,1,0),(31,29842,1,0),(31,29859,1,0),(31,29889,1,0),(31,33153,1,0),(31,34428,1,0),(31,35182,1,0),(31,35449,1,0),(31,35886,1,0),(31,35912,1,0),(31,36356,1,0),(31,38505,1,0),(31,38734,1,0),(31,39258,1,0),(31,45645,1,0),(31,45646,1,0),(31,45647,1,0),(31,45648,1,0),(31,45649,1,0),(31,45650,1,0),(31,45659,1,0),(31,45813,1,0),(31,46855,1,0),(31,46860,1,0),(31,46866,1,0),(31,46911,1,0),(31,46915,1,0),(31,46917,1,0),(31,46924,1,0),(31,46949,1,0),(31,46953,1,0),(31,46968,1,0),(31,47296,1,0),(31,47436,1,0),(31,47437,1,0),(31,47440,1,0),(31,47450,1,0),(31,47465,1,0),(31,47471,1,0),(31,47475,1,0),(31,47486,1,0),(31,47488,1,0),(31,47498,1,0),(31,47502,1,0),(31,47520,1,0),(31,47994,1,0),(31,50687,1,0),(31,50720,1,0),(31,55694,1,0),(31,56614,1,0),(31,56638,1,0),(31,56924,1,0),(31,56932,1,0),(31,57499,1,0),(31,57755,1,0),(31,57823,1,0),(31,58874,1,0),(31,59089,1,0),(31,60970,1,0),(31,61222,1,0),(31,64380,1,0),(31,64382,1,0),(31,64976,1,0),(32,72,1,0),(32,458,1,0),(32,472,1,0),(32,676,1,0),(32,694,1,0),(32,871,1,0),(32,1161,1,0),(32,1680,1,0),(32,1715,1,0),(32,1719,1,0),(32,2565,1,0),(32,2687,1,0),(32,3127,1,0),(32,3411,1,0),(32,5246,1,0),(32,6552,1,0),(32,6648,1,0),(32,7384,1,0),(32,11578,1,0),(32,12292,1,0),(32,12294,1,1),(32,12296,1,1),(32,12323,1,0),(32,12328,1,1),(32,12664,1,0),(32,12666,1,0),(32,12678,1,0),(32,12697,1,1),(32,12700,1,1),(32,12702,1,1),(32,12712,1,1),(32,12750,1,0),(32,12815,1,1),(32,12818,1,0),(32,12853,1,0),(32,12867,1,1),(32,12963,1,1),(32,12974,1,0),(32,13002,1,0),(32,13048,1,0),(32,16466,1,1),(32,16492,1,0),(32,16494,1,1),(32,18499,1,0),(32,20230,1,0),(32,20252,1,0),(32,20496,1,0),(32,20503,1,0),(32,23227,1,0),(32,23228,1,0),(32,23229,1,0),(32,23588,1,0),(32,23881,1,0),(32,23920,1,0),(32,29623,1,1),(32,29725,1,1),(32,29763,1,0),(32,29776,1,0),(32,29838,1,1),(32,29859,1,1),(32,29889,1,0),(32,32235,1,0),(32,32239,1,0),(32,32240,1,0),(32,32242,1,0),(32,32289,1,0),(32,32290,1,0),(32,32292,1,0),(32,34091,1,0),(32,34428,1,0),(32,35449,1,1),(32,46855,1,1),(32,46866,1,1),(32,46915,1,0),(32,46917,1,0),(32,46924,1,1),(32,47436,1,0),(32,47437,1,0),(32,47440,1,0),(32,47450,1,0),(32,47465,1,0),(32,47471,1,0),(32,47475,1,0),(32,47488,1,0),(32,47502,1,0),(32,47520,1,0),(32,50687,1,0),(32,54197,1,0),(32,55694,1,0),(32,56614,1,1),(32,56924,1,0),(32,56932,1,0),(32,57755,1,0),(32,57823,1,0),(32,61222,1,0),(32,64382,1,0),(32,64976,1,1),(32,75134,1,0),(33,23429,1,0),(33,74438,1,0),(33,74562,1,0),(33,74648,1,0),(33,74792,1,0),(33,74836,1,0),(33,75125,1,0),(33,75476,1,0),(39,72,1,0),(39,676,1,0),(39,694,1,0),(39,871,1,0),(39,1161,1,0),(39,1680,1,0),(39,1715,1,0),(39,1719,1,0),(39,2565,1,0),(39,2687,1,0),(39,3127,1,0),(39,3411,1,0),(39,5246,1,0),(39,6552,1,0),(39,7384,1,0),(39,11578,1,0),(39,12678,1,0),(39,18499,1,0),(39,20230,1,0),(39,20252,1,0),(39,23920,1,0),(39,34428,1,0),(39,47436,1,0),(39,47437,1,0),(39,47440,1,0),(39,47450,1,0),(39,47465,1,0),(39,47471,1,0),(39,47475,1,0),(39,47488,1,0),(39,47502,1,0),(39,47520,1,0),(39,55694,1,0),(39,57755,1,0),(39,57823,1,0),(39,64382,1,0),(40,72,1,0),(40,676,1,0),(40,694,1,0),(40,871,1,0),(40,1161,1,0),(40,1680,1,0),(40,1715,1,0),(40,1719,1,0),(40,2565,1,0),(40,2687,1,0),(40,3127,1,0),(40,3411,1,0),(40,5246,1,0),(40,6552,1,0),(40,7384,1,0),(40,11578,1,0),(40,12678,1,0),(40,18499,1,0),(40,20230,1,0),(40,20252,1,0),(40,23920,1,0),(40,34428,1,0),(40,47436,1,0),(40,47437,1,0),(40,47440,1,0),(40,47450,1,0),(40,47465,1,0),(40,47471,1,0),(40,47475,1,0),(40,47488,1,0),(40,47502,1,0),(40,47520,1,0),(40,55694,1,0),(40,57755,1,0),(40,57823,1,0),(40,64382,1,0),(42,72,1,0),(42,458,1,0),(42,472,1,0),(42,676,1,0),(42,694,1,0),(42,871,1,0),(42,1161,1,0),(42,1680,1,0),(42,1715,1,0),(42,1719,1,0),(42,2565,1,0),(42,2687,1,0),(42,3127,1,0),(42,3411,1,0),(42,5246,1,0),(42,6552,1,0),(42,6648,1,0),(42,7384,1,0),(42,11578,1,0),(42,12678,1,0),(42,18499,1,0),(42,20230,1,0),(42,20252,1,0),(42,23227,1,0),(42,23228,1,0),(42,23229,1,0),(42,23920,1,0),(42,33391,1,0),(42,34428,1,0),(42,47436,1,0),(42,47437,1,0),(42,47440,1,0),(42,47450,1,0),(42,47465,1,0),(42,47471,1,0),(42,47475,1,0),(42,47488,1,0),(42,47502,1,0),(42,47520,1,0),(42,55694,1,0),(42,57755,1,0),(42,57823,1,0),(42,64382,1,0);
/*!40000 ALTER TABLE `character_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell_cooldown`
--

DROP TABLE IF EXISTS `character_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell_cooldown`
--

LOCK TABLES `character_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `character_spell_cooldown` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_stats`
--

DROP TABLE IF EXISTS `character_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower1` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower2` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower3` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower4` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower5` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower6` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower7` int(10) unsigned NOT NULL DEFAULT '0',
  `strength` int(10) unsigned NOT NULL DEFAULT '0',
  `agility` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina` int(10) unsigned NOT NULL DEFAULT '0',
  `intellect` int(10) unsigned NOT NULL DEFAULT '0',
  `spirit` int(10) unsigned NOT NULL DEFAULT '0',
  `armor` int(10) unsigned NOT NULL DEFAULT '0',
  `resHoly` int(10) unsigned NOT NULL DEFAULT '0',
  `resFire` int(10) unsigned NOT NULL DEFAULT '0',
  `resNature` int(10) unsigned NOT NULL DEFAULT '0',
  `resFrost` int(10) unsigned NOT NULL DEFAULT '0',
  `resShadow` int(10) unsigned NOT NULL DEFAULT '0',
  `resArcane` int(10) unsigned NOT NULL DEFAULT '0',
  `blockPct` float unsigned NOT NULL DEFAULT '0',
  `dodgePct` float unsigned NOT NULL DEFAULT '0',
  `parryPct` float unsigned NOT NULL DEFAULT '0',
  `critPct` float unsigned NOT NULL DEFAULT '0',
  `rangedCritPct` float unsigned NOT NULL DEFAULT '0',
  `spellCritPct` float unsigned NOT NULL DEFAULT '0',
  `attackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `rangedAttackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `spellPower` int(10) unsigned NOT NULL DEFAULT '0',
  `resilience` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_stats`
--

LOCK TABLES `character_stats` WRITE;
/*!40000 ALTER TABLE `character_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_talent`
--

DROP TABLE IF EXISTS `character_talent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_talent` (
  `guid` int(10) unsigned NOT NULL,
  `spell` mediumint(8) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_talent`
--

LOCK TABLES `character_talent` WRITE;
/*!40000 ALTER TABLE `character_talent` DISABLE KEYS */;
INSERT INTO `character_talent` VALUES (2,5924,0),(2,20045,1),(2,20057,1),(2,20064,1),(2,20066,1),(2,20100,1),(2,20105,1),(2,20113,1),(2,20121,1),(2,20135,1),(2,20140,1),(2,20147,1),(2,20175,1),(2,20182,1),(2,20198,1),(2,20206,0),(2,20208,1),(2,20215,0),(2,20215,1),(2,20216,0),(2,20216,1),(2,20235,0),(2,20235,1),(2,20239,0),(2,20239,1),(2,20245,0),(2,20245,1),(2,20256,1),(2,20258,0),(2,20261,1),(2,20266,1),(2,20330,0),(2,20332,1),(2,20337,1),(2,20360,0),(2,20361,1),(2,20375,1),(2,20470,1),(2,20473,0),(2,20473,1),(2,20488,1),(2,20911,1),(2,20925,1),(2,25829,1),(2,25836,1),(2,25957,1),(2,25988,1),(2,26016,1),(2,26023,1),(2,31821,1),(2,31823,0),(2,31823,1),(2,31826,0),(2,31826,1),(2,31830,0),(2,31830,1),(2,31836,0),(2,31836,1),(2,31841,0),(2,31841,1),(2,31842,0),(2,31842,1),(2,31849,1),(2,31852,1),(2,31860,1),(2,31868,1),(2,31869,1),(2,31872,1),(2,31878,1),(2,31881,1),(2,31935,1),(2,33776,1),(2,35395,1),(2,35397,1),(2,53376,1),(2,53382,1),(2,53385,1),(2,53488,1),(2,53503,1),(2,53519,1),(2,53530,1),(2,53553,0),(2,53553,1),(2,53557,0),(2,53557,1),(2,53563,0),(2,53563,1),(2,53576,0),(2,53576,1),(2,53585,1),(2,53592,1),(2,53595,1),(2,53648,1),(2,53661,0),(2,53661,1),(2,53696,1),(2,53711,1),(2,54154,0),(2,54155,1),(2,63650,1),(2,64205,1),(4,724,0),(4,10060,0),(4,14751,0),(4,14767,0),(4,14769,0),(4,14771,0),(4,14772,0),(4,14774,0),(4,14777,0),(4,14781,0),(4,14785,0),(4,14791,0),(4,15011,0),(4,15012,0),(4,15014,0),(4,15017,0),(4,15018,0),(4,15031,0),(4,15286,0),(4,15310,0),(4,15311,0),(4,15316,0),(4,15317,0),(4,15320,0),(4,15328,0),(4,15332,0),(4,15336,0),(4,15338,0),(4,15356,0),(4,15363,0),(4,15407,0),(4,15448,0),(4,15473,0),(4,15487,0),(4,17191,0),(4,17323,0),(4,18535,0),(4,18555,0),(4,19236,0),(4,20711,0),(4,27790,0),(4,27816,0),(4,27840,0),(4,27904,0),(4,33146,0),(4,33154,0),(4,33162,0),(4,33172,0),(4,33190,0),(4,33193,0),(4,33202,0),(4,33206,0),(4,33215,0),(4,33225,0),(4,33371,0),(4,34860,0),(4,34861,0),(4,34910,0),(4,34914,0),(4,45244,0),(4,47508,0),(4,47515,0),(4,47517,0),(4,47537,0),(4,47540,0),(4,47560,0),(4,47567,0),(4,47570,0),(4,47582,0),(4,47585,0),(4,47788,0),(4,51167,0),(4,52800,0),(4,52803,0),(4,57472,0),(4,63506,0),(4,63543,0),(4,63574,0),(4,63627,0),(4,63737,0),(4,64044,0),(4,64129,0),(5,48982,0),(5,49005,0),(5,49016,0),(5,49028,0),(5,49039,0),(5,49143,0),(5,49158,0),(5,49184,0),(5,49194,0),(5,49203,0),(5,49206,0),(5,49222,0),(5,49393,0),(5,49395,0),(5,49480,0),(5,49483,0),(5,49489,0),(5,49491,0),(5,49497,0),(5,49504,0),(5,49509,0),(5,49530,0),(5,49534,0),(5,49538,0),(5,49543,0),(5,49562,0),(5,49565,0),(5,49568,0),(5,49572,0),(5,49589,0),(5,49599,0),(5,49611,0),(5,49628,0),(5,49632,0),(5,49638,0),(5,49655,0),(5,49657,0),(5,49664,0),(5,49789,0),(5,49791,0),(5,49796,0),(5,50029,0),(5,50034,0),(5,50043,0),(5,50115,0),(5,50121,0),(5,50130,0),(5,50138,0),(5,50147,0),(5,50150,0),(5,50152,0),(5,50191,0),(5,50371,0),(5,50385,0),(5,50392,0),(5,50887,0),(5,51052,0),(5,51109,0),(5,51130,0),(5,51161,0),(5,51267,0),(5,51271,0),(5,51456,0),(5,51465,0),(5,51473,0),(5,51746,0),(5,52143,0),(5,53138,0),(5,54637,0),(5,55050,0),(5,55062,0),(5,55090,0),(5,55108,0),(5,55133,0),(5,55136,0),(5,55226,0),(5,55233,0),(5,55237,0),(5,55610,0),(5,55623,0),(5,55667,0),(5,56835,0),(5,59057,0),(5,61158,0),(5,62908,0),(5,63560,0),(5,66192,0),(5,66817,0),(27,12292,0),(27,12856,0),(27,12860,0),(27,12974,0),(27,13002,0),(27,20501,0),(27,20503,0),(27,23588,0),(27,23881,0),(27,29763,0),(27,29801,0),(27,46911,0),(27,46917,0),(27,56924,0),(27,56932,0),(27,60970,0),(27,61222,0),(28,12292,0),(28,12318,0),(28,12323,0),(28,12835,0),(28,12856,0),(28,12879,0),(28,12974,0),(28,20496,0),(28,20501,0),(28,20503,0),(28,23588,0),(28,23881,0),(28,29761,0),(28,29801,0),(28,46911,0),(28,46915,0),(28,46917,0),(28,56924,0),(28,56932,0),(31,12292,0),(31,12294,0),(31,12296,0),(31,12323,0),(31,12328,0),(31,12330,0),(31,12658,0),(31,12664,0),(31,12666,0),(31,12677,0),(31,12697,0),(31,12704,0),(31,12712,0),(31,12727,0),(31,12753,0),(31,12764,0),(31,12785,0),(31,12799,0),(31,12803,0),(31,12804,0),(31,12809,0),(31,12811,0),(31,12815,0),(31,12818,0),(31,12835,0),(31,12856,0),(31,12861,0),(31,12867,0),(31,12879,0),(31,12958,0),(31,12960,0),(31,12963,0),(31,12974,0),(31,12975,0),(31,13002,0),(31,13048,0),(31,16466,0),(31,16492,0),(31,16494,0),(31,16542,0),(31,20243,0),(31,20496,0),(31,20501,0),(31,20503,0),(31,20505,0),(31,23588,0),(31,23695,0),(31,23881,0),(31,29144,0),(31,29592,0),(31,29594,0),(31,29599,0),(31,29623,0),(31,29724,0),(31,29763,0),(31,29776,0),(31,29792,0),(31,29801,0),(31,29838,0),(31,29859,0),(31,29889,0),(31,35449,0),(31,46855,0),(31,46860,0),(31,46866,0),(31,46911,0),(31,46915,0),(31,46917,0),(31,46924,0),(31,46949,0),(31,46953,0),(31,46968,0),(31,47296,0),(31,50687,0),(31,50720,0),(31,56614,0),(31,56638,0),(31,56924,0),(31,56932,0),(31,57499,0),(31,58874,0),(31,59089,0),(31,60970,0),(31,61222,0),(31,64976,0),(32,12292,1),(32,12294,0),(32,12296,0),(32,12323,1),(32,12328,0),(32,12664,0),(32,12664,1),(32,12666,1),(32,12697,0),(32,12700,0),(32,12702,0),(32,12712,0),(32,12750,1),(32,12815,0),(32,12818,1),(32,12853,1),(32,12867,0),(32,12963,0),(32,12974,1),(32,13002,1),(32,13048,1),(32,16466,0),(32,16492,1),(32,16494,0),(32,20496,1),(32,20503,1),(32,23588,1),(32,23881,1),(32,29623,0),(32,29725,0),(32,29763,1),(32,29776,1),(32,29838,0),(32,29859,0),(32,29889,1),(32,35449,0),(32,46855,0),(32,46866,0),(32,46915,1),(32,46917,1),(32,46924,0),(32,50687,1),(32,56614,0),(32,56924,1),(32,56932,1),(32,61222,1),(32,64976,0);
/*!40000 ALTER TABLE `character_talent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `account` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xp` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `skin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `face` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `facialStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bankSlots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `restState` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `playerFlags` int(10) unsigned NOT NULL DEFAULT '0',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `instance_id` int(10) unsigned NOT NULL DEFAULT '0',
  `instance_mode_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `taximask` text NOT NULL,
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cinematic` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  `leveltime` int(10) unsigned NOT NULL DEFAULT '0',
  `logout_time` int(10) unsigned NOT NULL DEFAULT '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rest_bonus` float NOT NULL DEFAULT '0',
  `resettalents_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` int(10) unsigned NOT NULL DEFAULT '0',
  `trans_x` float NOT NULL DEFAULT '0',
  `trans_y` float NOT NULL DEFAULT '0',
  `trans_z` float NOT NULL DEFAULT '0',
  `trans_o` float NOT NULL DEFAULT '0',
  `transguid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `extra_flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stable_slots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `at_login` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zone` smallint(5) unsigned NOT NULL DEFAULT '0',
  `death_expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `todayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalKills` int(10) unsigned NOT NULL DEFAULT '0',
  `todayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `chosenTitle` int(10) unsigned NOT NULL DEFAULT '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL DEFAULT '0',
  `watchedFaction` int(10) unsigned NOT NULL DEFAULT '0',
  `drunk` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `health` int(10) unsigned NOT NULL DEFAULT '0',
  `power1` int(10) unsigned NOT NULL DEFAULT '0',
  `power2` int(10) unsigned NOT NULL DEFAULT '0',
  `power3` int(10) unsigned NOT NULL DEFAULT '0',
  `power4` int(10) unsigned NOT NULL DEFAULT '0',
  `power5` int(10) unsigned NOT NULL DEFAULT '0',
  `power6` int(10) unsigned NOT NULL DEFAULT '0',
  `power7` int(10) unsigned NOT NULL DEFAULT '0',
  `latency` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `talentGroupsCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `activeTalentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL DEFAULT '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grantableLevels` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleteInfos_Account` int(10) unsigned DEFAULT NULL,
  `deleteInfos_Name` varchar(12) DEFAULT NULL,
  `deleteDate` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (2,2,'Liadrin',10,2,1,81,0,11634676,8,8,5,5,6,0,2,8,2721.24,-692.398,119.781,0,0,0,5.90142,'0 0 131072 4 0 0 1048576 0 0 0 0 0 0 0 ',0,1,20445,20326,1524916548,0,0,0,0,0,0,0,0,0,9,0,0,85,1522786112,'',10000,75000,0,0,0,0,0,0,6144,4294967295,0,16774,10144,0,0,100,0,0,0,0,2,0,'1086455808 134217747 0 1090519040 4472848 524288 262264 8192 0 0 0 0 0 16777216 0 4194304 0 4194320 0 384 64 8991240 1048576 16 0 0 0 0 49152 0 0 0 0 0 8388608 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16384 0 0 0 0 0 0 0 8 0 0 0 0 0 0 68420676 0 0 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2151677952 4 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 51726 0 24143 0 51275 0 50667 0 51278 0 50632 0 50721 0 51276 0 0 0 0 0 0 0 0 0 0 0 23346 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',11,0,NULL,NULL,NULL),(3,3,'Hacedor',1,2,0,100,0,15190252,1,2,5,6,2,0,2,11,1706.74,-882.769,125.976,0,0,0,4.53229,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,219579,219116,1553298019,0,0,0,0,0,0,0,0,0,25,0,0,28,0,'',10000,75000,0,0,0,0,0,0,6144,4294967295,0,8774,5749,0,0,100,0,0,0,15,1,0,'10092544 150995348 2969567233 3758297091 4194949 34078848 134217728 2629826272 31 268435456 889192448 8388608 1024 146800640 4 0 22544640 541073664 2147483650 536940672 66060360 73736 537018372 536870912 671088640 1536 1982464 72 10 3758096384 2 536871936 0 0 0 1 0 0 0 0 0 32768 0 0 0 0 0 0 0 536936448 0 0 0 1073741824 0 0 0 0 0 0 1073741824 0 1 0 357913925 16401 32 640 0 0 0 0 0 0 0 0 16777216 268435457 8388608 2134024 0 0 262144 2151677952 260 67108864 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 45 0 0 0 0 0 44 0 43 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2915 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(4,2,'Morticia',1,5,1,100,0,303265275,3,7,18,1,4,0,2,8,2872.7,-762.83,160.332,0,0,16,5.13296,'2 0 0 2147483656 0 0 1048576 0 0 0 0 0 0 0 ',0,1,261334,261141,1533661094,0,0,0,0,0,0,0,0,0,13,0,0,796,1524868968,'',10000,49000,0,0,0,0,0,0,6164,4294967295,0,9560,9283,0,0,100,0,0,0,72,1,0,'1610743808 16777216 0 536870912 0 524288 135528448 2121728 1744831520 0 0 8388608 0 16777216 0 0 0 32784 2147483648 4096 64 73736 1245184 0 0 0 5505024 64 0 0 0 0 0 0 0 0 0 0 128 0 0 32768 0 0 0 0 0 0 0 0 0 0 0 1073741824 0 0 0 0 0 0 0 0 1 4096 357913924 16401 32 512 0 0 0 0 0 0 0 0 16777216 1 0 32776 0 0 262144 4194304 2048 0 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 35133 0 0 0 44694 0 23303 0 0 0 17603 0 23289 0 0 0 0 0 35320 0 0 0 0 0 0 0 44431 0 35 0 0 0 0 0 0 0 51809 0 51809 0 51809 0 51809 0 ',0,'0 0 0 0 0 0 ',5,0,NULL,NULL,NULL),(5,2,'Tantaria',1,6,1,155,0,1002985,8,23,2,4,1,0,2,8,2736.88,-699.166,122.201,0,0,0,2.96588,'4294967295 2483027967 829882367 8 16384 1310944 3251642388 73752 896 67111952 2281701376 4190109713 1049856 12582912 ',0,1,29181,29072,1527606698,0,0,0,0,0,0,0,0,0,9,0,0,85,0,'',10000,75000,0,0,0,0,0,0,343939072,4294967295,0,25001,0,0,0,100,0,0,0,63,1,0,'0 0 0 1610612736 0 524288 0 176128 3211264 0 0 8455168 0 1912602624 0 6656 0 16 2148008000 32 1073741890 65544 0 0 0 0 0 131072 0 65536 0 0 0 0 8388608 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 263237 1 0 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 262144 4194304 0 0 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','40830 0 45819 0 40871 0 0 0 40787 0 45825 0 40851 0 34648 0 34653 0 40811 0 47731 0 47729 0 0 0 0 0 50466 0 23499 0 0 0 0 0 0 0 38145 0 38145 0 38145 0 38145 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(7,3,'Ieepa',4,5,0,100,0,1000000,6,6,2,0,0,0,2,3,1628.98,-5823.22,116.666,609,0,0,0.956655,'100663296 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,2183,1643,1522145950,0,0.000516667,0,0,0,0,0,0,0,0,0,0,4298,0,'',10000,75000,0,0,0,0,0,0,6144,4294967295,0,7650,7213,0,0,100,0,0,0,31,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 68506692 20 0 128 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 53 0 6119 0 0 0 52 0 51 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3661 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(13,4,'Gurg',2,3,0,80,0,1000000,3,4,3,3,9,0,2,0,1643.81,-5847.33,117.293,609,0,0,2.36645,'4194304 0 0 4 0 0 1048576 0 0 0 0 0 0 0 ',0,1,144,144,1522178471,0,0,0,0,0,0,0,0,0,4,0,0,4298,0,'',10000,75000,0,0,0,0,0,0,6144,4294967295,0,8444,6071,0,0,100,0,0,0,405,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 127 0 0 0 0 0 6126 0 6127 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12282 0 0 0 2504 0 0 0 2101 0 0 0 0 0 0 0 ',2512,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(14,4,'Flowapus',4,1,1,80,0,1000000,0,4,3,1,0,0,2,0,1644.46,-5845.35,117.293,609,0,0,2.68611,'100663296 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,168,168,1522178697,0,0,0,0,0,0,0,0,0,4,0,0,4298,0,'',10000,75000,0,0,0,0,0,0,6144,4294967295,0,9611,0,0,0,100,0,0,0,64,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6120 0 0 0 0 0 6121 0 6122 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(15,5,'Vanya',1,1,1,80,0,92494123,1,1,20,1,3,0,2,0,2884.45,-822.01,160.333,0,0,16,1.95268,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,32350,32350,1527441053,0,0,0,0,0,0,0,0,0,12,0,0,796,0,'',10000,34000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,37,1,0,'0 0 0 1073741824 0 0 0 8192 0 0 0 0 0 0 0 0 0 32784 1073741824 0 64 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 512 0 0 0 0 0 0 0 0 0 0 0 32776 0 0 262656 4194304 2048 0 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 0 0 2572 0 3597 0 7062 0 840 0 3603 0 793 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 41599 0 41599 0 41599 0 41599 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(16,6,'Artus',1,1,0,80,0,33994123,3,7,15,0,5,0,2,2048,1673.62,-730.403,59.5361,0,0,0,4.70998,'130 0 0 8 0 0 1048576 0 0 2097152 0 0 0 0 ',0,1,128260,128260,1551570720,0,0,0,0,0,0,0,0,0,12,0,0,85,1551482475,'',10000,900,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,40,1,0,'1703936 16777216 3328 1107296256 81953536 524416 2147483648 268460096 65 1191182432 675414016 8388608 16777222 0 0 0 0 40978 0 37753856 12582976 65931 2097152 2684354560 4195331 0 2048 0 67108864 0 8388608 536870912 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2048 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 262148 0 0 512 0 0 0 0 0 0 0 0 0 0 8388608 36872 0 0 512 2151677952 2304 0 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 100051 0 0 0 100053 0 100054 0 100055 0 100056 0 100057 0 100058 0 0 0 0 0 0 0 0 0 0 0 2520 0 1201 0 0 0 100000 0 41599 0 41599 0 41599 0 41599 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(21,11,'Eothan',1,1,0,80,0,447500,3,1,1,6,8,0,2,1024,1638.64,-338.806,18.6778,189,0,0,2.98949,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,32960,32960,1525901370,0,0,0,0,0,0,0,0,0,12,0,0,796,1522969201,'',100000,350000,0,0,0,0,0,0,6144,4294967295,0,10641,0,0,0,100,0,0,0,94,1,0,'0 0 0 0 0 524288 0 24576 0 0 0 0 0 0 0 0 0 0 0 4096 64 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','24633 0 0 0 0 0 38 0 10399 0 31660 0 6835 0 10402 0 0 0 10401 0 0 0 0 0 0 0 0 0 18495 0 0 0 0 0 0 0 0 0 51809 0 51809 0 51809 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(22,7,'Eadrig',1,1,0,80,0,291760632,2,8,12,0,0,0,2,0,2866.58,-777.284,160.333,0,0,0,5.04891,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,38437,38437,1525375968,0,0,0,0,0,0,0,0,0,12,0,0,796,1523213972,'',100000,2500,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,292,1,0,'0 0 0 1073741824 0 12058624 0 24576 0 0 0 8388608 0 0 0 0 0 16 0 0 64 204808 0 0 0 0 1050624 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2048 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 8 0 0 512 4194304 0 0 0 0 2 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 41248 0 0 0 2148 0 44 0 24654 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 44218 0 0 0 0 0 0 0 51809 0 51809 0 51809 0 51809 0 ',0,'0 0 0 0 0 0 ',7,0,NULL,NULL,NULL),(24,1,'Irma',1,1,1,80,0,105191871,2,6,8,6,2,0,2,3072,1688.16,-721.758,57.6406,0,0,0,5.20658,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,352741,352741,1551575854,0,0,0,0,0,0,0,0,0,12,0,0,85,1526682532,'',100000,231000,0,0,0,0,0,0,6144,4294967295,0,11761,0,0,0,100,0,0,0,71,1,0,'0 0 0 0 0 524288 0 8256 0 0 0 8388608 0 0 0 0 0 16 0 0 64 65544 256 0 0 0 0 0 0 0 0 0 0 0 8388608 0 0 0 0 0 0 32768 0 0 0 0 0 262144 0 8192 0 0 0 0 0 0 0 0 0 0 0 0 0 0 262404 1 0 512 0 0 0 0 0 0 0 0 0 0 0 32768 0 0 0 4194304 2048 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','4323 0 35135 0 100051 0 0 0 100053 0 100054 0 100055 0 100056 0 100057 0 100058 0 33919 0 35131 0 0 0 0 0 51330 0 2208 0 0 0 15807 0 100000 0 51809 0 51809 0 51809 0 51809 0 ',2515,'0 0 0 0 0 0 ',4,0,NULL,NULL,NULL),(25,12,'Drana',1,1,1,90,0,993742890,0,2,3,0,6,0,2,8,2891.68,-759.262,160.333,0,0,0,3.30441,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,33307,33307,1523821145,0,0,0,0,0,0,0,0,0,9,0,0,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,10191,0,0,0,100,0,0,0,28,1,0,'0 0 0 0 0 524288 0 2121728 0 0 0 8388608 0 0 0 0 0 0 0 0 4194368 65536 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','25974 0 0 0 0 0 38 0 14413 0 13403 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(26,14,'Drzoidberg',1,1,0,80,0,1000000,7,5,9,8,0,0,2,2,1658.66,-358.128,18.0233,189,0,0,2.35558,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,4411,4411,1525537844,0,0,0,0,0,0,0,0,0,12,0,0,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,17,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(27,10,'Emilia',1,1,1,80,0,1200952,2,5,23,0,0,0,2,3072,2869.33,-786.009,160.329,0,0,16,1.89848,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,94564,94564,1535652892,0,0,10000,1525204648,0,0,0,0,0,12,0,0,796,1525980213,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9631,0,0,0,100,0,0,0,75,1,0,'0 0 0 0 0 524288 0 8192 0 0 0 8388608 0 0 0 0 0 0 2147483648 4096 4194368 8 256 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','10024 0 0 0 0 0 11840 0 2317 0 1849 0 5961 0 6582 0 0 0 10401 0 0 0 0 0 0 0 0 0 13340 0 853 0 853 0 15808 0 0 0 51809 0 51809 0 51809 0 51809 0 ',2515,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(28,7,'Rothrik',3,1,0,80,0,708249,2,4,6,2,1,0,2,0,1656.33,-5841.16,116.143,609,0,0,1.34968,'32 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,1313,1313,1523572598,0,0,0,0,0,0,0,0,0,12,0,0,4298,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9651,0,0,0,100,0,0,0,304,1,0,'0 0 0 0 0 0 1048576 0 0 0 0 0 0 0 0 0 0 0 0 0 64 196608 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','3894 0 0 0 0 0 38 0 2423 0 2424 0 2425 0 2426 0 2427 0 2428 0 0 0 0 0 0 0 0 0 0 0 2523 0 2451 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(29,9,'Colette',1,1,1,80,0,10871592,4,0,17,3,2,0,2,3072,1650.18,-360.413,18.5475,189,0,16,6.11911,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,38610,38610,1526850053,0,0,0,0,0,0,0,0,0,12,0,0,796,1524856112,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,298,1,0,'0 0 0 536870912 128 524288 0 8192 0 0 0 0 0 0 0 0 0 0 0 0 64 196616 3328 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 100051 0 3428 0 100053 0 100054 0 100055 0 100056 0 100057 0 100058 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3026 0 0 0 7371 0 0 0 0 0 0 0 ',2515,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(30,13,'Tomasa',1,4,1,90,0,3010000,9,4,9,0,3,0,2,8,2872.7,-762.83,160.332,0,0,16,5.13296,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,79866,79866,1535655199,0,0,0,0,0,0,0,0,0,13,0,0,796,1525446605,'',100000,320500,0,0,0,0,0,0,6144,4294967295,0,8684,0,0,0,100,0,0,0,70,1,0,'0 12288 0 1073741824 524424 524288 262144 8450048 4286595104 805306373 0 8388608 0 12582912 0 0 524288 144 2147487744 0 4194880 65536 4 0 134217728 0 0 2147483712 16385 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 262144 4194304 2048 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 11840 0 6263 0 7026 0 0 0 4312 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 28979 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(31,3,'Aduin',1,1,0,90,0,980170,2,11,5,2,2,0,2,8,2865.4,-772.029,160.333,0,0,16,4.711,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,153824,153824,1551482660,0,0,0,0,0,0,0,0,0,9,0,64,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,11251,0,0,0,100,0,0,0,15,1,0,'402784256 12288 0 1073741824 512 524304 134479872 1350760128 3883942956 805306369 0 8388608 0 12582912 0 0 0 128 2147489794 1 11010112 204808 524556 0 134217728 524288 98304 72 16385 1610612736 0 0 0 0 8388608 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4196224 0 2 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','7048 0 0 0 100041 0 38 0 12422 0 12424 0 12429 0 12426 0 12425 0 100048 0 0 0 0 0 0 0 0 0 0 0 3206 0 0 0 15285 0 100000 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(32,8,'Jaqen',1,1,0,80,0,20646348,5,4,5,1,4,0,2,2048,1668.98,-350.999,18.0234,189,0,16,4.19499,'2 0 0 8 0 0 1048576 1048576 0 0 0 0 0 0 ',0,1,87619,87619,1527722392,0,0,0,0,0,0,0,0,0,12,0,0,796,1525381072,'',82150,16250,0,0,0,0,0,0,6144,4294967295,0,17611,0,0,0,100,0,0,0,20,2,1,'98304 0 4608 0 4194816 134743072 1672 3601472 131072 67108864 134220040 8454144 128 50331648 0 0 33554432 4096 2 33555200 4202562 65544 256 1073741832 32832 8389632 0 0 0 25165824 0 8192 0 0 1064960 1073763342 673280 1073741829 33620000 512 1374732288 33587232 32768 3221225476 4194368 75808 257 256 0 2684354688 768 268435456 0 2147483648 0 524288 0 0 0 0 0 0 0 335548416 0 0 0 512 0 0 0 0 8192 0 0 0 0 0 8388608 2097160 0 0 512 4194304 2048 0 0 0 0 0 0 0 0 2214592512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 51355 0 0 0 38 0 9434 0 40883 0 10400 0 40884 0 51364 0 10401 0 48956 0 51559 0 42133 0 42136 0 18689 0 7005 0 7005 0 3026 0 0 0 4499 0 4499 0 4499 0 4499 0 ',2515,'0 0 0 0 0 0 ',7,0,NULL,NULL,NULL),(33,17,'Devilman',1,1,0,90,0,1000000,1,6,1,9,4,0,2,9,2850.99,-364.28,78.5633,0,0,0,1.54939,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,36786,36786,1525980363,0,0,0,0,0,0,0,0,0,13,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,11501,0,0,0,100,0,0,0,21,1,0,'0 0 0 1610612736 136 524288 0 2121728 0 0 0 8388608 0 0 0 0 0 0 0 0 64 65536 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 262144 4194304 2048 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','30856 0 0 0 24924 0 41251 0 8312 0 45551 0 8318 0 51990 0 30927 0 40952 0 0 0 0 0 0 0 0 0 0 0 1893 0 0 0 0 0 0 0 23162 0 23162 0 23162 0 23162 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(35,19,'Tstdos',1,1,1,80,0,1000000,7,12,7,2,4,0,2,2,2604.52,-543.39,88.9996,0,0,0,5.87495,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,1152,1152,1525536735,0,0,0,0,0,0,0,0,0,12,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,74,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(36,21,'Tstcuatro',3,1,0,80,0,1000000,4,5,1,0,10,0,2,0,2604.52,-543.39,88.9996,0,0,0,0.0394463,'32 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,968,968,1525536722,0,0,0,0,0,0,0,0,0,12,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9651,0,0,0,100,0,0,0,65,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12282 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(37,20,'Tsttres',1,1,1,80,0,1000000,9,14,1,8,6,0,2,0,2604.52,-543.39,88.9996,0,0,0,0.733737,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,1066,1066,1525536741,0,0,0,0,0,0,0,0,0,12,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,58,1,0,'0 0 0 536870912 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(38,22,'Tstcinco',1,1,1,80,0,1000000,4,0,2,8,4,0,2,2,2604.52,-543.39,88.9996,0,0,0,0.548384,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,489,489,1525536731,0,0,0,0,0,0,0,0,0,12,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,64,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(39,2,'Alaina',1,1,1,90,0,94143351,5,11,11,7,4,0,2,1033,892.749,1390.67,18.6779,189,0,16,4.81548,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,88343,88343,1533943392,0,0,0,0,0,0,0,0,0,13,0,0,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,12491,0,0,0,100,0,0,0,72,1,0,'0 8192 0 1073741824 0 524304 262144 8413184 1073742880 268435456 0 0 0 4194304 0 0 0 16 2147483648 1 64 73736 264 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1920 0 2 512 0 0 0 0 67109892 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 41253 0 47739 0 0 0 46975 0 9630 0 0 0 5394 0 0 0 0 0 0 0 0 0 9938 0 33791 0 0 0 15285 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(40,18,'Tstuno',1,1,1,80,0,93156696,3,11,1,1,1,0,2,0,2688.88,-700.946,124.71,0,0,0,3.06641,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,697,697,1527879246,0,0,0,0,0,0,0,0,0,12,0,0,85,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,10021,0,0,0,100,0,0,0,176,1,0,'0 0 0 0 0 524288 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 100011 0 38 0 100013 0 100014 0 100015 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 100000 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(41,14,'Joseph',1,1,0,80,0,996200,2,7,9,0,5,0,2,0,886.654,1416.14,19.2183,189,0,16,0.0160384,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,10377,10377,1533854751,0,0,0,0,0,0,0,0,0,12,0,0,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9631,0,0,0,100,0,0,0,11,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 8 256 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 100051 0 38 0 100053 0 100054 0 100055 0 100056 0 100057 0 100058 0 0 0 0 0 0 0 0 0 0 0 1917 0 0 0 0 0 100000 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(42,23,'Gerd',1,1,0,80,0,98219490,1,1,9,4,4,0,2,0,935.689,1384.82,19.7319,189,0,16,6.19576,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,14403,14403,1533854811,0,0,0,0,0,0,0,0,0,12,0,0,796,0,'',100000,375000,0,0,0,0,0,0,6144,4294967295,0,9621,0,0,0,100,0,0,0,41,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 0 0 837 0 3589 0 794 0 202 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 51809 0 51809 0 51809 0 51809 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corpse`
--

DROP TABLE IF EXISTS `corpse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corpse` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `phaseMask` int(10) unsigned NOT NULL DEFAULT '1',
  `displayId` int(10) unsigned NOT NULL DEFAULT '0',
  `itemCache` text NOT NULL,
  `bytes1` int(10) unsigned NOT NULL DEFAULT '0',
  `bytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `guildId` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dynFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `corpseType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`),
  KEY `idx_type` (`corpseType`),
  KEY `idx_instance` (`instanceId`),
  KEY `idx_time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Death System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corpse`
--

LOCK TABLES `corpse` WRITE;
/*!40000 ALTER TABLE `corpse` DISABLE KEYS */;
/*!40000 ALTER TABLE `corpse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creature_respawn`
--

DROP TABLE IF EXISTS `creature_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creature_respawn`
--

LOCK TABLES `creature_respawn` WRITE;
/*!40000 ALTER TABLE `creature_respawn` DISABLE KEYS */;
INSERT INTO `creature_respawn` VALUES (775,1522141471,0,0),(895,1522141501,0,0),(2221,1525205182,0,0),(2224,1525205179,0,0),(2225,1525205182,0,0),(2228,1525205159,0,0),(2249,1525205158,0,0),(2320,1525205158,0,0),(2370,1525205160,0,0),(2377,1525205167,0,0),(2384,1525205221,0,0),(5016,1525371988,0,0),(5075,1525370377,0,0),(11023,1525370595,0,0),(11283,1522790896,0,0),(11643,1522790901,0,0),(11700,1522790901,0,0),(12402,1525216122,571,0),(13388,1525369950,0,0),(13392,1525369945,0,0),(13394,1525369974,0,0),(14536,1522790841,0,0),(14539,1522790844,0,0),(14552,1522790983,0,0),(14554,1522790972,0,0),(14557,1522790972,0,0),(14577,1522790943,0,0),(14580,1522790935,0,0),(14584,1522790954,0,0),(19737,1522956888,1,0),(19757,1522956883,1,0),(21574,1525370658,1,0),(21584,1525370648,1,0),(21693,1525370644,1,0),(21694,1525370646,1,0),(21926,1525370688,1,0),(23426,1526438824,1,0),(23429,1526436613,1,0),(23432,1526439209,1,0),(23433,1526436893,1,0),(23436,1526438410,1,0),(23437,1526438223,1,0),(23438,1526440143,1,0),(23439,1526439072,1,0),(23440,1526438876,1,0),(25858,1523300157,1,0),(26423,1525372834,1,0),(26488,1525372835,1,0),(26515,1525372835,1,0),(27805,1522957393,1,0),(28200,1523300556,1,0),(29819,1523300299,1,0),(29865,1523300377,1,0),(29995,1523300398,1,0),(31893,1522959029,0,0),(31894,1526066375,0,0),(31895,1522959024,0,0),(32046,1551520922,0,0),(32084,1533376323,0,0),(37890,1525202564,0,0),(37924,1524908068,0,0),(38019,1551569051,0,0),(38023,1525979113,0,0),(38105,1526066389,0,0),(38130,1526066368,0,0),(38248,1533663372,0,0),(38341,1525211518,0,0),(38427,1522959029,0,0),(38431,1522959029,0,0),(38490,1525458206,0,0),(41754,1525203998,0,0),(42005,1526066635,0,0),(42058,1551568760,0,0),(42128,1526066671,0,0),(42143,1526065829,0,0),(43918,1526230652,0,0),(44155,1551568752,0,0),(44273,1526230717,0,0),(44277,1526230681,0,0),(44283,1526230685,0,0),(44392,1525202597,0,0),(44430,1526230639,0,0),(44443,1526230707,0,0),(44449,1533376320,0,0),(44457,1523303169,571,0),(44459,1526230646,0,0),(44553,1526230742,0,0),(44563,1525211521,0,0),(44565,1526230695,0,0),(44572,1526230656,0,0),(44574,1526230576,0,0),(44578,1526230630,0,0),(44579,1525202632,0,0),(44580,1525202632,0,0),(44587,1526230670,0,0),(44595,1525202541,0,0),(44600,1525268889,0,0),(44604,1526230662,0,0),(44636,1526230734,0,0),(44652,1526230723,0,0),(44687,1551520975,0,0),(44958,1526066429,0,0),(45007,1525203449,0,0),(45051,1526066537,0,0),(45054,1522085684,0,0),(45073,1533662792,0,0),(45084,1525203476,0,0),(45133,1525203467,0,0),(45170,1551520922,0,0),(45205,1551520931,0,0),(45213,1526230693,0,0),(45218,1533664894,0,0),(45227,1522953978,0,0),(45258,1551907217,0,0),(45760,1522976804,1,0),(47178,1523382481,0,0),(49203,1525444311,0,0),(52587,1522953935,0,0),(54955,1522079770,530,0),(54960,1522079728,530,0),(57494,1525368124,530,0),(62838,1523732467,0,0),(63042,1525372137,530,0),(65894,1525370109,530,0),(65898,1525370103,530,0),(68010,1525380187,530,0),(68011,1525380374,530,0),(68012,1525380366,530,0),(68013,1525380044,530,0),(68015,1525380178,530,0),(68016,1525380211,530,0),(68017,1525380250,530,0),(68018,1525380242,530,0),(68020,1525380113,530,0),(68021,1525380372,530,0),(68022,1525380210,530,0),(68023,1525379544,530,0),(68024,1525380248,530,0),(68025,1525380226,530,0),(68111,1525379433,530,0),(68112,1525379110,530,0),(68113,1525379057,530,0),(68114,1525379567,530,0),(68115,1525379569,530,0),(68116,1525379591,530,0),(68118,1525379188,530,0),(68121,1525379988,530,0),(68122,1525380253,530,0),(68123,1525379067,530,0),(68124,1525379054,530,0),(68125,1525380238,530,0),(68126,1525379961,530,0),(68127,1525379046,530,0),(68128,1525377638,530,0),(68262,1525379586,530,0),(68263,1525379042,530,0),(68264,1525379803,530,0),(68265,1525379078,530,0),(68266,1525380072,530,0),(68311,1525380132,530,0),(68312,1525380180,530,0),(68313,1525380028,530,0),(68314,1525380307,530,0),(70889,1525370400,530,0),(70890,1525370396,530,0),(71280,1525370145,530,0),(74033,1526469642,0,0),(74349,1525370275,530,0),(75458,1525370398,530,0),(79680,1523301774,0,0),(79688,1523302142,0,0),(79705,1523301931,0,0),(79706,1523301956,0,0),(79707,1523301984,0,0),(79723,1523301939,0,0),(79808,1523301484,0,0),(79937,1523299455,0,0),(79944,1525462717,0,0),(79948,1525549105,0,0),(79960,1523299472,0,0),(79972,1525548901,0,0),(79974,1523299482,0,0),(79984,1523299475,0,0),(79988,1523299492,0,0),(79991,1525548736,0,0),(80128,1524937903,0,0),(80183,1522083951,0,0),(80297,1523974617,0,0),(80308,1523974729,0,0),(80761,1525462096,0,0),(80882,1523126291,0,0),(80886,1523126420,0,0),(80891,1523126428,0,0),(80892,1523126446,0,0),(80893,1523126450,0,0),(80894,1523126456,0,0),(80898,1523126483,0,0),(80901,1523126476,0,0),(80902,1523126469,0,0),(81032,1525377076,0,0),(85221,1525216530,571,0),(85222,1525216530,571,0),(85226,1525216530,571,0),(86029,1525367925,530,0),(86035,1525367920,530,0),(86066,1525379884,530,0),(86068,1525379937,530,0),(86069,1525379359,530,0),(86070,1525380210,530,0),(86071,1525379928,530,0),(86385,1523732458,0,0),(86649,1525370339,530,0),(90403,1523732671,0,0),(90408,1523732747,0,0),(92439,1525203455,0,0),(93417,1525373233,0,0),(93423,1525373135,0,0),(94985,1525372139,530,0),(97002,1525368345,530,0),(97005,1525368296,530,0),(97036,1525368310,530,0),(97125,1525275972,571,0),(107619,1522080611,571,0),(108753,1525216168,571,0),(108760,1525215916,571,0),(113089,1525374531,571,0),(115701,1525211272,571,0),(117272,1525216004,571,0),(117591,1525216759,571,0),(117596,1525215915,571,0),(117598,1525216669,571,0),(117601,1525216598,571,0),(117603,1525216579,571,0),(118064,1525448580,571,0),(118424,1525216047,571,0),(121072,1525211908,571,0),(121073,1525211914,571,0),(121074,1525211907,571,0),(121131,1525211920,571,0),(121132,1525211911,571,0),(121367,1525211925,571,0),(121370,1525211914,571,0),(124276,1525211934,571,0),(128495,1533870156,609,0),(128667,1533712546,609,0),(128752,1533713231,609,0),(128755,1533870360,609,0),(128756,1533870005,609,0),(128757,1533870302,609,0),(128758,1533870004,609,0),(128759,1533870153,609,0),(128760,1533870257,609,0),(128761,1533870032,609,0),(128762,1533870128,609,0),(128763,1533870193,609,0),(128764,1533869989,609,0),(128765,1533869750,609,0),(128766,1533870358,609,0),(128767,1533870297,609,0),(128768,1533870030,609,0),(128769,1533870060,609,0),(128770,1533870122,609,0),(128771,1533870209,609,0),(128772,1533870234,609,0),(128773,1533870152,609,0),(128774,1533870211,609,0),(128775,1533870292,609,0),(128776,1533870192,609,0),(128777,1533870203,609,0),(128778,1533870075,609,0),(128779,1533870250,609,0),(128780,1533870053,609,0),(128781,1533870242,609,0),(128782,1533870273,609,0),(128783,1533870207,609,0),(128784,1533870217,609,0),(128785,1533870015,609,0),(128786,1533870221,609,0),(128787,1533870085,609,0),(128788,1533869861,609,0),(128789,1533870287,609,0),(128790,1533870204,609,0),(128791,1533870346,609,0),(128792,1533870297,609,0),(128793,1533870215,609,0),(128794,1533870211,609,0),(128795,1533870091,609,0),(128796,1533713227,609,0),(128797,1533713176,609,0),(128798,1533713178,609,0),(128799,1533713176,609,0),(128800,1533713176,609,0),(128802,1533713176,609,0),(128892,1533868678,609,0),(128896,1533848908,609,0),(128903,1533860272,609,0),(128906,1533864438,609,0),(128907,1533859181,609,0),(128908,1533860473,609,0),(128909,1533848821,609,0),(128910,1533832494,609,0),(128919,1533869952,609,0),(128921,1527887852,609,0),(128922,1527887868,609,0),(128923,1533869991,609,0),(128924,1533869994,609,0),(128925,1533832406,609,0),(128927,1533837370,609,0),(128928,1527880786,609,0),(128934,1533870001,609,0),(128935,1533869833,609,0),(128936,1533712325,609,0),(128939,1533869998,609,0),(128946,1533869952,609,0),(128948,1533869835,609,0),(128949,1533869975,609,0),(128951,1527362694,609,0),(128957,1533869885,609,0),(128961,1527892872,609,0),(128963,1527881728,609,0),(128965,1527901714,609,0),(128970,1527880810,609,0),(128974,1533837369,609,0),(128979,1527887905,609,0),(128982,1527880865,609,0),(128985,1533869982,609,0),(128986,1533837371,609,0),(128988,1533835065,609,0),(128989,1527881710,609,0),(128990,1533837456,609,0),(128991,1533832400,609,0),(128992,1527896069,609,0),(128997,1533869994,609,0),(128998,1533869995,609,0),(128999,1533869993,609,0),(129000,1527896042,609,0),(129474,1533713177,609,0),(129475,1533713177,609,0),(129476,1533713177,609,0),(129477,1533713176,609,0),(129478,1533713176,609,0),(129479,1533712663,609,0),(129483,1522964194,609,0),(129484,1533713176,609,0),(129485,1533713177,609,0),(129486,1533713177,609,0),(129487,1533713177,609,0),(129488,1533713177,609,0),(129489,1533713176,609,0),(129490,1533713177,609,0),(129491,1533713176,609,0),(129531,1533868053,609,0),(129647,1527378893,609,0),(129679,1533866578,609,0),(129702,1523647023,609,0),(130018,1533860436,609,0),(130019,1533837337,609,0),(130022,1533779867,609,0),(130025,1533851042,609,0),(130026,1523615948,609,0),(130027,1523871822,609,0),(130028,1533855540,609,0),(130029,1533712618,609,0),(130034,1533725055,609,0),(130219,1533869876,609,0),(130221,1533870012,609,0),(130240,1533869919,609,0),(130259,1533869958,609,0),(130312,1533869958,609,0),(130338,1533869644,609,0),(130339,1533869975,609,0),(130340,1533870235,609,0),(130341,1533870351,609,0),(130342,1533870342,609,0),(130343,1533869650,609,0),(130559,1533739752,609,0),(130565,1533853890,609,0),(130566,1533870017,609,0),(130569,1533870031,609,0),(130578,1527363291,609,0),(130592,1527363283,609,0),(130599,1533870240,609,0),(130605,1527363276,609,0),(130609,1533783129,609,0),(130615,1533850884,609,0),(130616,1533870239,609,0),(130617,1533869405,609,0),(130619,1533753286,609,0),(130620,1533870136,609,0),(130628,1527363255,609,0),(130653,1533869366,609,0),(130654,1533870222,609,0),(130655,1533869997,609,0),(130656,1533869908,609,0),(130657,1533869522,609,0),(130659,1533869982,609,0),(130660,1533869972,609,0),(130661,1533869796,609,0),(130662,1533747660,609,0),(130665,1533870253,609,0),(130667,1533867561,609,0),(130668,1523584798,609,0),(130682,1533869430,609,0),(130683,1533870155,609,0),(130689,1533870322,609,0),(130690,1533869974,609,0),(130695,1533869610,609,0),(130703,1527363281,609,0),(130704,1527363285,609,0),(130709,1533870028,609,0),(130716,1523652733,609,0),(130717,1533780019,609,0),(130718,1533868497,609,0),(130719,1533869663,609,0),(130720,1533838739,609,0),(130734,1533863734,609,0),(130741,1533870358,609,0),(130747,1527363289,609,0),(130748,1527363278,609,0),(130749,1533870086,609,0),(130750,1533870159,609,0),(130751,1533869459,609,0),(130752,1533870351,609,0),(130753,1533870333,609,0),(130754,1533868703,609,0),(130755,1533870226,609,0),(130782,1533869920,609,0),(130788,1533867108,609,0),(130789,1533869414,609,0),(130790,1533870028,609,0),(130791,1533869221,609,0),(130794,1533869976,609,0),(130795,1533869794,609,0),(130796,1533870333,609,0),(130797,1533870337,609,0),(130798,1533870157,609,0),(130799,1533852584,609,0),(130820,1533869987,609,0),(130821,1533863056,609,0),(130826,1533867990,609,0),(130827,1533868707,609,0),(130828,1533870335,609,0),(130829,1533870153,609,0),(130830,1533870333,609,0),(130854,1527363272,609,0),(130855,1527363287,609,0),(130856,1533865628,609,0),(130879,1533764596,609,0),(130880,1533735342,609,0),(130881,1533846503,609,0),(130882,1533778323,609,0),(130883,1523642308,609,0),(130884,1533853165,609,0),(130902,1533836897,609,0),(130903,1533781668,609,0),(130921,1533867874,609,0),(130927,1533869255,609,0),(130929,1533673251,609,0),(130930,1533781235,609,0),(130931,1533850826,609,0),(130932,1533868183,609,0),(130933,1533841347,609,0),(130934,1533868453,609,0),(130935,1533856312,609,0),(130938,1533869904,609,0),(130942,1533867732,609,0),(130943,1533870117,609,0),(130944,1533870144,609,0),(130945,1533869980,609,0),(130947,1533752341,609,0),(130949,1533833626,609,0),(130950,1533870032,609,0),(130952,1533870117,609,0),(130953,1533870105,609,0),(130954,1533724391,609,0),(130955,1533869633,609,0),(146133,1525377993,0,0),(146134,1525378049,0,0),(152129,1525211975,571,0),(152130,1525211891,571,0),(152139,1525370023,571,0),(152152,1525211951,571,0),(203625,1525373851,571,0),(203626,1525373890,571,0),(203627,1525373839,571,0),(209092,1525370038,571,0),(213881,1533712656,609,0),(214009,1525173187,0,0),(214011,1525173155,0,0),(214018,1525173217,0,0),(214019,1525173252,0,0),(214106,1524869250,0,0),(214153,1525203930,0,0),(214154,1525203938,0,0),(214155,1525203936,0,0),(214156,1525442657,0,0),(214157,1525442652,0,0),(214205,1523738019,0,0),(214206,1523738064,0,0),(214208,1523738335,0,0),(214212,1523738083,0,0),(214217,1523738061,0,0),(214219,1523738065,0,0),(214231,1523738429,0,0),(214232,1523737552,0,0),(214316,1523727659,0,0),(214319,1523730040,1,0),(214324,1523738425,0,0),(214326,1523818577,0,0),(214329,1523738566,0,0),(214330,1523822065,0,0),(214332,1523738409,0,0),(214334,1523738211,0,0),(214335,1523738178,0,0),(214337,1523738192,0,0),(214342,1523738287,0,0),(214353,1523738040,0,0),(214354,1523738061,0,0),(214355,1523738075,0,0),(214357,1523738116,0,0),(214358,1523738132,0,0),(214359,1523738127,0,0),(214360,1523738160,0,0),(214361,1523738140,0,0),(214362,1523738184,0,0),(214363,1523738157,0,0),(214364,1523738150,0,0),(214366,1523822004,0,0),(214367,1523738644,0,0),(214368,1523818340,0,0),(214371,1523822667,0,0),(214372,1523822669,0,0),(214374,1525441139,0,0),(214466,1526230945,0,0),(214467,1526230954,0,0),(214481,1526230915,0,0),(214485,1523817684,0,0),(214486,1523818495,0,0),(215074,1551522903,0,0),(215241,1551904555,0,0);
/*!40000 ALTER TABLE `creature_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_condition_save`
--

DROP TABLE IF EXISTS `game_event_condition_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event_condition_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `condition_id` int(10) unsigned NOT NULL DEFAULT '0',
  `done` float DEFAULT '0',
  PRIMARY KEY (`eventEntry`,`condition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_condition_save`
--

LOCK TABLES `game_event_condition_save` WRITE;
/*!40000 ALTER TABLE `game_event_condition_save` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_event_condition_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_save`
--

DROP TABLE IF EXISTS `game_event_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `state` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `next_start` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventEntry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_save`
--

LOCK TABLES `game_event_save` WRITE;
/*!40000 ALTER TABLE `game_event_save` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_event_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gameobject_respawn`
--

DROP TABLE IF EXISTS `gameobject_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gameobject_respawn`
--

LOCK TABLES `gameobject_respawn` WRITE;
/*!40000 ALTER TABLE `gameobject_respawn` DISABLE KEYS */;
INSERT INTO `gameobject_respawn` VALUES (42914,1525974982,0,0),(45008,1526066186,0,0),(45508,1523381899,0,0),(45510,1533376186,0,0),(57075,1525210386,571,0),(57789,1525210363,571,0),(100424,1525210302,571,0),(100425,1525210335,571,0),(100429,1525215876,571,0),(100430,1525275711,571,0),(166257,1523657852,0,0),(166258,1523657914,0,0),(166282,1523613339,0,0),(166301,1523614104,0,0),(166372,1523735129,0,0),(167203,1525450537,0,0),(167206,1525450555,0,0),(167228,1525450865,571,0),(167325,1525454414,0,0),(167474,1525457654,0,0),(167731,1525533705,0,0);
/*!40000 ALTER TABLE `gameobject_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_subsurvey`
--

DROP TABLE IF EXISTS `gm_subsurvey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_subsurvey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionId` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `answerComment` text NOT NULL,
  PRIMARY KEY (`surveyId`,`questionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_subsurvey`
--

LOCK TABLES `gm_subsurvey` WRITE;
/*!40000 ALTER TABLE `gm_subsurvey` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_subsurvey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_survey`
--

DROP TABLE IF EXISTS `gm_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_survey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `mainSurvey` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` longtext NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`surveyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_survey`
--

LOCK TABLES `gm_survey` WRITE;
/*!40000 ALTER TABLE `gm_survey` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_ticket`
--

DROP TABLE IF EXISTS `gm_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 open, 1 closed, 2 character deleted',
  `playerGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier of ticket creator',
  `name` varchar(12) NOT NULL COMMENT 'Name of ticket creator',
  `description` text NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `lastModifiedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `closedBy` int(10) NOT NULL DEFAULT '0',
  `assignedTo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'GUID of admin to whom ticket is assigned',
  `comment` text NOT NULL,
  `response` text NOT NULL,
  `completed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `escalated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `needMoreHelp` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resolvedBy` int(10) NOT NULL DEFAULT '0' COMMENT 'GUID of GM who resolved the ticket',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_ticket`
--

LOCK TABLES `gm_ticket` WRITE;
/*!40000 ALTER TABLE `gm_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_instance`
--

DROP TABLE IF EXISTS `group_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_instance`
--

LOCK TABLES `group_instance` WRITE;
/*!40000 ALTER TABLE `group_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_member`
--

DROP TABLE IF EXISTS `group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_member` (
  `guid` int(10) unsigned NOT NULL,
  `memberGuid` int(10) unsigned NOT NULL,
  `memberFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subgroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `roles` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`memberGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_member`
--

LOCK TABLES `group_member` WRITE;
/*!40000 ALTER TABLE `group_member` DISABLE KEYS */;
INSERT INTO `group_member` VALUES (1,3,0,0,0),(1,16,0,0,0),(1,24,0,0,0);
/*!40000 ALTER TABLE `group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `guid` int(10) unsigned NOT NULL,
  `leaderGuid` int(10) unsigned NOT NULL,
  `lootMethod` tinyint(3) unsigned NOT NULL,
  `looterGuid` int(10) unsigned NOT NULL,
  `lootThreshold` tinyint(3) unsigned NOT NULL,
  `icon1` bigint(20) unsigned NOT NULL,
  `icon2` bigint(20) unsigned NOT NULL,
  `icon3` bigint(20) unsigned NOT NULL,
  `icon4` bigint(20) unsigned NOT NULL,
  `icon5` bigint(20) unsigned NOT NULL,
  `icon6` bigint(20) unsigned NOT NULL,
  `icon7` bigint(20) unsigned NOT NULL,
  `icon8` bigint(20) unsigned NOT NULL,
  `groupType` tinyint(3) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `raidDifficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `masterLooterGuid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guid`),
  KEY `leaderGuid` (`leaderGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,3,3,3,2,0,0,0,0,0,0,0,0,2,0,0,0);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild`
--

DROP TABLE IF EXISTS `guild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `leaderguid` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `EmblemColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BackgroundColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL DEFAULT '',
  `motd` varchar(128) NOT NULL DEFAULT '',
  `createdate` int(10) unsigned NOT NULL DEFAULT '0',
  `BankMoney` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild`
--

LOCK TABLES `guild` WRITE;
/*!40000 ALTER TABLE `guild` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_eventlog`
--

DROP TABLE IF EXISTS `guild_bank_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Event type',
  `PlayerGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemOrMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemStackCount` smallint(5) unsigned NOT NULL DEFAULT '0',
  `DestTabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Destination Tab Id',
  `TimeStamp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_eventlog`
--

LOCK TABLES `guild_bank_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_bank_eventlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_item`
--

DROP TABLE IF EXISTS `guild_bank_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_item` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_item`
--

LOCK TABLES `guild_bank_item` WRITE;
/*!40000 ALTER TABLE `guild_bank_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_right`
--

DROP TABLE IF EXISTS `guild_bank_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_right` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gbright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_right`
--

LOCK TABLES `guild_bank_right` WRITE;
/*!40000 ALTER TABLE `guild_bank_right` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_tab`
--

DROP TABLE IF EXISTS `guild_bank_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `TabName` varchar(16) NOT NULL DEFAULT '',
  `TabIcon` varchar(100) NOT NULL DEFAULT '',
  `TabText` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_tab`
--

LOCK TABLES `guild_bank_tab` WRITE;
/*!40000 ALTER TABLE `guild_bank_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_eventlog`
--

DROP TABLE IF EXISTS `guild_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_eventlog` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(3) unsigned NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(10) unsigned NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(10) unsigned NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(3) unsigned NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` int(10) unsigned NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_eventlog`
--

LOCK TABLES `guild_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_eventlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member`
--

DROP TABLE IF EXISTS `guild_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `guid` int(10) unsigned NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  `pnote` varchar(31) NOT NULL DEFAULT '',
  `offnote` varchar(31) NOT NULL DEFAULT '',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member`
--

LOCK TABLES `guild_member` WRITE;
/*!40000 ALTER TABLE `guild_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member_withdraw`
--

DROP TABLE IF EXISTS `guild_member_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member_withdraw` (
  `guid` int(10) unsigned NOT NULL,
  `tab0` int(10) unsigned NOT NULL DEFAULT '0',
  `tab1` int(10) unsigned NOT NULL DEFAULT '0',
  `tab2` int(10) unsigned NOT NULL DEFAULT '0',
  `tab3` int(10) unsigned NOT NULL DEFAULT '0',
  `tab4` int(10) unsigned NOT NULL DEFAULT '0',
  `tab5` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Member Daily Withdraws';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member_withdraw`
--

LOCK TABLES `guild_member_withdraw` WRITE;
/*!40000 ALTER TABLE `guild_member_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_rank`
--

DROP TABLE IF EXISTS `guild_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_rank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL,
  `rname` varchar(20) NOT NULL DEFAULT '',
  `rights` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `BankMoneyPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_rank`
--

LOCK TABLES `guild_rank` WRITE;
/*!40000 ALTER TABLE `guild_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance`
--

DROP TABLE IF EXISTS `instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `completedEncounters` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance`
--

LOCK TABLES `instance` WRITE;
/*!40000 ALTER TABLE `instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_reset`
--

DROP TABLE IF EXISTS `instance_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_reset` (
  `mapid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mapid`,`difficulty`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_reset`
--

LOCK TABLES `instance_reset` WRITE;
/*!40000 ALTER TABLE `instance_reset` DISABLE KEYS */;
INSERT INTO `instance_reset` VALUES (249,0,1553572800),(249,1,1553572800),(269,1,1553313600),(309,0,1553400000),(409,0,1553572800),(469,0,1553572800),(600,1,1553313600),(601,1,1553313600),(602,1,1553313600),(603,0,1553572800),(603,1,1553572800),(604,1,1553313600),(608,1,1553313600),(616,0,1553572800),(616,1,1553572800),(619,1,1553313600),(624,0,1553572800),(624,1,1553572800),(631,0,1553572800),(631,1,1553572800),(631,2,1553572800),(631,3,1553572800),(632,1,1553313600),(649,0,1553572800),(649,1,1553572800),(649,2,1553572800),(649,3,1553572800),(668,1,1553313600),(724,0,1553572800),(724,1,1553572800),(724,2,1553572800),(724,3,1553572800),(22509,0,1553486400),(22531,0,1553313600),(22532,0,1553313600),(22533,0,1553313600),(22533,1,1553313600),(22534,0,1553313600),(22540,1,1553313600),(22542,1,1553313600),(22543,1,1553313600),(22544,0,1553313600),(22546,1,1553313600),(22547,1,1553313600),(22548,0,1553313600),(22560,1,1553313600),(22564,0,1553313600),(22568,0,1553486400),(22574,1,1553313600),(22576,1,1553313600),(22578,1,1553313600),(22580,0,1553313600),(22598,1,1553313600),(22599,1,1553313600),(24026,0,1553313600),(24028,1,1553313600),(24029,1,1553313600),(24030,1,1553313600),(24032,1,1553313600),(24033,1,1553313600),(24034,1,1553313600),(26001,1,1553313600),(28001,0,1553313600),(29001,1,1553313600),(30001,1,1553313600),(31001,1,1553313600),(43529,1,1553313600),(61225,0,1553313600),(61225,1,1553313600),(62250,1,1553313600),(62258,1,1553313600);
/*!40000 ALTER TABLE `instance_reset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_instance`
--

DROP TABLE IF EXISTS `item_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemEntry` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `creatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `giftCreatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0',
  `charges` tinytext,
  `flags` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enchantments` text NOT NULL,
  `randomPropertyId` smallint(5) NOT NULL DEFAULT '0',
  `durability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text,
  PRIMARY KEY (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_instance`
--

LOCK TABLES `item_instance` WRITE;
/*!40000 ALTER TABLE `item_instance` DISABLE KEYS */;
INSERT INTO `item_instance` VALUES (12,24143,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(18,23346,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(20,6948,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(28,50632,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(29,50667,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(30,50721,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(31,51275,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,155,''),(32,51726,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(34,51276,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,156,''),(36,51278,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,156,''),(108,45,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(110,43,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(112,44,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(114,6948,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(116,2361,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(123,6098,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,32,0,''),(125,52,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,0,''),(127,53,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(129,51,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(131,35,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,0,''),(133,6948,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(136,34652,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(138,34655,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(140,34659,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(142,34650,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,115,0,''),(144,34653,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(146,34649,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(148,34651,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(150,34656,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(152,34648,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(154,34657,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(156,34658,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(158,38145,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(160,38145,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(162,38145,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(164,38145,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(166,38147,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(168,41751,5,0,0,9,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(207,3661,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(209,6119,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(211,52,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(213,51,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(215,53,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(217,6948,7,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(260,40,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(266,19028,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(269,5767,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(270,57,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(289,127,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(291,6126,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(293,6127,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(295,12282,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(297,6948,13,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(299,2101,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(301,2504,13,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(303,2512,13,0,0,200,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(306,49778,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(308,6120,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(310,6121,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(312,6122,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(314,6948,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(326,2208,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(327,15807,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(330,2289,4,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(340,4421,4,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(342,38,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(344,39,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(346,40,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(348,49778,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(350,6948,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(354,38,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(356,39,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,9,0,''),(358,40,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(360,49778,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,13,0,''),(362,6948,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(364,41599,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(365,41599,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(366,41599,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(367,41599,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(368,41599,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(369,41599,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(370,41599,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(371,41599,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(374,2572,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(375,2208,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(377,840,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(379,793,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(381,3597,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(383,3603,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(387,23452,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7183,''),(389,35320,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7194,''),(390,44431,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7199,''),(391,35133,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7166,''),(392,17603,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,7199,''),(393,23303,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,80,7175,''),(394,23288,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,7193,''),(395,23289,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,7199,''),(403,33447,15,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(404,33448,15,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(405,40211,15,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(406,41427,15,0,0,3,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(407,42378,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(408,42360,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(410,44817,4,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(414,44689,15,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(415,2396,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,10,0,''),(416,2397,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,10,0,''),(417,2395,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(418,2393,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,10,0,''),(419,2394,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,26,0,''),(420,2392,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,33,0,''),(421,1201,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,0,''),(422,2488,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(424,2520,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,39,0,''),(426,7058,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(427,7062,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(428,18876,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,7200,''),(429,12584,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,43,7185,''),(430,18825,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,48,7182,''),(431,16480,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,7169,''),(432,16478,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,7200,''),(433,16477,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,67,7166,''),(434,16483,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,32,7164,''),(435,16484,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,24,7162,''),(436,16479,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,48,7160,''),(437,42081,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7200,''),(463,33447,16,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(464,41427,16,0,0,3,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(465,40211,16,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(466,33448,16,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(471,3428,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(472,2432,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,27,0,''),(575,40895,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(576,6359,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(577,6350,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(578,24904,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 ',-40,75,0,''),(579,24870,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2819 0 0 0 0 0 0 0 0 0 0 0 ',-33,27,0,''),(580,24907,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 ',-7,57,0,''),(581,16059,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(583,3342,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(584,4330,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(585,2569,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(586,51809,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(587,51809,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(588,51809,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(589,51809,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(590,24919,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 ',-8,42,0,''),(591,24919,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 ',-36,55,0,''),(592,24919,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2804 0 0 2824 0 0 0 0 0 0 0 0 ',-36,55,0,''),(593,6327,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(594,2915,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),(596,38,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(598,39,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(600,40,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(602,49778,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(604,6948,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(608,18867,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,7180,''),(609,51809,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(610,51809,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(611,51809,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(699,6948,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(730,51809,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(731,51809,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(732,51809,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(733,51809,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(737,38,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(741,40,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(743,49778,32,0,24,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(745,6948,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(749,41427,22,0,0,3,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(750,39802,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(752,41248,22,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(753,2148,22,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(754,44,22,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(755,24654,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2824 0 0 2822 0 0 0 0 0 0 0 0 ',-39,35,0,''),(756,44218,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(757,50973,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,7190,''),(759,33448,24,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(760,40211,24,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(764,51809,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(766,51809,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(767,51809,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(768,51809,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(770,15198,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(771,16480,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,7189,''),(772,16478,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,7187,''),(773,16477,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,7195,''),(774,16483,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,7198,''),(775,16484,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,7175,''),(776,16479,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,7177,''),(777,18825,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,7200,''),(778,12584,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,104,7175,''),(781,44694,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(782,44693,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(783,44694,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(789,23499,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(804,2672,22,0,0,8,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(813,44692,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(815,794,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(828,38,25,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(830,39,25,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(832,40,25,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(834,49778,25,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(836,6948,25,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(838,13403,25,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(839,14413,25,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(840,25974,25,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(841,3770,22,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(843,38,26,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(845,39,26,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(847,40,26,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(849,49778,26,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(851,6948,26,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(853,51354,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7153,''),(854,40789,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,7123,''),(855,40807,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,7121,''),(856,40826,22,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,7120,''),(858,15284,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(860,45624,5,0,0,2925,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,8,''),(861,45819,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,6050,''),(862,45825,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,6020,''),(863,45833,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,5957,''),(864,49426,5,0,0,2640,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(865,40871,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,5764,''),(866,40851,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,5758,''),(867,40830,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,5749,''),(878,6948,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(879,50466,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,5729,''),(881,47241,5,0,0,2780,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,8,''),(882,47731,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,5553,''),(883,47729,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,5535,''),(884,40787,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,165,5418,''),(885,47677,5,0,0,1,0,'0 0 0 0 0 ',4097,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,5356,''),(886,10124,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2330 0 0 0 0 0 0 0 0 ',2050,75,0,''),(888,38,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(890,39,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(892,40,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(894,12282,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(896,6948,28,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(898,793,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(899,794,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(903,2451,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(904,2523,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(905,2423,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(906,2424,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(907,2426,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(908,2425,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(909,2427,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(910,2428,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(911,3894,28,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(912,1210,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(918,40,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(922,6948,29,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(932,1849,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(934,793,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,10,0,''),(935,15808,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,28,0,''),(936,853,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,28,0,''),(938,3428,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(939,795,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(940,201,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(941,3026,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(943,2515,29,0,0,600,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(947,7371,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(949,49,27,0,17,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(955,28979,30,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(961,6948,30,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(963,41749,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(964,41749,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(965,41749,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(966,41749,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(967,41749,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(968,38644,4,0,0,100,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(970,61,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(975,2317,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,39,0,''),(978,2315,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(981,11840,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(982,6582,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 94 0 0 98 0 0 0 0 0 ',763,21,0,''),(983,4336,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(984,4336,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(986,6240,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(987,5961,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,32,0,''),(990,3427,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(992,13340,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(993,10024,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,34,0,''),(995,13340,3,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(999,24729,4,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2806 0 0 2824 0 0 0 0 0 0 0 0 ',-42,50,0,''),(1000,24729,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 ',-40,28,0,''),(1001,51809,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1002,51809,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1003,51809,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1004,51809,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1006,38,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1014,6948,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1015,41426,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1016,4323,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1017,100041,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1018,100048,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1019,12422,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,115,0,''),(1020,12424,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1021,12425,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1022,27415,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(1023,12426,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,54,0,''),(1024,12429,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(1028,28672,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7180,''),(1030,33919,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7122,''),(1031,35135,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7163,''),(1032,35131,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7155,''),(1033,42080,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7186,''),(1034,40984,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,7187,''),(1037,2494,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(1038,40811,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,4,''),(1039,2589,5,0,0,5,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1045,2522,27,0,17,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(1046,2530,27,0,17,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(1049,6523,27,0,17,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(1071,10401,27,0,17,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(1073,853,27,0,17,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1131,38,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1133,39,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(1135,40,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1137,49778,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(1139,6948,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1140,41426,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1141,18689,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1142,10400,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,38,0,''),(1143,10401,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(1144,10401,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(1145,10402,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,27,0,''),(1146,13109,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1147,25349,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,64,0,''),(1148,19984,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1149,4039,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,34,0,''),(1150,8174,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1151,9434,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(1152,6561,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1157,30927,4,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1174,40847,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,90,7186,''),(1175,40789,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,124,7185,''),(1176,40807,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,42,7183,''),(1177,40866,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,7180,''),(1178,4499,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1179,4499,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1180,4499,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1181,4499,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1182,7005,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1183,7005,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1184,40790,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,43,7185,''),(1185,40829,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,7183,''),(1186,40850,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,29,7182,''),(1187,40870,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,7180,''),(1188,40810,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,17,7179,''),(1192,51559,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7194,''),(1195,48956,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7167,''),(1196,54343,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1199,45057,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1201,18876,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,29,7191,''),(1202,18876,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,28,7155,''),(1203,18836,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,21,7146,''),(1209,40884,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,21,7155,''),(1210,40883,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,7190,''),(1214,40890,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,42,7181,''),(1219,51364,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,17,7158,''),(1238,51355,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7152,''),(1239,51354,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7198,''),(1240,42136,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7180,''),(1241,42133,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7178,''),(1242,44012,32,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1243,35952,32,0,0,11,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1247,35952,32,0,0,20,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1253,25272,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 ',-11,49,0,''),(1259,28535,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',-19,0,0,''),(1261,25238,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 ',-10,64,0,''),(1264,25324,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2802 0 0 2803 0 0 0 0 0 0 0 0 ',-41,64,0,''),(1267,25270,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2803 0 0 2825 0 0 0 0 0 0 0 0 ',-40,49,0,''),(1273,24593,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 ',-9,34,0,''),(1275,24897,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2806 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 ',-8,27,0,''),(1277,25265,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2806 0 0 0 0 0 0 0 0 0 0 0 ',-13,49,0,''),(1281,25201,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',-16,57,0,''),(1285,15561,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 354 0 0 353 0 0 0 0 0 ',861,75,0,''),(1287,1722,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(1293,27409,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(1308,44693,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1309,44694,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1313,39,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1315,40,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1319,6948,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1320,41426,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1326,30927,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1327,38278,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1328,38277,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1329,38276,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1342,38,35,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1344,39,35,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1346,40,35,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1348,49778,35,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1350,6948,35,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1351,41426,35,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1353,38,36,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1355,39,36,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1357,40,36,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1359,12282,36,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1361,6948,36,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1362,41426,36,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1364,38,37,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1366,39,37,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1368,40,37,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1370,49778,37,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1372,6948,37,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1373,41426,37,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1375,38,38,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1377,39,38,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1379,40,38,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1381,49778,38,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1383,6948,38,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1384,41426,38,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1385,6786,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1386,10403,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(1387,10402,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1388,10401,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(1389,10399,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,90,0,''),(1390,6835,21,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1391,31660,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(1392,18495,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1393,24633,21,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2804 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 ',-6,45,0,''),(1394,51330,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7198,''),(1395,100051,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1396,100053,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1397,100054,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1398,100055,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1401,100057,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1403,100051,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1404,100053,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1405,100054,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1406,100055,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1407,100056,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1408,100057,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1409,100058,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1412,15242,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 106 0 0 0 0 0 0 0 0 ',97,55,0,''),(1413,4352,15,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1414,23162,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1415,23162,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1416,23162,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1417,23162,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1418,30856,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1419,25596,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1423,18584,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1424,21780,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1429,36942,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1432,1893,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(1433,24924,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 ',-14,70,0,''),(1434,8312,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,115,0,''),(1435,41251,33,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1436,40952,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1437,45551,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1438,8318,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(1440,51990,33,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2805 0 0 2803 0 0 0 0 0 0 0 0 0 0 0 ',-68,65,0,''),(1441,7146,3,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1442,21877,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1443,100000,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,6111,''),(1445,7048,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1446,3206,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 363 0 0 0 0 0 0 0 0 ',172,80,0,''),(1447,6835,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1448,6835,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1449,6836,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(1450,41254,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1451,41255,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1452,100051,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1453,100053,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1454,100054,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1455,100055,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1456,100056,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1457,100057,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1458,100058,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1460,100000,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,1,''),(1467,100058,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1468,100000,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7145,''),(1469,33791,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1470,33791,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1471,33791,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1472,33791,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1473,33791,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1474,33791,27,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1475,7050,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1476,11840,30,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1477,6263,30,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(1478,7026,30,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(1481,4312,30,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1483,100051,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1484,100053,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1485,100054,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1486,100055,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1487,100056,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1488,100057,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1489,100058,31,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1491,100051,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1492,100053,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1493,100054,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1494,100055,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1495,100056,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1496,100057,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1497,100058,29,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1498,100051,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1499,100053,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1500,100054,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1501,100055,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1502,100056,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1503,100057,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1504,100058,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1505,100000,32,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,425,''),(1507,38,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1509,39,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(1511,40,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1513,49778,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1515,6948,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1516,41426,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1517,33791,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,28,0,''),(1518,15285,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(1519,41253,39,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1520,47739,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,120,0,''),(1521,46975,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,90,6615,''),(1522,9630,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1523,5394,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(1524,9938,39,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 365 0 0 0 0 0 0 0 0 ',182,0,0,''),(1526,25873,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1527,2515,27,0,0,198,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1528,3026,27,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1529,3026,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1530,2515,24,0,0,162,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1531,3026,32,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1533,2515,32,0,0,600,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1536,15285,31,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(1541,1710,24,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1543,159,24,0,0,7,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1556,159,39,0,0,20,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,49,''),(1560,159,31,0,39,13,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1564,159,39,0,0,9,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1565,2512,24,0,0,200,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1567,38,40,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1569,39,40,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1571,40,40,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1573,49778,40,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1575,6948,40,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1577,100015,40,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(1578,100014,40,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1579,100013,40,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1580,100011,40,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1581,100000,40,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,228,''),(1583,38,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1585,39,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1587,40,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1589,49778,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1591,6948,41,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1593,100051,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(1594,100053,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(1595,100054,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1596,100055,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1598,100056,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1599,100057,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1600,100058,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1601,100000,41,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1602,1917,41,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1603,1917,41,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1604,100058,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1606,10003,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1609,100056,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1610,15809,24,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(1612,4073,24,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(1614,38,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1616,39,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1618,40,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1620,49778,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1622,6948,42,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1624,51809,42,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1625,51809,42,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1626,51809,42,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1627,51809,42,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1628,794,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(1629,202,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(1630,837,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1631,798,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(1632,796,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1633,799,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(1634,797,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(1635,3589,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(1636,923,42,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,'');
/*!40000 ALTER TABLE `item_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_loot_items`
--

DROP TABLE IF EXISTS `item_loot_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_loot_items` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'loot item entry (item_instance.itemEntry)',
  `item_count` int(10) NOT NULL DEFAULT '0' COMMENT 'stack size',
  `follow_rules` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'follow loot rules',
  `ffa` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'free-for-all',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `counted` tinyint(1) NOT NULL DEFAULT '0',
  `under_threshold` tinyint(1) NOT NULL DEFAULT '0',
  `needs_quest` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'quest drop',
  `rnd_prop` int(10) NOT NULL DEFAULT '0' COMMENT 'random enchantment added when originally rolled',
  `rnd_suffix` int(10) NOT NULL DEFAULT '0' COMMENT 'random suffix added when originally rolled'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_loot_items`
--

LOCK TABLES `item_loot_items` WRITE;
/*!40000 ALTER TABLE `item_loot_items` DISABLE KEYS */;
INSERT INTO `item_loot_items` VALUES (1015,33447,5,0,0,0,0,0,0,0,0),(1015,33448,5,0,0,0,0,0,0,0,0),(1015,40211,5,0,0,0,0,0,0,0,0),(1015,41427,5,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `item_loot_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_loot_money`
--

DROP TABLE IF EXISTS `item_loot_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_loot_money` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'money loot (in copper)',
  PRIMARY KEY (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_loot_money`
--

LOCK TABLES `item_loot_money` WRITE;
/*!40000 ALTER TABLE `item_loot_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_loot_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_refund_instance`
--

DROP TABLE IF EXISTS `item_refund_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_refund_instance` (
  `item_guid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `player_guid` int(10) unsigned NOT NULL COMMENT 'Player GUID',
  `paidMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `paidExtendedCost` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`,`player_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_refund_instance`
--

LOCK TABLES `item_refund_instance` WRITE;
/*!40000 ALTER TABLE `item_refund_instance` DISABLE KEYS */;
INSERT INTO `item_refund_instance` VALUES (372,16,0,427),(386,15,0,2257),(387,4,0,2291),(388,15,0,127),(389,4,0,129),(390,4,0,2428),(391,4,0,127),(392,4,0,542),(393,4,0,652),(394,4,0,428),(395,4,0,427),(400,11,0,2742),(401,11,0,2740),(402,11,0,2742),(428,16,0,2257),(429,16,0,2291),(430,16,0,2291),(431,16,0,465),(432,16,0,464),(433,16,0,463),(434,16,0,465),(435,16,0,541),(436,16,0,542),(437,16,0,2968),(481,17,0,465),(483,17,0,463),(486,17,0,542),(487,17,0,2257),(488,17,0,427),(489,17,0,428),(490,17,0,444),(494,17,0,2594),(495,17,0,2704),(496,17,0,2736),(498,17,0,2594),(499,17,0,2704),(608,21,0,2257),(726,23,0,2968),(727,23,0,2963),(728,23,0,2964),(729,23,0,2964),(771,22,0,465),(772,22,0,464),(773,22,0,463),(774,22,0,465),(775,22,0,541),(776,22,0,542),(777,22,0,2291),(778,22,0,2291),(779,22,0,423),(853,22,0,2964),(854,22,0,2959),(855,22,0,2960),(856,22,0,2959),(861,5,0,2606),(862,5,0,2607),(863,5,0,2607),(865,5,0,2740),(866,5,0,2742),(867,5,0,2742),(868,5,0,2740),(879,5,0,2741),(882,5,0,2685),(883,5,0,2685),(884,5,0,2708),(885,5,0,2708),(1030,24,0,129),(1031,24,0,127),(1032,24,0,2028),(1033,24,0,2968),(1034,24,0,2967),(1072,30,0,2959),(1115,17,0,2956),(1116,17,0,2956),(1117,17,0,2956),(1118,17,0,2955),(1120,17,0,2957),(1128,17,0,2966),(1129,17,0,2966),(1173,32,0,2959),(1174,32,0,2958),(1175,32,0,2959),(1176,32,0,2960),(1177,32,0,2958),(1184,32,0,2956),(1185,32,0,2956),(1186,32,0,2956),(1187,32,0,2955),(1188,32,0,2957),(1190,32,0,2594),(1191,32,0,2704),(1192,32,0,2736),(1194,32,0,2594),(1195,32,0,2704),(1201,32,0,2257),(1202,32,0,2257),(1203,32,0,2291),(1209,32,0,2966),(1210,32,0,2966),(1214,32,0,2967),(1219,32,0,2963),(1238,32,0,2964),(1239,32,0,2964),(1240,32,0,2966),(1241,32,0,2966),(1394,24,0,2964);
/*!40000 ALTER TABLE `item_refund_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_soulbound_trade_data`
--

DROP TABLE IF EXISTS `item_soulbound_trade_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `allowedPlayers` text NOT NULL COMMENT 'Space separated GUID list of players who can receive this item in trade',
  PRIMARY KEY (`itemGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_soulbound_trade_data`
--

LOCK TABLES `item_soulbound_trade_data` WRITE;
/*!40000 ALTER TABLE `item_soulbound_trade_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_soulbound_trade_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lag_reports`
--

DROP TABLE IF EXISTS `lag_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_reports` (
  `reportId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `lagType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `latency` int(10) unsigned NOT NULL DEFAULT '0',
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`reportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lag_reports`
--

LOCK TABLES `lag_reports` WRITE;
/*!40000 ALTER TABLE `lag_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `lag_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lfg_data`
--

DROP TABLE IF EXISTS `lfg_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lfg_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `dungeon` int(10) unsigned NOT NULL DEFAULT '0',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='LFG Data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lfg_data`
--

LOCK TABLES `lfg_data` WRITE;
/*!40000 ALTER TABLE `lfg_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfg_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stationery` tinyint(3) NOT NULL DEFAULT '41',
  `mailTemplateId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `deliver_time` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `cod` int(10) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Mail System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_items`
--

DROP TABLE IF EXISTS `mail_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_items` (
  `mail_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY (`item_guid`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_mail_id` (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_items`
--

LOCK TABLES `mail_items` WRITE;
/*!40000 ALTER TABLE `mail_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_aura`
--

DROP TABLE IF EXISTS `pet_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` mediumint(8) NOT NULL,
  `amount1` mediumint(8) NOT NULL,
  `amount2` mediumint(8) NOT NULL,
  `base_amount0` mediumint(8) NOT NULL,
  `base_amount1` mediumint(8) NOT NULL,
  `base_amount2` mediumint(8) NOT NULL,
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `critChance` float NOT NULL DEFAULT '0',
  `applyResilience` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_aura`
--

LOCK TABLES `pet_aura` WRITE;
/*!40000 ALTER TABLE `pet_aura` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell`
--

DROP TABLE IF EXISTS `pet_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell`
--

LOCK TABLES `pet_spell` WRITE;
/*!40000 ALTER TABLE `pet_spell` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell_cooldown`
--

DROP TABLE IF EXISTS `pet_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell_cooldown`
--

LOCK TABLES `pet_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `pet_spell_cooldown` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition`
--

DROP TABLE IF EXISTS `petition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition`
--

LOCK TABLES `petition` WRITE;
/*!40000 ALTER TABLE `petition` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition_sign`
--

DROP TABLE IF EXISTS `petition_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned NOT NULL DEFAULT '0',
  `playerguid` int(10) unsigned NOT NULL DEFAULT '0',
  `player_account` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition_sign`
--

LOCK TABLES `petition_sign` WRITE;
/*!40000 ALTER TABLE `petition_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pool_quest_save`
--

DROP TABLE IF EXISTS `pool_quest_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pool_quest_save` (
  `pool_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pool_id`,`quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pool_quest_save`
--

LOCK TABLES `pool_quest_save` WRITE;
/*!40000 ALTER TABLE `pool_quest_save` DISABLE KEYS */;
INSERT INTO `pool_quest_save` VALUES (348,24629),(349,14101),(350,13889),(351,13914),(352,11377),(353,11669),(354,13422),(356,11363),(357,11376),(359,12736),(360,12761),(361,12741),(362,12759),(363,14080),(364,14112),(365,14143),(366,14092),(367,14108),(370,12587),(5662,13673),(5663,13762),(5664,13770),(5665,13774),(5666,13780),(5667,13785),(5668,13670),(5669,13616),(5670,13742),(5671,13746),(5672,13757),(5673,13752),(5674,13102),(5675,13113),(5676,13830),(5677,12961),(5678,24584),(5681,24874),(5690,24876),(5690,24877),(5707,13198),(5708,13153),(5709,13201),(5710,13192);
/*!40000 ALTER TABLE `pool_quest_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_battlegrounds`
--

DROP TABLE IF EXISTS `pvpstats_battlegrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_battlegrounds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `winner_faction` tinyint(4) NOT NULL,
  `bracket_id` tinyint(3) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_battlegrounds`
--

LOCK TABLES `pvpstats_battlegrounds` WRITE;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_players`
--

DROP TABLE IF EXISTS `pvpstats_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_players` (
  `battleground_id` bigint(20) unsigned NOT NULL,
  `character_guid` int(10) unsigned NOT NULL,
  `winner` bit(1) NOT NULL,
  `score_killing_blows` mediumint(8) unsigned NOT NULL,
  `score_deaths` mediumint(8) unsigned NOT NULL,
  `score_honorable_kills` mediumint(8) unsigned NOT NULL,
  `score_bonus_honor` mediumint(8) unsigned NOT NULL,
  `score_damage_done` mediumint(8) unsigned NOT NULL,
  `score_healing_done` mediumint(8) unsigned NOT NULL,
  `attr_1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_3` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_4` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_5` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`battleground_id`,`character_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_players`
--

LOCK TABLES `pvpstats_players` WRITE;
/*!40000 ALTER TABLE `pvpstats_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quest_tracker`
--

DROP TABLE IF EXISTS `quest_tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_tracker` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `character_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_accept_time` datetime NOT NULL,
  `quest_complete_time` datetime DEFAULT NULL,
  `quest_abandon_time` datetime DEFAULT NULL,
  `completed_by_gm` tinyint(1) NOT NULL DEFAULT '0',
  `core_hash` varchar(120) NOT NULL DEFAULT '0',
  `core_revision` varchar(120) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_tracker`
--

LOCK TABLES `quest_tracker` WRITE;
/*!40000 ALTER TABLE `quest_tracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `quest_tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserved_name`
--

DROP TABLE IF EXISTS `reserved_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserved_name` (
  `name` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player Reserved Names';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserved_name`
--

LOCK TABLES `reserved_name` WRITE;
/*!40000 ALTER TABLE `reserved_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `reserved_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates`
--

DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates` (
  `name` varchar(200) NOT NULL COMMENT 'filename with extension of the update.',
  `hash` char(40) DEFAULT '' COMMENT 'sha1 hash of the sql file.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if an update is released or archived.',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'timestamp when the query was applied.',
  `speed` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'time the query takes to apply in ms.',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of all applied updates in this database.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates`
--

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES ('2015_03_20_00_characters.sql','B761760804EA73BD297F296C5C1919687DF7191C','ARCHIVED','2015-03-21 21:44:15',0),('2015_03_20_01_characters.sql','894F08B70449A5481FFAF394EE5571D7FC4D8A3A','ARCHIVED','2015-03-21 21:44:15',0),('2015_03_20_02_characters.sql','97D7BE0CAADC79F3F11B9FD296B8C6CD40FE593B','ARCHIVED','2015-03-21 21:44:51',0),('2015_06_26_00_characters_335.sql','C2CC6E50AFA1ACCBEBF77CC519AAEB09F3BBAEBC','ARCHIVED','2015-07-13 23:49:22',0),('2015_09_28_00_characters_335.sql','F8682A431D50E54BDC4AC0E7DBED21AE8AAB6AD4','ARCHIVED','2015-09-28 21:00:00',0),('2015_08_26_00_characters_335.sql','C7D6A3A00FECA3EBFF1E71744CA40D3076582374','ARCHIVED','2015-08-26 21:00:00',0),('2015_10_06_00_characters.sql','16842FDD7E8547F2260D3312F53EFF8761EFAB35','ARCHIVED','2015-10-06 16:06:38',0),('2015_10_07_00_characters.sql','E15AB463CEBE321001D7BFDEA4B662FF618728FD','ARCHIVED','2015-10-07 23:32:00',0),('2015_10_12_00_characters.sql','D6F9927BDED72AD0A81D6EC2C6500CBC34A39FA2','ARCHIVED','2015-10-12 15:35:47',0),('2015_10_28_00_characters.sql','622A9CA8FCE690429EBE23BA071A37C7A007BF8B','ARCHIVED','2015-10-19 14:32:22',0),('2015_10_29_00_characters_335.sql','4555A7F35C107E54C13D74D20F141039ED42943E','ARCHIVED','2015-10-29 17:05:43',0),('2015_11_03_00_characters.sql','CC045717B8FDD9733351E52A5302560CD08AAD57','ARCHIVED','2015-10-12 15:23:33',0),('2015_11_07_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 00:42:36',94),('2016_02_10_00_characters.sql','F1B4DA202819CABC7319A4470A2D224A34609E97','ARCHIVED','2016-02-10 00:00:00',0),('2016_03_13_2016_01_05_00_characters.sql','0EAD24977F40DE2476B4567DA2B477867CC0DA1A','ARCHIVED','2016-03-13 20:03:56',0),('2016_04_11_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 03:18:17',0),('2016_09_13_00_characters.sql','27A04615B11B2CFC3A26778F52F74C071E4F9C54','ARCHIVED','2016-07-06 18:55:18',0),('2016_10_16_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-10-16 14:02:49',35),('2016_10_30_00_characters.sql','7E2D5B226907B5A9AF320797F46E86DC27B7EC90','ARCHIVED','2016-10-30 00:00:00',0),('2017_04_03_00_characters.sql','CB072C56692C9FBF170C4036F15773DD86D368B5','ARCHIVED','2017-04-03 00:00:00',0),('2017_04_12_00_characters.sql','4FE3C6866A6DCD4926D451F6009464D290C2EF1F','ARCHIVED','2017-04-12 00:00:00',0),('2017_04_12_01_characters.sql','5A8A1215E3A2356722F52CD7A64BBE03D21FBEA3','ARCHIVED','2017-04-12 00:00:00',0),('2017_04_19_00_characters.sql','CE06FA9005C8A8EE4BDD925520278A5D83E87485','ARCHIVED','2017-04-19 00:07:40',25),('2017_10_29_00_characters.sql','8CFC473E7E87E58C317A72016BF69E9050D3BC83','ARCHIVED','2017-04-19 00:07:40',25),('2017_11_27_00_characters.sql','6FF1F84B8985ADFC7FF97F0BF8E53403CF13C320','ARCHIVED','2017-11-27 22:08:42',0),('2018_01_13_00_characters.sql','E3C0DA9995BA71ED5A267294470CD03DC51862DD','ARCHIVED','2018-01-13 00:00:00',0),('2018_02_19_00_characters.sql','FE5C5F9B88F0791549DDE680942493781E2269E6','RELEASED','2018-02-18 19:49:38',0),('2018_04_24_00_characters.sql','77264AB7BEF421C0A4BB81EEAFD0D8C1CBCA840F','RELEASED','2018-06-16 09:10:31',53);
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates_include`
--

DROP TABLE IF EXISTS `updates_include`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates_include` (
  `path` varchar(200) NOT NULL COMMENT 'directory to include. $ means relative to the source directory.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if the directory contains released or archived updates.',
  PRIMARY KEY (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of directories where we want to include sql updates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates_include`
--

LOCK TABLES `updates_include` WRITE;
/*!40000 ALTER TABLE `updates_include` DISABLE KEYS */;
INSERT INTO `updates_include` VALUES ('$/sql/updates/characters','RELEASED'),('$/sql/custom/characters','RELEASED'),('$/sql/old/3.3.5a/characters','ARCHIVED');
/*!40000 ALTER TABLE `updates_include` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warden_action`
--

DROP TABLE IF EXISTS `warden_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warden_action` (
  `wardenId` smallint(5) unsigned NOT NULL,
  `action` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`wardenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warden_action`
--

LOCK TABLES `warden_action` WRITE;
/*!40000 ALTER TABLE `warden_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `warden_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worldstates`
--

DROP TABLE IF EXISTS `worldstates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worldstates` (
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` tinytext,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Variable Saves';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worldstates`
--

LOCK TABLES `worldstates` WRITE;
/*!40000 ALTER TABLE `worldstates` DISABLE KEYS */;
INSERT INTO `worldstates` VALUES (1,0,NULL),(2,0,NULL),(3,0,NULL),(4,0,NULL),(5,0,NULL),(6,0,NULL),(7,0,NULL),(8,0,NULL),(9,0,NULL),(10,0,NULL),(11,0,NULL),(12,0,NULL),(13,0,NULL),(14,1553295601,NULL),(15,0,NULL),(16,1553306401,NULL),(17,0,NULL),(18,0,NULL),(19,1553293489,NULL),(20,0,NULL),(21,0,NULL),(22,0,NULL),(23,0,NULL),(24,0,NULL),(25,1553293489,NULL),(26,0,NULL),(27,0,NULL),(28,0,NULL),(29,0,NULL),(30,1553293489,NULL),(31,0,NULL),(32,0,NULL),(33,0,NULL),(34,0,NULL),(35,0,NULL),(36,0,NULL),(37,0,NULL),(38,0,NULL),(39,1553293489,NULL),(40,0,NULL),(41,0,NULL),(42,0,NULL),(43,0,NULL),(44,0,NULL),(45,0,NULL),(46,0,NULL),(47,0,NULL),(48,0,NULL),(49,0,NULL),(50,0,NULL),(51,0,NULL),(52,0,NULL),(53,0,NULL),(54,0,NULL),(55,0,NULL),(56,0,NULL),(57,0,NULL),(58,0,NULL),(59,0,NULL),(60,1553293489,NULL),(61,0,NULL),(62,0,NULL),(63,0,NULL),(64,0,NULL),(65,1553309701,NULL),(66,0,NULL),(67,0,NULL),(68,1553309701,NULL),(69,0,NULL),(70,0,NULL),(71,0,NULL),(72,0,NULL),(73,0,NULL),(74,0,NULL),(75,0,NULL),(76,0,NULL),(3781,9000000,NULL),(3801,0,NULL),(3802,1,NULL),(20001,1529140231,'NextArenaPointDistributionTime'),(20002,1553895362,'NextWeeklyQuestResetTime'),(20003,1553317200,'NextBGRandomDailyResetTime'),(20004,0,'cleaning_flags'),(20006,1553317200,NULL),(20007,1554073200,NULL);
/*!40000 ALTER TABLE `worldstates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08 16:55:24
