-- MySQL dump 10.13  Distrib 5.7.21, for Linux (x86_64)
--
-- Host: localhost    Database: characters2
-- ------------------------------------------------------
-- Server version	5.7.21-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `LD_HabPJ`
--

DROP TABLE IF EXISTS `LD_HabPJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_HabPJ` (
  `ID` int(11) NOT NULL,
  `LD_PJ` varchar(50) NOT NULL,
  `Nivel` int(11) NOT NULL,
  UNIQUE KEY `ID` (`ID`,`LD_PJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_HabPJ`
--

LOCK TABLES `LD_HabPJ` WRITE;
/*!40000 ALTER TABLE `LD_HabPJ` DISABLE KEYS */;
/*!40000 ALTER TABLE `LD_HabPJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_Habilidades`
--

DROP TABLE IF EXISTS `LD_Habilidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_Habilidades` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(50) NOT NULL,
  `Descrip` varchar(255) NOT NULL DEFAULT '0',
  `Ata_DESTRE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_PERCEP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_AGILID` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_SABIDU` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_FUERZA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_INTELE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Ata_CONSTI` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_DESTRE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_PERCEP` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_AGILID` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_SABIDU` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_FUERZA` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_INTELE` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Def_CONSTI` decimal(10,2) NOT NULL DEFAULT '0.00',
  `FunctionType` varchar(50) NOT NULL,
  `Dif_TIPI` int(11) NOT NULL DEFAULT '0',
  `Cos_MANA` int(11) NOT NULL DEFAULT '0',
  `Cos_ENER` int(11) NOT NULL DEFAULT '0',
  `Icono` varchar(255) NOT NULL,
  `OnlyAta` tinyint(1) NOT NULL DEFAULT '0',
  `OnlyDef` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_Habilidades`
--

LOCK TABLES `LD_Habilidades` WRITE;
/*!40000 ALTER TABLE `LD_Habilidades` DISABLE KEYS */;
INSERT INTO `LD_Habilidades` VALUES (1,'Combate sin armas','Define tu destreza en combatir cuerpo a cuerpo tan solo con tus manos y el resto de tu anatomia',0.30,0.10,0.20,0.00,0.30,0.00,0.00,0.30,0.20,0.30,0.00,0.20,0.00,0.00,'Basic',0,0,2,'ability_warrior_bloodfrenzy',0,0),(2,'Golpe de espada (entrenamiento)','Sirve para incrementar tu destreza en el manejo de la espada',0.50,0.10,0.20,0.00,0.20,0.00,0.00,1.00,0.00,0.00,0.00,0.00,0.00,0.00,'Basic',0,0,2,'ability_meleedamage',0,0),(3,'Practicas de tiro con arco','Sirve para incrementar tu destreza en el tiro con arco',0.50,0.30,0.00,0.00,0.20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'Dificultad',10,0,1,'inv_weapon_bow_02',0,0),(4,'Espada corta - Desviar','Desvías el ataque con un hábil movimiento de muñeca.',0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.40,0.00,0.30,0.00,0.30,0.00,0.00,'Basic',0,0,5,'ability_dualwield',0,0),(5,'Espada corta - Toque ligero','Un suave estoque para desorientar al contrario',0.30,0.10,0.40,0.00,0.20,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'Basic',0,0,5,'inv_weapon_shortblade_24',0,0);
/*!40000 ALTER TABLE `LD_Habilidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_PlayerPJ`
--

DROP TABLE IF EXISTS `LD_PlayerPJ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_PlayerPJ` (
  `LD_Player` varchar(50) NOT NULL,
  `LD_PJ` varchar(50) NOT NULL,
  UNIQUE KEY `IDX_PlayerPJ` (`LD_PJ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_PlayerPJ`
--

LOCK TABLES `LD_PlayerPJ` WRITE;
/*!40000 ALTER TABLE `LD_PlayerPJ` DISABLE KEYS */;
INSERT INTO `LD_PlayerPJ` VALUES ('SUBIGEMMA','Ahoniis'),('SUBIGEMMA','Bulldoza'),('NUVALIA','Eolion'),('SUBIGEMMA','Giselle');
/*!40000 ALTER TABLE `LD_PlayerPJ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SessionVars`
--

DROP TABLE IF EXISTS `LD_SessionVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SessionVars` (
  `LD_PJ` varchar(50) NOT NULL,
  `LD_INDEX` varchar(50) NOT NULL,
  `LD_VALUE` varchar(255) NOT NULL,
  `LD_TYPE` varchar(10) NOT NULL,
  `LD_DATEUP` bigint(14) NOT NULL,
  PRIMARY KEY (`LD_PJ`,`LD_INDEX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SessionVars`
--

LOCK TABLES `LD_SessionVars` WRITE;
/*!40000 ALTER TABLE `LD_SessionVars` DISABLE KEYS */;
INSERT INTO `LD_SessionVars` VALUES ('Ahoniis','MAGILID','0','ATRIBUTO',20180713121417),('Ahoniis','MCONSTI','0','ATRIBUTO',20180713121417),('Ahoniis','MDESTRE','0','ATRIBUTO',20180713121417),('Ahoniis','MFUERZA','0','ATRIBUTO',20180713121417),('Ahoniis','MINTELE','0','ATRIBUTO',20180713121417),('Ahoniis','MPERCEP','0','ATRIBUTO',20180713121417),('Ahoniis','MSABIDU','0','ATRIBUTO',20180713121417),('Bulldoza','MAGILID','0','ATRIBUTO',20180713120405),('Bulldoza','MCONSTI','0','ATRIBUTO',20180713120405),('Bulldoza','MDESTRE','0','ATRIBUTO',20180713120405),('Bulldoza','MFUERZA','0','ATRIBUTO',20180713120405),('Bulldoza','MINTELE','0','ATRIBUTO',20180713120405),('Bulldoza','MPERCEP','0','ATRIBUTO',20180713120405),('Bulldoza','MSABIDU','0','ATRIBUTO',20180713120405),('Eolion','MAGILID','0','ATRIBUTO',20180716170713),('Eolion','MCONSTI','0','ATRIBUTO',20180716170713),('Eolion','MDESTRE','0','ATRIBUTO',20180716170713),('Eolion','MFUERZA','0','ATRIBUTO',20180716170713),('Eolion','MINTELE','0','ATRIBUTO',20180716170713),('Eolion','MPERCEP','0','ATRIBUTO',20180716170713),('Eolion','MSABIDU','0','ATRIBUTO',20180716170713),('Giselle','MAGILID','0','ATRIBUTO',20180713121624),('Giselle','MCONSTI','0','ATRIBUTO',20180713121624),('Giselle','MDESTRE','0','ATRIBUTO',20180713121624),('Giselle','MFUERZA','0','ATRIBUTO',20180713121624),('Giselle','MINTELE','0','ATRIBUTO',20180713121624),('Giselle','MPERCEP','0','ATRIBUTO',20180713121624),('Giselle','MSABIDU','0','ATRIBUTO',20180713121624);
/*!40000 ALTER TABLE `LD_SessionVars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SysMessages`
--

DROP TABLE IF EXISTS `LD_SysMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SysMessages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `LD_Message` varchar(255) NOT NULL,
  `LD_Sender` varchar(50) NOT NULL,
  `LD_Recv` varchar(50) NOT NULL,
  `LD_TimeStamp` bigint(14) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SysMessages`
--

LOCK TABLES `LD_SysMessages` WRITE;
/*!40000 ALTER TABLE `LD_SysMessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `LD_SysMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LD_SystemVars`
--

DROP TABLE IF EXISTS `LD_SystemVars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LD_SystemVars` (
  `LD_NAME` varchar(50) NOT NULL,
  `LD_TYPE` varchar(50) NOT NULL,
  `LD_SUBTYPE` varchar(100) NOT NULL,
  `LD_VALUE` varchar(100) NOT NULL,
  PRIMARY KEY (`LD_NAME`,`LD_TYPE`,`LD_SUBTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LD_SystemVars`
--

LOCK TABLES `LD_SystemVars` WRITE;
/*!40000 ALTER TABLE `LD_SystemVars` DISABLE KEYS */;
INSERT INTO `LD_SystemVars` VALUES ('AGILID_MAX','ATTRSETS','BloodElf','7'),('AGILID_MAX','ATTRSETS','Human','7'),('AGILID_MIN','ATTRSETS','BloodElf','5'),('AGILID_MIN','ATTRSETS','Human','5'),('CONSTI_MAX','ATTRSETS','BloodElf','7'),('CONSTI_MAX','ATTRSETS','Human','7'),('CONSTI_MIN','ATTRSETS','BloodElf','5'),('CONSTI_MIN','ATTRSETS','Human','5'),('DESTRE_MAX','ATTRSETS','BloodElf','7'),('DESTRE_MAX','ATTRSETS','Human','7'),('DESTRE_MIN','ATTRSETS','BloodElf','5'),('DESTRE_MIN','ATTRSETS','Human','5'),('FUERZA_MAX','ATTRSETS','BloodElf','7'),('FUERZA_MAX','ATTRSETS','Human','7'),('FUERZA_MIN','ATTRSETS','BloodElf','5'),('FUERZA_MIN','ATTRSETS','Human','5'),('INTELE_MAX','ATTRSETS','BloodElf','7'),('INTELE_MAX','ATTRSETS','Human','7'),('INTELE_MIN','ATTRSETS','BloodElf','5'),('INTELE_MIN','ATTRSETS','Human','5'),('MVEP','SYS','SYS','1'),('MVHP','SYS','SYS','2'),('MVMP','SYS','SYS','2'),('PERCEP_MAX','ATTRSETS','BloodElf','7'),('PERCEP_MAX','ATTRSETS','Human','7'),('PERCEP_MIN','ATTRSETS','BloodElf','5'),('PERCEP_MIN','ATTRSETS','Human','5'),('SABIDU_MAX','ATTRSETS','BloodElf','7'),('SABIDU_MAX','ATTRSETS','Human','7'),('SABIDU_MIN','ATTRSETS','BloodElf','5'),('SABIDU_MIN','ATTRSETS','Human','5');
/*!40000 ALTER TABLE `LD_SystemVars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_data`
--

DROP TABLE IF EXISTS `account_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_data` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`accountId`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_data`
--

LOCK TABLES `account_data` WRITE;
/*!40000 ALTER TABLE `account_data` DISABLE KEYS */;
INSERT INTO `account_data` VALUES (1,0,1543652862,'SET scriptErrors \"1\"\nSET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##M##%##&##$##E##8##(##*##+##7##Z##[##;##)##\\##.##/##^##K##-##1##,##:##6##<##A##B##Q##5##O##P##Y##F##]##X##U##4##C##_##N##?##9##I##D##@##0##3##J##V##L##=##G\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\n'),(1,2,1543652863,'BINDINGMODE 0\r\nbind W TOGGLERUN\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind < TOGGLEAUTORUN\r\n'),(1,4,1543652864,'MACRO 1 \"m\" Spell_Nature_Polymorph_Cow\r\n/myaura 23228\r\nEND\r\n'),(2,0,1544172460,'SET scriptErrors \"1\"\nSET flaggedTutorials \"v##P##C##X##U##E\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraView \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showNewbieTips \"0\"\nSET showTutorials \"0\"\nSET talentFrameShown \"1\"\n'),(2,2,1544172461,'BINDINGMODE 0\r\nbind W TOGGLERUN\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind < TOGGLEAUTORUN\r\n'),(2,4,1544172462,'MACRO 14 \"A54844\" Spell_Holy_PrayerofShadowProtection\r\n.aura 54844\r\nEND\r\nMACRO 6 \"C1\" Ability_PoisonArrow\r\n.gob add 185475\r\nEND\r\nMACRO 7 \"C2\" Ability_PoisonArrow\r\n.gob add 178226  \r\nEND\r\nMACRO 3 \"del\" Ability_Creature_Cursed_02\r\n.npc del\r\nEND\r\nMACRO 5 \"DTFRAME\" Ability_Druid_EclipseOrange\r\n/dtframe stack on\r\nEND\r\nMACRO 13 \"fly\" Ability_Hunter_Pet_Wasp\r\n.gm fly on\r\nEND\r\nMACRO 8 \"H1\" Ability_Creature_Disease_05\r\n.npc add 16865\r\nEND\r\nMACRO 9 \"H2\" Ability_Creature_Disease_05\r\n.npc add 23783\r\nEND\r\nMACRO 11 \"H3\" Ability_Creature_Disease_05\r\n.npc add 27517\r\nEND\r\nMACRO 12 \"H4\" Ability_Creature_Disease_05\r\n.npc add 27517\r\nEND\r\nMACRO 4 \"MOV\" Ability_Druid_Eclipse\r\n.npc move\r\nEND\r\nMACRO 2 \"S1\" Ability_Creature_Cursed_04\r\n.mod speed 1\r\nEND\r\nMACRO 1 \"s5\" Ability_Creature_Cursed_04\r\n.mod speed 5\r\nEND\r\nMACRO 10 \"TAR\" Ability_Creature_Cursed_01\r\n.gob target\r\nEND\r\nMACRO 15 \"UNA\" Spell_Holy_PrayerOfHealing\r\n.unaura all\r\nEND\r\n'),(3,0,1532863669,'SET flaggedTutorials \"v##M##%##&##$##5##:##<##(##6##Z##1##9##I##D##0##J##V##[##A##B##)##\\##C##*##Q##7##?##@##Y##+##4##K##X##;##3##,##O##^##]##U##.##/\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\n'),(3,4,1532863670,'MACRO 1 \"apariencia\" Ability_Creature_Cursed_01\r\n.mod speed 5\r\n.gm fly on\r\nEND\r\nMACRO 6 \"ataque 2 manos\" Ability_ThunderClap\r\n.npc playemote 38\r\nEND\r\nMACRO 5 \"ataque una mano\" Ability_SteelMelee\r\n.npc playemote 36\r\nEND\r\nMACRO 2 \"Borrar NPC\" INV_Misc_QuestionMark\r\n.npc del\r\nEND\r\nMACRO 3 \"NPC Posses\" Ability_Hunter_GoForTheThroat\r\n.posses\r\nEND\r\nMACRO 4 \"npc unposses\" Ability_Hunter_BeastSoothe\r\n.unpossess\r\nEND\r\n'),(8,0,1524909055,'SET flaggedTutorials \"v##:##M##%##&##$##4##Z##1##9##I##D##0##J##V##K##X##[##A##B##=##7##)##+##;##-##,##\\##6##5##F##(##3##*##Y##Q##]##W##C##?##^##E##@##U\"\nSET profanityFilter \"0\"\nSET lockActionBars \"0\"\nSET alwaysShowActionBars \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\nSET ShowAllSpellRanks \"0\"\n'),(8,2,1524909056,'BINDINGMODE 0\r\nbind NUMPADPLUS CAMERAZOOMIN\r\nbind NUMPADMINUS CAMERAZOOMOUT\r\nbind MOUSEWHEELUP NONE\r\nbind MOUSEWHEELDOWN NONE\r\n'),(9,0,1525467323,'SET flaggedTutorials \"v##M##%##&##$##[##E##3##Q##:##)##6##5##4##(##\\##Y##7##K##+##,##X##A##B##;##O##?\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),(9,2,1525467324,'BINDINGMODE 0\r\nbind NUMLOCK NONE\r\nbind BUTTON4 TOGGLEAUTORUN\r\nbind NUMPADDIVIDE NONE\r\nbind HOME TOGGLEAUTORUN\r\nbind < TOGGLERUN\r\n'),(12,0,1523640992,'SET flaggedTutorials \"v##M##%##&##$##:##7##(##K##+##6##Q##[##)##5##\\##4##A##B##,##U\"\nSET cameraDistanceMaxFactor \"1\"\nSET talentFrameShown \"1\"\n'),(23,0,1533828192,'SET autoLootDefault \"1\"\nSET displayFreeBagSlots \"1\"\nSET flaggedTutorials \"v##R##_##P##M##%##&##$##(##A##B##7\"\nSET profanityFilter \"0\"\nSET alwaysShowActionBars \"1\"\nSET UnitNameOwn \"1\"\nSET UnitNameEnemyGuardianName \"1\"\nSET UnitNameEnemyTotemName \"1\"\nSET UnitNameFriendlyGuardianName \"1\"\nSET UnitNameFriendlyTotemName \"1\"\nSET fctRepChanges \"1\"\nSET cameraDistanceMaxFactor \"1\"\nSET showItemLevel \"1\"\nSET showTutorials \"0\"\nSET serviceTypeFilter \"1\"\nSET talentFrameShown \"1\"\nSET threatShowNumeric \"1\"\nSET ShowAllSpellRanks \"0\"\n'),(23,2,1533827620,'BINDINGMODE 0\r\nbind 1 ACTIONBUTTON1\r\nbind CTRL-1 MULTIACTIONBAR1BUTTON1\r\nbind CTRL-2 MULTIACTIONBAR1BUTTON2\r\nbind CTRL-3 MULTIACTIONBAR1BUTTON3\r\nbind CTRL-4 MULTIACTIONBAR1BUTTON4\r\nbind CTRL-5 MULTIACTIONBAR1BUTTON5\r\nbind CTRL-6 MULTIACTIONBAR1BUTTON6\r\n'),(23,4,1533827621,'MACRO 12 \" Adds\" INV_Misc_QuestionMark\r\n/y ADDS!\r\nEND\r\nMACRO 20 \"100\" Ability_Creature_Cursed_04\r\n/DADOS 100\r\nEND\r\nMACRO 3 \"Adds\" Ability_Creature_Disease_04\r\n/ab adds\r\nEND\r\nMACRO 15 \"Botas1\" Ability_Rogue_Sprint\r\n/use Sandalias de Consagración \r\n/d ¡Adelante Gadgeto botas!\r\nEND\r\nMACRO 13 \"Cambio\" Ability_CheapShot\r\n/y ¡CAMBIO!\r\nEND\r\nMACRO 5 \"Centro /Y\" Ability_Creature_Cursed_04\r\n/y TODOS AL CENTRO\r\nEND\r\nMACRO 22 \"colera\" Ability_Creature_Disease_05\r\n/use Cólera Vengativa\r\n/y ¡Redbull te da alas!\r\nEND\r\nMACRO 11 \"Controlado\" INV_Misc_QuestionMark\r\n/y CONTROLADO!!\r\nEND\r\nMACRO 16 \"coña moto 2\" Ability_Mount_Dreadsteed\r\nEND\r\nMACRO 14 \"coñas moto 1\" Ability_Mount_Charger\r\n/d Pero qué... ¿¡Depósito de reserva?! ¡Tenía que haberlo llenado  en Orgrimmar, mierda!\r\nEND\r\nMACRO 1 \"Kiss\" Ability_Creature_Poison_05\r\n/kiss\r\nEND\r\nMACRO 6 \"Orbes\" Ability_Creature_Cursed_01\r\n/y RANGOS ORBES\r\nEND\r\nMACRO 19 \"Pestes\" Ability_Creature_Disease_03\r\n/castsequence reset=5 <Toque vampírico>,<Peste devoradora>,<Palabra de las Sombras: dolor>\r\nEND\r\nMACRO 18 \"pollo\" Ability_Creature_Poison_03\r\n/gallina\r\nEND\r\nMACRO 21 \"pompaso\" Ability_Ambush\r\n/cast Mano de protección\r\n/use Piedra de Hogar\r\nEND\r\nMACRO 4 \"todos centro\" Ability_Creature_Cursed_04\r\n/ab Todos al centro\r\nEND\r\nMACRO 2 \"Volcanes\" INV_Misc_QuestionMark\r\n/y Volcanes\r\nEND\r\nMACRO 17 \"¡Varita!\" Spell_Nature_Brilliance\r\n/use Disparar\r\n/run \r\nEND\r\n');
/*!40000 ALTER TABLE `account_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_instance_times`
--

DROP TABLE IF EXISTS `account_instance_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_instance_times` (
  `accountId` int(10) unsigned NOT NULL,
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0',
  `releaseTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`,`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_instance_times`
--

LOCK TABLES `account_instance_times` WRITE;
/*!40000 ALTER TABLE `account_instance_times` DISABLE KEYS */;
INSERT INTO `account_instance_times` VALUES (1,1,1529734267),(2,1,1529734260),(3,1,1525292769);
/*!40000 ALTER TABLE `account_instance_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_tutorial`
--

DROP TABLE IF EXISTS `account_tutorial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_tutorial` (
  `accountId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `tut0` int(10) unsigned NOT NULL DEFAULT '0',
  `tut1` int(10) unsigned NOT NULL DEFAULT '0',
  `tut2` int(10) unsigned NOT NULL DEFAULT '0',
  `tut3` int(10) unsigned NOT NULL DEFAULT '0',
  `tut4` int(10) unsigned NOT NULL DEFAULT '0',
  `tut5` int(10) unsigned NOT NULL DEFAULT '0',
  `tut6` int(10) unsigned NOT NULL DEFAULT '0',
  `tut7` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`accountId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_tutorial`
--

LOCK TABLES `account_tutorial` WRITE;
/*!40000 ALTER TABLE `account_tutorial` DISABLE KEYS */;
INSERT INTO `account_tutorial` VALUES (1,4227776503,133570543,0,0,0,0,0,0),(2,4294885367,134091751,0,0,0,0,0,0),(3,3924210103,132516577,0,0,0,0,0,0),(12,205783047,512,0,0,0,0,0,0),(23,1611137047,512,0,0,0,0,0,0);
/*!40000 ALTER TABLE `account_tutorial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addons`
--

DROP TABLE IF EXISTS `addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addons` (
  `name` varchar(120) NOT NULL DEFAULT '',
  `crc` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Addons';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addons`
--

LOCK TABLES `addons` WRITE;
/*!40000 ALTER TABLE `addons` DISABLE KEYS */;
INSERT INTO `addons` VALUES ('Blizzard_AchievementUI',1276933997),('Blizzard_ArenaUI',1276933997),('Blizzard_AuctionUI',1276933997),('Blizzard_BarbershopUI',1276933997),('Blizzard_BattlefieldMinimap',1276933997),('Blizzard_BindingUI',1276933997),('Blizzard_Calendar',1276933997),('Blizzard_CombatLog',1276933997),('Blizzard_CombatText',1276933997),('Blizzard_DebugTools',1276933997),('Blizzard_GlyphUI',1276933997),('Blizzard_GMChatUI',1276933997),('Blizzard_GMSurveyUI',1276933997),('Blizzard_GuildBankUI',1276933997),('Blizzard_InspectUI',1276933997),('Blizzard_ItemSocketingUI',1276933997),('Blizzard_MacroUI',1276933997),('Blizzard_RaidUI',1276933997),('Blizzard_TalentUI',1276933997),('Blizzard_TimeManager',1276933997),('Blizzard_TokenUI',1276933997),('Blizzard_TradeSkillUI',1276933997),('Blizzard_TrainerUI',1276933997);
/*!40000 ALTER TABLE `addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team`
--

DROP TABLE IF EXISTS `arena_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `captainGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rating` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  `backgroundColor` int(10) unsigned NOT NULL DEFAULT '0',
  `emblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `emblemColor` int(10) unsigned NOT NULL DEFAULT '0',
  `borderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `borderColor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team`
--

LOCK TABLES `arena_team` WRITE;
/*!40000 ALTER TABLE `arena_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team_member`
--

DROP TABLE IF EXISTS `arena_team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team_member` (
  `arenaTeamId` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `weekGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `weekWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonGames` smallint(5) unsigned NOT NULL DEFAULT '0',
  `seasonWins` smallint(5) unsigned NOT NULL DEFAULT '0',
  `personalRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenaTeamId`,`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team_member`
--

LOCK TABLES `arena_team_member` WRITE;
/*!40000 ALTER TABLE `arena_team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auctionbidders`
--

DROP TABLE IF EXISTS `auctionbidders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auctionbidders` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `bidderguid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`bidderguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auctionbidders`
--

LOCK TABLES `auctionbidders` WRITE;
/*!40000 ALTER TABLE `auctionbidders` DISABLE KEYS */;
/*!40000 ALTER TABLE `auctionbidders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auctionhouse`
--

DROP TABLE IF EXISTS `auctionhouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auctionhouse` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `houseid` tinyint(3) unsigned NOT NULL DEFAULT '7',
  `itemguid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemowner` int(10) unsigned NOT NULL DEFAULT '0',
  `buyoutprice` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `buyguid` int(10) unsigned NOT NULL DEFAULT '0',
  `lastbid` int(10) unsigned NOT NULL DEFAULT '0',
  `startbid` int(10) unsigned NOT NULL DEFAULT '0',
  `deposit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_guid` (`itemguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auctionhouse`
--

LOCK TABLES `auctionhouse` WRITE;
/*!40000 ALTER TABLE `auctionhouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `auctionhouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banned_addons`
--

DROP TABLE IF EXISTS `banned_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banned_addons` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Version` varchar(255) NOT NULL DEFAULT '',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `idx_name_ver` (`Name`,`Version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banned_addons`
--

LOCK TABLES `banned_addons` WRITE;
/*!40000 ALTER TABLE `banned_addons` DISABLE KEYS */;
/*!40000 ALTER TABLE `banned_addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `battleground_deserters`
--

DROP TABLE IF EXISTS `battleground_deserters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `battleground_deserters` (
  `guid` int(10) unsigned NOT NULL COMMENT 'characters.guid',
  `type` tinyint(3) unsigned NOT NULL COMMENT 'type of the desertion',
  `datetime` datetime NOT NULL COMMENT 'datetime of the desertion'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `battleground_deserters`
--

LOCK TABLES `battleground_deserters` WRITE;
/*!40000 ALTER TABLE `battleground_deserters` DISABLE KEYS */;
/*!40000 ALTER TABLE `battleground_deserters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bugreport`
--

DROP TABLE IF EXISTS `bugreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bugreport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Debug System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bugreport`
--

LOCK TABLES `bugreport` WRITE;
/*!40000 ALTER TABLE `bugreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_events` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `creator` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '4',
  `dungeon` int(10) NOT NULL DEFAULT '-1',
  `eventtime` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  `time2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_invites`
--

DROP TABLE IF EXISTS `calendar_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar_invites` (
  `id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `event` bigint(20) unsigned NOT NULL DEFAULT '0',
  `invitee` int(10) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `statustime` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_invites`
--

LOCK TABLES `calendar_invites` WRITE;
/*!40000 ALTER TABLE `calendar_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels` (
  `name` varchar(128) NOT NULL,
  `team` int(10) unsigned NOT NULL,
  `announce` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ownership` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `password` varchar(32) DEFAULT NULL,
  `bannedList` text,
  `lastUsed` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`,`team`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Channel System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_account_data`
--

DROP TABLE IF EXISTS `character_account_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_account_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`guid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_account_data`
--

LOCK TABLES `character_account_data` WRITE;
/*!40000 ALTER TABLE `character_account_data` DISABLE KEYS */;
INSERT INTO `character_account_data` VALUES (2,1,1531498456,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v$(M$(\\$).\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.003997\"\nSET cameraSavedPitch \"9.150003\"\nSET nameplateShowEnemies \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_RANGED_COMBAT\"\nSET showTokenFrame \"1\"\nSET minimapTrackedInfo \"MINIMAP_TRACKING_TRAINER_CLASS\"\n'),(2,7,1523393545,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(5,1,1532863685,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"6.997199\"\nSET cameraSavedPitch \"20.099948\"\nSET showKeyring \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(5,7,1525288468,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(8,1,1525004526,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"4.550402\"\nSET cameraSavedPitch \"5.400004\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(8,7,1525003065,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(10,1,1525016131,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"9.002400\"\nSET cameraSavedPitch \"16.000005\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(10,7,1525016132,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(12,1,1544170432,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v#&h#)^#)Q#%&#%>#)@#%/\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"-2.850000\"\nSET nameplateShowEnemies \"1\"\nSET showKeyring \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_RANGED_COMBAT\"\n'),(12,7,1543652875,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nPOSITION BOTTOMLEFT 0.033175 0.156398\nDIMENSIONS 430.000031 120.000000\n\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(14,1,1532863637,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"18.450003\"\nSET nameplateShowEnemies \"1\"\nSET showKeyring \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(14,7,1529435820,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 52428803\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 18874371\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(15,1,1531498583,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v#|h$.D\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"6.549600\"\nSET cameraSavedPitch \"9.499998\"\nSET nameplateShowEnemies \"1\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(15,7,1531498584,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(16,1,1533718233,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"5.550000\"\nSET cameraSavedPitch \"22.599997\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_SPELL_COMBAT\"\n'),(16,7,1533718234,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 35651587\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n'),(17,1,1533828193,'SET questLogCollapseFilter \"-1\"\nSET trackedQuests \"v\"\nSET trackedAchievements \"v\"\nSET cameraSavedDistance \"15.000000\"\nSET cameraSavedPitch \"25.074414\"\nSET playerStatLeftDropdown \"PLAYERSTAT_BASE_STATS\"\nSET playerStatRightDropdown \"PLAYERSTAT_MELEE_COMBAT\"\n'),(17,7,1533828194,'VERSION 5\n\nADDEDVERSION 13\n\nOPTION_GUILD_RECRUITMENT_CHANNEL AUTO\n\nCHANNELS\nEND\n\nZONECHANNELS 35651587\n\nCOLORS\nSYSTEM 255 255 0 N\nSAY 255 255 255 N\nPARTY 170 170 255 N\nRAID 255 127 0 N\nGUILD 64 255 64 N\nOFFICER 64 192 64 N\nYELL 255 64 64 N\nWHISPER 255 128 255 N\nWHISPER_FOREIGN 255 128 255 N\nWHISPER_INFORM 255 128 255 N\nEMOTE 255 128 64 N\nTEXT_EMOTE 255 128 64 N\nMONSTER_SAY 255 255 159 N\nMONSTER_PARTY 170 170 255 N\nMONSTER_YELL 255 64 64 N\nMONSTER_WHISPER 255 181 235 N\nMONSTER_EMOTE 255 128 64 N\nCHANNEL 255 192 192 N\nCHANNEL_JOIN 192 128 128 N\nCHANNEL_LEAVE 192 128 128 N\nCHANNEL_LIST 192 128 128 N\nCHANNEL_NOTICE 192 192 192 N\nCHANNEL_NOTICE_USER 192 192 192 N\nAFK 255 128 255 N\nDND 255 128 255 N\nIGNORED 255 0 0 N\nSKILL 85 85 255 N\nLOOT 0 170 0 N\nMONEY 255 255 0 N\nOPENING 128 128 255 N\nTRADESKILLS 255 255 255 N\nPET_INFO 128 128 255 N\nCOMBAT_MISC_INFO 128 128 255 N\nCOMBAT_XP_GAIN 111 111 255 N\nCOMBAT_HONOR_GAIN 224 202 10 N\nCOMBAT_FACTION_CHANGE 128 128 255 N\nBG_SYSTEM_NEUTRAL 255 120 10 N\nBG_SYSTEM_ALLIANCE 0 174 239 N\nBG_SYSTEM_HORDE 255 0 0 N\nRAID_LEADER 255 72 9 N\nRAID_WARNING 255 72 0 N\nRAID_BOSS_EMOTE 255 221 0 N\nRAID_BOSS_WHISPER 255 221 0 N\nFILTERED 255 0 0 N\nBATTLEGROUND 255 127 0 N\nBATTLEGROUND_LEADER 255 219 183 N\nRESTRICTED 255 0 0 N\nBATTLENET 255 255 255 N\nACHIEVEMENT 255 255 0 N\nGUILD_ACHIEVEMENT 64 255 64 N\nARENA_POINTS 255 255 255 N\nPARTY_LEADER 118 200 255 N\nTARGETICONS 255 255 0 N\nBN_WHISPER 0 255 246 N\nBN_WHISPER_INFORM 0 255 246 N\nBN_CONVERSATION 0 177 240 N\nBN_CONVERSATION_NOTICE 0 177 240 N\nBN_CONVERSATION_LIST 0 177 240 N\nBN_INLINE_TOAST_ALERT 130 197 255 N\nBN_INLINE_TOAST_BROADCAST 130 197 255 N\nBN_INLINE_TOAST_BROADCAST_INFORM 130 197 255 N\nBN_INLINE_TOAST_CONVERSATION 130 197 255 N\nCHANNEL1 255 192 192 N\nCHANNEL2 255 192 192 N\nCHANNEL3 255 192 192 N\nCHANNEL4 255 192 192 N\nCHANNEL5 255 192 192 N\nCHANNEL6 255 192 192 N\nCHANNEL7 255 192 192 N\nCHANNEL8 255 192 192 N\nCHANNEL9 255 192 192 N\nCHANNEL10 255 192 192 N\nEND\n\nWINDOW 1\nNAME General\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 1\nSHOWN 1\nMESSAGES\nSYSTEM\nSYSTEM_NOMENU\nSAY\nEMOTE\nYELL\nWHISPER\nPARTY\nPARTY_LEADER\nRAID\nRAID_LEADER\nRAID_WARNING\nBATTLEGROUND\nBATTLEGROUND_LEADER\nGUILD\nOFFICER\nMONSTER_SAY\nMONSTER_YELL\nMONSTER_EMOTE\nMONSTER_WHISPER\nMONSTER_BOSS_EMOTE\nMONSTER_BOSS_WHISPER\nERRORS\nAFK\nDND\nIGNORED\nBG_HORDE\nBG_ALLIANCE\nBG_NEUTRAL\nCOMBAT_FACTION_CHANGE\nSKILL\nLOOT\nMONEY\nCHANNEL\nACHIEVEMENT\nGUILD_ACHIEVEMENT\nTARGETICONS\nBN_WHISPER\nBN_WHISPER_INFORM\nBN_CONVERSATION\nBN_INLINE_TOAST_ALERT\nEND\n\nCHANNELS\nBuscarGrupo\nEND\n\nZONECHANNELS 2097155\n\nEND\n\nWINDOW 2\nNAME Registro de combate\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 2\nSHOWN 0\nMESSAGES\nOPENING\nTRADESKILLS\nPET_INFO\nCOMBAT_XP_GAIN\nCOMBAT_HONOR_GAIN\nCOMBAT_MISC_INFO\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 3\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 4\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 5\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 6\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 7\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 8\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 9\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\nWINDOW 10\nSIZE 0\nCOLOR 0 0 0 40\nLOCKED 1\nUNINTERACTABLE 0\nDOCKED 0\nSHOWN 0\nMESSAGES\nEND\n\nCHANNELS\nEND\n\nZONECHANNELS 0\n\nEND\n\n');
/*!40000 ALTER TABLE `character_account_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_achievement`
--

DROP TABLE IF EXISTS `character_achievement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_achievement` (
  `guid` int(10) unsigned NOT NULL,
  `achievement` smallint(5) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`achievement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_achievement`
--

LOCK TABLES `character_achievement` WRITE;
/*!40000 ALTER TABLE `character_achievement` DISABLE KEYS */;
INSERT INTO `character_achievement` VALUES (2,6,1523396705),(2,503,1523398623),(2,522,1523465310),(2,1017,1523464370),(2,1700,1523464356),(2,4785,1523396021),(3,457,1523467334),(3,462,1523467334),(3,1411,1523467334),(4,459,1523567789),(4,1408,1523567789),(5,6,1524923122),(5,7,1524923122),(5,8,1524923122),(5,9,1524923122),(5,10,1524923122),(5,11,1524923122),(5,12,1524923122),(5,13,1524923122),(5,522,1524990274),(5,621,1524927946),(5,2116,1524927943),(8,461,1523804156),(8,1409,1523804156),(12,6,1529255043),(12,7,1529339312),(12,8,1529832173),(12,9,1544173216),(12,116,1529333058),(12,121,1529344279),(12,122,1529344663),(12,123,1544172085),(12,126,1531296785),(12,131,1529334164),(12,132,1529345256),(12,133,1531293674),(12,153,1529743188),(12,503,1529256718),(12,504,1529334638),(12,505,1531777207),(12,621,1530716635),(12,633,1529731408),(12,731,1529346141),(12,732,1531291629),(12,860,1529307974),(12,889,1544174897),(12,891,1529402161),(12,1556,1531296437),(12,1557,1531296820),(12,1795,1544172085),(14,6,1529435816),(14,7,1529435816),(14,8,1529435816),(14,9,1529435816),(14,10,1529435816),(14,11,1529438275),(14,12,1529438275),(14,13,1529438275),(14,131,1529435816),(14,132,1529435816),(14,133,1529435816),(14,633,1529731408),(14,868,1544175396),(14,889,1529436646),(14,891,1529436646),(14,1407,1529438275),(16,6,1533718247),(16,7,1533718247),(16,8,1533718247),(16,9,1533718247),(16,10,1533718247),(16,11,1533718247),(16,12,1533718247),(16,13,1533718247),(16,466,1533718247),(16,889,1533718261),(16,890,1533718261),(16,891,1533718261);
/*!40000 ALTER TABLE `character_achievement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_achievement_progress`
--

DROP TABLE IF EXISTS `character_achievement_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_achievement_progress` (
  `guid` int(10) unsigned NOT NULL,
  `criteria` smallint(5) unsigned NOT NULL,
  `counter` int(10) unsigned NOT NULL,
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_achievement_progress`
--

LOCK TABLES `character_achievement_progress` WRITE;
/*!40000 ALTER TABLE `character_achievement_progress` DISABLE KEYS */;
INSERT INTO `character_achievement_progress` VALUES (2,34,10,1523396705),(2,35,17,1529052474),(2,36,17,1529052474),(2,37,17,1529052474),(2,38,17,1529052474),(2,39,17,1529052474),(2,40,17,1529052474),(2,41,17,1529052474),(2,73,80,1529055154),(2,111,5,1523395084),(2,162,110992,1529055003),(2,167,1,1523383901),(2,168,75,1523399603),(2,230,50,1523398623),(2,231,80,1529055154),(2,232,80,1529055154),(2,233,80,1529055154),(2,234,80,1529055154),(2,236,80,1529055154),(2,612,75,1523399603),(2,613,75,1523399603),(2,614,75,1523399603),(2,615,75,1523399603),(2,623,75,1523391819),(2,625,75,1523391804),(2,641,1,1523383901),(2,651,85,1529054285),(2,653,78,1529054441),(2,753,15,1523386952),(2,754,38,1523395845),(2,755,1,1523461265),(2,756,1,1523383901),(2,832,1,1523465577),(2,855,75,1523391819),(2,857,75,1523391804),(2,866,75,1523391819),(2,868,75,1523391804),(2,877,75,1523391819),(2,879,75,1523391804),(2,888,75,1523391819),(2,890,75,1523391804),(2,899,75,1523391819),(2,901,75,1523391804),(2,977,1,1523465310),(2,978,2,1523465359),(2,979,2,1523465359),(2,980,2,1523465359),(2,981,2,1523465359),(2,982,2,1523465359),(2,984,2,1523465359),(2,985,2,1523465359),(2,992,2807,1523471058),(2,993,2807,1523471058),(2,994,5407,1523471058),(2,995,2807,1523471058),(2,996,42999,1523465359),(2,1504,1,1523399291),(2,1505,1,1523464244),(2,1506,1,1523463129),(2,1507,1,1523468459),(2,1508,1,1523384176),(2,1509,1,1523388811),(2,1510,1,1523390815),(2,1511,1,1523392390),(2,1512,1,1523390483),(2,1513,1,1523395440),(2,1514,1,1523397337),(2,1515,1,1523391739),(2,1517,1,1523392158),(2,1518,1,1523395453),(2,1519,1,1523398303),(2,1520,1,1523396403),(2,1521,1,1523397115),(2,1524,1,1523396313),(2,1525,1,1523398283),(2,1526,1,1523399895),(2,1527,1,1523399932),(2,1528,1,1523396260),(2,1529,1,1523393689),(2,1530,1,1523468087),(2,1532,1,1523398069),(2,1536,1,1523462957),(2,1537,1,1523463970),(2,1538,1,1523464628),(2,1539,1,1523464716),(2,1540,1,1523471231),(2,1541,1,1529054401),(2,1542,1,1524946506),(2,1544,1,1523471397),(2,1545,1,1523469180),(2,1546,1,1523398961),(2,1554,1,1529250792),(2,1884,3500,1523383901),(2,2020,200,1523383901),(2,2072,1685,1529149207),(2,2239,80,1529055154),(2,2428,2,1523465359),(2,2429,2,1523465359),(2,3354,6881,1529054811),(2,3355,17985,1524946849),(2,3356,99,1523399388),(2,3361,46464,1529149553),(2,3506,6881,1529054811),(2,3507,6881,1529054811),(2,3510,6881,1529054811),(2,3511,6881,1529054811),(2,3512,6881,1529054811),(2,3513,17985,1524946849),(2,3631,80,1529055154),(2,3686,1,1523464370),(2,3689,1,1523464370),(2,3690,1,1523464370),(2,3692,1,1523464370),(2,4091,46464,1529149553),(2,4092,17985,1524946849),(2,4093,6881,1529054811),(2,4224,62195,1529149553),(2,4295,1,1529054999),(2,4705,3,1523397762),(2,4763,3500,1523383901),(2,4788,1,1523464370),(2,4943,1251,1529054999),(2,4944,565,1529054805),(2,4946,543,1529054805),(2,4948,78,1523471278),(2,4951,63,1523467863),(2,4953,178,1524946752),(2,4955,246,1529054805),(2,5008,1,1529149238),(2,5212,17,1529052474),(2,5218,17,1529052474),(2,5230,17,1529052474),(2,5242,35,1523399813),(2,5254,19,1523465514),(2,5256,38,1523470982),(2,5289,1,1523399375),(2,5299,2,1523465359),(2,5300,2,1523465310),(2,5301,7,1523399247),(2,5305,1,1523399388),(2,5311,2,1523463815),(2,5313,2807,1523471058),(2,5314,2807,1523471058),(2,5315,2807,1523471058),(2,5316,5407,1523471058),(2,5317,42999,1523465359),(2,5323,42999,1523465310),(2,5371,925,1523469031),(2,5372,21814,1529250799),(2,5373,190,1529052207),(2,5374,153,1529054999),(2,5375,153,1529054999),(2,5376,153,1529054999),(2,5529,582,1529054805),(2,5530,9,1523465716),(2,5531,573,1529054805),(2,5558,75,1523391819),(2,5560,75,1523391804),(2,5563,35,1523399813),(2,5572,19,1523465514),(2,5574,38,1523470982),(2,5576,15,1523386952),(2,5577,1,1523461265),(2,5578,1,1523383901),(2,5579,38,1523395845),(2,5584,85,1529054285),(2,5585,78,1529054441),(2,5587,1,1523461265),(2,5589,1,1523383901),(2,5593,5,1523395084),(2,5701,35,1523399813),(2,5718,19,1523465514),(2,5720,38,1523470982),(2,5967,35,1523400050),(2,5968,25,1529055154),(2,6142,4,1523463815),(2,6322,1,1523464370),(2,6323,1,1523464356),(2,6391,8,1523465517),(2,6393,7,1523399833),(2,6565,4,1523462447),(2,6684,2,1529054513),(2,6714,1,1523469079),(2,6751,7,1523399833),(2,6752,7,1523399833),(2,6753,7,1523399833),(2,6754,7,1523399833),(2,6755,7,1523399833),(2,6891,1,1523470587),(2,6917,1,1529054821),(2,6991,2,1523389929),(2,7125,20,1523462234),(2,7221,7,1523399833),(2,7229,8,1523465517),(2,7891,15,1523389048),(2,8819,500,1523383901),(2,8820,500,1523383901),(2,8821,500,1523383901),(2,8822,500,1523383901),(2,9218,1,1523464370),(2,9378,1,1523461265),(2,9598,17,1529052474),(2,9683,2807,1523471058),(2,9684,2807,1523471058),(2,9685,42999,1523465359),(2,9686,2807,1523471058),(2,9687,5407,1523471058),(2,12698,50,1523465310),(2,13384,1,1523396021),(2,13409,3500,1523383901),(5,34,101,1524923122),(5,35,101,1524923122),(5,36,101,1524923122),(5,37,101,1524923122),(5,38,101,1524923122),(5,39,101,1524923122),(5,40,101,1524923122),(5,41,101,1524923122),(5,111,1,1525290725),(5,162,14845,1525290676),(5,167,4,1525011656),(5,169,1,1525290725),(5,641,1,1523567834),(5,653,1,1523567834),(5,655,1,1523567834),(5,753,351,1525290676),(5,754,1,1523567834),(5,755,1,1523567834),(5,756,4,1525011656),(5,834,1,1523567834),(5,977,1,1524990274),(5,978,1,1524990274),(5,979,1,1524990274),(5,980,1,1524990274),(5,981,1,1524990274),(5,982,1,1524990274),(5,984,1,1524990274),(5,985,1,1524990274),(5,1009,42999,1524990274),(5,1146,1,1523567847),(5,1147,1,1524923191),(5,2020,200,1523567834),(5,2030,4000,1523567834),(5,2031,3100,1523567834),(5,2032,3100,1523567834),(5,2033,3100,1523567834),(5,2034,3000,1523567834),(5,2428,1,1524990274),(5,2429,1,1524990274),(5,2912,1,1524928131),(5,2922,1,1524928109),(5,2925,1,1524927946),(5,4224,93245296,1525379915),(5,4752,42999,1524990274),(5,5212,101,1524923122),(5,5220,101,1524923122),(5,5233,101,1524923122),(5,5299,1,1524990274),(5,5300,1,1524990274),(5,5301,7,1524990274),(5,5328,3100,1523567834),(5,5329,3100,1523567834),(5,5330,3100,1523567834),(5,5331,4000,1523567834),(5,5332,3000,1523567834),(5,5336,42999,1524990274),(5,5371,696,1525289290),(5,5372,15626,1525290725),(5,5373,1292,1525290623),(5,5576,351,1525290676),(5,5577,1,1523567834),(5,5578,1,1523567834),(5,5579,1,1523567834),(5,5580,1,1523567834),(5,5581,1,1523567834),(5,5585,1,1523567834),(5,5589,4,1525011656),(5,5593,1,1525290725),(5,6142,1,1524990615),(5,6847,1,1525290725),(5,7493,1,1524927943),(5,8819,500,1523567834),(5,8820,500,1523567834),(5,8821,500,1523567834),(5,8822,500,1523567834),(5,9598,101,1524923122),(5,9678,3100,1523567834),(5,9679,3000,1523567834),(5,9680,3100,1523567834),(5,9681,3100,1523567834),(5,9682,4000,1523567834),(5,12698,100,1524990274),(5,13241,1,1524990632),(7,34,1,1523641049),(7,35,1,1523641049),(7,36,1,1523641049),(7,37,1,1523641049),(7,38,1,1523641049),(7,39,1,1523641049),(7,40,1,1523641049),(7,41,1,1523641049),(7,167,1,1523641049),(7,653,1,1523641049),(7,756,1,1523641049),(7,2020,200,1523641049),(7,2030,4000,1523641049),(7,2031,3100,1523641049),(7,2032,3100,1523641049),(7,2033,3100,1523641049),(7,2034,3000,1523641049),(7,5212,1,1523641049),(7,5221,1,1523641049),(7,5233,1,1523641049),(7,5301,6,1523641049),(7,5328,3100,1523641049),(7,5329,3100,1523641049),(7,5330,3100,1523641049),(7,5331,4000,1523641049),(7,5332,3000,1523641049),(7,5585,1,1523641049),(7,5587,1,1523641049),(7,5589,1,1523641049),(7,8819,500,1523641049),(7,8820,500,1523641049),(7,8821,500,1523641049),(7,8822,500,1523641049),(7,9378,1,1523641049),(7,9598,1,1523641049),(7,9678,3100,1523641049),(7,9679,3000,1523641049),(7,9680,3100,1523641049),(7,9681,3100,1523641049),(7,9682,4000,1523641049),(8,34,1,1525002030),(8,35,1,1525002030),(8,36,1,1525002030),(8,37,1,1525002030),(8,38,1,1525002030),(8,39,1,1525002030),(8,40,1,1525002030),(8,41,1,1525002030),(8,111,1,1525002032),(8,167,1,1525002030),(8,641,1,1525002030),(8,653,1,1525002030),(8,655,1,1525002030),(8,753,1,1525002030),(8,754,1,1525002030),(8,755,1,1525002030),(8,756,1,1525002030),(8,834,1,1525002030),(8,2020,200,1525002030),(8,2030,3100,1525002030),(8,2031,4000,1525002030),(8,2032,3100,1525002030),(8,2033,3100,1525002030),(8,2034,3000,1525002030),(8,5212,1,1525002030),(8,5220,1,1525002030),(8,5232,1,1525002030),(8,5301,6,1525002030),(8,5328,3100,1525002030),(8,5329,3100,1525002030),(8,5330,4000,1525002030),(8,5331,3100,1525002030),(8,5332,3000,1525002030),(8,5371,178,1525002032),(8,5372,90,1525002032),(8,5576,1,1525002030),(8,5577,1,1525002030),(8,5578,1,1525002030),(8,5579,1,1525002030),(8,5580,1,1525002030),(8,5581,1,1525002030),(8,5585,1,1525002030),(8,5589,1,1525002030),(8,5593,1,1525002032),(8,8819,500,1525002030),(8,8820,500,1525002030),(8,8821,500,1525002030),(8,8822,500,1525002030),(8,9598,1,1525002030),(8,9678,3100,1525002030),(8,9679,3000,1525002030),(8,9680,3100,1525002030),(8,9681,4000,1525002030),(8,9682,3100,1525002030),(9,34,1,1525003203),(9,35,1,1525003203),(9,36,1,1525003203),(9,37,1,1525003203),(9,38,1,1525003203),(9,39,1,1525003203),(9,40,1,1525003203),(9,41,1,1525003203),(9,167,1,1525003203),(9,641,1,1525003203),(9,653,1,1525003203),(9,655,1,1525003203),(9,753,1,1525003203),(9,754,1,1525003203),(9,755,1,1525003203),(9,756,1,1525003203),(9,834,1,1525003203),(9,2020,200,1525003203),(9,2030,3100,1525003203),(9,2031,4000,1525003203),(9,2032,3100,1525003203),(9,2033,3100,1525003203),(9,2034,3000,1525003203),(9,5212,1,1525003203),(9,5220,1,1525003203),(9,5232,1,1525003203),(9,5301,6,1525003203),(9,5328,3100,1525003203),(9,5329,3100,1525003203),(9,5330,4000,1525003203),(9,5331,3100,1525003203),(9,5332,3000,1525003203),(9,5576,1,1525003203),(9,5577,1,1525003203),(9,5578,1,1525003203),(9,5579,1,1525003203),(9,5580,1,1525003203),(9,5581,1,1525003203),(9,5585,1,1525003203),(9,5589,1,1525003203),(9,8819,500,1525003203),(9,8820,500,1525003203),(9,8821,500,1525003203),(9,8822,500,1525003203),(9,9598,1,1525003203),(9,9678,3100,1525003203),(9,9679,3000,1525003203),(9,9680,3100,1525003203),(9,9681,4000,1525003203),(9,9682,3100,1525003203),(10,34,1,1525016131),(10,35,1,1525016131),(10,36,1,1525016131),(10,37,1,1525016131),(10,38,1,1525016131),(10,39,1,1525016131),(10,40,1,1525016131),(10,41,1,1525016131),(10,167,1,1525016131),(10,653,1,1525016131),(10,756,1,1525016131),(10,2020,200,1525016131),(10,2030,4000,1525016131),(10,2031,3100,1525016131),(10,2032,3100,1525016131),(10,2033,3100,1525016131),(10,2034,3000,1525016131),(10,5212,1,1525016131),(10,5221,1,1525016131),(10,5233,1,1525016131),(10,5301,6,1525016131),(10,5328,3100,1525016131),(10,5329,3100,1525016131),(10,5330,3100,1525016131),(10,5331,4000,1525016131),(10,5332,3000,1525016131),(10,5585,1,1525016131),(10,5587,1,1525016131),(10,5589,1,1525016131),(10,8819,500,1525016131),(10,8820,500,1525016131),(10,8821,500,1525016131),(10,8822,500,1525016131),(10,9378,1,1525016131),(10,9598,1,1525016131),(10,9678,3100,1525016131),(10,9679,3000,1525016131),(10,9680,3100,1525016131),(10,9681,3100,1525016131),(10,9682,4000,1525016131),(12,34,10,1529255043),(12,35,20,1529339312),(12,36,30,1529832173),(12,37,40,1544173216),(12,38,40,1544173216),(12,39,40,1544173216),(12,40,40,1544173216),(12,41,40,1544173216),(12,73,267,1544175553),(12,111,41,1544175137),(12,162,1242538,1544175389),(12,167,49,1544170832),(12,168,150,1529344279),(12,230,50,1529256718),(12,231,100,1529334638),(12,232,250,1531777207),(12,233,267,1544175553),(12,234,267,1544175553),(12,236,267,1544175553),(12,529,1,1529731408),(12,612,225,1529344663),(12,613,300,1544172085),(12,614,300,1544172085),(12,615,300,1544172085),(12,623,150,1529343857),(12,625,150,1529333058),(12,641,1,1529243249),(12,651,198,1544175009),(12,652,33,1529250370),(12,653,112,1529434583),(12,657,1,1529252681),(12,752,3,1529825176),(12,753,198,1544175118),(12,754,38,1529251786),(12,755,57,1529278347),(12,756,49,1544170832),(12,835,150,1531296785),(12,836,150,1531296785),(12,837,150,1531296785),(12,838,150,1531296785),(12,839,150,1531296785),(12,840,150,1529334164),(12,841,225,1529345256),(12,842,300,1531293674),(12,843,300,1531293674),(12,844,300,1531293674),(12,855,225,1529346141),(12,857,225,1530645947),(12,866,300,1531293523),(12,868,300,1531291629),(12,877,300,1531293523),(12,879,300,1531291629),(12,888,300,1531293523),(12,890,300,1531291629),(12,899,300,1531293523),(12,901,300,1531291629),(12,945,1,1530889061),(12,950,1,1531417730),(12,951,1,1531419264),(12,952,1,1529742290),(12,953,1,1530887676),(12,954,1,1531295304),(12,955,1,1531417705),(12,956,1,1531417801),(12,957,1,1529742339),(12,958,1,1530889496),(12,959,1,1530894280),(12,960,1,1530887695),(12,961,1,1530895215),(12,962,1,1530731988),(12,963,1,1530717844),(12,964,1,1530886405),(12,965,1,1530718903),(12,967,1,1530718851),(12,968,1,1530712620),(12,969,1,1530886143),(12,970,1,1530714368),(12,971,1,1530717373),(12,972,1,1530885914),(12,973,1,1530885833),(12,974,1,1530727244),(12,975,1,1530731037),(12,976,1,1530727614),(12,1064,1,1529435747),(12,1103,1,1530887101),(12,1104,1,1530891764),(12,1105,1,1530886710),(12,1106,1,1530886550),(12,1108,1,1530896336),(12,1109,1,1529742681),(12,1110,1,1530887557),(12,1111,1,1531416994),(12,1112,1,1531417307),(12,1147,1,1529730042),(12,1149,1,1529730123),(12,1150,1,1529732471),(12,1152,1,1529823546),(12,1154,1,1529823594),(12,1161,1,1529733166),(12,1162,1,1529732911),(12,1163,1,1529732757),(12,1164,1,1529739168),(12,1165,1,1529733436),(12,1167,1,1529752060),(12,1168,1,1529733593),(12,1169,1,1529738482),(12,1170,1,1529737804),(12,1171,1,1529733506),(12,1172,1,1529821008),(12,1173,1,1529751749),(12,1196,1,1544174308),(12,1201,1,1544174450),(12,1248,1,1529732550),(12,1251,1,1529732503),(12,1256,1,1529823095),(12,1262,1,1529337783),(12,1263,1,1530710836),(12,1264,1,1529338426),(12,1266,1,1530647945),(12,1269,1,1530711142),(12,1272,1,1530713372),(12,1274,1,1530712179),(12,1308,1,1529251131),(12,1314,1,1529327236),(12,1316,1,1529339769),(12,1317,1,1529338869),(12,1319,1,1529347430),(12,1320,1,1529347566),(12,1321,1,1529336087),(12,1323,1,1529336837),(12,1324,1,1529402491),(12,1325,1,1529340919),(12,1326,1,1529342970),(12,1328,1,1529433505),(12,1329,1,1529340797),(12,1330,1,1529342413),(12,1331,1,1529346846),(12,1332,1,1529403063),(12,1334,1,1529340688),(12,1335,1,1529434452),(12,1336,1,1529434353),(12,1337,1,1529434221),(12,1358,1,1531759372),(12,1359,1,1531758331),(12,1360,1,1531758232),(12,1365,1,1531779046),(12,1366,1,1531775527),(12,1367,1,1531775503),(12,1368,1,1531775813),(12,1371,1,1544173672),(12,1373,1,1531775902),(12,1374,1,1531778808),(12,1375,1,1532037955),(12,1376,1,1533825375),(12,1377,1,1531778615),(12,1378,1,1544174141),(12,1379,1,1532038372),(12,1380,1,1532038703),(12,1381,1,1531776025),(12,1552,1,1529243271),(12,1553,1,1529247324),(12,1554,1,1529247800),(12,1555,1,1529253745),(12,1556,1,1529255767),(12,1557,1,1529255691),(12,1558,1,1529252062),(12,1559,1,1529248518),(12,1560,1,1529249173),(12,1561,1,1529307974),(12,1562,1,1529248828),(12,1563,1,1529255479),(12,1564,1,1529252810),(12,1565,1,1529250012),(12,1566,1,1529250936),(12,1567,1,1529306327),(12,1568,1,1529251430),(12,1574,1,1529308435),(12,1575,1,1529304614),(12,1576,1,1529278097),(12,1577,1,1529331284),(12,1578,1,1529276891),(12,1579,1,1529276307),(12,1580,1,1529256701),(12,1581,1,1529304958),(12,1582,1,1529304438),(12,1583,1,1529304345),(12,1584,1,1529305756),(12,1585,1,1529278238),(12,1588,1,1529330591),(12,1589,1,1529308810),(12,1590,1,1529330227),(12,1593,1,1529256761),(12,1595,1,1529315133),(12,1597,1,1529317593),(12,1598,1,1529276374),(12,1599,1,1529330262),(12,1600,1,1529307974),(12,1870,150,1544174897),(12,1871,150,1544174897),(12,1872,75,1529402161),(12,1873,150,1544174897),(12,2002,3,1529825176),(12,2020,200,1529243249),(12,2030,24184,1533655553),(12,2031,15416,1533655553),(12,2032,18237,1533655553),(12,2033,13835,1533655553),(12,2034,24987,1533655553),(12,2044,1,1530717586),(12,2072,2655,1544171449),(12,2104,1,1529312987),(12,2232,3,1529747912),(12,2233,3,1529747912),(12,2234,3,1529747912),(12,2235,3,1529747912),(12,2236,3,1529747912),(12,2239,267,1544175553),(12,3063,1,1530717341),(12,3067,1,1529733524),(12,3068,1,1529730059),(12,3075,1,1529732594),(12,3311,8,1529343313),(12,3314,15,1544175307),(12,3315,75,1530895059),(12,3316,12,1529332088),(12,3317,4,1531290764),(12,3354,92037,1544175454),(12,3355,405550,1544175416),(12,3356,2169,1530710282),(12,3361,944026,1544174743),(12,3506,92037,1544175454),(12,3507,92037,1544175454),(12,3510,92037,1544175454),(12,3511,92037,1544175454),(12,3512,92037,1544175454),(12,3513,405550,1544175416),(12,3610,3500,1529243249),(12,3631,267,1544175553),(12,3856,1,1529743253),(12,3857,1,1529743188),(12,3944,1,1529731408),(12,4091,944026,1544174743),(12,4092,405550,1544175416),(12,4093,92037,1544175454),(12,4224,5015330,1529317220),(12,4293,17,1544175121),(12,4294,12,1530894202),(12,4295,3,1529347774),(12,4299,2,1529316927),(12,4305,1,1531777731),(12,4323,11,1533655400),(12,4330,1,1531776860),(12,4386,1,1529245324),(12,4393,3,1530647676),(12,4682,11,1531419367),(12,4695,6,1529739731),(12,4697,15,1529745701),(12,4699,32,1544175289),(12,4717,58,1530894751),(12,4762,3500,1529243249),(12,4787,4,1544174919),(12,4943,142474,1544175332),(12,4944,2436,1544175404),(12,4946,2324,1544175404),(12,4948,457,1544170562),(12,4949,39,1530727058),(12,4951,116,1533824988),(12,4952,3,1544174657),(12,4953,1400,1544175404),(12,4955,383,1544173265),(12,4956,31,1530519027),(12,4958,7,1530726966),(12,4984,3,1529747912),(12,4985,3,1529747912),(12,5008,11,1544174834),(12,5078,1,1530517747),(12,5212,40,1544173216),(12,5218,40,1544173216),(12,5231,40,1544173216),(12,5242,212,1530896764),(12,5249,300,1531293938),(12,5250,55,1531296858),(12,5254,215,1531294076),(12,5256,236,1544170572),(12,5275,1,1531296192),(12,5288,54,1531296858),(12,5289,26,1532038898),(12,5299,2,1530896027),(12,5300,5,1529404281),(12,5301,17,1544174408),(12,5305,11,1530710081),(12,5328,18237,1533655553),(12,5329,13835,1533655553),(12,5330,15416,1533655553),(12,5331,24184,1533655553),(12,5332,24987,1533655553),(12,5371,753,1532040313),(12,5372,317850,1544175388),(12,5373,469,1532039640),(12,5374,822,1531777731),(12,5375,82917,1544175315),(12,5376,822,1531777731),(12,5512,1015,1544175389),(12,5529,2193,1544175389),(12,5530,695,1544173936),(12,5531,483,1530730711),(12,5558,300,1531293523),(12,5560,300,1531291629),(12,5562,300,1531293938),(12,5563,212,1530896764),(12,5564,55,1531296858),(12,5572,215,1531294076),(12,5574,236,1544170572),(12,5576,198,1544175118),(12,5577,57,1529278347),(12,5578,1,1529243249),(12,5579,38,1529251786),(12,5582,49,1544170832),(12,5584,198,1544175009),(12,5585,112,1529434583),(12,5587,1,1529252681),(12,5588,33,1529250370),(12,5589,49,1544170832),(12,5591,1,1529252681),(12,5592,300,1531293938),(12,5593,41,1544175137),(12,5663,1,1529743188),(12,5695,54,1531296858),(12,5696,55,1531296858),(12,5701,212,1530896764),(12,5718,215,1531294076),(12,5720,236,1544170572),(12,5756,25,1531296437),(12,5757,50,1531296820),(12,5758,54,1531296858),(12,5759,54,1531296858),(12,5760,54,1531296858),(12,5761,54,1531296858),(12,5802,1,1544175433),(12,5803,1,1529730708),(12,5900,11,1533655553),(12,5901,7,1530732991),(12,5912,62,1530644110),(12,5918,8,1531291490),(12,5930,1,1533654527),(12,5934,8,1530709501),(12,5935,4,1544175553),(12,5943,1,1529731701),(12,5949,11,1530714393),(12,6005,12,1529441530),(12,6007,33,1529340380),(12,6008,1,1529337241),(12,6009,45,1529334638),(12,6010,12,1529489090),(12,6011,14,1544173399),(12,6031,1,1530646985),(12,6142,5,1544174906),(12,6391,71,1531775709),(12,6393,26,1544172088),(12,6394,15,1531293908),(12,6679,17,1544175200),(12,6694,23,1530712358),(12,6696,24,1530895579),(12,6751,25,1544172085),(12,6752,26,1544172088),(12,6753,26,1544172088),(12,6754,26,1544172088),(12,6755,26,1544172088),(12,6923,1,1530885708),(12,6970,11,1529343321),(12,7221,26,1544172088),(12,7222,15,1531293908),(12,7229,71,1531775709),(12,7550,4,1544174919),(12,7551,4,1544174919),(12,7552,4,1544174919),(12,8098,17,1529245992),(12,8819,1168,1544175553),(12,8820,825,1544175553),(12,8821,825,1544175553),(12,8822,825,1544175553),(12,8824,638,1533655412),(12,9223,4,1544174919),(12,9368,1,1530726966),(12,9378,1,1529252681),(12,9598,40,1544173216),(12,9678,18237,1533655553),(12,9679,24987,1533655553),(12,9680,13835,1533655553),(12,9681,15416,1533655553),(12,9682,24184,1533655553),(12,11302,1,1530716635),(12,11303,1,1531294193),(12,12698,260,1544174897),(12,13395,3500,1529243249),(14,34,55,1529435816),(14,35,55,1529435816),(14,36,55,1529435816),(14,37,55,1529435816),(14,38,55,1529435816),(14,39,157,1529438275),(14,40,157,1529438275),(14,41,157,1529438275),(14,73,42,1529438245),(14,162,366970,1544175404),(14,167,270,1529435816),(14,230,42,1529438245),(14,231,42,1529438245),(14,232,42,1529438245),(14,233,42,1529438245),(14,234,42,1529438245),(14,236,42,1529438245),(14,529,1,1529731408),(14,641,270,1529435816),(14,656,270,1529435816),(14,753,270,1529435816),(14,754,400,1531498037),(14,755,270,1529435816),(14,756,270,1529435816),(14,840,300,1529435816),(14,841,300,1529435816),(14,842,300,1529435816),(14,843,300,1529435816),(14,844,300,1529435816),(14,904,1,1544175396),(14,905,1,1544175396),(14,906,1,1544175396),(14,928,1,1544175396),(14,935,1,1544175396),(14,936,1,1544175396),(14,965,1,1530732598),(14,970,1,1530727117),(14,973,1,1531291148),(14,1064,1,1529438288),(14,1109,1,1529742800),(14,1147,1,1531498346),(14,1149,1,1529438182),(14,1171,1,1530732598),(14,1196,1,1544175473),(14,1323,1,1529747247),(14,1366,1,1544175396),(14,1368,1,1544175396),(14,1371,1,1544175396),(14,1372,1,1544175396),(14,1373,1,1544175396),(14,1376,1,1544175396),(14,1377,1,1544175396),(14,1378,1,1544175396),(14,1379,1,1544175396),(14,1381,1,1532040906),(14,1382,1,1544175396),(14,1384,1,1544175396),(14,1385,1,1544175396),(14,1508,1,1531497950),(14,1509,1,1531497929),(14,1513,1,1531497989),(14,1518,1,1531497988),(14,1521,1,1531497884),(14,1541,1,1531498052),(14,1566,1,1530732598),(14,1789,1,1544175396),(14,1792,1,1544175396),(14,1796,1,1544175396),(14,1870,150,1529436646),(14,1871,150,1529436646),(14,1872,150,1529436646),(14,1873,150,1529436646),(14,2020,200,1529435816),(14,2030,9100,1529438245),(14,2031,5500,1529438245),(14,2032,4600,1529438245),(14,2033,4600,1529438245),(14,2034,4500,1529438245),(14,2072,3729,1529437698),(14,2239,42,1529438245),(14,2417,7763,1529438144),(14,3354,14350,1544175454),(14,3355,293800,1529438144),(14,3506,14350,1544175454),(14,3507,14350,1544175454),(14,3510,14350,1544175454),(14,3511,14350,1544175454),(14,3512,14350,1544175454),(14,3513,293800,1529438144),(14,3631,42,1529438245),(14,3944,1,1529731408),(14,4092,293800,1529438144),(14,4093,14350,1544175454),(14,4224,293800,1529438144),(14,4743,7763,1529438144),(14,4787,1,1529436646),(14,4944,259,1544175404),(14,4948,21,1529439982),(14,4949,10,1530727058),(14,4952,1,1544174657),(14,4953,172,1544175404),(14,4955,48,1531498102),(14,4958,7,1530726966),(14,5212,107,1529438316),(14,5219,107,1529438316),(14,5232,107,1529438316),(14,5249,270,1529435816),(14,5300,1,1529438245),(14,5301,15,1544175398),(14,5305,5,1529437895),(14,5328,4600,1529438245),(14,5329,4600,1529438245),(14,5330,5500,1529438245),(14,5331,9100,1529438245),(14,5332,4500,1529438245),(14,5371,1888,1529437698),(14,5372,19266,1544175403),(14,5373,2937,1530726841),(14,5374,669,1529438806),(14,5375,462,1529731373),(14,5512,63,1544175404),(14,5529,287,1544175404),(14,5531,5,1531498102),(14,5562,270,1529435816),(14,5576,270,1529435816),(14,5577,270,1529435816),(14,5578,270,1529435816),(14,5579,430,1544175404),(14,5589,270,1529435816),(14,5590,270,1529435816),(14,5592,270,1529435816),(14,6394,15,1529435804),(14,7222,15,1529435804),(14,7550,1,1529436646),(14,7551,1,1529436646),(14,7552,1,1529436646),(14,8749,1,1529438108),(14,8819,509,1544175404),(14,8820,503,1544175404),(14,8821,503,1544175404),(14,8822,503,1544175404),(14,8824,159,1530727058),(14,9223,1,1529436646),(14,9368,1,1530726966),(14,9598,55,1529435816),(14,9678,4600,1529438245),(14,9679,4500,1529438245),(14,9680,4600,1529438245),(14,9681,5500,1529438245),(14,9682,9100,1529438245),(14,12698,150,1544175396),(15,34,5,1531500829),(15,35,5,1531500829),(15,36,5,1531500829),(15,37,5,1531500829),(15,38,5,1531500829),(15,39,5,1531500829),(15,40,5,1531500829),(15,41,5,1531500829),(15,73,12,1531501316),(15,162,2917,1531500910),(15,167,1,1531472903),(15,230,12,1531501316),(15,231,12,1531501316),(15,232,12,1531501316),(15,233,12,1531501316),(15,234,12,1531501316),(15,236,12,1531501316),(15,653,20,1531498911),(15,756,1,1531472903),(15,992,989,1531501316),(15,993,989,1531501316),(15,994,3589,1531501316),(15,995,989,1531501316),(15,996,5980,1531501316),(15,1508,1,1531472991),(15,1509,1,1531501014),(15,1884,3500,1531472903),(15,2020,200,1531472903),(15,2072,1558,1531475752),(15,2239,12,1531501316),(15,3354,8,1531499339),(15,3355,730,1531500829),(15,3361,70,1531475111),(15,3506,8,1531499339),(15,3507,8,1531499339),(15,3510,8,1531499339),(15,3511,8,1531499339),(15,3512,8,1531499339),(15,3513,730,1531500829),(15,3631,12,1531501316),(15,4091,70,1531475111),(15,4092,730,1531500829),(15,4093,8,1531499339),(15,4224,799,1531500829),(15,4763,3500,1531472903),(15,4944,50,1531500910),(15,4946,50,1531500910),(15,4948,24,1531500910),(15,4951,25,1531499365),(15,4953,1,1531499329),(15,5008,1,1531475526),(15,5212,5,1531500829),(15,5221,5,1531500829),(15,5230,5,1531500829),(15,5301,6,1531472903),(15,5313,989,1531501316),(15,5314,989,1531501316),(15,5315,989,1531501316),(15,5316,3589,1531501316),(15,5317,5980,1531501316),(15,5371,12,1531498914),(15,5372,338,1531500908),(15,5373,27,1531499329),(15,5529,50,1531500910),(15,5531,50,1531500910),(15,5585,20,1531498911),(15,5587,12,1531500557),(15,5589,1,1531472903),(15,7891,11,1531501316),(15,8819,500,1531472903),(15,8820,500,1531472903),(15,8821,500,1531472903),(15,8822,500,1531472903),(15,9378,12,1531500557),(15,9598,5,1531500829),(15,9683,989,1531501316),(15,9684,989,1531501316),(15,9685,5980,1531501316),(15,9686,989,1531501316),(15,9687,3589,1531501316),(15,13409,3500,1531472903),(16,34,101,1533718247),(16,35,101,1533718247),(16,36,101,1533718247),(16,37,101,1533718247),(16,38,101,1533718247),(16,39,101,1533718247),(16,40,101,1533718247),(16,41,101,1533718247),(16,162,2725,1533719047),(16,167,1,1533718233),(16,653,1,1533718233),(16,655,1,1533718233),(16,657,1,1533718233),(16,756,1,1533718233),(16,1147,1,1533719109),(16,1299,1,1533718234),(16,1870,150,1533718261),(16,1871,225,1533718261),(16,1872,150,1533718261),(16,1873,225,1533718261),(16,2020,200,1533718233),(16,2030,3100,1533718233),(16,2031,3100,1533718233),(16,2032,4000,1533718233),(16,2033,3100,1533718233),(16,2034,3000,1533718233),(16,2045,2000,1533718233),(16,3354,88,1533719048),(16,3361,19,1533719129),(16,3506,88,1533719048),(16,3507,88,1533719048),(16,3510,88,1533719048),(16,3511,88,1533719048),(16,3512,88,1533719048),(16,4091,19,1533719129),(16,4093,88,1533719048),(16,4224,30000107,1533719129),(16,4944,42,1533719047),(16,4948,7,1533718488),(16,4949,34,1533719047),(16,4958,1,1533718498),(16,5212,101,1533718247),(16,5214,101,1533718247),(16,5234,101,1533718247),(16,5301,6,1533718233),(16,5328,4000,1533718233),(16,5329,3100,1533718233),(16,5330,3100,1533718233),(16,5331,3100,1533718233),(16,5332,3000,1533718233),(16,5371,13,1533718997),(16,5372,13,1533718997),(16,5373,2040,1533718476),(16,5374,373,1533718411),(16,5376,373,1533718411),(16,5529,42,1533719047),(16,5530,42,1533719047),(16,5580,1,1533718233),(16,5585,1,1533718233),(16,5589,1,1533718233),(16,5591,1,1533718233),(16,8819,500,1533718233),(16,8820,500,1533718233),(16,8821,500,1533718233),(16,8822,500,1533718233),(16,9598,101,1533718247),(16,9678,4000,1533718233),(16,9679,3000,1533718233),(16,9680,3100,1533718233),(16,9681,3100,1533718233),(16,9682,3100,1533718233),(16,12698,110,1533718261),(17,34,1,1533828026),(17,35,1,1533828026),(17,36,1,1533828026),(17,37,1,1533828026),(17,38,1,1533828026),(17,39,1,1533828026),(17,40,1,1533828026),(17,41,1,1533828026),(17,162,1,1533828135),(17,167,1,1533828026),(17,641,1,1533828026),(17,653,1,1533828026),(17,655,1,1533828026),(17,753,1,1533828026),(17,754,1,1533828026),(17,755,1,1533828026),(17,756,1,1533828026),(17,834,1,1533828026),(17,1146,1,1533828041),(17,1147,1,1533828287),(17,2020,200,1533828026),(17,2030,4000,1533828026),(17,2031,3100,1533828026),(17,2032,3100,1533828026),(17,2033,3100,1533828026),(17,2034,3000,1533828026),(17,4944,1,1533828135),(17,4958,1,1533828135),(17,5212,1,1533828026),(17,5220,1,1533828026),(17,5233,1,1533828026),(17,5301,6,1533828026),(17,5328,3100,1533828026),(17,5329,3100,1533828026),(17,5330,3100,1533828026),(17,5331,4000,1533828026),(17,5332,3000,1533828026),(17,5373,8,1533828135),(17,5512,1,1533828135),(17,5529,1,1533828135),(17,5576,1,1533828026),(17,5577,1,1533828026),(17,5578,1,1533828026),(17,5579,1,1533828026),(17,5580,1,1533828026),(17,5581,1,1533828026),(17,5585,1,1533828026),(17,5589,1,1533828026),(17,8819,500,1533828026),(17,8820,500,1533828026),(17,8821,500,1533828026),(17,8822,500,1533828026),(17,9598,1,1533828026),(17,9678,3100,1533828026),(17,9679,3000,1533828026),(17,9680,3100,1533828026),(17,9681,3100,1533828026),(17,9682,4000,1533828026);
/*!40000 ALTER TABLE `character_achievement_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_action`
--

DROP TABLE IF EXISTS `character_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_action` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `spec` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `button` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `action` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spec`,`button`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_action`
--

LOCK TABLES `character_action` WRITE;
/*!40000 ALTER TABLE `character_action` DISABLE KEYS */;
INSERT INTO `character_action` VALUES (2,0,0,14281,0),(2,0,1,13549,0),(2,0,2,14261,0),(2,0,3,5116,0),(2,0,4,2974,0),(2,0,6,28730,0),(2,0,10,2,64),(2,0,11,1,64),(2,0,24,2108,0),(2,0,25,818,0),(2,0,26,2550,0),(2,0,30,13795,0),(2,0,31,1513,0),(2,0,32,23444,128),(2,0,33,858,128),(2,0,34,13165,0),(2,0,35,13163,0),(2,0,60,1515,0),(2,0,61,2641,0),(2,0,62,6603,0),(2,0,63,75,0),(2,0,64,1130,0),(2,0,65,3770,128),(2,0,66,20736,0),(2,0,67,6991,0),(2,0,68,136,0),(2,0,69,883,0),(2,0,70,159,128),(2,0,71,4605,128),(5,0,0,6603,0),(5,0,72,6603,0),(5,0,73,47450,0),(5,0,74,47465,0),(5,0,75,47471,0),(5,0,76,2,64),(5,0,77,47520,0),(5,0,82,59752,0),(5,0,84,6603,0),(5,0,96,6603,0),(5,0,108,6603,0),(7,0,0,6603,0),(7,0,1,1752,0),(7,0,2,2098,0),(7,0,3,2764,0),(7,0,11,59752,0),(8,0,0,6603,0),(8,0,1,78,0),(8,0,72,6603,0),(8,0,73,78,0),(8,0,74,20594,0),(8,0,75,2481,0),(8,0,76,2,64),(8,0,84,6603,0),(8,0,96,6603,0),(8,0,108,6603,0),(9,0,0,6603,0),(9,0,1,78,0),(9,0,72,6603,0),(9,0,73,78,0),(9,0,74,20594,0),(9,0,75,2481,0),(9,0,84,6603,0),(9,0,96,6603,0),(9,0,108,6603,0),(10,0,0,6603,0),(10,0,1,1752,0),(10,0,2,2098,0),(10,0,3,2764,0),(10,0,11,59752,0),(12,0,0,20901,0),(12,0,1,14284,0),(12,0,2,13552,0),(12,0,3,5116,0),(12,0,4,14269,0),(12,0,5,14263,0),(12,0,6,14288,0),(12,0,7,781,0),(12,0,8,2974,0),(12,0,9,20736,0),(12,0,10,14323,0),(12,0,12,7731,0),(12,0,24,13163,0),(12,0,25,10662,0),(12,0,26,3927,128),(12,0,27,59543,0),(12,0,28,10846,0),(12,0,29,18260,0),(12,0,30,3827,128),(12,0,31,3385,128),(12,0,33,3928,128),(12,0,34,1710,128),(12,0,35,818,0),(12,0,36,6603,0),(12,0,37,75,0),(12,0,38,14530,128),(12,0,39,1462,0),(12,0,40,1645,128),(12,0,46,35714,0),(12,0,47,1,64),(12,0,48,3662,0),(12,0,49,982,0),(12,0,50,883,0),(12,0,51,6991,0),(12,0,52,2641,0),(12,0,53,1515,0),(12,0,54,1543,0),(12,0,60,13163,0),(12,0,61,14319,0),(12,0,62,34074,0),(12,0,63,5118,0),(12,0,64,3043,0),(12,0,66,5384,0),(12,0,67,3045,0),(12,0,68,13809,0),(12,0,69,1499,0),(12,0,70,14303,0),(12,0,71,13813,0),(12,0,72,6603,0),(12,0,73,14263,0),(12,0,74,75,0),(14,0,0,6603,0),(14,0,1,49941,0),(14,0,2,49909,0),(14,0,3,49921,0),(14,0,4,49930,0),(14,0,5,49895,0),(14,0,6,49576,0),(14,0,8,1,64),(14,0,9,2,64),(14,0,10,50977,0),(14,0,11,2481,0),(15,0,0,6603,0),(15,0,1,1752,0),(15,0,2,2098,0),(15,0,3,2764,0),(15,0,4,25046,0),(16,0,0,48461,0),(16,0,1,48378,0),(16,0,11,58984,0),(16,0,96,8983,0),(16,0,97,6795,0),(16,0,98,16979,0),(16,0,99,33357,0),(16,0,100,48564,0),(16,0,101,5229,0),(16,0,102,48562,0),(17,0,0,6603,0),(17,0,72,6603,0),(17,0,73,78,0),(17,0,82,59752,0),(17,0,84,6603,0),(17,0,96,6603,0),(17,0,108,6603,0);
/*!40000 ALTER TABLE `character_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_arena_stats`
--

DROP TABLE IF EXISTS `character_arena_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_arena_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `matchMakerRating` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_arena_stats`
--

LOCK TABLES `character_arena_stats` WRITE;
/*!40000 ALTER TABLE `character_arena_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_arena_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_aura`
--

DROP TABLE IF EXISTS `character_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` int(11) NOT NULL DEFAULT '0',
  `amount1` int(11) NOT NULL DEFAULT '0',
  `amount2` int(11) NOT NULL DEFAULT '0',
  `base_amount0` int(11) NOT NULL DEFAULT '0',
  `base_amount1` int(11) NOT NULL DEFAULT '0',
  `base_amount2` int(11) NOT NULL DEFAULT '0',
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `critChance` float NOT NULL DEFAULT '0',
  `applyResilience` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_aura`
--

LOCK TABLES `character_aura` WRITE;
/*!40000 ALTER TABLE `character_aura` DISABLE KEYS */;
INSERT INTO `character_aura` VALUES (2,2,13163,7,7,1,18,0,0,17,-1,-1,-1,-1,0,0,1),(2,2,29348,1,1,1,70,0,0,69,0,0,3600000,179251,0,0,1),(5,5,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(8,8,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(8,8,2481,1,1,1,0,0,0,0,0,0,-1,-1,0,0,1),(9,9,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1),(12,12,19884,3,3,1,0,0,0,0,-1,0,-1,-1,0,0,1),(14,14,48266,7,7,1,15,10,-45,14,-1,-21,-1,-1,0,0,1),(14,14,49772,1,1,1,15,0,0,14,0,0,-1,-1,0,0,1),(14,14,61261,3,3,1,8,600,0,7,599,0,-1,-1,0,0,1),(14,14,63611,2,2,1,0,4,0,0,3,0,-1,-1,0,0,1),(16,16,783,3,3,1,0,0,0,-1,-1,0,-1,-1,0,0,1),(17,17,2457,3,3,1,0,10,0,-1,9,0,-1,-1,0,0,1);
/*!40000 ALTER TABLE `character_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_banned`
--

DROP TABLE IF EXISTS `character_banned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_banned` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ban List';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_banned`
--

LOCK TABLES `character_banned` WRITE;
/*!40000 ALTER TABLE `character_banned` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_banned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_battleground_data`
--

DROP TABLE IF EXISTS `character_battleground_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_battleground_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `instanceId` int(10) unsigned NOT NULL COMMENT 'Instance Identifier',
  `team` smallint(5) unsigned NOT NULL,
  `joinX` float NOT NULL DEFAULT '0',
  `joinY` float NOT NULL DEFAULT '0',
  `joinZ` float NOT NULL DEFAULT '0',
  `joinO` float NOT NULL DEFAULT '0',
  `joinMapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `taxiStart` int(10) unsigned NOT NULL DEFAULT '0',
  `taxiEnd` int(10) unsigned NOT NULL DEFAULT '0',
  `mountSpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_battleground_data`
--

LOCK TABLES `character_battleground_data` WRITE;
/*!40000 ALTER TABLE `character_battleground_data` DISABLE KEYS */;
INSERT INTO `character_battleground_data` VALUES (2,0,0,0,0,0,0,65535,0,0,0),(5,0,0,0,0,0,0,65535,0,0,0),(7,0,0,0,0,0,0,65535,0,0,0),(8,0,0,0,0,0,0,65535,0,0,0),(9,0,0,0,0,0,0,65535,0,0,0),(10,0,0,0,0,0,0,65535,0,0,0),(12,0,0,0,0,0,0,65535,0,0,0),(14,0,0,0,0,0,0,65535,0,0,0),(15,0,0,0,0,0,0,65535,0,0,0),(16,0,0,0,0,0,0,65535,0,0,0),(17,0,0,0,0,0,0,65535,0,0,0);
/*!40000 ALTER TABLE `character_battleground_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_battleground_random`
--

DROP TABLE IF EXISTS `character_battleground_random`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_battleground_random` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_battleground_random`
--

LOCK TABLES `character_battleground_random` WRITE;
/*!40000 ALTER TABLE `character_battleground_random` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_battleground_random` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_declinedname`
--

DROP TABLE IF EXISTS `character_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_declinedname` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL DEFAULT '',
  `dative` varchar(15) NOT NULL DEFAULT '',
  `accusative` varchar(15) NOT NULL DEFAULT '',
  `instrumental` varchar(15) NOT NULL DEFAULT '',
  `prepositional` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_declinedname`
--

LOCK TABLES `character_declinedname` WRITE;
/*!40000 ALTER TABLE `character_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_equipmentsets`
--

DROP TABLE IF EXISTS `character_equipmentsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_equipmentsets` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `setguid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `setindex` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(31) NOT NULL,
  `iconname` varchar(100) NOT NULL,
  `ignore_mask` int(11) unsigned NOT NULL DEFAULT '0',
  `item0` int(11) unsigned NOT NULL DEFAULT '0',
  `item1` int(11) unsigned NOT NULL DEFAULT '0',
  `item2` int(11) unsigned NOT NULL DEFAULT '0',
  `item3` int(11) unsigned NOT NULL DEFAULT '0',
  `item4` int(11) unsigned NOT NULL DEFAULT '0',
  `item5` int(11) unsigned NOT NULL DEFAULT '0',
  `item6` int(11) unsigned NOT NULL DEFAULT '0',
  `item7` int(11) unsigned NOT NULL DEFAULT '0',
  `item8` int(11) unsigned NOT NULL DEFAULT '0',
  `item9` int(11) unsigned NOT NULL DEFAULT '0',
  `item10` int(11) unsigned NOT NULL DEFAULT '0',
  `item11` int(11) unsigned NOT NULL DEFAULT '0',
  `item12` int(11) unsigned NOT NULL DEFAULT '0',
  `item13` int(11) unsigned NOT NULL DEFAULT '0',
  `item14` int(11) unsigned NOT NULL DEFAULT '0',
  `item15` int(11) unsigned NOT NULL DEFAULT '0',
  `item16` int(11) unsigned NOT NULL DEFAULT '0',
  `item17` int(11) unsigned NOT NULL DEFAULT '0',
  `item18` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`setguid`),
  UNIQUE KEY `idx_set` (`guid`,`setguid`,`setindex`),
  KEY `Idx_setindex` (`setindex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_equipmentsets`
--

LOCK TABLES `character_equipmentsets` WRITE;
/*!40000 ALTER TABLE `character_equipmentsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_equipmentsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_fishingsteps`
--

DROP TABLE IF EXISTS `character_fishingsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_fishingsteps` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `fishingSteps` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_fishingsteps`
--

LOCK TABLES `character_fishingsteps` WRITE;
/*!40000 ALTER TABLE `character_fishingsteps` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_fishingsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_gifts`
--

DROP TABLE IF EXISTS `character_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_gifts` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_gifts`
--

LOCK TABLES `character_gifts` WRITE;
/*!40000 ALTER TABLE `character_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_glyphs`
--

DROP TABLE IF EXISTS `character_glyphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_glyphs` (
  `guid` int(10) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `glyph1` smallint(5) unsigned DEFAULT '0',
  `glyph2` smallint(5) unsigned DEFAULT '0',
  `glyph3` smallint(5) unsigned DEFAULT '0',
  `glyph4` smallint(5) unsigned DEFAULT '0',
  `glyph5` smallint(5) unsigned DEFAULT '0',
  `glyph6` smallint(5) unsigned DEFAULT '0',
  PRIMARY KEY (`guid`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_glyphs`
--

LOCK TABLES `character_glyphs` WRITE;
/*!40000 ALTER TABLE `character_glyphs` DISABLE KEYS */;
INSERT INTO `character_glyphs` VALUES (2,0,0,0,0,0,0,0),(5,0,0,0,0,0,0,0),(7,0,0,0,0,0,0,0),(8,0,0,0,0,0,0,0),(9,0,0,0,0,0,0,0),(10,0,0,0,0,0,0,0),(12,0,354,0,0,363,0,0),(14,0,0,0,0,0,0,0),(15,0,0,0,0,0,0,0),(16,0,0,0,0,0,0,0),(17,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `character_glyphs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_homebind`
--

DROP TABLE IF EXISTS `character_homebind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_homebind` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `zoneId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Zone Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_homebind`
--

LOCK TABLES `character_homebind` WRITE;
/*!40000 ALTER TABLE `character_homebind` DISABLE KEYS */;
INSERT INTO `character_homebind` VALUES (2,530,3487,9562.73,-7221.97,16.212),(5,0,12,-8949.95,-132.493,83.5312),(7,0,796,2872.36,-763.15,160.33),(8,0,796,2872.36,-763.15,160.33),(9,0,796,2872.36,-763.15,160.33),(10,0,796,2872.36,-763.15,160.33),(12,530,3557,-3749.28,-11694.9,-105.875),(14,0,4342,2359.64,-5662.41,382.261),(15,530,3431,10349.6,-6357.29,33.4026),(16,1,141,10311.3,832.463,1326.41),(17,0,12,-8949.95,-132.493,83.5312);
/*!40000 ALTER TABLE `character_homebind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_instance`
--

DROP TABLE IF EXISTS `character_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `extendState` tinyint(2) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_instance`
--

LOCK TABLES `character_instance` WRITE;
/*!40000 ALTER TABLE `character_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_inventory`
--

DROP TABLE IF EXISTS `character_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_inventory` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bag` int(10) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Global Unique Identifier',
  PRIMARY KEY (`item`),
  UNIQUE KEY `guid` (`guid`,`bag`,`slot`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_inventory`
--

LOCK TABLES `character_inventory` WRITE;
/*!40000 ALTER TABLE `character_inventory` DISABLE KEYS */;
INSERT INTO `character_inventory` VALUES (2,0,0,367),(2,0,2,291),(2,0,3,18),(2,0,4,292),(2,0,5,297),(2,0,6,362),(2,0,7,366),(2,0,8,364),(2,0,9,363),(2,0,10,358),(2,0,11,360),(2,0,14,912),(2,0,15,289),(2,0,17,290),(2,0,19,36),(2,0,20,35),(2,0,21,34),(2,0,22,33),(2,0,23,26),(2,0,24,5643),(2,0,39,214),(2,0,40,284),(2,0,41,308),(2,0,42,548),(2,0,43,1031),(2,0,44,1010),(2,0,45,724),(2,0,46,668),(2,0,47,631),(2,0,48,646),(2,0,53,352),(2,0,60,355),(2,0,61,242),(2,0,62,696),(2,0,118,288),(2,33,0,732),(2,33,1,737),(2,33,2,742),(2,33,6,398),(2,33,7,589),(2,33,11,721),(2,33,15,656),(2,33,16,318),(2,33,17,356),(2,33,18,650),(2,33,19,268),(2,33,20,348),(2,33,21,306),(2,33,22,201),(2,33,23,372),(2,36,22,1081),(2,36,23,1054),(5,0,0,927),(5,0,2,928),(5,0,4,929),(5,0,5,930),(5,0,6,942),(5,0,7,932),(5,0,9,933),(5,0,15,999),(5,0,18,934),(5,0,23,783),(5,0,24,940),(5,0,25,941),(5,0,26,931),(5,0,27,943),(5,0,28,944),(5,0,29,990),(5,0,30,991),(5,0,31,992),(5,0,32,994),(5,0,33,995),(5,0,34,996),(5,0,35,939),(5,0,36,997),(5,0,86,1000),(7,0,3,795),(7,0,6,799),(7,0,7,797),(7,0,15,803),(7,0,16,805),(7,0,17,801),(7,0,23,807),(8,0,0,955),(8,0,3,946),(8,0,4,956),(8,0,5,957),(8,0,6,958),(8,0,7,959),(8,0,8,975),(8,0,9,974),(8,0,14,961),(8,0,15,952),(8,0,23,954),(8,0,27,948),(8,0,28,950),(9,0,3,964),(9,0,6,966),(9,0,7,968),(9,0,15,970),(9,0,23,972),(9,0,24,973),(10,0,23,989),(10,0,24,981),(10,0,25,977),(10,0,26,983),(10,0,27,985),(10,0,28,987),(10,0,29,979),(12,0,0,4850),(12,0,1,5707),(12,0,2,1426),(12,0,4,1428),(12,0,5,5901),(12,0,6,1430),(12,0,7,4718),(12,0,8,3878),(12,0,9,5145),(12,0,10,4235),(12,0,11,3813),(12,0,14,5919),(12,0,15,5834),(12,0,16,3886),(12,0,17,1429),(12,0,18,5470),(12,0,19,1540),(12,0,20,1541),(12,0,21,1543),(12,0,22,1542),(12,0,23,1208),(12,0,24,5943),(12,0,25,5944),(12,0,26,5946),(12,0,27,5951),(12,0,28,5952),(12,0,29,5953),(12,0,30,5954),(12,0,31,5956),(12,0,39,2377),(12,0,40,2442),(12,0,41,3797),(12,0,42,3935),(12,0,43,4113),(12,0,44,2517),(12,0,45,2518),(12,0,46,3400),(12,0,47,3731),(12,0,48,3762),(12,0,49,3816),(12,0,50,3955),(12,0,52,3887),(12,0,53,3444),(12,0,54,1913),(12,0,55,3788),(12,0,56,3892),(12,0,59,3780),(12,0,60,3741),(12,0,61,3295),(12,0,62,3294),(12,0,63,3517),(12,0,64,2308),(12,0,65,4171),(12,0,66,3777),(12,0,67,4277),(12,0,68,4278),(12,0,69,4276),(12,1542,0,1554),(12,1542,1,1715),(12,1542,3,5542),(12,1542,4,5430),(12,1542,5,5450),(12,1542,6,5233),(12,1542,7,5174),(12,1542,8,2383),(12,1542,9,5911),(12,1542,10,5204),(12,1542,11,5172),(12,1542,12,3888),(12,1542,13,5905),(12,1542,14,5102),(12,1542,15,1954),(12,1542,16,5144),(12,1542,18,4194),(12,1542,19,4858),(12,1542,20,4362),(12,1542,21,3448),(12,1542,22,3587),(12,1542,23,4014),(12,1543,0,4735),(12,1543,1,4731),(12,1543,2,4729),(12,1543,3,4730),(12,1543,4,4732),(12,1543,5,4733),(12,1543,6,4734),(12,1543,7,4736),(12,1543,8,4740),(12,1543,9,4738),(12,1543,10,4743),(12,1543,11,4739),(12,1543,12,4744),(12,1543,13,4741),(12,1543,14,4745),(12,4276,0,3402),(12,4276,1,3537),(12,4276,2,3943),(12,4276,3,4128),(12,4276,7,4320),(12,4276,8,4127),(12,4276,9,3405),(12,4276,10,3569),(12,4276,11,3942),(14,0,0,3721),(14,0,1,3693),(14,0,2,3719),(14,0,4,3711),(14,0,5,3668),(14,0,6,3670),(14,0,7,3707),(14,0,8,3701),(14,0,9,3709),(14,0,10,3694),(14,0,11,3706),(14,0,12,3712),(14,0,13,3700),(14,0,14,3696),(14,0,15,3722),(14,0,17,3698),(14,0,19,3678),(14,0,20,3680),(14,0,21,3682),(14,0,22,3684),(14,0,23,3688),(14,0,24,3674),(14,0,25,3676),(14,0,26,3660),(14,0,27,3664),(14,0,28,3703),(14,0,29,3686),(14,0,30,3672),(14,0,31,3666),(14,0,32,3662),(14,0,33,3697),(14,0,34,3658),(14,0,35,3656),(14,0,36,3691),(14,0,37,3729),(14,0,38,3730),(14,3678,0,3732),(14,3678,1,3740),(14,3678,2,3724),(14,3678,3,4772),(14,3678,4,4773),(14,3678,5,5925),(14,3678,6,5936),(15,0,3,5589),(15,0,5,5628),(15,0,6,5591),(15,0,7,5600),(15,0,9,5624),(15,0,15,5642),(15,0,16,5595),(15,0,17,5597),(15,0,19,5610),(15,0,23,5599),(15,0,24,5609),(15,0,25,5629),(15,0,26,5631),(15,0,27,5640),(15,0,28,5587),(15,0,29,5644),(15,0,30,5645),(15,0,31,5654),(15,0,32,5667),(15,0,33,5664),(15,0,34,5659),(15,0,35,5660),(15,0,36,5661),(15,0,37,5662),(15,0,38,5663),(16,0,4,5838),(16,0,6,5840),(16,0,15,5836),(16,0,23,5842),(17,0,3,5865),(17,0,6,5867),(17,0,7,5869),(17,0,15,5871),(17,0,23,5873);
/*!40000 ALTER TABLE `character_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet`
--

DROP TABLE IF EXISTS `character_pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` int(10) unsigned DEFAULT '0',
  `CreatedBySpell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `PetType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` smallint(5) unsigned NOT NULL DEFAULT '1',
  `exp` int(10) unsigned NOT NULL DEFAULT '0',
  `Reactstate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(21) NOT NULL DEFAULT 'Pet',
  `renamed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `curhealth` int(10) unsigned NOT NULL DEFAULT '1',
  `curmana` int(10) unsigned NOT NULL DEFAULT '0',
  `curhappiness` int(10) unsigned NOT NULL DEFAULT '0',
  `savetime` int(10) unsigned NOT NULL DEFAULT '0',
  `abdata` text,
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`),
  KEY `idx_slot` (`slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet`
--

LOCK TABLES `character_pet` WRITE;
/*!40000 ALTER TABLE `character_pet` DISABLE KEYS */;
INSERT INTO `character_pet` VALUES (2,15649,2,17547,13481,1,17,0,1,'Dracohalcón',0,0,1234,1,1001090,1531498577,'7 2 7 1 7 0 129 17256 129 14916 129 35323 1 0 6 2 6 1 6 0 '),(8,2163,12,1006,13481,1,15,257,1,'Oso',0,1,829,1,646315,1529328593,'7 2 7 1 7 0 129 14916 129 16828 129 50256 1 0 6 2 6 1 6 0 '),(10,2070,12,11449,13481,1,40,0,1,'Felino',0,0,2492,1,722765,1544175668,'7 2 7 1 7 0 129 14919 129 16832 129 59883 129 24452 6 2 6 1 6 0 '),(12,2408,12,1244,13481,1,31,1014,1,'Tortuga',0,3,1854,1,133000,1530896826,'7 2 7 1 7 0 129 14918 129 17257 129 1742 129 26064 6 2 6 1 6 0 ');
/*!40000 ALTER TABLE `character_pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet_declinedname`
--

DROP TABLE IF EXISTS `character_pet_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_declinedname` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `owner` int(10) unsigned NOT NULL DEFAULT '0',
  `genitive` varchar(12) NOT NULL DEFAULT '',
  `dative` varchar(12) NOT NULL DEFAULT '',
  `accusative` varchar(12) NOT NULL DEFAULT '',
  `instrumental` varchar(12) NOT NULL DEFAULT '',
  `prepositional` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet_declinedname`
--

LOCK TABLES `character_pet_declinedname` WRITE;
/*!40000 ALTER TABLE `character_pet_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_pet_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus`
--

DROP TABLE IF EXISTS `character_queststatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `explored` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `timer` int(10) unsigned NOT NULL DEFAULT '0',
  `mobcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `mobcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `itemcount4` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playercount` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus`
--

LOCK TABLES `character_queststatus` WRITE;
/*!40000 ALTER TABLE `character_queststatus` DISABLE KEYS */;
INSERT INTO `character_queststatus` VALUES (2,9156,3,0,1529054844,0,0,0,0,0,1,0,0,0),(2,9171,3,0,1524947119,0,0,0,0,0,0,0,0,0),(2,9218,3,0,1529054393,0,0,0,0,8,0,0,0,0),(12,189,3,0,1544175643,0,0,0,0,0,0,0,0,0),(12,198,1,0,1544175643,0,0,0,0,1,0,0,0,0),(12,213,3,0,1544175643,0,0,0,0,0,0,0,0,0),(12,348,3,0,1544174793,0,0,0,0,0,0,0,0,0),(12,587,3,0,1544175643,0,0,0,0,0,0,0,0,0),(12,604,3,0,1544175643,0,0,0,0,0,0,0,0,0),(12,617,3,0,1544174888,0,0,0,0,0,0,0,0,0),(15,8346,3,0,1531500818,0,0,0,0,0,0,0,0,0),(15,9705,1,0,1531501406,0,0,0,0,1,0,0,0,0);
/*!40000 ALTER TABLE `character_queststatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_daily`
--

DROP TABLE IF EXISTS `character_queststatus_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_daily`
--

LOCK TABLES `character_queststatus_daily` WRITE;
/*!40000 ALTER TABLE `character_queststatus_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_monthly`
--

DROP TABLE IF EXISTS `character_queststatus_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_monthly`
--

LOCK TABLES `character_queststatus_monthly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_rewarded`
--

DROP TABLE IF EXISTS `character_queststatus_rewarded`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_rewarded` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `active` tinyint(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_rewarded`
--

LOCK TABLES `character_queststatus_rewarded` WRITE;
/*!40000 ALTER TABLE `character_queststatus_rewarded` DISABLE KEYS */;
INSERT INTO `character_queststatus_rewarded` VALUES (2,8325,1),(2,8326,1),(2,8327,1),(2,8330,1),(2,8334,1),(2,8335,1),(2,8336,1),(2,8338,1),(2,8345,1),(2,8346,1),(2,8347,1),(2,8350,1),(2,8463,1),(2,8468,1),(2,8472,1),(2,8473,1),(2,8474,1),(2,8476,1),(2,8480,1),(2,8482,1),(2,8483,1),(2,8486,1),(2,8487,1),(2,8488,1),(2,8490,1),(2,8491,1),(2,8886,1),(2,8892,1),(2,8895,1),(2,9035,1),(2,9062,1),(2,9064,1),(2,9066,1),(2,9067,1),(2,9076,1),(2,9119,1),(2,9138,1),(2,9139,1),(2,9140,1),(2,9143,1),(2,9144,1),(2,9145,1),(2,9146,1),(2,9147,1),(2,9148,1),(2,9150,1),(2,9152,1),(2,9155,1),(2,9160,1),(2,9163,1),(2,9166,1),(2,9169,1),(2,9173,1),(2,9192,1),(2,9193,1),(2,9199,1),(2,9212,1),(2,9216,1),(2,9252,1),(2,9253,1),(2,9254,1),(2,9255,1),(2,9256,1),(2,9258,1),(2,9315,1),(2,9327,1),(2,9352,1),(2,9358,1),(2,9359,1),(2,9393,1),(2,9395,1),(2,9484,1),(2,9485,1),(2,9486,1),(2,9673,1),(2,9704,1),(2,9705,1),(2,9758,1),(2,10070,1),(2,10166,1),(12,55,1),(12,56,1),(12,57,1),(12,58,1),(12,66,1),(12,67,1),(12,68,1),(12,69,1),(12,70,1),(12,72,1),(12,74,1),(12,75,1),(12,78,1),(12,79,1),(12,80,1),(12,90,1),(12,95,1),(12,97,1),(12,98,1),(12,101,1),(12,133,1),(12,134,1),(12,148,1),(12,149,1),(12,154,1),(12,156,1),(12,157,1),(12,158,1),(12,159,1),(12,160,1),(12,163,1),(12,164,1),(12,165,1),(12,173,1),(12,221,1),(12,222,1),(12,223,1),(12,225,1),(12,227,1),(12,228,1),(12,229,1),(12,230,1),(12,231,1),(12,245,1),(12,251,1),(12,252,1),(12,253,1),(12,261,1),(12,262,1),(12,265,1),(12,266,1),(12,268,1),(12,269,1),(12,270,1),(12,288,1),(12,289,1),(12,290,1),(12,292,1),(12,293,1),(12,303,1),(12,304,1),(12,321,1),(12,322,1),(12,323,1),(12,324,1),(12,325,1),(12,337,1),(12,387,1),(12,401,1),(12,453,1),(12,500,1),(12,504,1),(12,505,1),(12,510,1),(12,511,1),(12,512,1),(12,514,1),(12,522,1),(12,523,1),(12,525,1),(12,526,1),(12,537,1),(12,538,1),(12,540,1),(12,542,1),(12,543,1),(12,555,1),(12,564,1),(12,565,1),(12,595,1),(12,597,1),(12,599,1),(12,614,1),(12,631,1),(12,632,1),(12,633,1),(12,634,1),(12,642,1),(12,651,1),(12,652,1),(12,657,1),(12,658,1),(12,659,1),(12,660,1),(12,661,1),(12,681,1),(12,682,1),(12,684,1),(12,685,1),(12,729,1),(12,731,1),(12,741,1),(12,942,1),(12,947,1),(12,965,1),(12,966,1),(12,967,1),(12,970,1),(12,973,1),(12,982,1),(12,991,1),(12,1008,1),(12,1010,1),(12,1020,1),(12,1023,1),(12,1024,1),(12,1025,1),(12,1033,1),(12,1034,1),(12,1035,1),(12,1052,1),(12,1053,1),(12,1054,1),(12,1078,1),(12,1241,1),(12,1242,1),(12,1243,1),(12,1274,1),(12,1275,1),(12,1369,1),(12,1371,1),(12,1375,1),(12,1381,1),(12,1385,1),(12,1386,1),(12,1437,1),(12,1438,1),(12,1439,1),(12,1465,1),(12,5321,1),(12,6132,1),(12,6134,1),(12,9279,1),(12,9280,1),(12,9283,1),(12,9288,1),(12,9293,1),(12,9294,1),(12,9303,1),(12,9305,1),(12,9309,1),(12,9311,1),(12,9312,1),(12,9313,1),(12,9314,1),(12,9371,1),(12,9409,1),(12,9452,1),(12,9453,1),(12,9454,1),(12,9455,1),(12,9456,1),(12,9463,1),(12,9473,1),(12,9505,1),(12,9506,1),(12,9512,1),(12,9513,1),(12,9523,1),(12,9530,1),(12,9531,1),(12,9533,1),(12,9537,1),(12,9538,1),(12,9539,1),(12,9540,1),(12,9541,1),(12,9542,1),(12,9544,1),(12,9548,1),(12,9549,1),(12,9550,1),(12,9557,1),(12,9559,1),(12,9560,1),(12,9562,1),(12,9564,1),(12,9567,1),(12,9574,1),(12,9576,1),(12,9578,1),(12,9580,1),(12,9581,1),(12,9584,1),(12,9585,1),(12,9591,1),(12,9592,1),(12,9593,1),(12,9602,1),(12,9603,1),(12,9604,1),(12,9605,1),(12,9606,1),(12,9616,1),(12,9620,1),(12,9623,1),(12,9624,1),(12,9625,1),(12,9628,1),(12,9629,1),(12,9632,1),(12,9633,1),(12,9634,1),(12,9641,1),(12,9643,1),(12,9646,1),(12,9648,1),(12,9663,1),(12,9666,1),(12,9668,1),(12,9671,1),(12,9672,1),(12,9674,1),(12,9675,1),(12,9682,1),(12,9683,1),(12,9687,1),(12,9688,1),(12,9693,1),(12,9694,1),(12,9696,1),(12,9698,1),(12,9699,1),(12,9757,1),(12,9779,1),(12,9798,1),(12,9799,1),(12,10063,1),(12,10064,1),(12,10302,1),(12,10303,1),(12,10304,1),(12,10324,1),(12,11583,1),(12,11657,1),(12,11731,1),(12,11804,1),(12,11814,1),(12,11816,1),(12,11828,1),(12,11882,1),(12,11886,1),(12,11891,1),(12,11964,1),(12,11970,1),(12,12012,1),(12,14082,1),(14,12593,1),(14,12619,1),(14,12636,1),(14,12641,1),(14,12657,1),(14,12670,1),(14,12678,1),(14,12679,1),(14,12680,1),(14,12687,1),(14,12697,1),(14,12698,1),(14,12700,1),(14,12701,1),(14,12706,1),(14,12714,1),(14,12715,1),(14,12719,1),(14,12720,1),(14,12722,1),(14,12723,1),(14,12724,1),(14,12725,1),(14,12727,1),(14,12733,1),(14,12738,1),(14,12744,1),(14,12751,1),(14,12754,1),(14,12755,1),(14,12756,1),(14,12757,1),(14,12778,1),(14,12779,1),(14,12800,1),(14,12801,1),(14,12842,1),(14,12848,1),(14,12850,1),(14,13165,1),(14,13166,1),(14,13188,1),(15,8325,1),(15,8326,1),(15,8327,1),(15,8330,1),(15,8334,1),(15,8335,1),(15,8338,1),(15,8345,1),(15,8347,1),(15,9392,1),(15,9704,1),(15,10071,1);
/*!40000 ALTER TABLE `character_queststatus_rewarded` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_seasonal`
--

DROP TABLE IF EXISTS `character_queststatus_seasonal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_seasonal` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `event` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_seasonal`
--

LOCK TABLES `character_queststatus_seasonal` WRITE;
/*!40000 ALTER TABLE `character_queststatus_seasonal` DISABLE KEYS */;
INSERT INTO `character_queststatus_seasonal` VALUES (12,11583,1),(12,11657,1),(12,11731,1),(12,11804,1),(12,11814,1),(12,11816,1),(12,11828,1),(12,11882,1),(12,11886,1),(12,11891,1),(12,11964,1),(12,11970,1),(12,12012,1);
/*!40000 ALTER TABLE `character_queststatus_seasonal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_weekly`
--

DROP TABLE IF EXISTS `character_queststatus_weekly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_weekly`
--

LOCK TABLES `character_queststatus_weekly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_weekly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_reputation`
--

DROP TABLE IF EXISTS `character_reputation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_reputation` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `faction` smallint(5) unsigned NOT NULL DEFAULT '0',
  `standing` int(11) NOT NULL DEFAULT '0',
  `flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_reputation`
--

LOCK TABLES `character_reputation` WRITE;
/*!40000 ALTER TABLE `character_reputation` DISABLE KEYS */;
INSERT INTO `character_reputation` VALUES (2,21,0,64),(2,46,0,4),(2,47,0,6),(2,54,0,6),(2,59,0,16),(2,67,0,25),(2,68,2307,17),(2,69,0,6),(2,70,0,2),(2,72,0,6),(2,76,2307,17),(2,81,2307,17),(2,83,0,4),(2,86,0,4),(2,87,0,2),(2,92,0,2),(2,93,0,2),(2,169,0,12),(2,270,0,16),(2,289,0,4),(2,349,0,0),(2,369,0,64),(2,469,0,14),(2,470,0,64),(2,471,0,22),(2,509,0,2),(2,510,0,16),(2,529,0,0),(2,530,2307,17),(2,549,0,4),(2,550,0,4),(2,551,0,4),(2,569,0,4),(2,570,0,4),(2,571,0,4),(2,574,0,4),(2,576,0,2),(2,577,0,64),(2,589,0,6),(2,609,0,0),(2,729,0,16),(2,730,0,2),(2,749,0,0),(2,809,0,16),(2,889,0,16),(2,890,0,6),(2,891,0,0),(2,892,0,24),(2,909,0,16),(2,910,0,2),(2,911,38999,17),(2,922,42999,17),(2,930,0,6),(2,932,0,82),(2,933,0,16),(2,934,0,80),(2,935,0,16),(2,936,0,28),(2,941,0,16),(2,942,0,16),(2,946,0,2),(2,947,0,16),(2,948,0,8),(2,949,0,24),(2,952,0,0),(2,967,0,16),(2,970,0,0),(2,978,0,2),(2,980,0,0),(2,989,0,16),(2,990,0,16),(2,1005,0,4),(2,1011,0,16),(2,1012,0,16),(2,1015,0,2),(2,1031,0,16),(2,1037,0,6),(2,1038,0,16),(2,1050,0,6),(2,1052,0,152),(2,1064,0,16),(2,1067,0,16),(2,1068,0,6),(2,1073,0,16),(2,1077,0,16),(2,1082,0,2),(2,1085,0,16),(2,1090,0,16),(2,1091,0,16),(2,1094,0,6),(2,1097,0,0),(2,1098,0,16),(2,1104,0,16),(2,1105,0,16),(2,1106,0,16),(2,1117,0,12),(2,1118,0,12),(2,1119,0,2),(2,1124,0,16),(2,1126,0,2),(2,1136,0,4),(2,1137,0,4),(2,1154,0,4),(2,1155,0,4),(2,1156,0,16),(5,21,0,64),(5,46,0,4),(5,47,0,17),(5,54,0,17),(5,59,0,16),(5,67,0,14),(5,68,0,6),(5,69,0,17),(5,70,0,2),(5,72,0,17),(5,76,0,6),(5,81,0,6),(5,83,0,4),(5,86,0,4),(5,87,0,2),(5,92,0,2),(5,93,0,2),(5,169,0,12),(5,270,0,16),(5,289,0,4),(5,349,0,0),(5,369,0,64),(5,469,0,25),(5,470,0,64),(5,471,0,20),(5,509,0,16),(5,510,0,2),(5,529,0,0),(5,530,0,6),(5,549,0,4),(5,550,0,4),(5,551,0,4),(5,569,0,4),(5,570,0,4),(5,571,0,4),(5,574,0,4),(5,576,0,2),(5,577,0,64),(5,589,0,0),(5,609,0,0),(5,729,0,2),(5,730,0,16),(5,749,0,0),(5,809,0,16),(5,889,0,6),(5,890,0,16),(5,891,0,24),(5,892,0,14),(5,909,0,16),(5,910,0,2),(5,911,0,6),(5,922,0,6),(5,930,0,17),(5,932,0,80),(5,933,0,16),(5,934,0,80),(5,935,0,16),(5,936,0,28),(5,941,0,6),(5,942,0,16),(5,946,42999,17),(5,947,0,2),(5,948,0,8),(5,949,0,24),(5,952,0,0),(5,967,0,16),(5,970,0,0),(5,978,0,16),(5,980,0,0),(5,989,0,16),(5,990,0,16),(5,1005,0,4),(5,1011,0,16),(5,1012,0,16),(5,1015,0,2),(5,1031,0,16),(5,1037,0,136),(5,1038,0,16),(5,1050,0,16),(5,1052,0,2),(5,1064,0,6),(5,1067,0,2),(5,1068,0,16),(5,1073,0,16),(5,1077,0,16),(5,1082,0,4),(5,1085,0,6),(5,1090,0,16),(5,1091,0,16),(5,1094,0,16),(5,1097,0,0),(5,1098,0,16),(5,1104,0,16),(5,1105,0,16),(5,1106,0,16),(5,1117,0,12),(5,1118,0,12),(5,1119,0,2),(5,1124,0,6),(5,1126,0,16),(5,1136,0,4),(5,1137,0,4),(5,1154,0,4),(5,1155,0,4),(5,1156,0,16),(7,21,0,64),(7,46,0,4),(7,47,0,17),(7,54,0,17),(7,59,0,16),(7,67,0,14),(7,68,0,6),(7,69,0,17),(7,70,0,2),(7,72,0,17),(7,76,0,6),(7,81,0,6),(7,83,0,4),(7,86,0,4),(7,87,0,2),(7,92,0,2),(7,93,0,2),(7,169,0,12),(7,270,0,16),(7,289,0,4),(7,349,0,0),(7,369,0,64),(7,469,0,25),(7,470,0,64),(7,471,0,20),(7,509,0,16),(7,510,0,2),(7,529,0,0),(7,530,0,6),(7,549,0,4),(7,550,0,4),(7,551,0,4),(7,569,0,4),(7,570,0,4),(7,571,0,4),(7,574,0,4),(7,576,0,2),(7,577,0,64),(7,589,0,0),(7,609,0,0),(7,729,0,2),(7,730,0,16),(7,749,0,0),(7,809,0,16),(7,889,0,6),(7,890,0,16),(7,891,0,24),(7,892,0,14),(7,909,0,16),(7,910,0,0),(7,911,0,6),(7,922,0,6),(7,930,0,17),(7,932,0,80),(7,933,0,16),(7,934,0,80),(7,935,0,16),(7,936,0,28),(7,941,0,6),(7,942,0,16),(7,946,0,16),(7,947,0,0),(7,948,0,8),(7,949,0,24),(7,952,0,0),(7,967,0,16),(7,970,0,0),(7,978,0,16),(7,980,0,0),(7,989,0,16),(7,990,0,16),(7,1005,0,4),(7,1011,0,16),(7,1012,0,16),(7,1015,0,2),(7,1031,0,16),(7,1037,0,136),(7,1038,0,16),(7,1050,0,16),(7,1052,0,0),(7,1064,0,6),(7,1067,0,0),(7,1068,0,16),(7,1073,0,16),(7,1077,0,16),(7,1082,0,4),(7,1085,0,6),(7,1090,0,16),(7,1091,0,16),(7,1094,0,16),(7,1097,0,0),(7,1098,0,16),(7,1104,0,16),(7,1105,0,16),(7,1106,0,16),(7,1117,0,12),(7,1118,0,12),(7,1119,0,0),(7,1124,0,6),(7,1126,0,16),(7,1136,0,4),(7,1137,0,4),(7,1154,0,4),(7,1155,0,4),(7,1156,0,16),(8,21,0,64),(8,46,0,4),(8,47,0,17),(8,54,0,17),(8,59,0,16),(8,67,0,14),(8,68,0,6),(8,69,0,17),(8,70,0,2),(8,72,0,17),(8,76,0,6),(8,81,0,6),(8,83,0,4),(8,86,0,4),(8,87,0,2),(8,92,0,2),(8,93,0,2),(8,169,0,12),(8,270,0,16),(8,289,0,4),(8,349,0,0),(8,369,0,64),(8,469,0,25),(8,470,0,64),(8,471,0,4),(8,509,0,16),(8,510,0,2),(8,529,0,0),(8,530,0,6),(8,549,0,4),(8,550,0,4),(8,551,0,4),(8,569,0,4),(8,570,0,4),(8,571,0,4),(8,574,0,4),(8,576,0,2),(8,577,0,64),(8,589,0,0),(8,609,0,0),(8,729,0,2),(8,730,0,16),(8,749,0,0),(8,809,0,16),(8,889,0,6),(8,890,0,16),(8,891,0,24),(8,892,0,14),(8,909,0,16),(8,910,0,2),(8,911,0,6),(8,922,0,6),(8,930,0,17),(8,932,0,80),(8,933,0,16),(8,934,0,80),(8,935,0,16),(8,936,0,28),(8,941,0,6),(8,942,0,16),(8,946,0,16),(8,947,0,2),(8,948,0,8),(8,949,0,24),(8,952,0,0),(8,967,0,16),(8,970,0,0),(8,978,0,16),(8,980,0,0),(8,989,0,16),(8,990,0,16),(8,1005,0,4),(8,1011,0,16),(8,1012,0,16),(8,1015,0,2),(8,1031,0,16),(8,1037,0,136),(8,1038,0,16),(8,1050,0,16),(8,1052,0,2),(8,1064,0,6),(8,1067,0,2),(8,1068,0,16),(8,1073,0,16),(8,1077,0,16),(8,1082,0,4),(8,1085,0,6),(8,1090,0,16),(8,1091,0,16),(8,1094,0,16),(8,1097,0,0),(8,1098,0,16),(8,1104,0,16),(8,1105,0,16),(8,1106,0,16),(8,1117,0,12),(8,1118,0,12),(8,1119,0,2),(8,1124,0,6),(8,1126,0,16),(8,1136,0,4),(8,1137,0,4),(8,1154,0,4),(8,1155,0,4),(8,1156,0,16),(9,21,0,64),(9,46,0,4),(9,47,0,17),(9,54,0,17),(9,59,0,16),(9,67,0,14),(9,68,0,6),(9,69,0,17),(9,70,0,2),(9,72,0,17),(9,76,0,6),(9,81,0,6),(9,83,0,4),(9,86,0,4),(9,87,0,2),(9,92,0,2),(9,93,0,2),(9,169,0,12),(9,270,0,16),(9,289,0,4),(9,349,0,0),(9,369,0,64),(9,469,0,25),(9,470,0,64),(9,471,0,4),(9,509,0,16),(9,510,0,2),(9,529,0,0),(9,530,0,6),(9,549,0,4),(9,550,0,4),(9,551,0,4),(9,569,0,4),(9,570,0,4),(9,571,0,4),(9,574,0,4),(9,576,0,2),(9,577,0,64),(9,589,0,0),(9,609,0,0),(9,729,0,2),(9,730,0,16),(9,749,0,0),(9,809,0,16),(9,889,0,6),(9,890,0,16),(9,891,0,24),(9,892,0,14),(9,909,0,16),(9,910,0,0),(9,911,0,6),(9,922,0,6),(9,930,0,17),(9,932,0,80),(9,933,0,16),(9,934,0,80),(9,935,0,16),(9,936,0,28),(9,941,0,6),(9,942,0,16),(9,946,0,16),(9,947,0,0),(9,948,0,8),(9,949,0,24),(9,952,0,0),(9,967,0,16),(9,970,0,0),(9,978,0,16),(9,980,0,0),(9,989,0,16),(9,990,0,16),(9,1005,0,4),(9,1011,0,16),(9,1012,0,16),(9,1015,0,2),(9,1031,0,16),(9,1037,0,136),(9,1038,0,16),(9,1050,0,16),(9,1052,0,0),(9,1064,0,6),(9,1067,0,0),(9,1068,0,16),(9,1073,0,16),(9,1077,0,16),(9,1082,0,4),(9,1085,0,6),(9,1090,0,16),(9,1091,0,16),(9,1094,0,16),(9,1097,0,0),(9,1098,0,16),(9,1104,0,16),(9,1105,0,16),(9,1106,0,16),(9,1117,0,12),(9,1118,0,12),(9,1119,0,0),(9,1124,0,6),(9,1126,0,16),(9,1136,0,4),(9,1137,0,4),(9,1154,0,4),(9,1155,0,4),(9,1156,0,16),(10,21,0,64),(10,46,0,4),(10,47,0,17),(10,54,0,17),(10,59,0,16),(10,67,0,14),(10,68,0,6),(10,69,0,17),(10,70,0,2),(10,72,0,17),(10,76,0,6),(10,81,0,6),(10,83,0,4),(10,86,0,4),(10,87,0,2),(10,92,0,2),(10,93,0,2),(10,169,0,12),(10,270,0,16),(10,289,0,4),(10,349,0,0),(10,369,0,64),(10,469,0,25),(10,470,0,64),(10,471,0,20),(10,509,0,16),(10,510,0,2),(10,529,0,0),(10,530,0,6),(10,549,0,4),(10,550,0,4),(10,551,0,4),(10,569,0,4),(10,570,0,4),(10,571,0,4),(10,574,0,4),(10,576,0,2),(10,577,0,64),(10,589,0,0),(10,609,0,0),(10,729,0,2),(10,730,0,16),(10,749,0,0),(10,809,0,16),(10,889,0,6),(10,890,0,16),(10,891,0,24),(10,892,0,14),(10,909,0,16),(10,910,0,0),(10,911,0,6),(10,922,0,6),(10,930,0,17),(10,932,0,80),(10,933,0,16),(10,934,0,80),(10,935,0,16),(10,936,0,28),(10,941,0,6),(10,942,0,16),(10,946,0,16),(10,947,0,0),(10,948,0,8),(10,949,0,24),(10,952,0,0),(10,967,0,16),(10,970,0,0),(10,978,0,16),(10,980,0,0),(10,989,0,16),(10,990,0,16),(10,1005,0,4),(10,1011,0,16),(10,1012,0,16),(10,1015,0,2),(10,1031,0,16),(10,1037,0,136),(10,1038,0,16),(10,1050,0,16),(10,1052,0,0),(10,1064,0,6),(10,1067,0,0),(10,1068,0,16),(10,1073,0,16),(10,1077,0,16),(10,1082,0,4),(10,1085,0,6),(10,1090,0,16),(10,1091,0,16),(10,1094,0,16),(10,1097,0,0),(10,1098,0,16),(10,1104,0,16),(10,1105,0,16),(10,1106,0,16),(10,1117,0,12),(10,1118,0,12),(10,1119,0,0),(10,1124,0,6),(10,1126,0,16),(10,1136,0,4),(10,1137,0,4),(10,1154,0,4),(10,1155,0,4),(10,1156,0,16),(12,21,668,65),(12,46,0,4),(12,47,12316,17),(12,54,10735,17),(12,59,0,16),(12,67,0,14),(12,68,0,6),(12,69,15137,17),(12,70,-3190,3),(12,72,21084,17),(12,76,0,6),(12,81,0,6),(12,83,0,4),(12,86,0,4),(12,87,-1043,3),(12,92,-29500,3),(12,93,6050,3),(12,169,0,12),(12,270,0,16),(12,289,0,4),(12,349,638,1),(12,369,325,65),(12,469,500,25),(12,470,325,65),(12,471,0,20),(12,509,0,17),(12,510,0,2),(12,529,0,0),(12,530,0,6),(12,549,0,4),(12,550,0,4),(12,551,0,4),(12,569,0,4),(12,570,0,4),(12,571,0,4),(12,574,0,4),(12,576,0,2),(12,577,325,65),(12,589,0,0),(12,609,0,0),(12,729,0,2),(12,730,0,16),(12,749,0,0),(12,809,0,16),(12,889,0,6),(12,890,0,16),(12,891,0,24),(12,892,0,0),(12,909,0,17),(12,910,0,2),(12,911,0,6),(12,922,0,6),(12,930,20987,17),(12,932,0,80),(12,933,0,16),(12,934,0,82),(12,935,0,16),(12,936,0,28),(12,941,0,6),(12,942,0,16),(12,946,0,16),(12,947,0,2),(12,948,0,8),(12,949,0,24),(12,952,0,0),(12,967,0,16),(12,970,0,0),(12,978,0,16),(12,980,0,0),(12,989,0,16),(12,990,0,16),(12,1005,0,4),(12,1011,0,16),(12,1012,0,16),(12,1015,0,2),(12,1031,0,16),(12,1037,0,136),(12,1038,0,16),(12,1050,0,16),(12,1052,0,2),(12,1064,0,6),(12,1067,0,2),(12,1068,0,16),(12,1073,0,16),(12,1077,0,16),(12,1082,0,4),(12,1085,0,6),(12,1090,0,16),(12,1091,0,16),(12,1094,0,16),(12,1097,0,0),(12,1098,0,16),(12,1104,0,16),(12,1105,0,16),(12,1106,0,16),(12,1117,0,12),(12,1118,0,12),(12,1119,0,2),(12,1124,0,6),(12,1126,0,16),(12,1136,0,4),(12,1137,0,4),(12,1154,0,4),(12,1155,0,4),(12,1156,0,16),(14,21,9,65),(14,46,0,4),(14,47,1500,17),(14,54,1500,17),(14,59,0,16),(14,67,0,14),(14,68,0,6),(14,69,1500,17),(14,70,-947,3),(14,72,6000,17),(14,76,0,6),(14,81,0,6),(14,83,0,4),(14,86,0,4),(14,87,-54,3),(14,92,0,2),(14,93,0,2),(14,169,0,12),(14,270,0,16),(14,289,0,4),(14,349,159,1),(14,369,3,65),(14,469,0,25),(14,470,3,65),(14,471,0,4),(14,509,0,16),(14,510,0,2),(14,529,0,0),(14,530,0,6),(14,549,0,4),(14,550,0,4),(14,551,0,4),(14,569,0,4),(14,570,0,4),(14,571,0,4),(14,574,0,4),(14,576,0,2),(14,577,3,65),(14,589,0,0),(14,609,0,0),(14,729,0,2),(14,730,0,16),(14,749,0,0),(14,809,0,16),(14,889,0,6),(14,890,0,16),(14,891,0,24),(14,892,0,14),(14,909,0,17),(14,910,0,2),(14,911,0,6),(14,922,0,6),(14,930,1500,17),(14,932,0,80),(14,933,0,16),(14,934,0,80),(14,935,0,16),(14,936,0,28),(14,941,0,6),(14,942,0,16),(14,946,0,16),(14,947,0,2),(14,948,0,8),(14,949,0,24),(14,952,0,0),(14,967,0,16),(14,970,0,0),(14,978,0,16),(14,980,0,0),(14,989,0,16),(14,990,0,16),(14,1005,0,0),(14,1011,0,16),(14,1012,0,16),(14,1015,0,2),(14,1031,0,16),(14,1037,0,136),(14,1038,0,16),(14,1050,0,16),(14,1052,0,2),(14,1064,0,6),(14,1067,0,2),(14,1068,0,16),(14,1073,0,16),(14,1077,0,16),(14,1082,0,4),(14,1085,0,6),(14,1090,0,16),(14,1091,0,16),(14,1094,0,16),(14,1097,0,0),(14,1098,4563,17),(14,1104,0,16),(14,1105,0,16),(14,1106,0,16),(14,1117,0,12),(14,1118,0,12),(14,1119,0,2),(14,1124,0,6),(14,1126,0,16),(14,1136,0,4),(14,1137,0,4),(14,1154,0,4),(14,1155,0,4),(14,1156,0,16),(15,21,0,64),(15,46,0,4),(15,47,0,6),(15,54,0,6),(15,59,0,16),(15,67,0,25),(15,68,489,17),(15,69,0,6),(15,70,0,2),(15,72,0,6),(15,76,489,17),(15,81,489,17),(15,83,0,4),(15,86,0,4),(15,87,0,2),(15,92,0,2),(15,93,0,2),(15,169,0,12),(15,270,0,16),(15,289,0,4),(15,349,0,0),(15,369,0,64),(15,469,0,14),(15,470,0,64),(15,471,0,22),(15,509,0,2),(15,510,0,16),(15,529,0,0),(15,530,489,17),(15,549,0,4),(15,550,0,4),(15,551,0,4),(15,569,0,4),(15,570,0,4),(15,571,0,4),(15,574,0,4),(15,576,0,2),(15,577,0,64),(15,589,0,6),(15,609,0,0),(15,729,0,16),(15,730,0,2),(15,749,0,0),(15,809,0,16),(15,889,0,16),(15,890,0,6),(15,891,0,0),(15,892,0,24),(15,909,0,16),(15,910,0,2),(15,911,1980,17),(15,922,0,16),(15,930,0,6),(15,932,0,82),(15,933,0,16),(15,934,0,80),(15,935,0,16),(15,936,0,28),(15,941,0,16),(15,942,0,16),(15,946,0,2),(15,947,0,16),(15,948,0,8),(15,949,0,24),(15,952,0,0),(15,967,0,16),(15,970,0,0),(15,978,0,2),(15,980,0,0),(15,989,0,16),(15,990,0,16),(15,1005,0,4),(15,1011,0,16),(15,1012,0,16),(15,1015,0,2),(15,1031,0,16),(15,1037,0,6),(15,1038,0,16),(15,1050,0,6),(15,1052,0,152),(15,1064,0,16),(15,1067,0,16),(15,1068,0,6),(15,1073,0,16),(15,1077,0,16),(15,1082,0,2),(15,1085,0,16),(15,1090,0,16),(15,1091,0,16),(15,1094,0,6),(15,1097,0,0),(15,1098,0,16),(15,1104,0,16),(15,1105,0,16),(15,1106,0,16),(15,1117,0,12),(15,1118,0,12),(15,1119,0,2),(15,1124,0,16),(15,1126,0,2),(15,1136,0,4),(15,1137,0,4),(15,1154,0,4),(15,1155,0,4),(15,1156,0,16),(16,21,0,64),(16,46,0,4),(16,47,0,17),(16,54,0,17),(16,59,0,16),(16,67,0,14),(16,68,0,6),(16,69,0,17),(16,70,0,2),(16,72,0,17),(16,76,0,6),(16,81,0,6),(16,83,0,4),(16,86,0,4),(16,87,0,2),(16,92,0,2),(16,93,0,2),(16,169,0,12),(16,270,0,16),(16,289,0,4),(16,349,0,0),(16,369,0,64),(16,469,0,25),(16,470,0,64),(16,471,0,20),(16,509,0,16),(16,510,0,2),(16,529,0,0),(16,530,0,6),(16,549,0,4),(16,550,0,4),(16,551,0,4),(16,569,0,4),(16,570,0,4),(16,571,0,4),(16,574,0,4),(16,576,0,2),(16,577,0,64),(16,589,0,0),(16,609,0,0),(16,729,0,2),(16,730,0,16),(16,749,0,0),(16,809,0,16),(16,889,0,6),(16,890,0,16),(16,891,0,24),(16,892,0,14),(16,909,0,16),(16,910,0,0),(16,911,0,6),(16,922,0,6),(16,930,0,17),(16,932,0,80),(16,933,0,16),(16,934,0,80),(16,935,0,16),(16,936,0,28),(16,941,0,6),(16,942,0,16),(16,946,0,16),(16,947,0,0),(16,948,0,8),(16,949,0,24),(16,952,0,0),(16,967,0,16),(16,970,0,0),(16,978,0,16),(16,980,0,0),(16,989,0,16),(16,990,0,16),(16,1005,0,4),(16,1011,0,16),(16,1012,0,16),(16,1015,0,2),(16,1031,0,16),(16,1037,0,136),(16,1038,0,16),(16,1050,0,16),(16,1052,0,0),(16,1064,0,6),(16,1067,0,0),(16,1068,0,16),(16,1073,0,16),(16,1077,0,16),(16,1082,0,4),(16,1085,0,6),(16,1090,0,16),(16,1091,0,16),(16,1094,0,16),(16,1097,0,0),(16,1098,0,16),(16,1104,0,16),(16,1105,0,16),(16,1106,0,16),(16,1117,0,12),(16,1118,0,12),(16,1119,0,0),(16,1124,0,6),(16,1126,0,16),(16,1136,0,4),(16,1137,0,4),(16,1154,0,4),(16,1155,0,4),(16,1156,0,16),(17,21,0,64),(17,46,0,4),(17,47,0,17),(17,54,0,17),(17,59,0,16),(17,67,0,14),(17,68,0,6),(17,69,0,17),(17,70,0,2),(17,72,0,17),(17,76,0,6),(17,81,0,6),(17,83,0,4),(17,86,0,4),(17,87,0,2),(17,92,0,2),(17,93,0,2),(17,169,0,12),(17,270,0,16),(17,289,0,4),(17,349,0,0),(17,369,0,64),(17,469,0,25),(17,470,0,64),(17,471,0,20),(17,509,0,16),(17,510,0,2),(17,529,0,0),(17,530,0,6),(17,549,0,4),(17,550,0,4),(17,551,0,4),(17,569,0,4),(17,570,0,4),(17,571,0,4),(17,574,0,4),(17,576,0,2),(17,577,0,64),(17,589,0,0),(17,609,0,0),(17,729,0,2),(17,730,0,16),(17,749,0,0),(17,809,0,16),(17,889,0,6),(17,890,0,16),(17,891,0,24),(17,892,0,14),(17,909,0,16),(17,910,0,2),(17,911,0,6),(17,922,0,6),(17,930,0,17),(17,932,0,80),(17,933,0,16),(17,934,0,80),(17,935,0,16),(17,936,0,28),(17,941,0,6),(17,942,0,16),(17,946,0,16),(17,947,0,2),(17,948,0,8),(17,949,0,24),(17,952,0,0),(17,967,0,16),(17,970,0,0),(17,978,0,16),(17,980,0,0),(17,989,0,16),(17,990,0,16),(17,1005,0,4),(17,1011,0,16),(17,1012,0,16),(17,1015,0,2),(17,1031,0,16),(17,1037,0,136),(17,1038,0,16),(17,1050,0,16),(17,1052,0,2),(17,1064,0,6),(17,1067,0,2),(17,1068,0,16),(17,1073,0,16),(17,1077,0,16),(17,1082,0,4),(17,1085,0,6),(17,1090,0,16),(17,1091,0,16),(17,1094,0,16),(17,1097,0,0),(17,1098,0,16),(17,1104,0,16),(17,1105,0,16),(17,1106,0,16),(17,1117,0,12),(17,1118,0,12),(17,1119,0,2),(17,1124,0,6),(17,1126,0,16),(17,1136,0,4),(17,1137,0,4),(17,1154,0,4),(17,1155,0,4),(17,1156,0,16);
/*!40000 ALTER TABLE `character_reputation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_skills`
--

DROP TABLE IF EXISTS `character_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_skills` (
  `guid` int(10) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` smallint(5) unsigned NOT NULL,
  `value` smallint(5) unsigned NOT NULL,
  `max` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_skills`
--

LOCK TABLES `character_skills` WRITE;
/*!40000 ALTER TABLE `character_skills` DISABLE KEYS */;
INSERT INTO `character_skills` VALUES (2,43,15,85),(2,44,1,85),(2,45,85,85),(2,50,5,85),(2,51,5,85),(2,55,1,85),(2,95,81,85),(2,109,300,300),(2,137,300,300),(2,162,1,85),(2,163,5,85),(2,165,19,75),(2,172,38,85),(2,173,78,85),(2,176,1,85),(2,183,5,85),(2,185,35,75),(2,393,38,75),(2,414,1,1),(2,415,1,1),(2,756,5,85),(2,777,1,85),(2,778,1,85),(5,26,5,505),(5,43,353,505),(5,44,1,505),(5,54,1,505),(5,55,1,505),(5,95,55,505),(5,98,300,300),(5,118,1,505),(5,136,1,505),(5,160,32,505),(5,162,42,505),(5,172,1,505),(5,173,1,505),(5,183,5,505),(5,226,1,505),(5,229,1,505),(5,256,5,505),(5,257,5,505),(5,293,1,1),(5,413,1,1),(5,414,1,1),(5,415,1,1),(5,433,1,1),(5,754,5,505),(5,777,1,505),(5,778,1,505),(7,38,5,5),(7,39,5,5),(7,95,1,5),(7,98,300,300),(7,118,5,5),(7,162,1,5),(7,173,1,5),(7,176,1,5),(7,183,5,5),(7,253,5,5),(7,414,1,1),(7,415,1,1),(7,754,5,5),(7,777,1,5),(7,778,1,5),(8,26,5,505),(8,43,1,505),(8,44,1,505),(8,54,1,505),(8,55,1,505),(8,95,1,505),(8,98,300,300),(8,101,5,505),(8,111,300,300),(8,160,1,505),(8,162,1,505),(8,172,1,505),(8,173,1,505),(8,183,5,505),(8,256,5,505),(8,257,5,505),(8,413,1,1),(8,414,1,1),(8,415,1,1),(8,433,1,1),(8,777,1,505),(8,778,1,505),(9,26,5,505),(9,43,1,505),(9,44,1,505),(9,54,1,505),(9,55,1,505),(9,95,1,505),(9,98,300,300),(9,101,5,505),(9,111,300,300),(9,160,1,505),(9,162,1,505),(9,172,1,505),(9,173,1,505),(9,183,5,505),(9,256,5,505),(9,257,5,505),(9,413,1,1),(9,414,1,1),(9,415,1,1),(9,433,1,1),(9,777,1,505),(9,778,1,505),(10,38,5,5),(10,39,5,5),(10,95,1,5),(10,98,300,300),(10,118,5,5),(10,162,1,5),(10,173,1,5),(10,176,1,5),(10,183,5,5),(10,253,5,5),(10,414,1,1),(10,415,1,1),(10,754,5,5),(10,777,1,5),(10,778,1,5),(12,43,198,200),(12,44,1,200),(12,45,198,200),(12,50,5,200),(12,51,5,200),(12,55,57,200),(12,95,198,200),(12,98,300,300),(12,118,1,200),(12,129,300,300),(12,136,1,200),(12,162,49,200),(12,163,5,200),(12,165,215,300),(12,172,38,200),(12,173,112,200),(12,176,1,200),(12,183,5,200),(12,185,212,300),(12,226,33,200),(12,356,55,150),(12,393,236,300),(12,414,1,1),(12,415,1,1),(12,473,49,200),(12,759,300,300),(12,760,5,200),(12,762,150,150),(12,777,1,200),(12,778,1,200),(14,43,270,535),(14,44,270,535),(14,55,270,535),(14,95,535,535),(14,98,300,300),(14,101,275,535),(14,111,300,300),(14,118,275,535),(14,129,270,300),(14,162,270,535),(14,172,430,535),(14,183,275,535),(14,229,270,535),(14,293,1,1),(14,413,1,1),(14,414,1,1),(14,415,1,1),(14,762,150,150),(14,770,275,535),(14,771,270,535),(14,772,275,535),(14,776,1,1),(14,777,270,535),(14,778,270,535),(15,38,5,25),(15,39,5,25),(15,95,21,25),(15,109,300,300),(15,118,5,25),(15,137,300,300),(15,162,1,25),(15,173,20,25),(15,176,12,25),(15,183,5,25),(15,253,5,25),(15,414,1,1),(15,415,1,1),(15,756,5,25),(15,777,1,25),(15,778,1,25),(16,54,1,505),(16,95,3,505),(16,98,300,300),(16,113,300,300),(16,126,5,505),(16,134,5,505),(16,136,1,505),(16,162,1,505),(16,173,1,505),(16,183,5,505),(16,414,1,1),(16,415,1,1),(16,573,5,505),(16,574,5,505),(16,762,225,225),(16,777,1,505),(16,778,1,505),(17,26,5,5),(17,43,1,5),(17,44,1,5),(17,54,1,5),(17,55,1,5),(17,95,1,5),(17,98,300,300),(17,160,1,5),(17,162,1,5),(17,172,1,5),(17,173,1,5),(17,183,5,5),(17,256,5,5),(17,257,5,5),(17,413,1,1),(17,414,1,1),(17,415,1,1),(17,433,1,1),(17,754,5,5),(17,777,1,5),(17,778,1,5);
/*!40000 ALTER TABLE `character_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_social`
--

DROP TABLE IF EXISTS `character_social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_social` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL DEFAULT '' COMMENT 'Friend Note',
  PRIMARY KEY (`guid`,`friend`,`flags`),
  KEY `friend` (`friend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_social`
--

LOCK TABLES `character_social` WRITE;
/*!40000 ALTER TABLE `character_social` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell`
--

DROP TABLE IF EXISTS `character_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell`
--

LOCK TABLES `character_spell` WRITE;
/*!40000 ALTER TABLE `character_spell` DISABLE KEYS */;
INSERT INTO `character_spell` VALUES (2,136,1,0),(2,883,1,0),(2,982,1,0),(2,1002,1,0),(2,1130,1,0),(2,1494,1,0),(2,1495,1,0),(2,1513,1,0),(2,1515,1,0),(2,2108,1,0),(2,2153,1,0),(2,2539,1,0),(2,2550,1,0),(2,2641,1,0),(2,2974,1,0),(2,3127,1,0),(2,5116,1,0),(2,5118,1,0),(2,6197,1,0),(2,6991,1,0),(2,8613,1,0),(2,13163,1,0),(2,13165,1,0),(2,13549,1,0),(2,13795,1,0),(2,14261,1,0),(2,14281,1,0),(2,19883,1,0),(2,20736,1,0),(2,27570,1,0),(2,37836,1,0),(5,72,1,0),(5,676,1,0),(5,694,1,0),(5,871,1,0),(5,1161,1,0),(5,1680,1,0),(5,1715,1,0),(5,1719,1,0),(5,2565,1,0),(5,2687,1,0),(5,3127,1,0),(5,3411,1,0),(5,5246,1,0),(5,6552,1,0),(5,7384,1,0),(5,11578,1,0),(5,12678,1,0),(5,18499,1,0),(5,20230,1,0),(5,20252,1,0),(5,23920,1,0),(5,34428,1,0),(5,47436,1,0),(5,47437,1,0),(5,47440,1,0),(5,47450,1,0),(5,47465,1,0),(5,47471,1,0),(5,47475,1,0),(5,47488,1,0),(5,47502,1,0),(5,47520,1,0),(5,55694,1,0),(5,57755,1,0),(5,57823,1,0),(5,64382,1,0),(12,781,1,0),(12,883,1,0),(12,982,1,0),(12,1002,1,0),(12,1462,1,0),(12,1494,1,0),(12,1499,1,0),(12,1515,1,0),(12,1543,1,0),(12,2153,1,0),(12,2158,1,0),(12,2159,1,0),(12,2160,1,0),(12,2161,1,0),(12,2162,1,0),(12,2165,1,0),(12,2166,1,0),(12,2167,1,0),(12,2168,1,0),(12,2169,1,0),(12,2539,1,0),(12,2541,1,0),(12,2544,1,0),(12,2546,1,0),(12,2549,1,0),(12,2641,1,0),(12,2974,1,0),(12,3034,1,0),(12,3043,1,0),(12,3045,1,0),(12,3127,1,0),(12,3276,1,0),(12,3277,1,0),(12,3278,1,0),(12,3399,1,0),(12,3400,1,0),(12,3662,1,0),(12,3753,1,0),(12,3756,1,0),(12,3759,1,0),(12,3760,1,0),(12,3761,1,0),(12,3762,1,0),(12,3763,1,0),(12,3764,1,0),(12,3766,1,0),(12,3768,1,0),(12,3770,1,0),(12,3774,1,0),(12,3776,1,0),(12,3779,1,0),(12,3780,1,0),(12,3816,1,0),(12,3817,1,0),(12,3818,1,0),(12,5116,1,0),(12,5118,1,0),(12,5384,1,0),(12,6197,1,0),(12,6499,1,0),(12,6500,1,0),(12,6661,1,0),(12,6704,1,0),(12,6991,1,0),(12,7135,1,0),(12,7147,1,0),(12,7149,1,0),(12,7151,1,0),(12,7153,1,0),(12,7156,1,0),(12,7731,1,0),(12,7751,1,0),(12,7755,1,0),(12,7827,1,0),(12,7928,1,0),(12,7929,1,0),(12,7934,1,0),(12,9060,1,0),(12,9062,1,0),(12,9065,1,0),(12,9068,1,0),(12,9074,1,0),(12,9145,1,0),(12,9193,1,0),(12,9194,1,0),(12,9195,1,0),(12,9196,1,0),(12,9198,1,0),(12,9201,1,0),(12,9206,1,0),(12,10482,1,0),(12,10487,1,0),(12,10499,1,0),(12,10507,1,0),(12,10511,1,0),(12,10518,1,0),(12,10520,1,0),(12,10662,1,0),(12,10768,1,0),(12,10840,1,0),(12,10841,1,0),(12,10846,1,0),(12,13161,1,0),(12,13163,1,0),(12,13552,1,0),(12,13809,1,0),(12,13813,1,0),(12,14263,1,0),(12,14269,1,0),(12,14284,1,0),(12,14288,1,0),(12,14303,1,0),(12,14319,1,0),(12,14323,1,0),(12,14326,1,0),(12,15855,1,0),(12,18260,1,0),(12,18629,1,0),(12,18630,1,0),(12,19160,1,1),(12,19388,1,1),(12,19412,1,0),(12,19420,1,1),(12,19423,1,0),(12,19430,1,0),(12,19456,1,0),(12,19466,1,0),(12,19490,1,0),(12,19500,1,1),(12,19506,1,1),(12,19509,1,1),(12,19556,1,1),(12,19575,1,1),(12,19587,1,1),(12,19620,1,1),(12,19878,1,0),(12,19880,1,0),(12,19883,1,0),(12,19884,1,0),(12,19885,1,0),(12,20648,1,0),(12,20649,1,0),(12,20650,1,0),(12,20736,1,0),(12,20901,1,0),(12,21175,1,0),(12,23190,1,0),(12,23559,1,0),(12,23989,1,1),(12,24283,1,1),(12,24691,1,0),(12,25704,1,0),(12,25954,1,0),(12,33277,1,0),(12,33391,1,0),(12,34074,1,0),(12,34476,1,1),(12,34484,1,1),(12,34496,1,1),(12,34949,1,1),(12,34954,1,1),(12,35030,1,1),(12,35100,1,0),(12,35111,1,1),(12,35711,1,0),(12,35712,1,0),(12,35713,1,0),(12,35714,1,0),(12,37836,1,0),(12,52788,1,1),(12,53238,1,1),(12,53622,1,0),(12,63458,1,1),(14,23559,1,0),(14,42650,1,0),(14,45469,1,0),(14,45470,1,0),(14,45524,1,0),(14,45529,1,0),(14,46584,1,0),(14,47476,1,0),(14,47528,1,0),(14,47568,1,0),(14,47632,1,0),(14,47633,1,0),(14,48263,1,0),(14,48265,1,0),(14,48707,1,0),(14,48743,1,0),(14,48778,1,0),(14,48792,1,0),(14,48982,1,0),(14,49005,1,0),(14,49016,1,0),(14,49028,1,0),(14,49039,1,0),(14,49142,1,0),(14,49194,1,0),(14,49203,1,0),(14,49206,1,0),(14,49222,1,0),(14,49393,1,0),(14,49395,1,0),(14,49480,1,0),(14,49483,1,0),(14,49489,1,0),(14,49491,1,0),(14,49497,1,0),(14,49504,1,0),(14,49509,1,0),(14,49530,1,0),(14,49534,1,0),(14,49538,1,0),(14,49543,1,0),(14,49562,1,0),(14,49565,1,0),(14,49568,1,0),(14,49572,1,0),(14,49589,1,0),(14,49599,1,0),(14,49611,1,0),(14,49628,1,0),(14,49632,1,0),(14,49638,1,0),(14,49655,1,0),(14,49657,1,0),(14,49664,1,0),(14,49789,1,0),(14,49791,1,0),(14,49796,1,0),(14,49895,1,0),(14,49909,1,0),(14,49921,1,0),(14,49924,1,0),(14,49930,1,0),(14,49938,1,0),(14,49941,1,0),(14,50029,1,0),(14,50034,1,0),(14,50043,1,0),(14,50111,1,0),(14,50115,1,0),(14,50121,1,0),(14,50130,1,0),(14,50138,1,0),(14,50147,1,0),(14,50150,1,0),(14,50152,1,0),(14,50191,1,0),(14,50371,1,0),(14,50385,1,0),(14,50392,1,0),(14,50536,1,0),(14,50842,1,0),(14,50887,1,0),(14,50977,1,0),(14,51052,1,0),(14,51109,1,0),(14,51130,1,0),(14,51161,1,0),(14,51267,1,0),(14,51271,1,0),(14,51328,1,0),(14,51411,1,0),(14,51425,1,0),(14,51456,1,0),(14,51465,1,0),(14,51473,1,0),(14,51746,1,0),(14,51970,1,0),(14,51986,1,0),(14,52143,1,0),(14,52286,1,0),(14,52372,1,0),(14,52373,1,0),(14,52374,1,0),(14,52375,1,0),(14,53138,1,0),(14,53342,1,0),(14,53428,1,0),(14,54447,1,0),(14,54637,1,0),(14,55062,1,0),(14,55108,1,0),(14,55133,1,0),(14,55136,1,0),(14,55226,1,0),(14,55233,1,0),(14,55237,1,0),(14,55262,1,0),(14,55268,1,0),(14,55271,1,0),(14,55610,1,0),(14,55623,1,0),(14,55667,1,0),(14,56222,1,0),(14,56815,1,0),(14,56835,1,0),(14,57532,1,0),(14,57623,1,0),(14,59057,1,0),(14,61158,1,0),(14,61278,1,0),(14,61999,1,0),(14,62904,1,0),(14,62908,1,0),(14,63560,1,0),(14,66192,1,0),(14,66817,1,0),(15,1784,1,0),(16,768,1,0),(16,770,1,0),(16,783,1,0),(16,1066,1,0),(16,1178,1,0),(16,2782,1,0),(16,2893,1,0),(16,3025,1,0),(16,5209,1,0),(16,5215,1,0),(16,5229,1,0),(16,5420,1,0),(16,5421,1,0),(16,6795,1,0),(16,8946,1,0),(16,8983,1,0),(16,9634,1,0),(16,9635,1,0),(16,16818,1,0),(16,16820,1,0),(16,16822,1,0),(16,16835,1,0),(16,16840,1,0),(16,16847,1,0),(16,16857,1,0),(16,16862,1,0),(16,16864,1,0),(16,16899,1,0),(16,16913,1,0),(16,16924,1,0),(16,16931,1,0),(16,16938,1,0),(16,16941,1,0),(16,16944,1,0),(16,16949,1,0),(16,16954,1,0),(16,16961,1,0),(16,16968,1,0),(16,16975,1,0),(16,16979,1,0),(16,16999,1,0),(16,17007,1,0),(16,17051,1,0),(16,17061,1,0),(16,17066,1,0),(16,17073,1,0),(16,17078,1,0),(16,17108,1,0),(16,17113,1,0),(16,17116,1,0),(16,17120,1,0),(16,17124,1,0),(16,18562,1,0),(16,18658,1,0),(16,18960,1,0),(16,21178,1,0),(16,22812,1,0),(16,22842,1,0),(16,24858,1,0),(16,24866,1,0),(16,24894,1,0),(16,24905,1,0),(16,24907,1,0),(16,24946,1,0),(16,24972,1,0),(16,26995,1,0),(16,29166,1,0),(16,33357,1,0),(16,33591,1,0),(16,33596,1,0),(16,33602,1,0),(16,33607,1,0),(16,33786,1,0),(16,33831,1,0),(16,33856,1,0),(16,33867,1,0),(16,33873,1,0),(16,33880,1,0),(16,33883,1,0),(16,33890,1,0),(16,33891,1,0),(16,33917,1,0),(16,33956,1,0),(16,33957,1,0),(16,34153,1,0),(16,34300,1,0),(16,35364,1,0),(16,37117,1,0),(16,40120,1,0),(16,48378,1,0),(16,48393,1,0),(16,48396,1,0),(16,48410,1,0),(16,48412,1,0),(16,48441,1,0),(16,48443,1,0),(16,48445,1,0),(16,48447,1,0),(16,48451,1,0),(16,48461,1,0),(16,48463,1,0),(16,48465,1,0),(16,48466,1,0),(16,48467,1,0),(16,48468,1,0),(16,48469,1,0),(16,48470,1,0),(16,48477,1,0),(16,48480,1,0),(16,48485,1,0),(16,48491,1,0),(16,48495,1,0),(16,48500,1,0),(16,48511,1,0),(16,48514,1,0),(16,48525,1,0),(16,48537,1,0),(16,48545,1,0),(16,48560,1,0),(16,48562,1,0),(16,48564,1,0),(16,48566,1,0),(16,48568,1,0),(16,48570,1,0),(16,48572,1,0),(16,48574,1,0),(16,48575,1,0),(16,48577,1,0),(16,48579,1,0),(16,49376,1,0),(16,49377,1,0),(16,49800,1,0),(16,49802,1,0),(16,49803,1,0),(16,50213,1,0),(16,50322,1,0),(16,50334,1,0),(16,50464,1,0),(16,50763,1,0),(16,51183,1,0),(16,51269,1,0),(16,52610,1,0),(16,53201,1,0),(16,53227,1,0),(16,53251,1,0),(16,53307,1,0),(16,53308,1,0),(16,53312,1,0),(16,57814,1,0),(16,57851,1,0),(16,57865,1,0),(16,57877,1,0),(16,57881,1,0),(16,61336,1,0),(16,61346,1,0),(16,61384,1,0),(16,62078,1,0),(16,63411,1,0),(16,63503,1,0),(16,64801,1,0),(16,65139,1,0);
/*!40000 ALTER TABLE `character_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell_cooldown`
--

DROP TABLE IF EXISTS `character_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `item` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell_cooldown`
--

LOCK TABLES `character_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `character_spell_cooldown` DISABLE KEYS */;
INSERT INTO `character_spell_cooldown` VALUES (12,8690,6948,1544176634,1176,1544176634);
/*!40000 ALTER TABLE `character_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_stats`
--

DROP TABLE IF EXISTS `character_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_stats` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower1` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower2` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower3` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower4` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower5` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower6` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower7` int(10) unsigned NOT NULL DEFAULT '0',
  `strength` int(10) unsigned NOT NULL DEFAULT '0',
  `agility` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina` int(10) unsigned NOT NULL DEFAULT '0',
  `intellect` int(10) unsigned NOT NULL DEFAULT '0',
  `spirit` int(10) unsigned NOT NULL DEFAULT '0',
  `armor` int(10) unsigned NOT NULL DEFAULT '0',
  `resHoly` int(10) unsigned NOT NULL DEFAULT '0',
  `resFire` int(10) unsigned NOT NULL DEFAULT '0',
  `resNature` int(10) unsigned NOT NULL DEFAULT '0',
  `resFrost` int(10) unsigned NOT NULL DEFAULT '0',
  `resShadow` int(10) unsigned NOT NULL DEFAULT '0',
  `resArcane` int(10) unsigned NOT NULL DEFAULT '0',
  `blockPct` float unsigned NOT NULL DEFAULT '0',
  `dodgePct` float unsigned NOT NULL DEFAULT '0',
  `parryPct` float unsigned NOT NULL DEFAULT '0',
  `critPct` float unsigned NOT NULL DEFAULT '0',
  `rangedCritPct` float unsigned NOT NULL DEFAULT '0',
  `spellCritPct` float unsigned NOT NULL DEFAULT '0',
  `attackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `rangedAttackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `spellPower` int(10) unsigned NOT NULL DEFAULT '0',
  `resilience` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_stats`
--

LOCK TABLES `character_stats` WRITE;
/*!40000 ALTER TABLE `character_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_talent`
--

DROP TABLE IF EXISTS `character_talent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_talent` (
  `guid` int(10) unsigned NOT NULL,
  `spell` mediumint(8) unsigned NOT NULL,
  `talentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`,`talentGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_talent`
--

LOCK TABLES `character_talent` WRITE;
/*!40000 ALTER TABLE `character_talent` DISABLE KEYS */;
INSERT INTO `character_talent` VALUES (12,19412,0),(12,19423,0),(12,19430,0),(12,19434,0),(12,19456,0),(12,19466,0),(12,19490,0),(12,24691,0),(12,35100,0),(12,53622,0),(14,48982,0),(14,49005,0),(14,49016,0),(14,49028,0),(14,49039,0),(14,49143,0),(14,49158,0),(14,49184,0),(14,49194,0),(14,49203,0),(14,49206,0),(14,49222,0),(14,49393,0),(14,49395,0),(14,49480,0),(14,49483,0),(14,49489,0),(14,49491,0),(14,49497,0),(14,49504,0),(14,49509,0),(14,49530,0),(14,49534,0),(14,49538,0),(14,49543,0),(14,49562,0),(14,49565,0),(14,49568,0),(14,49572,0),(14,49589,0),(14,49599,0),(14,49611,0),(14,49628,0),(14,49632,0),(14,49638,0),(14,49655,0),(14,49657,0),(14,49664,0),(14,49789,0),(14,49791,0),(14,49796,0),(14,50029,0),(14,50034,0),(14,50043,0),(14,50115,0),(14,50121,0),(14,50130,0),(14,50138,0),(14,50147,0),(14,50150,0),(14,50152,0),(14,50191,0),(14,50371,0),(14,50385,0),(14,50392,0),(14,50887,0),(14,51052,0),(14,51109,0),(14,51130,0),(14,51161,0),(14,51267,0),(14,51271,0),(14,51456,0),(14,51465,0),(14,51473,0),(14,51746,0),(14,52143,0),(14,53138,0),(14,54637,0),(14,55050,0),(14,55062,0),(14,55090,0),(14,55108,0),(14,55133,0),(14,55136,0),(14,55226,0),(14,55233,0),(14,55237,0),(14,55610,0),(14,55623,0),(14,55667,0),(14,56835,0),(14,59057,0),(14,61158,0),(14,62908,0),(14,63560,0),(14,66192,0),(14,66817,0),(16,5570,0),(16,16818,0),(16,16820,0),(16,16822,0),(16,16835,0),(16,16840,0),(16,16847,0),(16,16862,0),(16,16864,0),(16,16899,0),(16,16913,0),(16,16924,0),(16,16931,0),(16,16938,0),(16,16941,0),(16,16944,0),(16,16949,0),(16,16968,0),(16,16975,0),(16,16999,0),(16,17007,0),(16,17051,0),(16,17061,0),(16,17066,0),(16,17073,0),(16,17078,0),(16,17108,0),(16,17113,0),(16,17116,0),(16,17120,0),(16,17124,0),(16,18562,0),(16,24858,0),(16,24866,0),(16,24894,0),(16,24946,0),(16,24972,0),(16,33591,0),(16,33596,0),(16,33602,0),(16,33607,0),(16,33831,0),(16,33856,0),(16,33867,0),(16,33873,0),(16,33880,0),(16,33883,0),(16,33890,0),(16,33917,0),(16,33956,0),(16,33957,0),(16,34153,0),(16,34300,0),(16,35364,0),(16,37117,0),(16,48393,0),(16,48396,0),(16,48410,0),(16,48412,0),(16,48438,0),(16,48485,0),(16,48491,0),(16,48495,0),(16,48500,0),(16,48505,0),(16,48511,0),(16,48514,0),(16,48525,0),(16,48537,0),(16,48545,0),(16,49377,0),(16,50334,0),(16,50516,0),(16,51183,0),(16,51269,0),(16,57814,0),(16,57851,0),(16,57865,0),(16,57877,0),(16,57881,0),(16,61336,0),(16,61346,0),(16,63411,0),(16,63503,0),(16,65139,0);
/*!40000 ALTER TABLE `character_talent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `account` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xp` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `skin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `face` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hairColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `facialStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `bankSlots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `restState` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `playerFlags` int(10) unsigned NOT NULL DEFAULT '0',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `instance_id` int(10) unsigned NOT NULL DEFAULT '0',
  `instance_mode_mask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `taximask` text NOT NULL,
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cinematic` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  `leveltime` int(10) unsigned NOT NULL DEFAULT '0',
  `logout_time` int(10) unsigned NOT NULL DEFAULT '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rest_bonus` float NOT NULL DEFAULT '0',
  `resettalents_cost` int(10) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` int(10) unsigned NOT NULL DEFAULT '0',
  `trans_x` float NOT NULL DEFAULT '0',
  `trans_y` float NOT NULL DEFAULT '0',
  `trans_z` float NOT NULL DEFAULT '0',
  `trans_o` float NOT NULL DEFAULT '0',
  `transguid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `extra_flags` smallint(5) unsigned NOT NULL DEFAULT '0',
  `stable_slots` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `at_login` smallint(5) unsigned NOT NULL DEFAULT '0',
  `zone` smallint(5) unsigned NOT NULL DEFAULT '0',
  `death_expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `todayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalKills` int(10) unsigned NOT NULL DEFAULT '0',
  `todayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `chosenTitle` int(10) unsigned NOT NULL DEFAULT '0',
  `knownCurrencies` bigint(20) unsigned NOT NULL DEFAULT '0',
  `watchedFaction` int(10) unsigned NOT NULL DEFAULT '0',
  `drunk` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `health` int(10) unsigned NOT NULL DEFAULT '0',
  `power1` int(10) unsigned NOT NULL DEFAULT '0',
  `power2` int(10) unsigned NOT NULL DEFAULT '0',
  `power3` int(10) unsigned NOT NULL DEFAULT '0',
  `power4` int(10) unsigned NOT NULL DEFAULT '0',
  `power5` int(10) unsigned NOT NULL DEFAULT '0',
  `power6` int(10) unsigned NOT NULL DEFAULT '0',
  `power7` int(10) unsigned NOT NULL DEFAULT '0',
  `latency` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `talentGroupsCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `activeTalentGroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL DEFAULT '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grantableLevels` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleteInfos_Account` int(10) unsigned DEFAULT NULL,
  `deleteInfos_Name` varchar(12) DEFAULT NULL,
  `deleteDate` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (2,2,'Ahoniis',10,3,1,17,16025,53239,5,1,5,7,10,0,1,3080,9262.38,-7013.52,5.14142,530,0,0,2.11134,'0 0 393216 4 0 0 0 0 0 0 0 0 0 0 ',0,1,32600,4998,1531498577,0,12300,0,0,0,0,0,0,0,1,0,0,3430,0,'',0,0,0,0,0,0,0,0,512,4294967295,0,1818,1785,0,0,100,0,0,0,109,1,0,'0 0 0 2147483648 0 0 0 0 0 0 0 1048576 0 0 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 3221225472 2143845373 269443807 536871024 65536 0 0 576 0 0 0 0 128 128 2147483648 3 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 0 32768 0 0 262144 2151677952 0 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','28182 0 0 0 42952 0 20901 0 48689 15 6517 0 44347 0 18424 0 22004 0 29327 0 29282 0 51991 0 0 0 0 0 23400 0 42944 0 0 0 42946 0 0 0 51809 0 51809 0 51809 0 51809 0 ',2515,'0 0 0 0 0 0 ',5,0,NULL,NULL,NULL),(5,3,'Hacedor',1,1,0,101,0,93245296,7,1,5,6,0,0,2,11,9514.75,-7109.63,14.2043,530,0,0,2.20873,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,53512,32003,1532868775,0,0,0,0,0,0,0,0,0,1,0,0,3487,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,11091,0,0,0,100,0,0,0,9,1,0,'0 0 0 1610612736 640 524288 134479872 2620847680 15 0 0 8388608 0 0 0 0 0 16 2147483650 0 13631488 73728 0 0 134217728 0 3758243840 26 0 0 12 0 0 3489660928 1288330812 787648 1073741944 0 0 0 0 0 0 0 0 0 4096 3221225472 0 90112 0 0 536870912 18850816 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','21803 0 0 0 100041 0 0 0 12422 0 12424 0 13498 0 12426 0 0 0 100048 0 0 0 0 0 0 0 0 0 0 0 25825 0 0 0 0 0 52252 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(7,12,'Olivia',1,4,1,1,0,0,0,0,4,1,0,0,2,8,16187.8,16240.7,4.35093,1,0,0,3.06884,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 ',0,1,2813,2813,1523643862,0,0.00241111,0,0,0,0,0,0,0,1,0,0,876,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,55,0,0,0,100,0,0,0,37,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 49 0 0 0 0 0 48 0 47 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2092 0 50055 0 28979 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(8,3,'Enano',3,1,0,101,0,0,7,9,2,8,6,0,2,8,2902.31,-808.384,160.333,0,0,0,0.0771394,'32 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,1372,1134,1525004771,0,0,0,0,0,0,0,0,0,1,0,0,796,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,10091,0,0,0,100,0,0,0,12,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','100020 0 0 0 0 0 38 0 100023 0 100024 0 100025 0 100026 0 100027 0 100028 0 0 0 0 0 0 0 0 0 100029 0 12282 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(9,3,'Enan',3,1,0,101,0,0,6,2,7,0,6,0,2,8,2876.78,-768.298,160.33,0,0,0,3.24699,'32 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,353,327,1525003556,0,0.000688889,0,0,0,0,0,0,0,1,0,0,796,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,10091,0,0,0,100,0,0,0,16,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 12282 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(10,3,'Superaznar',1,4,0,1,0,0,2,10,1,0,7,0,2,8,-9000.71,-87.1762,85.9392,0,0,0,2.13819,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 ',0,1,615,615,1525016746,0,0.00120556,0,0,0,0,0,0,0,1,0,0,12,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,55,0,0,0,100,0,0,0,18,1,0,'0 0 0 536870912 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(12,1,'Eolion',11,3,1,40,32238,2829451,11,8,3,4,0,3,1,1024,-14415.9,426.191,23.6985,0,0,0,0.695454,'167815274 17 805306368 8 0 64 0 0 0 0 0 0 0 0 ',0,1,171042,2451,1544175668,0,36014.3,0,0,0,0,0,0,0,4,4,0,33,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,2387,2415,0,0,100,0,0,0,71,1,0,'1406795776 2709258645 7 1082130432 6078480 31457280 1040 40 1073742912 14 3172204544 17 1024 1627389952 3054234488 6237 33554448 2638384 2080260224 17958818 517 1770368 2081028 1610612736 3221225472 262404 0 50331776 56623104 134217729 16777344 0 0 0 65536 4026531840 2684354567 4220517825 1120071 32768 0 0 0 0 0 0 256 973176832 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','4052 0 12019 0 42952 0 0 0 48689 15 6788 0 44347 15 14579 18 3230 0 3754 0 2043 0 6321 0 0 0 0 0 13108 0 6829 0 44096 0 42946 0 45580 0 51809 0 51809 0 51809 0 51809 0 ',3030,'0 0 0 0 0 0 ',15,0,NULL,NULL,NULL),(14,2,'Bulldoza',3,6,1,107,0,270734,4,17,1,11,5,0,2,1,-14293.9,529.83,8.72512,0,0,0,2.80284,'4294967295 2483027967 829882367 8 16384 1310944 3251642388 73752 896 67111952 2281701376 4190109713 1049856 12582912 ',0,1,21874,19374,1544175654,0,0,0,0,0,0,0,0,0,0,0,0,33,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,12231,0,0,0,100,0,0,0,71,1,0,'0 19136512 524288 1075855424 4734980 0 0 0 1073808384 0 0 132632 4194304 536870912 32 0 0 2097168 974782464 128 2415919105 1114112 8388608 0 0 2097152 0 0 50331648 168034304 128 0 0 268435456 8913440 262160 536870968 0 0 0 0 0 0 0 0 0 0 0 0 24576 0 0 0 18251776 0 0 0 0 0 0 1073741824 0 1 0 1410683973 4116 0 128 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 67108864 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','38661 0 38662 0 38663 0 0 0 38665 0 34651 0 34656 0 38670 0 38666 0 38667 0 38671 0 38672 0 38675 0 38674 0 38664 0 38633 0 0 0 39208 0 0 0 38145 0 38145 0 38145 0 38145 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(15,2,'Giselle',10,4,1,5,364,799,2,8,11,0,9,0,2,2,9954.84,-6513.67,7.05948,530,0,0,0.524548,'0 0 131072 4 0 0 0 0 0 0 0 0 0 0 ',0,1,9653,3225,1531504054,0,0.441692,0,0,0,0,0,0,0,0,0,0,3430,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,113,0,0,0,100,0,0,0,63,1,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4194304 0 16 0 0 0 0 0 0 0 0 0 0 0 0 57344 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 20897 0 0 0 20996 0 20896 0 21010 0 0 0 20993 0 0 0 0 0 0 0 0 0 0 0 20836 0 50057 0 28979 0 0 0 20474 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(16,2,'Flowapowa',4,11,1,101,0,30000107,7,3,6,7,9,0,2,0,-9482.08,76.2124,56.5281,0,0,0,5.17141,'100663296 0 0 8 0 0 1048576 0 0 0 0 0 0 0 ',0,1,936,922,1533719169,0,0.00258333,0,0,0,0,0,0,0,0,0,0,12,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,8757,7281,0,0,100,0,0,0,0,1,0,'64 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 131088 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 0 0 6123 0 0 0 6124 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 3661 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL),(17,23,'Gerd',1,1,0,1,45,0,1,6,9,3,4,0,2,32,-9464.48,12.8403,56.963,0,0,0,4.49187,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 ',0,1,609,609,1533828652,1,0.23555,0,0,0,0,0,0,0,4,0,0,12,0,'',0,0,0,0,0,0,0,0,0,4294967295,0,60,0,0,0,100,0,0,0,32,1,0,'0 0 0 1610612736 0 0 0 0 0 0 0 0 0 0 0 0 0 16 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 0 0 0 0 39 0 40 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49778 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,'0 0 0 0 0 0 ',0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corpse`
--

DROP TABLE IF EXISTS `corpse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corpse` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `phaseMask` int(10) unsigned NOT NULL DEFAULT '1',
  `displayId` int(10) unsigned NOT NULL DEFAULT '0',
  `itemCache` text NOT NULL,
  `bytes1` int(10) unsigned NOT NULL DEFAULT '0',
  `bytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `guildId` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `dynFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `corpseType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`),
  KEY `idx_type` (`corpseType`),
  KEY `idx_instance` (`instanceId`),
  KEY `idx_time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Death System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corpse`
--

LOCK TABLES `corpse` WRITE;
/*!40000 ALTER TABLE `corpse` DISABLE KEYS */;
/*!40000 ALTER TABLE `corpse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creature_respawn`
--

DROP TABLE IF EXISTS `creature_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creature_respawn`
--

LOCK TABLES `creature_respawn` WRITE;
/*!40000 ALTER TABLE `creature_respawn` DISABLE KEYS */;
INSERT INTO `creature_respawn` VALUES (2089,1530710413,0,0),(2352,1529290807,530,0),(2355,1529291098,530,0),(2360,1529290226,530,0),(2567,1544174708,0,0),(2568,1544174774,0,0),(2570,1544174740,0,0),(2571,1544175665,0,0),(2572,1544175647,0,0),(2574,1544175704,0,0),(2576,1544175698,0,0),(2580,1544175583,0,0),(2581,1544175554,0,0),(2584,1544175689,0,0),(2586,1544175700,0,0),(2625,1544175605,0,0),(2634,1544175017,0,0),(3498,1523468128,530,0),(3506,1523468101,530,0),(3643,1530647403,0,0),(4233,1529829878,0,0),(4236,1529829866,0,0),(4237,1529829945,0,0),(4254,1529829844,0,0),(4259,1529829935,0,0),(4262,1529829959,0,0),(4263,1529829972,0,0),(4267,1529752428,0,0),(4271,1529733281,0,0),(4272,1529752383,0,0),(4302,1529733235,0,0),(4317,1529824081,0,0),(4319,1529752406,0,0),(4320,1529752444,0,0),(4327,1529733252,0,0),(4356,1529820452,0,0),(4359,1529829785,0,0),(4406,1529733396,0,0),(4418,1529733320,0,0),(4423,1529733374,0,0),(4424,1529733352,0,0),(4430,1529829732,0,0),(4439,1529824785,0,0),(4440,1529824770,0,0),(4442,1529751899,0,0),(4444,1529738354,0,0),(4454,1529824503,0,0),(4455,1529824469,0,0),(4456,1529824451,0,0),(4457,1529824522,0,0),(4829,1529824217,0,0),(4866,1529820291,0,0),(4869,1529752459,0,0),(4870,1529752495,0,0),(4874,1529752516,0,0),(4875,1529752541,0,0),(4877,1529752554,0,0),(4878,1529829617,0,0),(4888,1529830793,0,0),(4892,1529828618,0,0),(4893,1529828509,0,0),(4896,1529820336,0,0),(4904,1529739451,0,0),(4925,1529739421,0,0),(4927,1529740258,0,0),(4941,1529740109,0,0),(4943,1529739805,0,0),(4944,1529739791,0,0),(4945,1529739886,0,0),(4947,1529824354,0,0),(4960,1529820434,0,0),(4961,1529825025,0,0),(4962,1529824666,0,0),(4963,1529823140,0,0),(4964,1529823175,0,0),(4965,1529824677,0,0),(4968,1529824992,0,0),(4969,1529820273,0,0),(4970,1529824974,0,0),(4972,1529740320,0,0),(4973,1529745386,0,0),(4976,1530644040,0,0),(4977,1530644027,0,0),(4978,1529824746,0,0),(4979,1529745886,0,0),(4981,1529823015,0,0),(4984,1529822878,0,0),(4985,1529746240,0,0),(4988,1529824727,0,0),(4990,1529823028,0,0),(4991,1529830529,0,0),(4993,1529740281,0,0),(5001,1529824910,0,0),(5002,1529830618,0,0),(5003,1529824938,0,0),(5004,1529824920,0,0),(5005,1529824709,0,0),(5010,1529824242,0,0),(5017,1529828926,0,0),(5018,1529828818,0,0),(5019,1529828959,0,0),(5020,1529828916,0,0),(5021,1529828689,0,0),(5023,1529828640,0,0),(5024,1529828562,0,0),(5029,1529831595,0,0),(5030,1529831572,0,0),(5033,1529831548,0,0),(5036,1529752887,0,0),(5038,1529739550,0,0),(5039,1529752937,0,0),(5040,1529740488,0,0),(5041,1529740512,0,0),(5042,1529739529,0,0),(5043,1529739511,0,0),(5044,1529825016,0,0),(5046,1529831696,0,0),(5048,1529831670,0,0),(5049,1530644105,0,0),(5050,1529831614,0,0),(5051,1529831630,0,0),(5052,1530644149,0,0),(5056,1530644635,0,0),(5058,1529831654,0,0),(5061,1529831714,0,0),(5062,1529831894,0,0),(5063,1529832140,0,0),(5064,1529832122,0,0),(5066,1529832032,0,0),(5068,1529831972,0,0),(5069,1529831989,0,0),(5070,1529831921,0,0),(5071,1529832061,0,0),(5072,1529832048,0,0),(5073,1529832185,0,0),(5074,1529831844,0,0),(5075,1529832199,0,0),(5076,1529832220,0,0),(5077,1529831751,0,0),(5078,1529831736,0,0),(5085,1529824951,0,0),(5086,1529825148,0,0),(5088,1529740169,0,0),(5089,1529740165,0,0),(5091,1529830594,0,0),(5092,1529820791,0,0),(5093,1529830709,0,0),(5095,1529830724,0,0),(5096,1530644118,0,0),(5101,1529830746,0,0),(5120,1529830614,0,0),(5121,1529830662,0,0),(5122,1529830559,0,0),(5124,1529830193,0,0),(5125,1530643928,0,0),(5127,1530643989,0,0),(5128,1530643958,0,0),(5130,1530644084,0,0),(5135,1529752189,0,0),(5137,1529830563,0,0),(5138,1529821006,0,0),(5140,1529740069,0,0),(5150,1529822798,0,0),(5156,1529820355,0,0),(5157,1529820381,0,0),(5159,1529820311,0,0),(5160,1529740307,0,0),(5162,1529824375,0,0),(5163,1529740344,0,0),(5164,1529824393,0,0),(5168,1529740267,0,0),(5175,1529740392,0,0),(5176,1529740142,0,0),(5178,1529752917,0,0),(5190,1529822125,0,0),(5192,1529752102,0,0),(5193,1529752062,0,0),(5194,1529752159,0,0),(5195,1529822495,0,0),(5197,1529822664,0,0),(5198,1529822102,0,0),(5884,1529822438,0,0),(5885,1529821895,0,0),(5886,1529822639,0,0),(5887,1529821866,0,0),(5888,1529821915,0,0),(5897,1529752227,0,0),(5923,1529752120,0,0),(5930,1529752139,0,0),(5931,1529824407,0,0),(5932,1529739178,0,0),(5933,1529824423,0,0),(5935,1529824140,0,0),(5936,1529824105,0,0),(5942,1529821150,0,0),(5958,1529752869,0,0),(5959,1529752841,0,0),(5961,1529752946,0,0),(5964,1529746199,0,0),(5966,1529745009,0,0),(5968,1529738290,0,0),(5972,1529744941,0,0),(5975,1529746223,0,0),(5976,1529746182,0,0),(5977,1529745711,0,0),(5978,1529746250,0,0),(5979,1529745930,0,0),(5980,1529744926,0,0),(5981,1529744680,0,0),(5982,1529744698,0,0),(5983,1529744994,0,0),(5985,1529738334,0,0),(5986,1529738303,0,0),(5988,1529738438,0,0),(5989,1529738581,0,0),(5990,1529738614,0,0),(5991,1529738648,0,0),(5993,1529738450,0,0),(5999,1529738417,0,0),(6000,1529738388,0,0),(6001,1529738498,0,0),(6003,1529738122,0,0),(6004,1529738245,0,0),(6005,1529738253,0,0),(6009,1529733458,0,0),(6010,1529733504,0,0),(6017,1529733531,0,0),(6018,1529751887,0,0),(6019,1529733474,0,0),(6021,1529733563,0,0),(6022,1529751975,0,0),(6023,1529751994,0,0),(6025,1529733489,0,0),(6027,1529751946,0,0),(6028,1529751924,0,0),(6053,1529733582,0,0),(6054,1529733600,0,0),(6055,1529733629,0,0),(6056,1529733732,0,0),(6059,1529821965,0,0),(6062,1529821943,0,0),(6073,1529822151,0,0),(6077,1529824192,0,0),(6080,1529824168,0,0),(6082,1529828663,0,0),(6083,1529828573,0,0),(6084,1529828540,0,0),(6093,1529828837,0,0),(6094,1529744465,0,0),(6098,1529823154,0,0),(6099,1529825043,0,0),(6107,1529822355,0,0),(6113,1529828768,0,0),(6117,1529822408,0,0),(6118,1529822343,0,0),(6119,1529822326,0,0),(6120,1529822538,0,0),(6125,1529822553,0,0),(6126,1529828892,0,0),(6128,1529828704,0,0),(6138,1529828718,0,0),(6510,1523465913,1,0),(6511,1523465968,1,0),(8143,1523468998,530,0),(8144,1523469013,530,0),(8145,1523468987,530,0),(8146,1523468928,530,0),(8147,1523468946,530,0),(8148,1523468955,530,0),(9492,1530518291,0,0),(9712,1530712573,0,0),(9746,1530712765,0,0),(9748,1530712783,0,0),(9750,1530712800,0,0),(9872,1530648121,0,0),(9890,1530648179,0,0),(9891,1530648090,0,0),(9924,1530647901,0,0),(9925,1530648130,0,0),(9926,1530648005,0,0),(9927,1530647848,0,0),(9928,1530648018,0,0),(9929,1530647873,0,0),(9933,1530647914,0,0),(9937,1530712403,0,0),(9941,1530712495,0,0),(10000,1530712533,0,0),(10005,1530518662,0,0),(10006,1530518447,0,0),(10011,1530518387,0,0),(10016,1530713573,0,0),(10018,1530713631,0,0),(10019,1530518644,0,0),(10023,1530712732,0,0),(10026,1530518892,0,0),(10028,1530518731,0,0),(10039,1530518903,0,0),(10041,1530518866,0,0),(10043,1530713586,0,0),(10044,1530518708,0,0),(10045,1530713602,0,0),(10046,1530518730,0,0),(10203,1530648162,0,0),(10224,1530648035,0,0),(10227,1530648023,0,0),(10250,1530711591,0,0),(10257,1530711706,0,0),(10262,1530711775,0,0),(10266,1530711714,0,0),(10342,1530711885,0,0),(10483,1530711671,0,0),(10484,1530711680,0,0),(10485,1530711569,0,0),(10487,1530712313,0,0),(10488,1530711997,0,0),(10489,1530712012,0,0),(10546,1530712060,0,0),(10549,1530712148,0,0),(10550,1530712122,0,0),(10578,1530711513,0,0),(10583,1530711819,0,0),(10585,1530712047,0,0),(10586,1530712306,0,0),(10588,1530711967,0,0),(10589,1530712093,0,0),(10590,1530712271,0,0),(10594,1530711949,0,0),(10606,1530712302,0,0),(10629,1530712248,0,0),(10638,1530713544,0,0),(10649,1530713609,0,0),(10736,1530647806,0,0),(10738,1530648225,0,0),(10742,1530647783,0,0),(10819,1530518332,0,0),(10820,1530518824,0,0),(10821,1530518873,0,0),(10822,1530518503,0,0),(10825,1530518530,0,0),(10826,1530518494,0,0),(10828,1530518428,0,0),(10829,1530518610,0,0),(10831,1530518621,0,0),(10847,1530711527,0,0),(10848,1530711611,0,0),(10875,1530519139,0,0),(10876,1530519128,0,0),(10877,1530519294,0,0),(10878,1530519374,0,0),(10879,1530519213,0,0),(10880,1530519201,0,0),(10882,1530519078,0,0),(10889,1530519404,0,0),(10890,1530519163,0,0),(10894,1530519261,0,0),(10898,1530519063,0,0),(10904,1530519248,0,0),(10912,1530518087,0,0),(10915,1530518121,0,0),(10927,1530518271,0,0),(10928,1530518238,0,0),(11004,1533658138,0,0),(11026,1530518073,0,0),(11040,1530518153,0,0),(11042,1530518159,0,0),(11043,1530518165,0,0),(11054,1530518149,0,0),(11056,1530518248,0,0),(11062,1530518203,0,0),(11064,1530518223,0,0),(11195,1530712587,0,0),(11196,1530712544,0,0),(11289,1530727366,0,0),(11305,1530886698,0,0),(11313,1530886724,0,0),(11316,1530886674,0,0),(11321,1530886430,0,0),(11366,1530886754,0,0),(11371,1530886791,0,0),(11398,1531291040,0,0),(11412,1531291229,0,0),(11435,1531291021,0,0),(11437,1531291091,0,0),(11438,1531291114,0,0),(11453,1531291225,0,0),(11468,1530717973,0,0),(11473,1531291325,0,0),(11486,1530717916,0,0),(11490,1530717944,0,0),(11507,1530718039,0,0),(11521,1531290843,0,0),(11528,1531291005,0,0),(11529,1531291158,0,0),(11535,1531291468,0,0),(11546,1530718212,0,0),(11567,1530732622,0,0),(11577,1530718722,0,0),(11582,1530729741,0,0),(11583,1530730351,0,0),(11587,1530729795,0,0),(11593,1530728068,0,0),(11595,1530728128,0,0),(11598,1530728775,0,0),(11604,1530732549,0,0),(11608,1530718795,0,0),(11639,1530886867,0,0),(11640,1530886847,0,0),(11643,1530727153,0,0),(11649,1530718007,0,0),(11650,1530726833,0,0),(11656,1530726612,0,0),(11684,1530729781,0,0),(11699,1530727393,0,0),(11700,1530727140,0,0),(11739,1530727438,0,0),(11742,1530727280,0,0),(11744,1530727312,0,0),(11748,1530886383,0,0),(11916,1530731070,0,0),(11917,1530730991,0,0),(11935,1530714412,0,0),(11941,1530728149,0,0),(11943,1530731429,0,0),(11944,1530730407,0,0),(11945,1530729873,0,0),(11946,1530730435,0,0),(11947,1530730455,0,0),(11948,1530730566,0,0),(11949,1530730503,0,0),(11950,1530730583,0,0),(11951,1530730718,0,0),(11952,1530730696,0,0),(11953,1530730744,0,0),(11954,1530730889,0,0),(11955,1530730833,0,0),(11956,1530730922,0,0),(11957,1530731023,0,0),(11958,1530714448,0,0),(11960,1530714435,0,0),(11962,1530714382,0,0),(11967,1530727774,0,0),(11968,1530727657,0,0),(11982,1530731400,0,0),(12001,1531290829,0,0),(12003,1531291117,0,0),(12004,1531291312,0,0),(12005,1531291192,0,0),(12006,1531291209,0,0),(12009,1531291439,0,0),(12017,1530718783,0,0),(12032,1530717847,0,0),(12033,1530717864,0,0),(12034,1530717824,0,0),(12039,1530713512,0,0),(12040,1530731707,0,0),(12041,1530731499,0,0),(12042,1530713280,0,0),(12043,1530731575,0,0),(12044,1530731476,0,0),(12059,1530717389,0,0),(12061,1530731652,0,0),(12062,1530731691,0,0),(12063,1530727833,0,0),(12071,1530731628,0,0),(12072,1530727747,0,0),(12077,1530732052,0,0),(12078,1530732080,0,0),(12080,1530732100,0,0),(12098,1530731874,0,0),(12369,1523465982,1,0),(12379,1523465939,1,0),(12899,1530718679,0,0),(12900,1530718646,0,0),(12904,1530718692,0,0),(12905,1530733214,0,0),(12907,1530718523,0,0),(12910,1530718382,0,0),(12912,1530718349,0,0),(13250,1530729560,0,0),(13252,1530730800,0,0),(13253,1530728807,0,0),(13254,1530730979,0,0),(13257,1530729901,0,0),(13258,1530728559,0,0),(13262,1530732705,0,0),(13263,1530732780,0,0),(13272,1530723031,0,0),(13276,1530718233,0,0),(13284,1530718509,0,0),(13300,1530718369,0,0),(13302,1530727631,0,0),(13304,1530718435,0,0),(13306,1530717769,0,0),(13307,1530718411,0,0),(13310,1530718469,0,0),(13311,1530718262,0,0),(13313,1530718274,0,0),(13315,1530718322,0,0),(13338,1530886148,0,0),(13339,1530717695,0,0),(13371,1530886208,0,0),(13375,1530737189,0,0),(14488,1530718120,0,0),(14489,1530718176,0,0),(14493,1530718095,0,0),(14494,1530718069,0,0),(14503,1530732423,0,0),(14504,1530732462,0,0),(14505,1530732451,0,0),(14507,1530727933,0,0),(14508,1530731387,0,0),(14513,1530727861,0,0),(14518,1530733304,0,0),(14519,1530733361,0,0),(14521,1530728314,0,0),(14522,1530727217,0,0),(14523,1530729688,0,0),(14524,1530729650,0,0),(14526,1530732118,0,0),(14528,1530727390,0,0),(14529,1530730671,0,0),(14530,1530732006,0,0),(14534,1530731834,0,0),(14536,1530727155,0,0),(14538,1530727241,0,0),(14539,1530727155,0,0),(14540,1530727458,0,0),(14541,1530727458,0,0),(14542,1530727417,0,0),(14545,1530727384,0,0),(14546,1530727257,0,0),(14548,1530727252,0,0),(14549,1530727366,0,0),(14552,1530727093,0,0),(14553,1530727178,0,0),(14554,1530726714,0,0),(14555,1530726750,0,0),(14556,1530726862,0,0),(14557,1530726713,0,0),(14560,1530726726,0,0),(14564,1530726778,0,0),(14565,1530726854,0,0),(14566,1530726851,0,0),(14567,1530726803,0,0),(14568,1530726851,0,0),(14569,1530726853,0,0),(14570,1530726825,0,0),(14573,1530726939,0,0),(14576,1530726938,0,0),(14577,1530727113,0,0),(14578,1530727135,0,0),(14580,1530727132,0,0),(14584,1530727108,0,0),(14586,1530727328,0,0),(14633,1530725486,0,0),(14635,1530726019,0,0),(14637,1530726036,0,0),(14640,1530725509,0,0),(14641,1530725612,0,0),(14642,1530725367,0,0),(14643,1530725581,0,0),(14654,1530886501,0,0),(14658,1530729714,0,0),(14660,1530886535,0,0),(14668,1530731322,0,0),(14683,1530728826,0,0),(14689,1530728096,0,0),(14690,1530729505,0,0),(14691,1530886464,0,0),(14692,1530729591,0,0),(14695,1530728585,0,0),(14696,1530727714,0,0),(14701,1530729521,0,0),(14706,1530728625,0,0),(14710,1530728296,0,0),(14720,1530886351,0,0),(14741,1530732385,0,0),(14746,1530732409,0,0),(14762,1530718708,0,0),(14763,1530718765,0,0),(14764,1530718426,0,0),(14766,1530718629,0,0),(14777,1531290963,0,0),(14778,1531291036,0,0),(15780,1530889771,0,0),(15808,1531417580,0,0),(15819,1531417478,0,0),(15976,1533654848,0,0),(15997,1530896673,0,0),(16011,1530891787,0,0),(16014,1530896658,0,0),(16015,1530896628,0,0),(16066,1530896980,0,0),(16085,1530896720,0,0),(16086,1530896824,0,0),(16087,1530896798,0,0),(16089,1530896918,0,0),(16090,1530896882,0,0),(16091,1530896850,0,0),(16093,1530892064,0,0),(16095,1530896952,0,0),(16102,1531417271,0,0),(16114,1531417373,0,0),(16116,1531417392,0,0),(16121,1531417408,0,0),(16123,1531417365,0,0),(16124,1531417444,0,0),(16125,1531417426,0,0),(16129,1531417516,0,0),(16137,1531417506,0,0),(16139,1531417473,0,0),(16140,1531417318,0,0),(16142,1531417490,0,0),(16143,1531417497,0,0),(16144,1531417290,0,0),(16154,1531417331,0,0),(16306,1530887480,0,0),(16307,1530887875,0,0),(16311,1530887762,0,0),(16331,1530887385,0,0),(16363,1530887904,0,0),(16389,1530887504,0,0),(16391,1530887522,0,0),(16393,1530887461,0,0),(16429,1530887413,0,0),(16458,1533655852,0,0),(16480,1530887562,0,0),(16533,1530887751,0,0),(16540,1530887600,0,0),(16542,1530887679,0,0),(16546,1530887699,0,0),(16548,1530887582,0,0),(16550,1530887723,0,0),(16552,1530887617,0,0),(16555,1530887535,0,0),(16558,1530887438,0,0),(16670,1531419962,0,0),(16691,1530895764,0,0),(16693,1531419597,0,0),(16709,1531420208,0,0),(16710,1531419623,0,0),(16731,1531295922,0,0),(16733,1530894749,0,0),(16734,1533655204,0,0),(16747,1531297550,0,0),(16751,1530894676,0,0),(16754,1530894800,0,0),(16755,1533655185,0,0),(16757,1530888825,0,0),(16758,1530888776,0,0),(16759,1530892890,0,0),(16766,1530888889,0,0),(16775,1530893977,0,0),(16787,1530888871,0,0),(16796,1530895398,0,0),(16802,1530888755,0,0),(16836,1530895721,0,0),(16837,1530888911,0,0),(16838,1533655323,0,0),(16840,1533655293,0,0),(16885,1530894567,0,0),(16889,1533655365,0,0),(16902,1530895701,0,0),(16905,1530895958,0,0),(16906,1533655349,0,0),(16910,1530895807,0,0),(16914,1530895912,0,0),(16921,1533655450,0,0),(16923,1530895871,0,0),(16927,1530895979,0,0),(16928,1530895854,0,0),(16951,1531295559,0,0),(16953,1530888609,0,0),(16955,1531295907,0,0),(16958,1530892547,0,0),(16959,1530892509,0,0),(16960,1530892498,0,0),(16961,1530892782,0,0),(16962,1530894632,0,0),(16963,1530894622,0,0),(16966,1530892554,0,0),(16968,1530892531,0,0),(16970,1530892570,0,0),(16972,1530892470,0,0),(16987,1530894778,0,0),(16993,1530892352,0,0),(16999,1530894449,0,0),(17001,1530894690,0,0),(17002,1530894545,0,0),(17003,1530894520,0,0),(17006,1530894953,0,0),(17014,1530895335,0,0),(17015,1530895238,0,0),(17016,1530895322,0,0),(17017,1530894980,0,0),(17018,1530895265,0,0),(17019,1530895154,0,0),(17020,1530895096,0,0),(17021,1530895162,0,0),(17022,1530895134,0,0),(17023,1530895431,0,0),(17024,1530895381,0,0),(17025,1530895459,0,0),(17026,1530895471,0,0),(17027,1530895291,0,0),(17028,1530895305,0,0),(17029,1530895646,0,0),(17030,1530895657,0,0),(17031,1531419649,0,0),(17032,1533655620,0,0),(17036,1531295879,0,0),(17039,1531295863,0,0),(17042,1531297488,0,0),(17043,1531297510,0,0),(17044,1531419645,0,0),(17046,1531297455,0,0),(17047,1533655631,0,0),(17048,1533655712,0,0),(17049,1533655679,0,0),(17050,1533655568,0,0),(17051,1533655595,0,0),(17052,1533655699,0,0),(17053,1533655534,0,0),(17054,1533655473,0,0),(17055,1533655424,0,0),(17060,1531297382,0,0),(17062,1531295834,0,0),(17063,1531297362,0,0),(17064,1531297605,0,0),(17065,1530888937,0,0),(17097,1531420187,0,0),(17105,1530894342,0,0),(17106,1530894435,0,0),(17111,1533655089,0,0),(17114,1533655078,0,0),(17286,1531420144,0,0),(17287,1531419909,0,0),(17292,1531420162,0,0),(17342,1530893727,0,0),(17345,1530894403,0,0),(17350,1530894381,0,0),(17352,1531297297,0,0),(17353,1530894317,0,0),(17356,1531297323,0,0),(17357,1530893807,0,0),(17358,1530893831,0,0),(17365,1530894471,0,0),(17371,1530889012,0,0),(17377,1530889378,0,0),(17380,1530894074,0,0),(17381,1530892322,0,0),(17382,1530892303,0,0),(17383,1530888973,0,0),(17384,1530894043,0,0),(17385,1530888538,0,0),(17386,1530889454,0,0),(17387,1530892212,0,0),(17549,1530892200,0,0),(17550,1530888381,0,0),(17551,1530889089,0,0),(17556,1530888440,0,0),(17558,1530889352,0,0),(17560,1530888483,0,0),(17561,1530888415,0,0),(17568,1530889430,0,0),(17569,1530892157,0,0),(17570,1530892384,0,0),(17580,1530888711,0,0),(17581,1530892180,0,0),(17582,1530889032,0,0),(17583,1530892336,0,0),(17585,1530888731,0,0),(17586,1530888989,0,0),(17587,1530888515,0,0),(21020,1523465977,1,0),(21022,1523466000,1,0),(21026,1523465954,1,0),(21034,1523465904,1,0),(22473,1523465896,1,0),(23426,1533696196,1,0),(23429,1533695948,1,0),(23432,1533697026,1,0),(23433,1533696021,1,0),(23436,1533695452,1,0),(23437,1533695567,1,0),(23438,1533697174,1,0),(23439,1533697212,1,0),(23440,1533695898,1,0),(26973,1531778292,1,0),(26995,1532039926,1,0),(26996,1532040011,1,0),(26997,1532040045,1,0),(26998,1532040098,1,0),(26999,1532040160,1,0),(27000,1532039833,1,0),(27001,1532039789,1,0),(27002,1532039773,1,0),(27003,1532039943,1,0),(27004,1532039965,1,0),(27006,1532040077,1,0),(27007,1532040057,1,0),(27008,1532040180,1,0),(27009,1532039888,1,0),(27010,1532040199,1,0),(27012,1532039411,1,0),(27014,1532039368,1,0),(27015,1532039350,1,0),(27017,1532039384,1,0),(27019,1532039439,1,0),(27020,1532039491,1,0),(27023,1532039241,1,0),(27024,1532039335,1,0),(27028,1532039503,1,0),(27030,1532039976,1,0),(27036,1532039609,1,0),(27038,1532039263,1,0),(27043,1532039515,1,0),(27044,1532039545,1,0),(27047,1532039318,1,0),(27050,1532039220,1,0),(27051,1532039285,1,0),(27131,1532040532,1,0),(27135,1544174076,1,0),(27136,1532040645,1,0),(27137,1544174088,1,0),(27139,1544173278,1,0),(27140,1531777124,1,0),(27141,1544173345,1,0),(27143,1532040510,1,0),(27150,1532041821,1,0),(27151,1532041870,1,0),(27153,1532040667,1,0),(27154,1532041768,1,0),(27158,1532041984,1,0),(27160,1532041352,1,0),(27162,1532041565,1,0),(27163,1544174172,1,0),(27166,1532038752,1,0),(27168,1532038861,1,0),(27170,1532041889,1,0),(27172,1531777150,1,0),(27177,1531777196,1,0),(27178,1532041953,1,0),(27185,1531776637,1,0),(27186,1531776565,1,0),(27188,1531776612,1,0),(27189,1531777316,1,0),(27190,1532040826,1,0),(27191,1532041598,1,0),(27192,1544172939,1,0),(27193,1544172909,1,0),(27194,1544172876,1,0),(27195,1544172963,1,0),(27196,1544172977,1,0),(27197,1531777022,1,0),(27198,1531777031,1,0),(27199,1531777067,1,0),(27200,1531777093,1,0),(27201,1531777269,1,0),(27202,1531777286,1,0),(27203,1544173524,1,0),(27204,1544173391,1,0),(27205,1544173354,1,0),(27206,1544173440,1,0),(27207,1544173001,1,0),(27208,1544172999,1,0),(27209,1544174195,1,0),(27210,1544174213,1,0),(27214,1532038764,1,0),(27215,1532038723,1,0),(27216,1532038816,1,0),(27217,1532038838,1,0),(27219,1544174131,1,0),(27220,1544174236,1,0),(27221,1544173349,1,0),(27238,1544174379,1,0),(27246,1532041703,1,0),(27248,1532041581,1,0),(27255,1544174152,1,0),(27258,1532041745,1,0),(27259,1532040690,1,0),(27260,1532042053,1,0),(27262,1532041850,1,0),(27266,1532038795,1,0),(27283,1532042013,1,0),(27284,1532042066,1,0),(27285,1532042177,1,0),(27293,1532041801,1,0),(27295,1532042168,1,0),(27299,1544171171,1,0),(27300,1544171285,1,0),(27302,1544171312,1,0),(27304,1544171032,1,0),(27305,1544171063,1,0),(27309,1544170956,1,0),(27311,1544171087,1,0),(27312,1544171138,1,0),(27314,1539534468,1,0),(27315,1539534495,1,0),(27318,1544170911,1,0),(27319,1544170974,1,0),(27326,1539534515,1,0),(27328,1544171241,1,0),(27339,1544171194,1,0),(27344,1544171349,1,0),(27579,1544171399,1,0),(27581,1544171436,1,0),(27582,1544171427,1,0),(27622,1531778381,1,0),(27623,1531778386,1,0),(27629,1531777811,1,0),(27638,1531777758,1,0),(27646,1531777842,1,0),(27647,1531777854,1,0),(27648,1531777797,1,0),(27649,1531778423,1,0),(27650,1531777737,1,0),(27656,1532038522,1,0),(27663,1533825288,1,0),(27665,1533825126,1,0),(27673,1531778337,1,0),(27674,1531778284,1,0),(27675,1531778300,1,0),(27676,1531778394,1,0),(27681,1531778688,1,0),(27682,1531778569,1,0),(27683,1531778613,1,0),(27684,1531778608,1,0),(27685,1531778597,1,0),(27707,1531778337,1,0),(27708,1531778066,1,0),(27709,1531778674,1,0),(27710,1531778237,1,0),(27711,1531778556,1,0),(27712,1531778189,1,0),(27713,1531778226,1,0),(27714,1531778198,1,0),(27715,1531778248,1,0),(27716,1531778528,1,0),(27717,1531778502,1,0),(27718,1531778507,1,0),(27719,1531778541,1,0),(27721,1531778481,1,0),(27722,1531778437,1,0),(27741,1531778312,1,0),(27743,1531778595,1,0),(27937,1531779450,1,0),(28009,1531778802,1,0),(28055,1532039997,1,0),(28061,1532038544,1,0),(28064,1532040369,1,0),(28076,1533825171,1,0),(28077,1533825351,1,0),(28097,1533824955,1,0),(28108,1544170816,1,0),(28112,1532038326,1,0),(28238,1533825001,1,0),(28286,1543653244,1,0),(28291,1543653209,1,0),(28788,1532038648,1,0),(28790,1532038578,1,0),(28835,1531778874,1,0),(28838,1533824908,1,0),(28847,1531779093,1,0),(28895,1544170847,1,0),(28896,1533825158,1,0),(28977,1531776080,1,0),(28990,1531775597,1,0),(28999,1533825201,1,0),(29000,1533825244,1,0),(29005,1532038512,1,0),(29008,1533824978,1,0),(29009,1533825234,1,0),(29044,1544170862,1,0),(29143,1532042145,1,0),(29165,1532038204,1,0),(29197,1539534958,1,0),(30424,1531759633,1,0),(32046,1525288897,0,0),(32439,1529434185,1,0),(32440,1529408672,1,0),(32441,1529408643,1,0),(32442,1529408966,1,0),(32443,1529407971,1,0),(32444,1529408022,1,0),(32445,1529408048,1,0),(32446,1529408778,1,0),(32447,1529408221,1,0),(32448,1529408136,1,0),(32449,1529408358,1,0),(32450,1529408461,1,0),(32452,1529408484,1,0),(32453,1529408450,1,0),(32454,1529408608,1,0),(32455,1529408955,1,0),(32457,1529408707,1,0),(32458,1529408745,1,0),(32459,1529407983,1,0),(32460,1529408250,1,0),(32461,1529408719,1,0),(32462,1529408960,1,0),(32463,1529408328,1,0),(32464,1529408321,1,0),(32465,1529408421,1,0),(32466,1529408522,1,0),(32468,1529408579,1,0),(32469,1529408292,1,0),(32471,1529408397,1,0),(32472,1529408371,1,0),(32475,1529343301,1,0),(32476,1529343420,1,0),(32480,1529407802,1,0),(32481,1529407759,1,0),(32484,1529407413,1,0),(32487,1529407642,1,0),(32488,1529407831,1,0),(32495,1529407324,1,0),(32496,1529407348,1,0),(32501,1529407373,1,0),(32502,1529343260,1,0),(32504,1529407814,1,0),(32505,1529343215,1,0),(32506,1529343451,1,0),(32507,1529407726,1,0),(32509,1529407455,1,0),(32511,1529407695,1,0),(32516,1529407381,1,0),(32517,1529407584,1,0),(32519,1529407525,1,0),(32521,1529407287,1,0),(32522,1529407302,1,0),(32523,1529407490,1,0),(32524,1529343334,1,0),(32527,1529407931,1,0),(32569,1529434955,1,0),(32674,1529441524,1,0),(32744,1529349121,1,0),(32752,1529348985,1,0),(32754,1529747357,1,0),(32755,1529747303,1,0),(32756,1529348691,1,0),(32757,1529747773,1,0),(32783,1529434460,1,0),(32792,1529349253,1,0),(32793,1529349284,1,0),(32794,1529348993,1,0),(32796,1529348747,1,0),(32797,1529747387,1,0),(32798,1529348660,1,0),(32800,1529348721,1,0),(32801,1529349063,1,0),(32802,1529348599,1,0),(32806,1529348547,1,0),(32864,1529341565,1,0),(32869,1529427413,1,0),(32882,1529407798,1,0),(32883,1529341607,1,0),(32885,1529341771,1,0),(32888,1529341921,1,0),(32889,1529341759,1,0),(32890,1529341935,1,0),(32891,1529341853,1,0),(32893,1529341653,1,0),(32894,1529341665,1,0),(32897,1529341638,1,0),(32901,1529341706,1,0),(32902,1529341741,1,0),(32903,1529341803,1,0),(32904,1529342192,1,0),(32907,1529341957,1,0),(32909,1529342009,1,0),(32928,1529402947,1,0),(32932,1529402810,1,0),(32940,1529402876,1,0),(32942,1529402842,1,0),(32947,1529404512,1,0),(32948,1529404543,1,0),(32949,1529403962,1,0),(32956,1529403864,1,0),(32957,1529404032,1,0),(33019,1529404499,1,0),(33033,1529403603,1,0),(33034,1529403621,1,0),(33075,1529403637,1,0),(33081,1529403717,1,0),(33082,1529403733,1,0),(33085,1529404244,1,0),(33086,1529404067,1,0),(33095,1529404487,1,0),(33166,1529337329,1,0),(33167,1529337302,1,0),(33170,1529337469,1,0),(33171,1529337431,1,0),(33172,1529337399,1,0),(33247,1529433825,1,0),(33258,1529433795,1,0),(33260,1529433877,1,0),(33261,1529433915,1,0),(33262,1529434109,1,0),(33263,1529434134,1,0),(33272,1529434190,1,0),(33273,1529434161,1,0),(33277,1529433836,1,0),(33278,1529433864,1,0),(33279,1529434001,1,0),(33280,1529434080,1,0),(33286,1529337269,1,0),(33287,1529337348,1,0),(33290,1529337439,1,0),(33291,1529337339,1,0),(33293,1529337259,1,0),(33326,1529342833,1,0),(33328,1529342862,1,0),(33329,1529342970,1,0),(33334,1529347313,1,0),(33339,1529347375,1,0),(33361,1529434767,1,0),(33365,1529434794,1,0),(33368,1529434815,1,0),(33417,1529347351,1,0),(33419,1529347385,1,0),(33461,1529347488,1,0),(33464,1529347459,1,0),(33466,1529347422,1,0),(33573,1529434897,1,0),(33574,1529434873,1,0),(34280,1529405892,1,0),(34307,1529405030,1,0),(34309,1529434729,1,0),(34316,1529407428,1,0),(34317,1529405596,1,0),(34318,1529405705,1,0),(34330,1529343054,1,0),(34331,1529342796,1,0),(34341,1529342687,1,0),(34342,1529405645,1,0),(34344,1529406674,1,0),(34345,1529405746,1,0),(34350,1529405671,1,0),(34351,1529407605,1,0),(34354,1529405536,1,0),(34360,1529441571,1,0),(34366,1529441634,1,0),(34512,1529405433,1,0),(34540,1529341495,1,0),(34541,1529405351,1,0),(34549,1529405372,1,0),(34552,1529341520,1,0),(34553,1529341445,1,0),(34554,1529341370,1,0),(34557,1529341470,1,0),(34558,1529405326,1,0),(34573,1529405299,1,0),(34580,1529341541,1,0),(34600,1529341286,1,0),(34604,1529405414,1,0),(34814,1529343185,1,0),(34815,1529342743,1,0),(34835,1529343138,1,0),(34837,1529343090,1,0),(34838,1529407935,1,0),(34844,1529343110,1,0),(34859,1529342705,1,0),(34861,1529342766,1,0),(34863,1529407535,1,0),(34872,1529433764,1,0),(34983,1529402526,1,0),(34991,1529747033,1,0),(34992,1529341422,1,0),(34993,1529747061,1,0),(34998,1529433733,1,0),(35042,1529406778,1,0),(35088,1529406807,1,0),(35092,1529406837,1,0),(36839,1529329250,1,0),(36859,1529328307,1,0),(36868,1529329875,1,0),(36879,1529329808,1,0),(36885,1529329840,1,0),(36894,1529329798,1,0),(36895,1529338974,1,0),(36912,1529335090,1,0),(36915,1529335104,1,0),(36930,1529327857,1,0),(36935,1529336056,1,0),(36939,1529335212,1,0),(36954,1529329158,1,0),(36960,1529348061,1,0),(36963,1529336929,1,0),(36988,1529340129,1,0),(36991,1529340119,1,0),(36999,1529340100,1,0),(37000,1529340076,1,0),(37001,1529340070,1,0),(37050,1529339741,1,0),(37051,1529339747,1,0),(37085,1529336793,1,0),(37089,1529346637,1,0),(37090,1529336582,1,0),(37092,1529336751,1,0),(37093,1529336768,1,0),(37094,1529336731,1,0),(37095,1529336563,1,0),(37098,1529336612,1,0),(37099,1529336602,1,0),(37100,1529336744,1,0),(37129,1529335142,1,0),(37131,1529335177,1,0),(37135,1529335122,1,0),(37149,1529335072,1,0),(37159,1529336094,1,0),(37178,1529335229,1,0),(37179,1529335260,1,0),(37180,1529335196,1,0),(37190,1529327822,1,0),(37204,1529329538,1,0),(37212,1529328328,1,0),(37250,1529338938,1,0),(37257,1529339206,1,0),(37258,1529328394,1,0),(37263,1529327952,1,0),(37266,1529328359,1,0),(37280,1529328375,1,0),(37289,1529339242,1,0),(37316,1529329267,1,0),(37325,1529348293,1,0),(37329,1529339011,1,0),(37330,1529339023,1,0),(37339,1529339161,1,0),(37344,1529339118,1,0),(37350,1529339232,1,0),(37354,1529348111,1,0),(37355,1529348094,1,0),(37356,1529348128,1,0),(37361,1529339173,1,0),(37362,1529339141,1,0),(37368,1529348176,1,0),(37371,1529348150,1,0),(37372,1529348215,1,0),(37379,1529348193,1,0),(37380,1529348185,1,0),(37432,1529342159,1,0),(37482,1529339587,1,0),(37486,1529339819,1,0),(37487,1529339662,1,0),(37488,1529339620,1,0),(37489,1529339414,1,0),(37490,1529339500,1,0),(37491,1529339394,1,0),(37492,1529339490,1,0),(37495,1529339447,1,0),(37496,1529339370,1,0),(37498,1529339314,1,0),(37510,1529339741,1,0),(37511,1529339697,1,0),(37512,1529339604,1,0),(37513,1529339810,1,0),(37514,1529339537,1,0),(37515,1529339636,1,0),(37516,1529339878,1,0),(37517,1529339646,1,0),(37518,1529339431,1,0),(37519,1529339469,1,0),(37520,1529339346,1,0),(37524,1529339385,1,0),(37858,1529335897,1,0),(37866,1529335699,1,0),(37867,1529335714,1,0),(37930,1529335600,1,0),(37931,1529335617,1,0),(37932,1529335760,1,0),(37935,1529335975,1,0),(37941,1529329403,1,0),(37942,1529329416,1,0),(37943,1529329462,1,0),(37944,1529329484,1,0),(37945,1529335891,1,0),(37946,1529335934,1,0),(37948,1529335864,1,0),(37949,1529335917,1,0),(37951,1529329660,1,0),(37953,1529335959,1,0),(37955,1529335359,1,0),(37956,1529335396,1,0),(37957,1529335602,1,0),(37958,1529335767,1,0),(37959,1529335625,1,0),(37960,1529335842,1,0),(37963,1529335315,1,0),(37964,1529329432,1,0),(37965,1529329427,1,0),(37966,1529329620,1,0),(37967,1529329694,1,0),(37968,1529329680,1,0),(37972,1529329638,1,0),(37973,1529329635,1,0),(37974,1529329675,1,0),(37981,1529330037,1,0),(37984,1529330063,1,0),(37985,1529330070,1,0),(37986,1529330060,1,0),(37989,1529330045,1,0),(37990,1529329992,1,0),(37993,1529330001,1,0),(37994,1529329984,1,0),(38642,1529336355,1,0),(38646,1529336970,1,0),(38662,1529329791,1,0),(39059,1529489351,1,0),(41792,1523394701,530,0),(42005,1525288775,0,0),(44600,1525288724,0,0),(45170,1525288680,0,0),(45205,1525289276,0,0),(46438,1533718798,1,0),(46913,1533718782,1,0),(46915,1533718743,1,0),(46916,1533718785,1,0),(46920,1533718788,1,0),(46921,1533718769,1,0),(46924,1529231235,1,0),(46925,1529231634,1,0),(46933,1533718723,1,0),(46934,1529230572,1,0),(46935,1529230551,1,0),(46936,1533718711,1,0),(46938,1529231700,1,0),(46940,1529231723,1,0),(46941,1529231681,1,0),(46942,1529231746,1,0),(46947,1529231802,1,0),(47010,1529232487,1,0),(47012,1529232413,1,0),(47037,1529232394,1,0),(47038,1529232317,1,0),(47054,1529232268,1,0),(47055,1529232339,1,0),(47061,1529232552,1,0),(47062,1529232921,1,0),(47208,1529232357,1,0),(47266,1529232435,1,0),(47267,1529232459,1,0),(47281,1533719251,1,0),(47282,1533719230,1,0),(47283,1533719281,1,0),(47284,1533719256,1,0),(47285,1533719251,1,0),(47286,1533719247,1,0),(47287,1533719278,1,0),(47288,1533719275,1,0),(47289,1533719232,1,0),(47290,1533719238,1,0),(47310,1533719242,1,0),(47312,1533718776,1,0),(47334,1533719302,1,0),(47335,1533719293,1,0),(47336,1533719347,1,0),(47338,1533719296,1,0),(47339,1533719296,1,0),(47341,1533719308,1,0),(47342,1533719325,1,0),(47343,1533719329,1,0),(47344,1533719340,1,0),(47345,1533719320,1,0),(47346,1533719317,1,0),(47350,1529233355,1,0),(47923,1529229760,1,0),(47924,1529229765,1,0),(47934,1529229761,1,0),(49612,1529230207,1,0),(49613,1529230525,1,0),(49622,1529230150,1,0),(49626,1529231867,1,0),(49636,1529231849,1,0),(49637,1529231831,1,0),(49640,1529231895,1,0),(49646,1529231878,1,0),(51882,1529352498,1,0),(51883,1529443540,1,0),(51899,1529357401,1,0),(54873,1531476866,530,0),(54875,1531476783,530,0),(54877,1531476716,530,0),(54888,1531476661,530,0),(54889,1523387077,530,0),(54891,1523387033,530,0),(54893,1523386899,530,0),(54897,1531476468,530,0),(54898,1523386932,530,0),(54914,1531499249,530,0),(54915,1531499082,530,0),(54916,1531499122,530,0),(54925,1523387742,530,0),(54926,1523387662,530,0),(54927,1531499169,530,0),(54928,1531499208,530,0),(54929,1523387722,530,0),(54947,1531501210,530,0),(54948,1531473406,530,0),(54951,1531473371,530,0),(54954,1523385043,530,0),(54955,1531473727,530,0),(54956,1531473814,530,0),(54957,1531473984,530,0),(54958,1531473886,530,0),(54959,1523384659,530,0),(54960,1531473664,530,0),(54963,1531473946,530,0),(54964,1531474052,530,0),(54965,1531474109,530,0),(54966,1523385905,530,0),(54968,1523385883,530,0),(54970,1523385382,530,0),(54973,1531500196,530,0),(54977,1531499902,530,0),(55014,1531476757,530,0),(55019,1531476826,530,0),(55038,1523386964,530,0),(55039,1531476637,530,0),(55040,1531476585,530,0),(55041,1523387059,530,0),(55043,1523387047,530,0),(55044,1531476495,530,0),(55045,1523386892,530,0),(55047,1523386863,530,0),(55056,1531499357,530,0),(55057,1531499485,530,0),(55058,1523387683,530,0),(55135,1523386172,530,0),(55136,1523386198,530,0),(55137,1531499634,530,0),(55141,1531474705,530,0),(55143,1531474833,530,0),(55146,1531474739,530,0),(55147,1531474789,530,0),(55152,1531474895,530,0),(55154,1531474643,530,0),(55157,1523385788,530,0),(55161,1523385811,530,0),(55162,1523386275,530,0),(55165,1531499389,530,0),(55178,1523386128,530,0),(55184,1531499652,530,0),(55187,1531474664,530,0),(55366,1523396790,530,0),(55371,1523391798,530,0),(55487,1523398978,530,0),(55511,1523468163,530,0),(55512,1523468154,530,0),(55524,1523397005,530,0),(55525,1523396721,530,0),(55526,1523396752,530,0),(55537,1523396965,530,0),(55541,1523396818,530,0),(55542,1523396900,530,0),(55543,1523396876,530,0),(55544,1523396845,530,0),(55569,1523396694,530,0),(55572,1523390480,530,0),(55576,1523389926,530,0),(55577,1523389770,530,0),(55579,1523389705,530,0),(55580,1523390540,530,0),(55583,1523390505,530,0),(55587,1523390021,530,0),(55588,1523390013,530,0),(55595,1523398772,530,0),(55598,1523398692,530,0),(55599,1523398503,530,0),(55602,1523398420,530,0),(55603,1523398445,530,0),(55617,1523398664,530,0),(55618,1523398520,530,0),(55619,1523398538,530,0),(55621,1523398397,530,0),(55623,1523399075,530,0),(55634,1523398737,530,0),(55635,1523398628,530,0),(55636,1523398554,530,0),(55637,1523398481,530,0),(55638,1523398467,530,0),(55641,1523390395,530,0),(55642,1523390444,530,0),(55644,1523390443,530,0),(55645,1523390455,530,0),(55646,1523390450,530,0),(55653,1523390315,530,0),(55654,1523390295,530,0),(55656,1523390342,530,0),(55657,1523390003,530,0),(55658,1523390251,530,0),(55662,1523389943,530,0),(55663,1523389894,530,0),(55669,1523390269,530,0),(55671,1523389866,530,0),(55677,1523389834,530,0),(55678,1523389806,530,0),(55679,1523389755,530,0),(55681,1523389731,530,0),(55682,1523389678,530,0),(55686,1523390431,530,0),(55706,1523390004,530,0),(55708,1523393234,530,0),(55709,1523395117,530,0),(55710,1523393368,530,0),(55711,1523395085,530,0),(55712,1523395240,530,0),(55713,1523392957,530,0),(55714,1523395178,530,0),(55716,1523393014,530,0),(55717,1523393448,530,0),(55718,1523393645,530,0),(55720,1523395325,530,0),(55721,1523391473,530,0),(55722,1523391500,530,0),(55725,1523391362,530,0),(55732,1523391208,530,0),(55733,1523391191,530,0),(55736,1523391442,530,0),(55740,1523391264,530,0),(55742,1523391288,530,0),(55743,1523391337,530,0),(55744,1523391312,530,0),(55806,1523465658,530,0),(55807,1523468437,530,0),(55961,1523392543,530,0),(55968,1523392631,530,0),(55970,1523393188,530,0),(55971,1523393874,530,0),(55972,1523394938,530,0),(55973,1523394913,530,0),(55976,1523393378,530,0),(55981,1523392573,530,0),(55999,1523399032,530,0),(56031,1531498650,530,0),(56083,1523395959,530,0),(56104,1523395915,530,0),(56105,1523395859,530,0),(56115,1523398147,530,0),(56118,1523398009,530,0),(56119,1523398043,530,0),(56121,1523398057,530,0),(56123,1523395818,530,0),(56124,1523396053,530,0),(56125,1523396112,530,0),(56148,1523397989,530,0),(56149,1523398026,530,0),(56151,1523398167,530,0),(56160,1523395894,530,0),(56162,1523396004,530,0),(56165,1523397966,530,0),(56172,1523394592,530,0),(56173,1523394605,530,0),(56181,1523394845,530,0),(56196,1523394601,530,0),(56197,1523394596,530,0),(56201,1523394656,530,0),(56202,1523394694,530,0),(56203,1523394032,530,0),(56205,1523394464,530,0),(56206,1523394862,530,0),(56207,1523394724,530,0),(56220,1523394631,530,0),(56221,1523394075,530,0),(56227,1523394678,530,0),(56229,1523394154,530,0),(56232,1523394669,530,0),(56234,1523394674,530,0),(56373,1523390359,530,0),(56460,1523391243,530,0),(56755,1523393115,530,0),(56756,1523393153,530,0),(56757,1523393079,530,0),(56758,1523392910,530,0),(56759,1523393215,530,0),(56760,1523395151,530,0),(56761,1523395050,530,0),(56762,1523395031,530,0),(56763,1523395319,530,0),(56764,1523392986,530,0),(56765,1523395136,530,0),(56766,1523395212,530,0),(56767,1523395273,530,0),(56768,1523393488,530,0),(56769,1523393420,530,0),(56771,1523393619,530,0),(56772,1523393575,530,0),(56773,1523393677,530,0),(56774,1523395293,530,0),(56994,1523395543,530,0),(57198,1529245055,530,0),(57242,1529243975,530,0),(57243,1529243847,530,0),(57244,1529243868,530,0),(57269,1529243917,530,0),(57270,1529243945,530,0),(57273,1529243957,530,0),(57274,1529243998,530,0),(57275,1529243820,530,0),(57290,1529244303,530,0),(57294,1529244962,530,0),(57295,1529244938,530,0),(57296,1529244925,530,0),(57297,1529244369,530,0),(57306,1529244346,530,0),(57307,1529244332,530,0),(57310,1529245368,530,0),(57313,1529245351,530,0),(57316,1529245451,530,0),(57317,1529245424,530,0),(57318,1529245516,530,0),(57340,1529245913,530,0),(57360,1529243688,530,0),(57361,1529243668,530,0),(57362,1529243649,530,0),(57363,1529243726,530,0),(57364,1529243757,530,0),(57368,1529243702,530,0),(57393,1529243928,530,0),(57395,1529243878,530,0),(57396,1529243890,530,0),(57398,1529243903,530,0),(57399,1529243776,530,0),(57400,1529243793,530,0),(57405,1529243743,530,0),(57422,1529245926,530,0),(57423,1529245899,530,0),(57425,1529246066,530,0),(57426,1529246086,530,0),(57427,1529245947,530,0),(57428,1529245991,530,0),(57431,1529246012,530,0),(57432,1529246045,530,0),(57433,1529245972,530,0),(57434,1529246030,530,0),(57439,1529246166,530,0),(60681,1529254356,530,0),(60682,1529254193,530,0),(60683,1529254178,530,0),(60691,1529254416,530,0),(60692,1529254299,530,0),(60696,1529254326,530,0),(60698,1529254553,530,0),(60705,1529254577,530,0),(60710,1529254377,530,0),(60711,1529254510,530,0),(60712,1529254437,530,0),(60713,1529254232,530,0),(60714,1529254143,530,0),(60715,1529254157,530,0),(60716,1529254213,530,0),(60816,1529255938,530,0),(60817,1529255951,530,0),(60831,1529255871,530,0),(60834,1529255829,530,0),(60860,1529255892,530,0),(60870,1529255909,530,0),(60902,1529255858,530,0),(60906,1529255923,530,0),(60931,1530731011,530,0),(60938,1529252089,530,0),(60942,1529251881,530,0),(60943,1529251832,530,0),(60950,1530731009,530,0),(60953,1529252076,530,0),(60958,1529251999,530,0),(60959,1529251850,530,0),(60961,1529251805,530,0),(60983,1529251916,530,0),(60985,1529251955,530,0),(60986,1529251754,530,0),(60991,1529252057,530,0),(60994,1529251976,530,0),(60995,1529251774,530,0),(61014,1529252113,530,0),(61017,1529251938,530,0),(61018,1529251787,530,0),(61029,1529252015,530,0),(61030,1529251899,530,0),(61069,1529248469,530,0),(61075,1529248546,530,0),(61077,1529248980,530,0),(61078,1529249020,530,0),(61108,1529249066,530,0),(61110,1529249163,530,0),(61112,1529249144,530,0),(61113,1529249089,530,0),(61118,1529249116,530,0),(61122,1529248405,530,0),(61158,1529255145,530,0),(61178,1529255768,530,0),(61179,1529255736,530,0),(61203,1529255158,530,0),(61240,1529256035,530,0),(61241,1529256274,530,0),(61244,1529256145,530,0),(61245,1529256079,530,0),(61247,1529256215,530,0),(61272,1529256190,530,0),(61273,1529256319,530,0),(61276,1529256246,530,0),(61278,1529256052,530,0),(61308,1529256168,530,0),(61313,1529256112,530,0),(61356,1529248846,530,0),(61359,1529248385,530,0),(61363,1529250543,530,0),(61371,1529248531,530,0),(61372,1529248501,530,0),(61373,1529248567,530,0),(61374,1529248449,530,0),(61375,1529248358,530,0),(61474,1529250487,530,0),(61475,1529250522,530,0),(61477,1529250604,530,0),(61482,1529250689,530,0),(61495,1529250455,530,0),(61496,1529250636,530,0),(61505,1529250574,530,0),(61510,1529248904,530,0),(61558,1529254110,530,0),(61564,1529308232,530,0),(61567,1529255343,530,0),(61568,1529255309,530,0),(61592,1529255203,530,0),(61594,1529255238,530,0),(61595,1529255283,530,0),(61596,1529250712,530,0),(61611,1529250718,530,0),(61613,1529255271,530,0),(61614,1529255222,530,0),(61616,1529253652,530,0),(61632,1529255327,530,0),(61646,1529255753,530,0),(61669,1529255651,530,0),(61685,1529255712,530,0),(61686,1529255633,530,0),(61760,1529249548,530,0),(61763,1529249628,530,0),(61764,1529249593,530,0),(61765,1529249678,530,0),(61766,1529249656,530,0),(61774,1529249706,530,0),(61775,1529249732,530,0),(61776,1529249755,530,0),(61966,1529253446,530,0),(62055,1529252373,530,0),(62056,1529252345,530,0),(62057,1529252427,530,0),(62059,1529252405,530,0),(62060,1529252359,530,0),(62061,1529252436,530,0),(62062,1529252395,530,0),(62063,1529252381,530,0),(62103,1529276625,530,0),(62126,1529332252,530,0),(62127,1529332518,530,0),(62128,1529332528,530,0),(62129,1529332865,530,0),(62130,1529332844,530,0),(62134,1529332673,530,0),(62135,1529332609,530,0),(62136,1529332309,530,0),(62137,1529332722,530,0),(62139,1529332443,530,0),(62145,1529332318,530,0),(62146,1529332879,530,0),(62148,1529332652,530,0),(62149,1529332589,530,0),(62150,1529332732,530,0),(62151,1529332749,530,0),(62153,1529332405,530,0),(62155,1529332242,530,0),(62156,1529332268,530,0),(62158,1529332466,530,0),(62159,1529332894,530,0),(62160,1529332550,530,0),(62165,1529332624,530,0),(62166,1529332635,530,0),(62167,1529332573,530,0),(62168,1529332780,530,0),(62169,1529332706,530,0),(62170,1529332382,530,0),(62172,1529332419,530,0),(62174,1529305121,530,0),(62192,1529305177,530,0),(62204,1529305059,530,0),(62221,1529314892,530,0),(62222,1529315068,530,0),(62224,1529315260,530,0),(62232,1529315071,530,0),(62233,1529315356,530,0),(62234,1529315089,530,0),(62235,1529315153,530,0),(62236,1529315189,530,0),(62238,1529315224,530,0),(62239,1529315298,530,0),(62255,1529314879,530,0),(62256,1529315343,530,0),(62258,1529315328,530,0),(62260,1529315049,530,0),(62261,1529315123,530,0),(62264,1529315174,530,0),(62266,1529315242,530,0),(62267,1529315272,530,0),(62284,1529276976,530,0),(62285,1529276935,530,0),(62286,1529276999,530,0),(62297,1529277027,530,0),(62302,1529276894,530,0),(62305,1529276865,530,0),(62321,1529305794,530,0),(62322,1529305486,530,0),(62328,1529305716,530,0),(62332,1529330459,530,0),(62336,1529278563,530,0),(62341,1529305557,530,0),(62348,1529330419,530,0),(62349,1529330434,530,0),(62351,1529278585,530,0),(62362,1529313036,530,0),(62388,1529313173,530,0),(62406,1529309902,530,0),(62407,1529309920,530,0),(62416,1529309011,530,0),(62418,1529309963,530,0),(62419,1529309996,530,0),(62430,1529308710,530,0),(62431,1529309942,530,0),(62432,1529310035,530,0),(62534,1529308856,530,0),(62536,1529309127,530,0),(62537,1529308893,530,0),(62539,1529308686,530,0),(62541,1529310531,530,0),(62546,1529317861,530,0),(62547,1529314188,530,0),(62550,1529310661,530,0),(62552,1529313909,530,0),(62553,1529317620,530,0),(62554,1529317575,530,0),(62558,1529257681,530,0),(62559,1529257727,530,0),(62560,1529257664,530,0),(62561,1529257635,530,0),(62577,1529277892,530,0),(62591,1529278112,530,0),(62609,1529304771,530,0),(62610,1529304820,530,0),(62613,1529313000,530,0),(62614,1529312967,530,0),(62615,1529312920,530,0),(62616,1529313128,530,0),(62617,1529313526,530,0),(62619,1529316320,530,0),(62620,1529313561,530,0),(62621,1529278175,530,0),(62631,1529310370,530,0),(62635,1529310386,530,0),(62640,1529314473,530,0),(62642,1529314435,530,0),(62643,1529314445,530,0),(62645,1529314392,530,0),(62651,1529317854,530,0),(62653,1529310630,530,0),(62654,1529310592,530,0),(62655,1529314031,530,0),(62656,1529317740,530,0),(62657,1529316354,530,0),(62658,1529313989,530,0),(62670,1529317820,530,0),(62671,1529317794,530,0),(62675,1529317610,530,0),(62676,1529317546,530,0),(62677,1529317758,530,0),(62678,1529316378,530,0),(62679,1529309701,530,0),(62680,1529309691,530,0),(62681,1529309738,530,0),(62682,1529309722,530,0),(62683,1529309673,530,0),(62684,1529309623,530,0),(62685,1529309640,530,0),(62688,1529304895,530,0),(62694,1529312929,530,0),(62695,1529312891,530,0),(62696,1529309657,530,0),(62697,1529278150,530,0),(62699,1529306090,530,0),(62749,1529252715,530,0),(62750,1529308053,530,0),(62753,1529253772,530,0),(62768,1529252228,530,0),(62787,1529255252,530,0),(62789,1529255385,530,0),(62799,1529253675,530,0),(62810,1529255692,530,0),(62833,1529306938,530,0),(62989,1529255806,530,0),(63004,1529304983,530,0),(63063,1529257536,530,0),(63095,1529257777,530,0),(63096,1529257753,530,0),(63097,1529257304,530,0),(63098,1529257595,530,0),(63099,1529257575,530,0),(63100,1529257488,530,0),(63101,1529257323,530,0),(63102,1529257350,530,0),(63105,1529257831,530,0),(63110,1529278037,530,0),(63111,1529278003,530,0),(63114,1529277940,530,0),(63115,1529257452,530,0),(63118,1529257391,530,0),(63120,1529257421,530,0),(63172,1529330611,530,0),(63173,1529334741,530,0),(63174,1529330670,530,0),(63175,1529334764,530,0),(63176,1529334588,530,0),(63177,1529334775,530,0),(63179,1529330746,530,0),(63180,1529330771,530,0),(63183,1529330793,530,0),(63204,1529330642,530,0),(63206,1529330582,530,0),(63207,1529333019,530,0),(63209,1529334810,530,0),(63212,1529334830,530,0),(63213,1529334852,530,0),(63220,1529330863,530,0),(63234,1529332998,530,0),(63235,1529333037,530,0),(63238,1529309484,530,0),(63239,1529309413,530,0),(63241,1529278477,530,0),(63244,1529278411,530,0),(63245,1529278297,530,0),(63247,1529310453,530,0),(63249,1529278390,530,0),(63250,1529278454,530,0),(63251,1529309444,530,0),(63252,1529278433,530,0),(63254,1529310465,530,0),(63257,1529308465,530,0),(63259,1529310432,530,0),(63260,1529317024,530,0),(63262,1529316952,530,0),(63263,1529316983,530,0),(63264,1529316932,530,0),(63265,1529316654,530,0),(63266,1529317508,530,0),(63267,1529317400,530,0),(63268,1529317270,530,0),(63269,1529317300,530,0),(63270,1529317503,530,0),(63271,1529317355,530,0),(63272,1529317380,530,0),(63273,1529317393,530,0),(63274,1529317343,530,0),(63275,1529317440,530,0),(63276,1529317282,530,0),(63277,1529316814,530,0),(63278,1529317063,530,0),(63279,1529317237,530,0),(63280,1529317229,530,0),(63281,1529317215,530,0),(63282,1529316871,530,0),(63283,1529317113,530,0),(63284,1529317131,530,0),(63285,1529316884,530,0),(63385,1529309160,530,0),(63394,1529277854,530,0),(63448,1529277068,530,0),(63457,1529331252,530,0),(63458,1529331218,530,0),(63459,1529331240,530,0),(63463,1529331108,530,0),(63464,1529331075,530,0),(63465,1529331091,530,0),(63466,1529330963,530,0),(63468,1529331015,530,0),(63469,1529330977,530,0),(63470,1529330997,530,0),(63479,1529331598,530,0),(63481,1529331614,530,0),(63483,1529331644,530,0),(63485,1529331742,530,0),(63486,1529331631,530,0),(63487,1529331694,530,0),(63490,1529331674,530,0),(63491,1529331714,530,0),(63492,1529331841,530,0),(63493,1529331754,530,0),(63494,1529331893,530,0),(63495,1529331806,530,0),(63496,1529331876,530,0),(63497,1529331859,530,0),(63498,1529331826,530,0),(63499,1529331372,530,0),(63500,1529331326,530,0),(63501,1529331279,530,0),(63502,1529331310,530,0),(75081,1529331280,530,0),(75963,1529245475,530,0),(76002,1544173336,1,0),(76004,1544172856,1,0),(76005,1544173276,1,0),(76006,1544173314,1,0),(76007,1544173385,1,0),(76010,1544173362,1,0),(76012,1544172860,1,0),(76015,1544173296,1,0),(76016,1544173148,1,0),(76017,1544172851,1,0),(77281,1529320398,530,0),(79944,1533828274,0,0),(79954,1524668251,0,0),(79959,1524668258,0,0),(79972,1533828302,0,0),(79991,1533828211,0,0),(80126,1524933023,0,0),(80128,1525002982,0,0),(80166,1533828315,0,0),(80297,1531498510,0,0),(80472,1529732662,0,0),(80761,1529823699,0,0),(80878,1529823886,0,0),(81032,1529823703,0,0),(81080,1529823693,0,0),(81116,1523403263,571,0),(81117,1523403270,571,0),(81118,1523403265,571,0),(81119,1523399590,571,0),(81120,1523399590,571,0),(81121,1523399591,571,0),(81148,1530712914,0,0),(81149,1530712928,0,0),(81370,1529823839,0,0),(81374,1529823843,0,0),(81746,1523464288,530,0),(81750,1523464318,530,0),(81752,1523399524,530,0),(81754,1523464351,530,0),(81758,1523464378,530,0),(81759,1523464431,530,0),(81760,1523464468,530,0),(81762,1523464486,530,0),(81765,1523470412,530,0),(81768,1523464521,530,0),(81769,1523464553,530,0),(81775,1523464872,530,0),(81776,1523464895,530,0),(81778,1523464837,530,0),(81781,1523464858,530,0),(81785,1523464811,530,0),(81788,1523464752,530,0),(81789,1523464775,530,0),(81790,1523464586,530,0),(81791,1523464566,530,0),(81834,1523465321,530,0),(81835,1523465286,530,0),(81836,1523465306,530,0),(81837,1523465345,530,0),(81838,1523465332,530,0),(81845,1523465228,530,0),(81848,1523465197,530,0),(81849,1523465208,530,0),(81850,1523465216,530,0),(81851,1523465156,530,0),(81852,1523465243,530,0),(81854,1523465254,530,0),(81855,1523465265,530,0),(81856,1523465288,530,0),(81893,1523464986,530,0),(81896,1523465172,530,0),(81918,1523471270,530,0),(81922,1523471220,530,0),(81924,1523465100,530,0),(81925,1523465076,530,0),(81936,1523465120,530,0),(82004,1523465042,530,0),(82011,1523471275,530,0),(82015,1523471226,530,0),(82019,1523464976,530,0),(82041,1523465150,530,0),(82046,1523471207,530,0),(82047,1523471192,530,0),(82048,1523471175,530,0),(82050,1523471162,530,0),(82052,1523470969,530,0),(82053,1523471088,530,0),(82054,1523471097,530,0),(82055,1523470879,530,0),(82056,1523471082,530,0),(82058,1523471007,530,0),(82059,1523470866,530,0),(82062,1523471121,530,0),(82063,1523470862,530,0),(82064,1523470848,530,0),(82065,1523470844,530,0),(82066,1523470872,530,0),(82067,1523471108,530,0),(82068,1523471114,530,0),(82069,1523471018,530,0),(82071,1523471368,530,0),(82072,1523471041,530,0),(82073,1523470740,530,0),(82074,1523470713,530,0),(82075,1523470727,530,0),(82078,1523470684,530,0),(82080,1523470614,530,0),(82082,1523470646,530,0),(82084,1523470610,530,0),(82088,1523470485,530,0),(82089,1523470468,530,0),(82090,1523470445,530,0),(82091,1523470418,530,0),(82093,1523464453,530,0),(82095,1523464493,530,0),(82096,1523464423,530,0),(82098,1523464403,530,0),(82101,1523464365,530,0),(82102,1523464333,530,0),(82106,1523399288,530,0),(82107,1523399496,530,0),(82108,1523399472,530,0),(82110,1523464888,530,0),(82114,1523399448,530,0),(82116,1523399398,530,0),(82117,1523399309,530,0),(82122,1529052384,530,0),(82123,1529052377,530,0),(82124,1529052259,530,0),(82125,1529052291,530,0),(82126,1529052272,530,0),(82127,1529052405,530,0),(82129,1529052248,530,0),(82130,1529052232,530,0),(82131,1529052239,530,0),(82132,1529052210,530,0),(82133,1529052192,530,0),(82134,1529052199,530,0),(82137,1523463863,530,0),(82138,1523463838,530,0),(82142,1523463853,530,0),(82144,1523463877,530,0),(82146,1523463925,530,0),(82147,1523463895,530,0),(82148,1523463935,530,0),(82150,1523463820,530,0),(82151,1523463905,530,0),(82152,1523463946,530,0),(82169,1523463733,530,0),(82193,1523469232,530,0),(82194,1523469203,530,0),(82200,1523469188,530,0),(82203,1523469196,530,0),(82204,1523469160,530,0),(82207,1523469170,530,0),(82208,1523469145,530,0),(82241,1523469124,530,0),(82242,1523469130,530,0),(82251,1523469064,530,0),(82253,1523469096,530,0),(82254,1523469106,530,0),(82270,1523468725,530,0),(82271,1523468716,530,0),(82275,1523468711,530,0),(82277,1523468778,530,0),(82285,1523468773,530,0),(82286,1523468873,530,0),(82287,1523468831,530,0),(82288,1523468878,530,0),(82289,1523468802,530,0),(82291,1523468896,530,0),(82292,1523468799,530,0),(82293,1523468841,530,0),(82338,1523469903,530,0),(82340,1523469968,530,0),(82344,1523469948,530,0),(82345,1523469937,530,0),(82346,1523469918,530,0),(82348,1523469888,530,0),(82352,1523469857,530,0),(82373,1523470145,530,0),(82389,1523469489,530,0),(82393,1523469503,530,0),(82414,1523463555,530,0),(82415,1523463568,530,0),(82422,1523463468,530,0),(82427,1523463307,530,0),(82428,1523463581,530,0),(82429,1523463454,530,0),(82431,1529052705,530,0),(82432,1523463441,530,0),(82433,1523463611,530,0),(82434,1523463639,530,0),(82435,1529052795,530,0),(82436,1529052671,530,0),(82437,1529052691,530,0),(82438,1529052774,530,0),(82439,1529052537,530,0),(82440,1531498299,530,0),(82441,1529052745,530,0),(82442,1529052683,530,0),(82443,1529052579,530,0),(82444,1523463427,530,0),(82446,1529052597,530,0),(82447,1529052558,530,0),(82448,1529052547,530,0),(82450,1529052492,530,0),(82451,1523463658,530,0),(82452,1523463682,530,0),(82453,1523463705,530,0),(82454,1523463713,530,0),(82455,1523463665,530,0),(82458,1523463779,530,0),(82484,1523470129,530,0),(82485,1523470102,530,0),(82486,1523470115,530,0),(82487,1523469804,530,0),(82489,1523470087,530,0),(82490,1523470069,530,0),(82491,1523469873,530,0),(82492,1523470034,530,0),(82495,1523470052,530,0),(82499,1523470014,530,0),(82500,1523469997,530,0),(82501,1523469987,530,0),(82508,1523471607,530,0),(82509,1523471625,530,0),(82511,1523471578,530,0),(82514,1523471660,530,0),(82523,1523471643,530,0),(82525,1523471680,530,0),(82526,1523471671,530,0),(82528,1523471916,530,0),(82529,1523471703,530,0),(82530,1523471708,530,0),(82531,1523471831,530,0),(82532,1523471836,530,0),(82534,1523471734,530,0),(82537,1523471743,530,0),(82540,1523471861,530,0),(82541,1523471755,530,0),(82542,1523471775,530,0),(82543,1523471802,530,0),(82545,1523471855,530,0),(82547,1523471856,530,0),(82607,1523469643,530,0),(82608,1523469629,530,0),(82614,1523469621,530,0),(82618,1523469660,530,0),(82622,1523469596,530,0),(82623,1523469667,530,0),(82624,1523469576,530,0),(82625,1523469694,530,0),(82626,1523469681,530,0),(82627,1523469590,530,0),(82628,1523469689,530,0),(82637,1523469558,530,0),(82638,1523469723,530,0),(82639,1523469718,530,0),(82649,1523469534,530,0),(82653,1523469453,530,0),(82661,1523469368,530,0),(82662,1523469463,530,0),(82663,1523469518,530,0),(82672,1529054184,530,0),(82674,1529054204,530,0),(82676,1529054169,530,0),(82677,1529054155,530,0),(82678,1529054226,530,0),(82679,1531498302,530,0),(82680,1529052955,530,0),(82681,1529052979,530,0),(82682,1529052948,530,0),(82683,1531498302,530,0),(82684,1529052922,530,0),(82685,1531498304,530,0),(82686,1529052966,530,0),(82687,1529053228,530,0),(82688,1529052909,530,0),(82689,1529052934,530,0),(82690,1529052859,530,0),(82692,1529052698,530,0),(82693,1529052808,530,0),(82694,1529052813,530,0),(82695,1523463412,530,0),(82696,1531498300,530,0),(82697,1531498373,530,0),(82698,1531498300,530,0),(82699,1529052752,530,0),(82700,1529052830,530,0),(82701,1529052759,530,0),(82702,1529052660,530,0),(82703,1529052720,530,0),(82704,1529052611,530,0),(82705,1531498298,530,0),(82706,1529052622,530,0),(82707,1529052480,530,0),(82708,1529052640,530,0),(82709,1529052449,530,0),(82710,1529052454,530,0),(82711,1529052500,530,0),(82712,1529052438,530,0),(82713,1529052507,530,0),(82714,1529052140,530,0),(82715,1529052147,530,0),(82716,1529052161,530,0),(82717,1529052176,530,0),(82718,1529052479,530,0),(82720,1523463690,530,0),(82721,1523463831,530,0),(82722,1523463814,530,0),(82724,1529052556,530,0),(82725,1529052592,530,0),(82726,1523461630,530,0),(82727,1529052731,530,0),(82728,1529052787,530,0),(82729,1529052886,530,0),(82730,1529052654,530,0),(82731,1523461604,530,0),(82732,1531498302,530,0),(82733,1529052842,530,0),(82734,1529052872,530,0),(82735,1531498300,530,0),(82736,1529052854,530,0),(82738,1529052897,530,0),(82739,1529052994,530,0),(82740,1529053956,530,0),(82744,1529054219,530,0),(82745,1529054256,530,0),(82746,1529054247,530,0),(82747,1529054304,530,0),(82748,1529054366,530,0),(82749,1529054284,530,0),(82750,1529054386,530,0),(82776,1529054415,530,0),(82778,1531498327,530,0),(82779,1529054523,530,0),(82780,1531498319,530,0),(82781,1529054334,530,0),(82782,1529054323,530,0),(82784,1529054455,530,0),(82785,1529054486,530,0),(82786,1531498337,530,0),(82788,1529054556,530,0),(82790,1529054570,530,0),(82791,1529054760,530,0),(82792,1529054585,530,0),(82796,1529054600,530,0),(82798,1529054638,530,0),(82799,1529054623,530,0),(82805,1529054672,530,0),(82806,1529054646,530,0),(82808,1529054689,530,0),(82809,1529054724,530,0),(82812,1529054752,530,0),(82816,1529054711,530,0),(82817,1531498402,530,0),(82899,1529463611,609,0),(82915,1529463606,609,0),(83999,1532865719,530,0),(84002,1532866522,530,0),(84003,1532866600,530,0),(84004,1532866590,530,0),(84005,1532866577,530,0),(84104,1529308093,530,0),(84105,1529249205,530,0),(84106,1529308100,530,0),(84109,1529308202,530,0),(84128,1529256286,530,0),(84260,1530783809,0,0),(84418,1529463593,609,0),(84423,1529463578,609,0),(84432,1529463547,609,0),(84436,1529463561,609,0),(84437,1529463584,609,0),(84439,1529463561,609,0),(84989,1529245564,530,0),(85651,1531498663,530,0),(85810,1524947043,530,0),(85815,1524947014,530,0),(85816,1524947006,530,0),(85817,1524946902,530,0),(85876,1524947052,530,0),(85934,1524947037,530,0),(85935,1524946842,530,0),(85937,1524946925,530,0),(85939,1524946990,530,0),(85941,1524946967,530,0),(85942,1524946865,530,0),(86385,1529732818,0,0),(86514,1529317329,530,0),(86541,1529313330,530,0),(86542,1529313252,530,0),(86548,1529313398,530,0),(86756,1530966549,0,0),(87945,1529747626,1,0),(87946,1529747650,1,0),(87947,1529747650,1,0),(87950,1529747398,1,0),(87954,1529747630,1,0),(87956,1529747394,1,0),(87958,1529747646,1,0),(90403,1529732837,0,0),(90935,1532866633,530,0),(90994,1529254597,530,0),(90995,1529254465,530,0),(90996,1529254488,530,0),(90997,1529254350,530,0),(90998,1529254253,530,0),(90999,1529254278,530,0),(91000,1529254268,530,0),(91002,1529254477,530,0),(91114,1530591027,0,0),(93970,1532865450,530,0),(93971,1532865468,530,0),(93982,1532865173,530,0),(94380,1532867054,530,0),(94384,1532866228,530,0),(95000,1529314214,530,0),(97122,1523399907,571,0),(97125,1523396268,571,0),(128496,1529438291,609,0),(128497,1529438187,609,0),(128910,1529447459,609,0),(128919,1529463575,609,0),(128923,1529463557,609,0),(128924,1529463598,609,0),(128925,1529463573,609,0),(128927,1529463575,609,0),(128934,1529463564,609,0),(128935,1529463545,609,0),(128939,1529463599,609,0),(128946,1529463540,609,0),(128948,1529463580,609,0),(128949,1529463595,609,0),(128957,1529463545,609,0),(128974,1529463575,609,0),(128985,1529463523,609,0),(128986,1529463575,609,0),(128988,1529437750,609,0),(128990,1529463575,609,0),(128991,1529463573,609,0),(128997,1529463563,609,0),(128998,1529463603,609,0),(128999,1529463601,609,0),(129216,1529463589,609,0),(129217,1529463591,609,0),(129237,1529463589,609,0),(129252,1529463589,609,0),(129278,1529438272,609,0),(129517,1529437926,609,0),(129518,1529437950,609,0),(129529,1529437969,609,0),(129530,1529437857,609,0),(129531,1529462194,609,0),(129544,1529437940,609,0),(129546,1529437929,609,0),(129547,1529438047,609,0),(129654,1529438038,609,0),(129657,1529437859,609,0),(129673,1529437789,609,0),(129676,1529437455,609,0),(129678,1529437581,609,0),(129689,1529437575,609,0),(129697,1529437609,609,0),(129698,1529437639,609,0),(129699,1529437607,609,0),(129700,1529437578,609,0),(129701,1529437583,609,0),(129711,1529437580,609,0),(129716,1529437708,609,0),(129718,1529437586,609,0),(129720,1529437593,609,0),(129721,1529437599,609,0),(129726,1529437856,609,0),(129752,1529437818,609,0),(129758,1529437794,609,0),(129759,1529437790,609,0),(129789,1529437831,609,0),(129793,1529437816,609,0),(129796,1529437792,609,0),(129797,1529437834,609,0),(129799,1529437804,609,0),(129850,1529437642,609,0),(130035,1529456726,609,0),(130219,1529463465,609,0),(130221,1529463602,609,0),(130240,1529463509,609,0),(130259,1529463548,609,0),(130312,1529463543,609,0),(130354,1529437742,609,0),(130362,1529438071,609,0),(130559,1529463497,609,0),(130615,1529462924,609,0),(130616,1529463836,609,0),(130617,1529463414,609,0),(130618,1529463040,609,0),(130619,1529463923,609,0),(130653,1529463202,609,0),(130654,1529463784,609,0),(130655,1529463672,609,0),(130656,1529463663,609,0),(130659,1529463596,609,0),(130661,1529463460,609,0),(130663,1529461608,609,0),(130665,1529463493,609,0),(130669,1529462499,609,0),(130671,1529463339,609,0),(130675,1529436752,609,0),(130676,1529463537,609,0),(130677,1529435957,609,0),(130679,1529436693,609,0),(130682,1529463848,609,0),(130709,1529461988,609,0),(130716,1529463806,609,0),(130718,1529463621,609,0),(130720,1529463700,609,0),(130734,1529463877,609,0),(130749,1529463709,609,0),(130752,1529463908,609,0),(130753,1529463843,609,0),(130754,1529436284,609,0),(130755,1529463877,609,0),(130782,1529463586,609,0),(130788,1529463563,609,0),(130790,1529463652,609,0),(130791,1529463175,609,0),(130794,1529463257,609,0),(130796,1529451162,609,0),(130798,1529461856,609,0),(130801,1529436189,609,0),(130802,1529436693,609,0),(130803,1529463339,609,0),(130804,1529438446,609,0),(130805,1529437081,609,0),(130806,1529462814,609,0),(130809,1529439363,609,0),(130810,1529436802,609,0),(130811,1529438648,609,0),(130812,1529462814,609,0),(130813,1529443156,609,0),(130819,1529462726,609,0),(130820,1529463625,609,0),(130825,1529436788,609,0),(130827,1529462842,609,0),(130829,1529463496,609,0),(130830,1529463637,609,0),(130856,1529463723,609,0),(130919,1529463162,609,0),(130921,1529461988,609,0),(130922,1529463485,609,0),(130924,1529463545,609,0),(130925,1529462637,609,0),(130927,1529462117,609,0),(130929,1529435681,609,0),(130930,1529458162,609,0),(130931,1529462860,609,0),(130932,1529456072,609,0),(130933,1529462721,609,0),(130934,1529463407,609,0),(130935,1529435794,609,0),(130938,1529463509,609,0),(130942,1529463530,609,0),(130943,1529463001,609,0),(130944,1529458302,609,0),(130945,1529463502,609,0),(130946,1529461853,609,0),(130949,1529463497,609,0),(130950,1529436545,609,0),(130952,1529436665,609,0),(130953,1529463605,609,0),(130955,1529462019,609,0),(145370,1523394309,530,0),(146133,1533828675,0,0),(146134,1533828949,0,0),(213928,1529409098,1,0);
/*!40000 ALTER TABLE `creature_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_condition_save`
--

DROP TABLE IF EXISTS `game_event_condition_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event_condition_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `condition_id` int(10) unsigned NOT NULL DEFAULT '0',
  `done` float DEFAULT '0',
  PRIMARY KEY (`eventEntry`,`condition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_condition_save`
--

LOCK TABLES `game_event_condition_save` WRITE;
/*!40000 ALTER TABLE `game_event_condition_save` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_event_condition_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_save`
--

DROP TABLE IF EXISTS `game_event_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event_save` (
  `eventEntry` tinyint(3) unsigned NOT NULL,
  `state` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `next_start` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventEntry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_save`
--

LOCK TABLES `game_event_save` WRITE;
/*!40000 ALTER TABLE `game_event_save` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_event_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gameobject_respawn`
--

DROP TABLE IF EXISTS `gameobject_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawnTime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(10) unsigned NOT NULL DEFAULT '0',
  `instanceId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Instance Identifier',
  PRIMARY KEY (`guid`,`instanceId`),
  KEY `idx_instance` (`instanceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gameobject_respawn`
--

LOCK TABLES `gameobject_respawn` WRITE;
/*!40000 ALTER TABLE `gameobject_respawn` DISABLE KEYS */;
INSERT INTO `gameobject_respawn` VALUES (79,1529314451,530,0),(963,1529278169,530,0),(14246,1529278606,530,0),(15216,1530731320,0,0),(15398,1530732069,0,0),(16598,1530731729,0,0),(16933,1530714070,0,0),(18547,1529835247,0,0),(21117,1531475419,530,0),(21118,1531475499,530,0),(21119,1531475279,530,0),(21133,1523389758,530,0),(21136,1523389722,530,0),(21137,1523389695,530,0),(21138,1523389622,530,0),(21139,1523389540,530,0),(21141,1523389481,530,0),(21169,1523394764,530,0),(21170,1523394754,530,0),(21171,1523394756,530,0),(21176,1523395855,530,0),(21186,1523395965,530,0),(21187,1523395815,530,0),(21188,1523395952,530,0),(21189,1523395944,530,0),(21264,1529746926,0,0),(21283,1523393537,530,0),(21289,1523393013,530,0),(21290,1523393574,530,0),(21291,1523393582,530,0),(21292,1523393509,530,0),(21293,1523390701,530,0),(21618,1529245837,530,0),(22038,1529247784,530,0),(22039,1529247581,530,0),(22040,1529247701,530,0),(22041,1529247627,530,0),(22044,1529247802,530,0),(22045,1529247808,530,0),(22046,1529247842,530,0),(22049,1529247801,530,0),(22096,1529249159,530,0),(22104,1529249241,530,0),(22106,1529249222,530,0),(22151,1529252116,530,0),(22152,1529252156,530,0),(22157,1529251617,530,0),(22159,1529251918,530,0),(22160,1529251924,530,0),(22161,1529252031,530,0),(22179,1529251980,530,0),(22188,1529253000,530,0),(22189,1529252323,530,0),(22192,1529252311,530,0),(22195,1529252528,530,0),(22196,1529252554,530,0),(22198,1529252566,530,0),(22215,1529252454,530,0),(22216,1529252471,530,0),(22544,1529244138,530,0),(22545,1529244176,530,0),(22546,1529244242,530,0),(26242,1529823481,0,0),(27082,1529823813,0,0),(27337,1523474448,530,0),(27355,1523471667,530,0),(27431,1523468614,530,0),(27437,1523468609,530,0),(27464,1523463445,530,0),(29225,1529245366,530,0),(29226,1529245265,530,0),(29227,1529245258,530,0),(29277,1529304727,530,0),(30170,1531785309,1,0),(30466,1529249294,530,0),(30470,1529249308,530,0),(30483,1529251948,530,0),(30484,1529251906,530,0),(30485,1529251983,530,0),(30511,1529254127,530,0),(32286,1529257855,530,0),(32317,1529257792,530,0),(32598,1532040821,1,0),(32603,1532040906,1,0),(32651,1532040847,1,0),(33894,1523395909,530,0),(33932,1523398304,530,0),(34007,1523468518,530,0),(34010,1523468730,530,0),(42127,1529332726,530,0),(42128,1529333057,530,0),(42129,1529332958,530,0),(42130,1529332630,530,0),(42131,1529332575,530,0),(42135,1529333200,530,0),(42136,1529332858,530,0),(42137,1529333061,530,0),(44628,1529257835,530,0),(44629,1529257740,530,0),(44630,1529257437,530,0),(44631,1529257444,530,0),(44634,1529257304,530,0),(44638,1529257636,530,0),(44639,1529257681,530,0),(44724,1529312902,530,0),(45934,1525296313,0,0),(47368,1529746825,0,0),(47818,1529415881,1,0),(47877,1529342864,1,0),(47882,1529347376,1,0),(47886,1529347383,1,0),(47887,1529347317,1,0),(47888,1529347351,1,0),(47891,1529347380,1,0),(48510,1529488622,1,0),(48652,1529335364,1,0),(48653,1529335696,1,0),(48672,1529339457,1,0),(48673,1529339463,1,0),(48674,1529339324,1,0),(48678,1529339358,1,0),(48680,1529339408,1,0),(48687,1529339502,1,0),(48695,1529346693,1,0),(49544,1529233095,1,0),(49555,1529233060,1,0),(49558,1529233077,1,0),(49560,1529233009,1,0),(49564,1529232951,1,0),(49568,1529233049,1,0),(49570,1529232905,1,0),(49578,1529232857,1,0),(49586,1529232883,1,0),(49587,1529232873,1,0),(49588,1529232865,1,0),(49589,1529233318,1,0),(65949,1529436094,609,0),(65960,1529436082,609,0),(85853,1531784989,1,0);
/*!40000 ALTER TABLE `gameobject_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_subsurvey`
--

DROP TABLE IF EXISTS `gm_subsurvey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_subsurvey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `questionId` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` int(10) unsigned NOT NULL DEFAULT '0',
  `answerComment` text NOT NULL,
  PRIMARY KEY (`surveyId`,`questionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_subsurvey`
--

LOCK TABLES `gm_subsurvey` WRITE;
/*!40000 ALTER TABLE `gm_subsurvey` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_subsurvey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_survey`
--

DROP TABLE IF EXISTS `gm_survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_survey` (
  `surveyId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `mainSurvey` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` longtext NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`surveyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_survey`
--

LOCK TABLES `gm_survey` WRITE;
/*!40000 ALTER TABLE `gm_survey` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gm_ticket`
--

DROP TABLE IF EXISTS `gm_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gm_ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 open, 1 closed, 2 character deleted',
  `playerGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier of ticket creator',
  `name` varchar(12) NOT NULL COMMENT 'Name of ticket creator',
  `description` text NOT NULL,
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `lastModifiedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `closedBy` int(10) NOT NULL DEFAULT '0',
  `assignedTo` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'GUID of admin to whom ticket is assigned',
  `comment` text NOT NULL,
  `response` text NOT NULL,
  `completed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `escalated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `needMoreHelp` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resolvedBy` int(10) NOT NULL DEFAULT '0' COMMENT 'GUID of GM who resolved the ticket',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gm_ticket`
--

LOCK TABLES `gm_ticket` WRITE;
/*!40000 ALTER TABLE `gm_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `gm_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_instance`
--

DROP TABLE IF EXISTS `group_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `instance` int(10) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_instance`
--

LOCK TABLES `group_instance` WRITE;
/*!40000 ALTER TABLE `group_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_member`
--

DROP TABLE IF EXISTS `group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_member` (
  `guid` int(10) unsigned NOT NULL,
  `memberGuid` int(10) unsigned NOT NULL,
  `memberFlags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `subgroup` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `roles` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`memberGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_member`
--

LOCK TABLES `group_member` WRITE;
/*!40000 ALTER TABLE `group_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `guid` int(10) unsigned NOT NULL,
  `leaderGuid` int(10) unsigned NOT NULL,
  `lootMethod` tinyint(3) unsigned NOT NULL,
  `looterGuid` int(10) unsigned NOT NULL,
  `lootThreshold` tinyint(3) unsigned NOT NULL,
  `icon1` bigint(20) unsigned NOT NULL,
  `icon2` bigint(20) unsigned NOT NULL,
  `icon3` bigint(20) unsigned NOT NULL,
  `icon4` bigint(20) unsigned NOT NULL,
  `icon5` bigint(20) unsigned NOT NULL,
  `icon6` bigint(20) unsigned NOT NULL,
  `icon7` bigint(20) unsigned NOT NULL,
  `icon8` bigint(20) unsigned NOT NULL,
  `groupType` tinyint(3) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `raidDifficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `masterLooterGuid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`guid`),
  KEY `leaderGuid` (`leaderGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild`
--

DROP TABLE IF EXISTS `guild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(24) NOT NULL DEFAULT '',
  `leaderguid` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `EmblemColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderStyle` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BorderColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BackgroundColor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL DEFAULT '',
  `motd` varchar(128) NOT NULL DEFAULT '',
  `createdate` int(10) unsigned NOT NULL DEFAULT '0',
  `BankMoney` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild`
--

LOCK TABLES `guild` WRITE;
/*!40000 ALTER TABLE `guild` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_eventlog`
--

DROP TABLE IF EXISTS `guild_bank_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Event type',
  `PlayerGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemOrMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `ItemStackCount` smallint(5) unsigned NOT NULL DEFAULT '0',
  `DestTabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Destination Tab Id',
  `TimeStamp` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`,`TabId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_eventlog`
--

LOCK TABLES `guild_bank_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_bank_eventlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_item`
--

DROP TABLE IF EXISTS `guild_bank_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_item` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`SlotId`),
  KEY `guildid_key` (`guildid`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_item`
--

LOCK TABLES `guild_bank_item` WRITE;
/*!40000 ALTER TABLE `guild_bank_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_right`
--

DROP TABLE IF EXISTS `guild_bank_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_right` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gbright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`rid`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_right`
--

LOCK TABLES `guild_bank_right` WRITE;
/*!40000 ALTER TABLE `guild_bank_right` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_tab`
--

DROP TABLE IF EXISTS `guild_bank_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `TabName` varchar(16) NOT NULL DEFAULT '',
  `TabIcon` varchar(100) NOT NULL DEFAULT '',
  `TabText` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`guildid`,`TabId`),
  KEY `guildid_key` (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_tab`
--

LOCK TABLES `guild_bank_tab` WRITE;
/*!40000 ALTER TABLE `guild_bank_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_eventlog`
--

DROP TABLE IF EXISTS `guild_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_eventlog` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(10) unsigned NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(3) unsigned NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(10) unsigned NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(10) unsigned NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(3) unsigned NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` int(10) unsigned NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_eventlog`
--

LOCK TABLES `guild_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_eventlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member`
--

DROP TABLE IF EXISTS `guild_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member` (
  `guildid` int(10) unsigned NOT NULL COMMENT 'Guild Identificator',
  `guid` int(10) unsigned NOT NULL,
  `rank` tinyint(3) unsigned NOT NULL,
  `pnote` varchar(31) NOT NULL DEFAULT '',
  `offnote` varchar(31) NOT NULL DEFAULT '',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_key` (`guildid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member`
--

LOCK TABLES `guild_member` WRITE;
/*!40000 ALTER TABLE `guild_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member_withdraw`
--

DROP TABLE IF EXISTS `guild_member_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member_withdraw` (
  `guid` int(10) unsigned NOT NULL,
  `tab0` int(10) unsigned NOT NULL DEFAULT '0',
  `tab1` int(10) unsigned NOT NULL DEFAULT '0',
  `tab2` int(10) unsigned NOT NULL DEFAULT '0',
  `tab3` int(10) unsigned NOT NULL DEFAULT '0',
  `tab4` int(10) unsigned NOT NULL DEFAULT '0',
  `tab5` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Member Daily Withdraws';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member_withdraw`
--

LOCK TABLES `guild_member_withdraw` WRITE;
/*!40000 ALTER TABLE `guild_member_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_member_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_rank`
--

DROP TABLE IF EXISTS `guild_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_rank` (
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` tinyint(3) unsigned NOT NULL,
  `rname` varchar(20) NOT NULL DEFAULT '',
  `rights` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `BankMoneyPerDay` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_rank`
--

LOCK TABLES `guild_rank` WRITE;
/*!40000 ALTER TABLE `guild_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance`
--

DROP TABLE IF EXISTS `instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  `map` smallint(5) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `completedEncounters` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance`
--

LOCK TABLES `instance` WRITE;
/*!40000 ALTER TABLE `instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_reset`
--

DROP TABLE IF EXISTS `instance_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_reset` (
  `mapid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mapid`,`difficulty`),
  KEY `difficulty` (`difficulty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_reset`
--

LOCK TABLES `instance_reset` WRITE;
/*!40000 ALTER TABLE `instance_reset` DISABLE KEYS */;
INSERT INTO `instance_reset` VALUES (249,0,1544500800),(249,1,1544500800),(269,1,1544241600),(309,0,1544328000),(409,0,1544500800),(469,0,1544500800),(600,1,1544241600),(601,1,1544241600),(602,1,1544241600),(603,0,1544500800),(603,1,1544500800),(604,1,1544241600),(608,1,1544241600),(616,0,1544500800),(616,1,1544500800),(619,1,1544241600),(624,0,1544500800),(624,1,1544500800),(631,0,1544500800),(631,1,1544500800),(631,2,1544500800),(631,3,1544500800),(632,1,1544241600),(649,0,1544500800),(649,1,1544500800),(649,2,1544500800),(649,3,1544500800),(668,1,1544241600),(724,0,1544500800),(724,1,1544500800),(724,2,1544500800),(724,3,1544500800),(22509,0,1544241600),(22531,0,1544328000),(22532,0,1544328000),(22533,0,1544328000),(22533,1,1544328000),(22534,0,1544328000),(22540,1,1544241600),(22542,1,1544241600),(22543,1,1544241600),(22544,0,1544328000),(22546,1,1544241600),(22547,1,1544241600),(22548,0,1544328000),(22560,1,1544241600),(22564,0,1544328000),(22568,0,1544241600),(22574,1,1544241600),(22576,1,1544241600),(22578,1,1544241600),(22580,0,1544328000),(22598,1,1544241600),(22599,1,1544241600),(24026,0,1544328000),(24028,1,1544241600),(24029,1,1544241600),(24030,1,1544241600),(24032,1,1544241600),(24033,1,1544241600),(24034,1,1544241600),(26001,1,1544241600),(28001,0,1544328000),(29001,1,1544241600),(30001,1,1544241600),(31001,1,1544241600),(43529,1,1544241600),(61225,0,1544328000),(61225,1,1544328000),(62250,1,1544241600),(62258,1,1544241600);
/*!40000 ALTER TABLE `instance_reset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_instance`
--

DROP TABLE IF EXISTS `item_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_instance` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `itemEntry` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `creatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `giftCreatorGuid` int(10) unsigned NOT NULL DEFAULT '0',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `duration` int(10) NOT NULL DEFAULT '0',
  `charges` tinytext,
  `flags` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `enchantments` text NOT NULL,
  `randomPropertyId` smallint(5) NOT NULL DEFAULT '0',
  `durability` smallint(5) unsigned NOT NULL DEFAULT '0',
  `playedTime` int(10) unsigned NOT NULL DEFAULT '0',
  `text` text,
  PRIMARY KEY (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_instance`
--

LOCK TABLES `item_instance` WRITE;
/*!40000 ALTER TABLE `item_instance` DISABLE KEYS */;
INSERT INTO `item_instance` VALUES (18,20901,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(26,6948,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(33,51809,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(34,51809,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(35,51809,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(36,51809,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(201,7005,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(214,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(242,774,2,0,0,4,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(268,2070,2,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(284,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(288,40752,2,0,0,2815,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(289,42944,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7195,''),(290,42946,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7192,''),(291,42952,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7179,''),(292,48689,2,0,0,1,0,'0 0 0 0 0 ',1,'15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7173,''),(297,6517,2,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(306,23500,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(308,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(318,159,2,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(348,4605,2,0,0,9,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(352,22641,2,0,0,5,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,38,''),(355,818,2,0,0,3,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(356,1179,2,0,0,11,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(358,29282,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(360,51991,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2803 0 0 2824 0 0 2816 0 0 0 0 0 0 0 0 ',-93,0,0,''),(362,44347,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(363,29327,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(364,22004,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(366,18424,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,50,0,''),(367,28182,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,59,0,''),(372,858,2,0,0,8,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(398,2318,2,2,0,11,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(548,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(589,2934,2,0,0,6,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(631,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(646,2589,2,0,0,15,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(650,23444,2,0,0,4,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(656,2455,2,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(668,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(696,2592,2,0,0,19,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(721,422,2,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(724,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(732,2515,2,0,0,553,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(737,2515,2,0,0,1000,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(742,2515,2,0,0,1000,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(783,6948,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(795,49,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(797,47,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(799,48,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(801,28979,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(803,2092,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(805,50055,7,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(807,6948,7,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(912,23400,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(927,21803,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,52,0,''),(928,100041,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,46,0,''),(929,12422,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,76,0,''),(930,12424,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,26,0,''),(931,13498,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,75,0,''),(932,12426,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,37,0,''),(933,100048,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(934,52252,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(939,200001,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,60,0,''),(940,12422,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,87,0,''),(941,12424,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(942,13498,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(943,12426,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,42,0,''),(944,15285,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,49,0,''),(946,38,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(948,39,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,0,''),(950,40,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(952,12282,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,23,0,''),(954,6948,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(955,100020,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(956,100023,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(957,100024,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(958,100025,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(959,100026,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(961,100029,8,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2802 0 0 2805 0 0 0 0 0 0 0 0 0 0 0 ',-14,0,0,''),(964,38,9,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(966,39,9,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(968,40,9,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(970,12282,9,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(972,6948,9,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(973,100028,9,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,30,0,''),(974,100028,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,12,0,''),(975,100027,8,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(977,49,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(979,47,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(981,48,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(983,28979,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(985,2092,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(987,50055,10,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(989,6948,10,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(990,100051,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,34,0,''),(991,100053,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,53,0,''),(992,100054,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(994,100055,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,42,0,''),(995,100056,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,27,0,''),(996,100057,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(997,100058,5,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,19,0,''),(999,25825,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,59,0,''),(1000,12382,5,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1010,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1031,2589,2,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1054,22642,2,0,0,8,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1081,22893,2,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1208,6948,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1426,42952,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7125,''),(1428,48689,12,0,0,1,0,'0 0 0 0 0 ',1,'15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7159,''),(1429,42946,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7194,''),(1430,44347,12,0,0,1,0,'0 0 0 0 0 ',1,'15 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(1540,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1541,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1542,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1543,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1554,7005,12,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1715,23984,12,0,0,54,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(1913,2319,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,2431,''),(1954,23989,12,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(2308,4231,12,12,0,4,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(2377,818,12,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(2383,5996,12,0,0,7,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(2442,1705,12,0,0,3,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(2517,42944,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,6865,''),(2518,42944,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,6589,''),(3294,4233,12,0,0,15,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3295,4233,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3400,2318,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3402,2592,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3405,2589,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3444,2319,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3448,5505,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3517,783,12,0,0,5,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3537,2592,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3569,2589,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3587,1970,12,0,0,1,0,'-1 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3656,34652,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,69,0,''),(3658,34655,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,70,0,''),(3660,34659,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3662,34650,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,115,0,''),(3664,34653,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(3666,34649,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(3668,34651,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,40,0,''),(3670,34656,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,85,0,''),(3672,34648,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,55,0,''),(3674,34657,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3676,34658,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3678,38145,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3680,38145,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3682,38145,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3684,38145,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3686,38147,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3688,41751,14,0,0,10,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3691,38707,14,0,0,1,0,'0 0 0 0 0 ',1,'3369 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(3693,38662,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3694,38671,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3696,38664,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3697,40483,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3698,39208,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3700,38674,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3701,38666,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(3703,38669,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(3706,38672,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3707,38670,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,64,0,''),(3709,38667,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,45,0,''),(3711,38665,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,135,0,''),(3712,38675,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3719,38663,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,80,0,''),(3721,38661,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,80,0,''),(3722,38633,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,100,0,''),(3724,41426,14,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3729,3301,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3730,3402,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3731,2318,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3732,5635,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3740,6553,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 76 0 0 73 0 0 0 0 0 ',590,50,0,''),(3741,4232,12,0,0,4,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3762,2318,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3777,6341,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,66146,''),(3780,935,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,65,0,''),(3788,2319,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,5624,''),(3797,1210,12,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3813,6321,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,66469,''),(3816,2318,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3878,3230,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,14,67229,''),(3886,44096,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7197,''),(3887,44096,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,1750,''),(3888,42945,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,7125,''),(3892,2319,12,0,0,18,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3935,1206,12,0,0,3,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3942,2589,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3943,2592,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(3955,2318,12,0,0,19,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4014,6530,12,0,0,19,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4113,2154,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4127,2589,12,0,0,8,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4128,2592,12,0,0,20,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4171,4234,12,0,0,10,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4194,1710,12,0,0,14,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4235,2043,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4276,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4277,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4278,51809,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4320,2592,12,0,0,12,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4362,3248,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4718,14579,12,0,0,1,0,'0 0 0 0 0 ',1,'18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(4729,42917,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4730,42916,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4731,42915,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4732,42914,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4733,42913,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4734,42912,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4735,42911,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4736,42910,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4738,42908,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4739,42907,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4740,42902,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4741,42901,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4743,42899,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4744,42898,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4745,42897,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4772,4306,14,0,0,10,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4773,1757,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(4850,4052,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,13,0,''),(4858,3928,12,0,0,5,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5102,3030,12,0,0,1000,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5144,3728,12,0,0,10,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5145,3754,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,8,0,''),(5172,3385,12,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5174,3927,12,0,0,3,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5204,1645,12,0,0,8,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5233,3927,12,0,0,20,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5430,14530,12,0,0,20,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5450,14530,12,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5470,45580,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5542,6365,12,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5587,20982,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(5589,20897,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5591,20896,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5595,50057,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,15,0,''),(5597,28979,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5599,6948,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5600,21010,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(5609,20998,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,14,0,''),(5610,20474,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5624,20993,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(5628,20996,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,16,0,''),(5629,20842,15,0,0,10,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5631,20843,15,0,0,4,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5640,20842,15,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5642,20836,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,20,0,''),(5643,2589,2,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5644,20847,15,0,0,10,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5645,20848,15,0,0,10,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5654,20847,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5659,20848,15,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5660,20812,15,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5661,20813,15,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5662,20845,15,0,0,4,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5663,20846,15,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5664,20841,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(5667,20804,15,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5707,12019,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 105 0 0 0 0 0 0 0 0 ',154,0,0,''),(5834,6829,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,44,0,''),(5836,3661,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5838,6123,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,35,0,''),(5840,6124,16,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5842,6948,16,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5865,38,17,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5867,39,17,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5869,40,17,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5871,49778,17,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,25,0,''),(5873,6948,17,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5901,6788,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,21,0,''),(5905,3030,12,0,0,650,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5911,2512,12,0,0,1000,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5919,13108,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5925,15543,14,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 94 0 0 106 0 0 0 0 0 ',933,85,0,''),(5936,7973,14,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5943,4338,12,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5944,4306,12,0,0,9,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5946,9260,12,0,0,2,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5951,3858,12,0,0,2,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5952,4087,12,0,0,1,0,'0 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 84 0 0 102 0 0 0 0 0 ',1017,65,0,''),(5953,4599,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5954,1707,12,0,0,1,0,'-1 0 0 0 0 ',0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,''),(5956,2252,12,0,0,1,0,'0 0 0 0 0 ',1,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,'');
/*!40000 ALTER TABLE `item_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_loot_items`
--

DROP TABLE IF EXISTS `item_loot_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_loot_items` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `item_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'loot item entry (item_instance.itemEntry)',
  `item_count` int(10) NOT NULL DEFAULT '0' COMMENT 'stack size',
  `follow_rules` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'follow loot rules',
  `ffa` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'free-for-all',
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `counted` tinyint(1) NOT NULL DEFAULT '0',
  `under_threshold` tinyint(1) NOT NULL DEFAULT '0',
  `needs_quest` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'quest drop',
  `rnd_prop` int(10) NOT NULL DEFAULT '0' COMMENT 'random enchantment added when originally rolled',
  `rnd_suffix` int(10) NOT NULL DEFAULT '0' COMMENT 'random suffix added when originally rolled'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_loot_items`
--

LOCK TABLES `item_loot_items` WRITE;
/*!40000 ALTER TABLE `item_loot_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_loot_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_loot_money`
--

DROP TABLE IF EXISTS `item_loot_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_loot_money` (
  `container_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'guid of container (item_instance.guid)',
  `money` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'money loot (in copper)',
  PRIMARY KEY (`container_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_loot_money`
--

LOCK TABLES `item_loot_money` WRITE;
/*!40000 ALTER TABLE `item_loot_money` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_loot_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_refund_instance`
--

DROP TABLE IF EXISTS `item_refund_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_refund_instance` (
  `item_guid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `player_guid` int(10) unsigned NOT NULL COMMENT 'Player GUID',
  `paidMoney` int(10) unsigned NOT NULL DEFAULT '0',
  `paidExtendedCost` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`,`player_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_refund_instance`
--

LOCK TABLES `item_refund_instance` WRITE;
/*!40000 ALTER TABLE `item_refund_instance` DISABLE KEYS */;
INSERT INTO `item_refund_instance` VALUES (289,2,0,2524),(290,2,0,2551),(291,2,0,2524),(292,2,0,2524);
/*!40000 ALTER TABLE `item_refund_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_soulbound_trade_data`
--

DROP TABLE IF EXISTS `item_soulbound_trade_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_soulbound_trade_data` (
  `itemGuid` int(10) unsigned NOT NULL COMMENT 'Item GUID',
  `allowedPlayers` text NOT NULL COMMENT 'Space separated GUID list of players who can receive this item in trade',
  PRIMARY KEY (`itemGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Item Refund System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_soulbound_trade_data`
--

LOCK TABLES `item_soulbound_trade_data` WRITE;
/*!40000 ALTER TABLE `item_soulbound_trade_data` DISABLE KEYS */;
INSERT INTO `item_soulbound_trade_data` VALUES (3745,'12 14'),(3802,'12 14'),(3836,'12 14'),(3850,'12 14'),(3948,'12 14');
/*!40000 ALTER TABLE `item_soulbound_trade_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lag_reports`
--

DROP TABLE IF EXISTS `lag_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lag_reports` (
  `reportId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `lagType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mapId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `latency` int(10) unsigned NOT NULL DEFAULT '0',
  `createTime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`reportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lag_reports`
--

LOCK TABLES `lag_reports` WRITE;
/*!40000 ALTER TABLE `lag_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `lag_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lfg_data`
--

DROP TABLE IF EXISTS `lfg_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lfg_data` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `dungeon` int(10) unsigned NOT NULL DEFAULT '0',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='LFG Data';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lfg_data`
--

LOCK TABLES `lfg_data` WRITE;
/*!40000 ALTER TABLE `lfg_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `lfg_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stationery` tinyint(3) NOT NULL DEFAULT '41',
  `mailTemplateId` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sender` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `body` longtext,
  `has_items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expire_time` int(10) unsigned NOT NULL DEFAULT '0',
  `deliver_time` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `cod` int(10) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Mail System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_items`
--

DROP TABLE IF EXISTS `mail_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_items` (
  `mail_id` int(10) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `receiver` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY (`item_guid`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_mail_id` (`mail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_items`
--

LOCK TABLES `mail_items` WRITE;
/*!40000 ALTER TABLE `mail_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `mail_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_aura`
--

DROP TABLE IF EXISTS `pet_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_aura` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `casterGuid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `effectMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `recalculateMask` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stackCount` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `amount0` mediumint(8) NOT NULL,
  `amount1` mediumint(8) NOT NULL,
  `amount2` mediumint(8) NOT NULL,
  `base_amount0` mediumint(8) NOT NULL,
  `base_amount1` mediumint(8) NOT NULL,
  `base_amount2` mediumint(8) NOT NULL,
  `maxDuration` int(11) NOT NULL DEFAULT '0',
  `remainTime` int(11) NOT NULL DEFAULT '0',
  `remainCharges` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `critChance` float NOT NULL DEFAULT '0',
  `applyResilience` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`casterGuid`,`spell`,`effectMask`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_aura`
--

LOCK TABLES `pet_aura` WRITE;
/*!40000 ALTER TABLE `pet_aura` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell`
--

DROP TABLE IF EXISTS `pet_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell`
--

LOCK TABLES `pet_spell` WRITE;
/*!40000 ALTER TABLE `pet_spell` DISABLE KEYS */;
INSERT INTO `pet_spell` VALUES (2,14916,129),(2,17256,129),(2,35323,129),(4,2649,129),(4,16828,129),(4,50285,129),(6,14916,129),(6,16829,129),(6,24450,129),(6,59882,129),(8,14916,129),(8,16828,129),(8,50256,129),(10,1742,129),(10,14919,129),(10,16832,129),(10,24452,129),(10,59883,129),(12,1742,129),(12,14918,129),(12,17257,129),(12,26064,129);
/*!40000 ALTER TABLE `pet_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell_cooldown`
--

DROP TABLE IF EXISTS `pet_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `categoryId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell category Id',
  `categoryEnd` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell_cooldown`
--

LOCK TABLES `pet_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `pet_spell_cooldown` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition`
--

DROP TABLE IF EXISTS `petition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned DEFAULT '0',
  `name` varchar(24) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition`
--

LOCK TABLES `petition` WRITE;
/*!40000 ALTER TABLE `petition` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition_sign`
--

DROP TABLE IF EXISTS `petition_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned NOT NULL DEFAULT '0',
  `playerguid` int(10) unsigned NOT NULL DEFAULT '0',
  `player_account` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition_sign`
--

LOCK TABLES `petition_sign` WRITE;
/*!40000 ALTER TABLE `petition_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pool_quest_save`
--

DROP TABLE IF EXISTS `pool_quest_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pool_quest_save` (
  `pool_id` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pool_id`,`quest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pool_quest_save`
--

LOCK TABLES `pool_quest_save` WRITE;
/*!40000 ALTER TABLE `pool_quest_save` DISABLE KEYS */;
INSERT INTO `pool_quest_save` VALUES (348,24635),(349,14105),(350,13889),(351,13917),(352,11379),(353,11668),(354,13424),(356,11378),(357,11371),(359,12735),(360,12761),(361,12758),(362,12703),(363,14077),(364,14090),(365,14143),(366,14145),(367,14107),(370,12587),(5662,13674),(5663,13764),(5664,13770),(5665,13774),(5666,13778),(5667,13783),(5668,13666),(5669,13600),(5670,13741),(5671,13746),(5672,13757),(5673,13753),(5674,13102),(5675,13114),(5676,13836),(5677,12960),(5678,24587),(5683,24873),(5686,24879),(5707,13195),(5708,236),(5709,13199),(5710,13191);
/*!40000 ALTER TABLE `pool_quest_save` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_battlegrounds`
--

DROP TABLE IF EXISTS `pvpstats_battlegrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_battlegrounds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `winner_faction` tinyint(4) NOT NULL,
  `bracket_id` tinyint(3) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_battlegrounds`
--

LOCK TABLES `pvpstats_battlegrounds` WRITE;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_players`
--

DROP TABLE IF EXISTS `pvpstats_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_players` (
  `battleground_id` bigint(20) unsigned NOT NULL,
  `character_guid` int(10) unsigned NOT NULL,
  `winner` bit(1) NOT NULL,
  `score_killing_blows` mediumint(8) unsigned NOT NULL,
  `score_deaths` mediumint(8) unsigned NOT NULL,
  `score_honorable_kills` mediumint(8) unsigned NOT NULL,
  `score_bonus_honor` mediumint(8) unsigned NOT NULL,
  `score_damage_done` mediumint(8) unsigned NOT NULL,
  `score_healing_done` mediumint(8) unsigned NOT NULL,
  `attr_1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_3` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_4` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_5` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`battleground_id`,`character_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_players`
--

LOCK TABLES `pvpstats_players` WRITE;
/*!40000 ALTER TABLE `pvpstats_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quest_tracker`
--

DROP TABLE IF EXISTS `quest_tracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quest_tracker` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `character_guid` int(10) unsigned NOT NULL DEFAULT '0',
  `quest_accept_time` datetime NOT NULL,
  `quest_complete_time` datetime DEFAULT NULL,
  `quest_abandon_time` datetime DEFAULT NULL,
  `completed_by_gm` tinyint(1) NOT NULL DEFAULT '0',
  `core_hash` varchar(120) NOT NULL DEFAULT '0',
  `core_revision` varchar(120) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quest_tracker`
--

LOCK TABLES `quest_tracker` WRITE;
/*!40000 ALTER TABLE `quest_tracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `quest_tracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserved_name`
--

DROP TABLE IF EXISTS `reserved_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserved_name` (
  `name` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Player Reserved Names';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserved_name`
--

LOCK TABLES `reserved_name` WRITE;
/*!40000 ALTER TABLE `reserved_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `reserved_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates`
--

DROP TABLE IF EXISTS `updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates` (
  `name` varchar(200) NOT NULL COMMENT 'filename with extension of the update.',
  `hash` char(40) DEFAULT '' COMMENT 'sha1 hash of the sql file.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if an update is released or archived.',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'timestamp when the query was applied.',
  `speed` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'time the query takes to apply in ms.',
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of all applied updates in this database.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates`
--

LOCK TABLES `updates` WRITE;
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
INSERT INTO `updates` VALUES ('2015_03_20_00_characters.sql','B761760804EA73BD297F296C5C1919687DF7191C','ARCHIVED','2015-03-21 21:44:15',0),('2015_03_20_01_characters.sql','894F08B70449A5481FFAF394EE5571D7FC4D8A3A','ARCHIVED','2015-03-21 21:44:15',0),('2015_03_20_02_characters.sql','97D7BE0CAADC79F3F11B9FD296B8C6CD40FE593B','ARCHIVED','2015-03-21 21:44:51',0),('2015_06_26_00_characters_335.sql','C2CC6E50AFA1ACCBEBF77CC519AAEB09F3BBAEBC','ARCHIVED','2015-07-13 23:49:22',0),('2015_09_28_00_characters_335.sql','F8682A431D50E54BDC4AC0E7DBED21AE8AAB6AD4','ARCHIVED','2015-09-28 21:00:00',0),('2015_08_26_00_characters_335.sql','C7D6A3A00FECA3EBFF1E71744CA40D3076582374','ARCHIVED','2015-08-26 21:00:00',0),('2015_10_06_00_characters.sql','16842FDD7E8547F2260D3312F53EFF8761EFAB35','ARCHIVED','2015-10-06 16:06:38',0),('2015_10_07_00_characters.sql','E15AB463CEBE321001D7BFDEA4B662FF618728FD','ARCHIVED','2015-10-07 23:32:00',0),('2015_10_12_00_characters.sql','D6F9927BDED72AD0A81D6EC2C6500CBC34A39FA2','ARCHIVED','2015-10-12 15:35:47',0),('2015_10_28_00_characters.sql','622A9CA8FCE690429EBE23BA071A37C7A007BF8B','ARCHIVED','2015-10-19 14:32:22',0),('2015_10_29_00_characters_335.sql','4555A7F35C107E54C13D74D20F141039ED42943E','ARCHIVED','2015-10-29 17:05:43',0),('2015_11_03_00_characters.sql','CC045717B8FDD9733351E52A5302560CD08AAD57','ARCHIVED','2015-10-12 15:23:33',0),('2015_11_07_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 00:42:36',94),('2016_02_10_00_characters.sql','F1B4DA202819CABC7319A4470A2D224A34609E97','ARCHIVED','2016-02-10 00:00:00',0),('2016_03_13_2016_01_05_00_characters.sql','0EAD24977F40DE2476B4567DA2B477867CC0DA1A','ARCHIVED','2016-03-13 20:03:56',0),('2016_04_11_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-04-11 03:18:17',0),('2016_09_13_00_characters.sql','27A04615B11B2CFC3A26778F52F74C071E4F9C54','ARCHIVED','2016-07-06 18:55:18',0),('2016_10_16_00_characters.sql','0ACDD35EC9745231BCFA701B78056DEF94D0CC53','ARCHIVED','2016-10-16 14:02:49',35),('2016_10_30_00_characters.sql','7E2D5B226907B5A9AF320797F46E86DC27B7EC90','ARCHIVED','2016-10-30 00:00:00',0),('2017_04_03_00_characters.sql','CB072C56692C9FBF170C4036F15773DD86D368B5','ARCHIVED','2017-04-03 00:00:00',0),('2017_04_12_00_characters.sql','4FE3C6866A6DCD4926D451F6009464D290C2EF1F','ARCHIVED','2017-04-12 00:00:00',0),('2017_04_12_01_characters.sql','5A8A1215E3A2356722F52CD7A64BBE03D21FBEA3','ARCHIVED','2017-04-12 00:00:00',0),('2017_04_19_00_characters.sql','CE06FA9005C8A8EE4BDD925520278A5D83E87485','ARCHIVED','2017-04-19 00:07:40',25),('2017_10_29_00_characters.sql','8CFC473E7E87E58C317A72016BF69E9050D3BC83','ARCHIVED','2017-04-19 00:07:40',25),('2017_11_27_00_characters.sql','6FF1F84B8985ADFC7FF97F0BF8E53403CF13C320','ARCHIVED','2017-11-27 22:08:42',0),('2018_01_13_00_characters.sql','E3C0DA9995BA71ED5A267294470CD03DC51862DD','ARCHIVED','2018-01-13 00:00:00',0),('2018_02_19_00_characters.sql','FE5C5F9B88F0791549DDE680942493781E2269E6','RELEASED','2018-02-18 19:49:38',0),('2018_04_24_00_characters.sql','77264AB7BEF421C0A4BB81EEAFD0D8C1CBCA840F','RELEASED','2018-04-29 15:18:59',68);
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `updates_include`
--

DROP TABLE IF EXISTS `updates_include`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `updates_include` (
  `path` varchar(200) NOT NULL COMMENT 'directory to include. $ means relative to the source directory.',
  `state` enum('RELEASED','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if the directory contains released or archived updates.',
  PRIMARY KEY (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='List of directories where we want to include sql updates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `updates_include`
--

LOCK TABLES `updates_include` WRITE;
/*!40000 ALTER TABLE `updates_include` DISABLE KEYS */;
INSERT INTO `updates_include` VALUES ('$/sql/updates/characters','RELEASED'),('$/sql/custom/characters','RELEASED'),('$/sql/old/3.3.5a/characters','ARCHIVED');
/*!40000 ALTER TABLE `updates_include` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warden_action`
--

DROP TABLE IF EXISTS `warden_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warden_action` (
  `wardenId` smallint(5) unsigned NOT NULL,
  `action` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`wardenId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warden_action`
--

LOCK TABLES `warden_action` WRITE;
/*!40000 ALTER TABLE `warden_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `warden_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worldstates`
--

DROP TABLE IF EXISTS `worldstates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worldstates` (
  `entry` int(10) unsigned NOT NULL DEFAULT '0',
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` tinytext,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Variable Saves';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worldstates`
--

LOCK TABLES `worldstates` WRITE;
/*!40000 ALTER TABLE `worldstates` DISABLE KEYS */;
INSERT INTO `worldstates` VALUES (1,0,NULL),(2,0,NULL),(3,0,NULL),(4,0,NULL),(5,0,NULL),(6,0,NULL),(7,0,NULL),(8,0,NULL),(9,0,NULL),(10,0,NULL),(11,0,NULL),(12,0,NULL),(13,0,NULL),(14,1544223601,NULL),(15,0,NULL),(16,1544234401,NULL),(17,0,NULL),(18,0,NULL),(19,0,NULL),(20,1544170381,NULL),(21,0,NULL),(22,0,NULL),(23,0,NULL),(24,0,NULL),(25,1544212801,NULL),(26,0,NULL),(27,1544170381,NULL),(28,0,NULL),(29,0,NULL),(30,0,NULL),(31,0,NULL),(32,0,NULL),(33,0,NULL),(34,0,NULL),(35,0,NULL),(36,1544170381,NULL),(37,0,NULL),(38,0,NULL),(39,0,NULL),(40,0,NULL),(41,0,NULL),(42,0,NULL),(43,0,NULL),(44,0,NULL),(45,0,NULL),(46,0,NULL),(47,0,NULL),(48,0,NULL),(49,0,NULL),(50,0,NULL),(51,0,NULL),(52,0,NULL),(53,0,NULL),(54,0,NULL),(55,0,NULL),(56,0,NULL),(57,0,NULL),(58,0,NULL),(59,0,NULL),(60,1544170381,NULL),(61,0,NULL),(62,0,NULL),(63,0,NULL),(64,0,NULL),(65,1544237701,NULL),(66,0,NULL),(67,0,NULL),(68,1544237701,NULL),(69,0,NULL),(70,0,NULL),(71,0,NULL),(72,0,NULL),(73,0,NULL),(74,0,NULL),(75,0,NULL),(76,0,NULL),(3781,9000000,NULL),(3801,0,NULL),(3802,1,NULL),(20001,1525015139,'NextArenaPointDistributionTime'),(20002,1544257628,'NextWeeklyQuestResetTime'),(20003,1544245200,'NextBGRandomDailyResetTime'),(20004,0,'cleaning_flags'),(20006,1544245200,NULL),(20007,1546297200,NULL);
/*!40000 ALTER TABLE `worldstates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08 16:56:25
